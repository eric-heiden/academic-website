You are working on a Newton physics simulation task.

Workspace: /home/horde/artifacts/newton-live-mcp-v4/loop/i10/abc_arm-opus-restart-p0
Newton source tree (read-only reference, including docs and examples): /home/horde/apps/newton-live-mcp

arm_replay.py models a real robot arm from the ABC-130k dataset (https://abc.bot): the 6-DoF YAM arm of a bimanual teleoperation station, whose joints track position commands streamed from a leader arm at about 30 Hz. logs/ holds 64 recorded arm logs (32 episodes, both arms; about 87 minutes per arm) with measured joint positions, velocities, and motor torques, the commanded joint positions, and the gripper opening. Each log is cut into 1 s windows; each window is one Newton world that starts from the measured state and is driven open loop by the logged commands through the arm's joint position targets (rollout/window_errors). Problem: the model uses the nominal gains, armature, and friction of the ABC simulation model, and its predicted joint angles drift from the recordings.

Goal: calibrate the arm model so it predicts the real arm. Verification imports build_model(num_worlds), make_solver(model), and PARAMS["command_delay"], and runs its own multiple-shooting evaluation (1 s windows every 0.5 s, 2 ms steps, the logged commands applied as joint position targets after the command delay) on 16 held-out logs of 8 other episodes. The mean joint-angle RMSE must be at most 0.023 rad. The starter scores about 0.038 rad.
Constraints (checked): keep one arm per world with the kinematics of yam_arm.xml (joint frames, axes, and types), gravity, nonnegative masses, and valid inertias; the command delay must be between 0 and 0.2 s. Controller gains, effort limits, armature, friction, damping, masses and inertias, gravity compensation, solver settings, and other Newton modeling features inside build_model/make_solver may change. Keep the file runnable (`python arm_replay.py --viewer null`).

Deliverable: the edited arm_replay.py in the workspace, then a brief report. You have 30 minutes, starting 00:42:23 UTC (check with `date -u`); working efficiently matters. Do not modify files outside the workspace, do not look for other trials or hidden verification data, and do not use subagents.

Workflow: this is a script-based setup. Run the simulation with
  uv run --no-sync --project /home/horde/apps/newton-live-mcp python arm_replay.py --viewer null --num-frames <N>
or write your own scripts that import the Example class; each run starts a fresh simulator process. There is no display; to look at the scene, render images yourself (for example with newton.sensors.SensorTiledCamera) and open them with your image-viewing tool.
