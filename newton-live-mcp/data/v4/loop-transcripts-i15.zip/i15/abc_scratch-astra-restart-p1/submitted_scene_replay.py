# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure), three passive fruit bodies,
and a static wooden tray in ``num_worlds`` identical worlds. ``Example`` drives
every world with the logged commands as joint position targets, open loop.
The fitted dimensions, inertias, materials, servo settings, and latency are stored
below; replay does not depend on the photos or calibration logs.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

# Constants fitted from the calibrated views and the recorded arm responses.
PARAMS = {
    "command_delay": 0.015,
    "dt": 0.002,
    "arm_kp": [51.15469, 43.91031, 75.55322, 9.92827, 5.20721, 2.71172],
    "arm_kd": [3.56988, 3.94027, 7.13585, 1.67609, 0.81509, 0.4341],
    "arm_armature": [0.032, 0.032, 0.032, 0.0018, 0.0018, 0.0018],
    "arm_friction": [0.08, 0.08, 0.08, 0.04, 0.04, 0.025],
    "gravcomp": [1, 1.0, 0.79765, 1.0, 0.99921, 0.21973],
    "gripper_kp": 600.0,
    "gripper_kd": 14.0,
    "gripper_force": 9.0,
}

FRUITS = [
    # name, position, inertia-envelope semi-axes, yaw, mass, RGB
    # The pear's collision envelope is a rounded bulb with a short neck.
    ("pear", (0.654, 0.333, 0.778), (0.0385, 0.028, 0.028), -0.65, 0.240, (0.90, 0.71, 0.025)),
    ("orange", (0.505, -0.052, 0.781), (0.030, 0.030, 0.031), 0.0, 0.090, (0.96, 0.23, 0.025)),
    ("dark_fruit", (0.643, -0.191, 0.784), (0.035, 0.035, 0.034), 0.0, 0.105, (0.12, 0.042, 0.023)),
]
TRAY_OUTLINE = np.array([
    [0.919, 0.137], [0.772, -0.030], [0.731, 0.004],
    [0.699, 0.046], [0.684, 0.104], [0.694, 0.179], [0.731, 0.189],
])


def _numbers(values):
    return " ".join(f"{float(x):.9g}" for x in values)


def _scene_xml():
    """Keep the supplied mechanism; fit only its servo and material parameters."""
    root = ET.parse(STATION).getroot()
    root.find("compiler").set("meshdir", str(STATION.parent / "assets/i2rt_yam/assets"))
    option = root.find("option")
    for key, value in {"cone": "elliptic", "iterations": "40", "ls_iterations": "30", "tolerance": "1e-5"}.items():
        option.set(key, value)
    # Distinct collision bits suppress contacts between immovable surfaces.
    # Dynamic robot and fruit geoms keep bit 1 and still contact every surface.
    robot_geoms = {g for side in SIDES for g in root.find(f".//body[@name='{side}_arm']").iter("geom")}
    for geom in root.find("worldbody").iter("geom"):
        if geom not in robot_geoms and not (geom.get("contype") == "0" and geom.get("conaffinity") == "0"):
            geom.set("contype", "2")
            geom.set("conaffinity", "1")
    # Existing servo actuator types and robot joint geometry are retained.
    for side in SIDES:
        for k in range(6):
            name = f"{side}_joint{k + 1}"
            joint = root.find(f".//worldbody//joint[@name='{name}']")
            joint.set("armature", str(PARAMS["arm_armature"][k]))
            joint.set("frictionloss", str(PARAMS["arm_friction"][k]))
            actuator = root.find(f"actuator/position[@name='{name}']")
            actuator.set("kp", str(PARAMS["arm_kp"][k]))
            actuator.set("kv", str(PARAMS["arm_kd"][k]))
            limit = 28 if k < 3 else 10
            actuator.set("forcerange", f"{-limit} {limit}")
            body = root.find(f".//body[@name='{side}_link_{k + 1}']")
            body.set("gravcomp", str(PARAMS["gravcomp"][k]))
        actuator = root.find(f"actuator/position[@name='{side}_gripper']")
        actuator.set("kp", str(PARAMS["gripper_kp"]))
        actuator.set("kv", str(PARAMS["gripper_kd"]))
        actuator.set("forcerange", _numbers([-PARAMS["gripper_force"], PARAMS["gripper_force"]]))
        for geom in root.find(f".//body[@name='{side}_arm']").iter("geom"):
            if geom.get("class") in ("collision", "sphere_collision") or geom.get("name", "").endswith("cam_col"):
                geom.set("friction", "1.0 0.003 0.0002")
                geom.set("solref", "0.008 1")
                geom.set("solimp", "0.95 0.99 0.001")
    # Static wooden tray: a convex decomposition of the floor and beveled rim.
    asset = root.find("asset")
    world = root.find("worldbody")
    tray = ET.SubElement(world, "body", name="wooden_tray")
    # A shallow dished wooden floor, faceted into convex triangular prisms.
    center = np.array([0.744, 0.090])
    ring = center + 0.5 * (TRAY_OUTLINE - center)
    def floor_z(p):
        return 0.756 + 0.9 * float(np.dot(p - center, p - center))
    triangles = []
    for i in range(len(ring)):
        j = (i + 1) % len(ring)
        triangles.extend([(center, ring[i], ring[j]),
                          (ring[i], TRAY_OUTLINE[i], TRAY_OUTLINE[j]),
                          (ring[i], TRAY_OUTLINE[j], ring[j])])
    for i, triangle in enumerate(triangles):
        verts = [[*p, 0.750] for p in triangle] + [[*p, floor_z(p)] for p in triangle]
        name = f"tray_floor_{i}"
        ET.SubElement(asset, "mesh", name=name, vertex=_numbers(np.ravel(verts)))
        ET.SubElement(tray, "geom", name=name, type="mesh", mesh=name, mass=str(0.45 / len(triangles)), contype="4", conaffinity="1",
                      friction="0.65 0.003 0.0002", rgba="0.61 0.36 0.16 1", condim="6", solref="0.008 1")
    for i, (a, b) in enumerate(zip(TRAY_OUTLINE, np.roll(TRAY_OUTLINE, -1, axis=0))):
        delta = b - a
        length = np.linalg.norm(delta)
        inward = np.array([delta[1], -delta[0]]) / length
        # The rounded wooden lip is approximated by an inward bevel, without a flat perch.
        verts = []
        outside = 0.018 if i == 0 else 0.003
        lip_z = 0.784 if i == 0 else 0.789
        for p in (a, b):
            verts.extend([[*(p - outside * inward), 0.750],
                          [*(p - outside * inward), lip_z],
                          [*(p + 0.020 * inward), 0.756]])
        name = f"tray_rim_{i}"
        ET.SubElement(asset, "mesh", name=name, vertex=_numbers(np.ravel(verts)))
        ET.SubElement(tray, "geom", name=name, type="mesh", mesh=name, mass="0.01", contype="4", conaffinity="1",
                      friction="0.65 0.003 0.0002", rgba="0.70 0.45 0.22 1", condim="6", solref="0.008 1")
    for name, pos, radii, yaw, mass, color in FRUITS:
        body = ET.SubElement(world, "body", name=name, pos=_numbers(pos), euler=f"0 0 {yaw}")
        ET.SubElement(body, "freejoint", name=f"{name}_free")
        rx, ry, rz = radii
        inertia = mass / 5 * np.array([ry*ry + rz*rz, rx*rx + rz*rz, rx*rx + ry*ry])
        ET.SubElement(body, "inertial", pos="0 0 0", mass=str(mass), diaginertia=_numbers(inertia))
        parts = [("surface", (0, 0, 0), radii)]
        if name == "pear":
            parts = [("bulb", (0, 0, 0), (0.030, 0.028, 0.028)),
                     ("neck", (0.027, 0, 0), (0.020, 0.016, 0.016))]
        for suffix, offset, axes in parts:
            ET.SubElement(body, "geom", name=f"{name}_{suffix}", type="ellipsoid", size=_numbers(axes),
                          pos=_numbers(offset), rgba=_numbers([*color, 1]),
                          friction=f"0.9 0.001 {dict(pear=0.0003, orange=0.0003, dark_fruit=0.0045)[name]}", condim="6",
                          solref="0.008 1", solimp="0.90 0.98 0.002", margin="0")
    # Source keyframes contain only the original 16 joint coordinates.
    root.remove(root.find("keyframe"))
    return ET.tostring(root, encoding="unicode")


def build_model(num_worlds: int = 1) -> newton.Model:
    """Build identical, independent copies with three passive free fruits."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(_scene_xml())
    station.shape_gap[:] = [0.002] * len(station.shape_gap)
    episode = load_episode()
    for j, label in enumerate(station.joint_label):
        name = label.rsplit("/", 1)[-1]
        for side in SIDES:
            if name.startswith(f"{side}_joint") and name[-1:].isdigit():
                k = int(name[-1]) - 1
                station.joint_q[station.joint_q_start[j]] = float(episode[f"{side}_q"][0, k])
            elif name in (f"{side}_left_finger", f"{side}_right_finger"):
                sign = 1 if name == f"{side}_left_finger" else -1
                station.joint_q[station.joint_q_start[j]] = sign * float(episode[f"{side}_grip"][0]) * GRIPPER_TRAVEL
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    return builder.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(
        model, use_mujoco_contacts=True, cone="elliptic", integrator="implicitfast",
        iterations=40, ls_iterations=30, tolerance=1.0e-5, njmax=1024, nconmax=256,
    )


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """MuJoCo generates the contacts, including curved fruit surfaces."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
