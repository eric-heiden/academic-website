# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 humanoid tracking a reference motion (starter for a controller).

The robot is the floating-base Unitree G1 with 29 actuated joints, standing on
the floor of its MJCF and simulated by SolverMuJoCo with 2 ms steps. A
controller runs at 100 Hz: every 10 ms it reads the robot's state and returns
one :class:`Command` for the next control period. Each joint actuator then
applies, at every 2 ms physics step,

    tau = clip(kp * (q - q_joint) + kd * (qd - qd_joint) + tau_ff, -limit, limit)

with the MJCF torque limit of its joint. The plant (``build_model``,
``make_solver``, :class:`Robot`) is fixed; the controller is the part to develop.

Reference motions are MuJoCo-qpos CSV clips at 30 fps: root position [m], root
quaternion (w, x, y, z), and the 29 joint angles [rad] in MJCF order. The robot
starts at rest at the clip's first frame with its feet 2 mm above the floor.

The :class:`Controller` is a sampling-based model predictive controller (MPPI on GPU-batched rollouts of the
robot model) around an inverse-dynamics feedforward of the reference; see its docstring.

Run: ``python g1_mpc.py --motion walk.csv --viewer null`` (the whole clip; ``--num-frames N``
runs N control periods) prints the tracking report.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
import warp as wp

import newton
import newton.examples

SIM_DT = 0.002  # physics step [s]
CONTROL_DT = 0.01  # control period [s] (100 Hz)
SUBSTEPS = round(CONTROL_DT / SIM_DT)
JOINT_COUNT = 29

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)

# Accepted actuator gains: kp [N m/rad] and kd [N m s/rad] per joint.
KP_RANGE = (1.0, 10000.0)
KD_RANGE = (0.0, 500.0)

# The robot has fallen when the root drops below this height [m], its up axis tilts more than 45 degrees
# (cosine below 0.7), or anything but the feet touches the floor.
FALL_HEIGHT_M = 0.55
FALL_UP_COS = 0.7
FEET = ("left_ankle_roll_link", "right_ankle_roll_link")
WRISTS = ("left_wrist_yaw_link", "right_wrist_yaw_link")
# Foot contact spheres (centres in the ankle roll link frame [m]) and their radius [m].
SOLE_POINTS = np.array([[-0.05, -0.025, -0.03], [-0.05, 0.025, -0.03], [0.12, -0.03, -0.03], [0.12, 0.03, -0.03]])
SOLE_RADIUS = 0.005
SOLE_CENTER = np.array([0.035, 0.0, -0.035])
LIFT_REFERENCE_M = 0.03  # lift recall: reference sole clearance above this [m] ...
LIFT_ROBOT_M = 0.02  # ... counts when the robot's sole clearance is above this [m]
JITTER_HZ = 6.0  # jitter: joint-error RMS above this frequency [Hz]


def asset_path() -> str:
    return str(newton.utils.download_asset("unitree_g1") / "mjcf/g1_29dof_rev_1_0.xml")


def build_model(joint_q: np.ndarray | None = None) -> newton.Model:
    """The G1 on the MJCF floor with torque-limited joint actuators, optionally posed at ``joint_q``."""
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    builder.add_mjcf(asset_path(), collapse_fixed_joints=True)
    # Robot self-collision is excluded; the feet and body still collide with the floor.
    robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
    for i, shape in enumerate(robot_shapes):
        for other in robot_shapes[i + 1 :]:
            builder.add_shape_collision_filter_pair(shape, other)
    builder.joint_armature[6:] = ARMATURE.tolist()
    # MuJoCo position servos whose gains and targets Robot.apply sets from each Command.
    builder.joint_target_ke[6:] = [100.0] * JOINT_COUNT
    builder.joint_target_kd[6:] = [2.0] * JOINT_COUNT
    builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * JOINT_COUNT
    builder.custom_attributes["mujoco:ctrl_source"].values = [
        int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
    ] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcerange"].values = [
        (-limit, limit) for limit in builder.joint_effort_limit[6:]
    ]
    if joint_q is not None:
        builder.joint_q[:] = np.asarray(joint_q, dtype=float).tolist()
    return builder.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverMuJoCo:
    return newton.solvers.SolverMuJoCo(
        model, njmax=192, nconmax=64, use_mujoco_contacts=True, integrator="implicitfast", iterations=50
    )


def quat_wxyz_to_xyzw(q: np.ndarray) -> np.ndarray:
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def body_index(model: newton.Model, name: str) -> int:
    return [label.rsplit("/", 1)[-1] for label in model.body_label].index(name)


class MotionClip:
    """A reference clip, linearly interpolated in time (root quaternion by normalized lerp).

    With a model, the clip is shifted vertically so that the lowest foot contact point of its first frame
    is 2 mm above the floor (the robot starts there).
    """

    def __init__(self, path, model: newton.Model | None = None, fps: float = 30.0):
        self.qpos = np.loadtxt(path, delimiter=",", ndmin=2)
        if self.qpos.shape[1] != 7 + JOINT_COUNT or len(self.qpos) < 2:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps
        self.z_offset = 0.0
        if model is not None:
            self.z_offset = floor_offset(model, self.sample(0.0))

    def sample(self, t: float) -> np.ndarray:
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time ``t`` [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        q[2] += self.z_offset
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


def floor_offset(model: newton.Model, joint_q: np.ndarray) -> float:
    """Vertical shift [m] that puts the lowest foot contact point of ``joint_q`` 2 mm above the floor."""
    state = model.state()
    newton.eval_fk(model, wp.array(joint_q, dtype=float, device=model.device), model.joint_qd, state)
    body_q = state.body_q.numpy().astype(np.float64)
    lowest = np.inf
    for name in FEET:
        pose = body_q[body_index(model, name)]
        points = pose[:3] + SOLE_POINTS @ _rotation(pose[3:7]).T
        lowest = min(lowest, float(points[:, 2].min()) - SOLE_RADIUS)
    return float(0.002 - lowest)


@dataclass
class Command:
    """Actuator command for one control period: per-joint arrays of 29 values in MJCF joint order (scalars
    broadcast). Each actuator applies ``clip(kp (q - q_joint) + kd (qd - qd_joint) + tau, -limit, limit)``
    at every physics step of the period."""

    q: np.ndarray
    """Position targets [rad]."""
    kp: np.ndarray | float
    """Stiffness [N m/rad], within KP_RANGE."""
    kd: np.ndarray | float
    """Damping [N m s/rad], within KD_RANGE."""
    qd: np.ndarray | float = 0.0
    """Velocity targets [rad/s]."""
    tau: np.ndarray | float = 0.0
    """Feedforward torques [N m]."""


def command_arrays(command) -> dict[str, np.ndarray]:
    """The command's fields as float64 arrays of 29 values; raises ValueError for invalid commands."""
    out = {}
    for name in ("q", "kp", "kd", "qd", "tau"):
        value = getattr(command, name, 0.0)
        value = np.broadcast_to(np.asarray(0.0 if value is None else value, dtype=np.float64), (JOINT_COUNT,))
        if not np.all(np.isfinite(value)):
            raise ValueError(f"Command.{name} is not finite")
        out[name] = value.copy()
    for name, (low, high) in (("kp", KP_RANGE), ("kd", KD_RANGE)):
        if np.any(out[name] < low) or np.any(out[name] > high):
            raise ValueError(f"Command.{name} must be within [{low:g}, {high:g}]")
    return out


class Robot:
    """The simulated G1 (the plant): model, solver, state, and the actuator command interface."""

    def __init__(self, start_q: np.ndarray):
        self.model = build_model(start_q)
        self.solver = make_solver(self.model)
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.effort_limit = self.model.joint_effort_limit.numpy()[6:].copy()
        # MuJoCo actuator -> actuated joint (0..28), for writing servo gains without a full model update.
        self._actuator_joint = self.solver.mjc_actuator_to_newton_idx.numpy() - 6
        self._gains = None
        self._target = self.model.joint_q.numpy().copy()
        self.graph = None
        self.capture()

    def capture(self):
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def simulate(self):
        """One control period of physics steps."""
        for i in range(SUBSTEPS):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, SIM_DT)
            if SUBSTEPS % 2 == 1 and i == SUBSTEPS - 1:
                self.state_0.assign(self.state_1)
            else:
                self.state_0, self.state_1 = self.state_1, self.state_0

    def apply(self, command) -> None:
        """Set the actuators from a :class:`Command` (the servo target absorbs qd and tau, which is exact)."""
        c = command_arrays(command)
        gains = np.concatenate([c["kp"], c["kd"]])
        if self._gains is None or not np.array_equal(gains, self._gains):
            ke, kd = self.model.joint_target_ke.numpy(), self.model.joint_target_kd.numpy()
            ke[6:], kd[6:] = c["kp"], c["kd"]
            self.model.joint_target_ke.assign(ke)
            self.model.joint_target_kd.assign(kd)
            # Same effect as solver.notify_model_changed(JOINT_DOF_PROPERTIES) on the servos, which is much slower.
            gain, bias = self.solver.mjw_model.actuator_gainprm, self.solver.mjw_model.actuator_biasprm
            gain_np, bias_np = gain.numpy(), bias.numpy()
            gain_np[:, :, 0] = c["kp"][self._actuator_joint]
            bias_np[:, :, 1] = -c["kp"][self._actuator_joint]
            bias_np[:, :, 2] = -c["kd"][self._actuator_joint]
            gain.assign(gain_np)
            bias.assign(bias_np)
            self._gains = gains
        self._target[7:] = c["q"] + (c["kd"] * c["qd"] + c["tau"]) / c["kp"]
        self.control.joint_target_q.assign(self._target)

    def advance(self):
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()


def _quat_angle(a: np.ndarray, b: np.ndarray) -> float:
    """Angle [rad] between two unit quaternions (xyzw)."""
    return float(2.0 * np.arccos(np.clip(abs(np.dot(a, b)), 0.0, 1.0)))


def _rotation(quat_xyzw: np.ndarray) -> np.ndarray:
    x, y, z, w = quat_xyzw / np.linalg.norm(quat_xyzw)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def foot_points(body_q: np.ndarray, foot: int) -> tuple[np.ndarray, float]:
    """Sole centre [m] and sole clearance above the floor [m] of a foot body."""
    rotation = _rotation(body_q[foot, 3:7])
    clearance = float(np.min((body_q[foot, :3] + SOLE_POINTS @ rotation.T)[:, 2]) - SOLE_RADIUS)
    return body_q[foot, :3] + rotation @ SOLE_CENTER, clearance


def jitter(errors: np.ndarray, dt: float, cutoff: float = JITTER_HZ, trim: float = 0.1) -> float:
    """RMS [rad] of the joint errors' content above ``cutoff`` [Hz] (zero-phase, ``trim`` [s] cut at both ends)."""
    k = round(trim / dt)
    errors = errors[k : len(errors) - k]
    if len(errors) < 16:
        return float("nan")
    errors = errors - errors.mean(axis=0)
    spectrum = np.fft.rfft(errors, axis=0)
    spectrum[np.fft.rfftfreq(len(errors), dt) <= cutoff] = 0.0
    return float(np.sqrt(np.mean(np.fft.irfft(spectrum, n=len(errors), axis=0) ** 2)))


class TrackingReport:
    """Tracking errors against a reference clip, sampled after every control period."""

    def __init__(self, robot: Robot, motion: MotionClip):
        self.robot, self.motion = robot, motion
        model = robot.model
        self.scratch = model.state()
        self.joint_q = wp.zeros(model.joint_coord_count, dtype=float, device=model.device)
        self.feet = [body_index(model, name) for name in FEET]
        self.wrists = [body_index(model, name) for name in WRISTS]
        mj = robot.solver.mj_model
        foot_ids = {i for i in range(mj.nbody) if mj.body(i).name.endswith(FEET)}
        # MuJoCo geoms that may touch the floor: those of the feet.
        self.foot_geom = np.array([int(mj.geom_bodyid[g]) in foot_ids for g in range(mj.ngeom)])
        self.robot_geom = np.array([int(mj.geom_bodyid[g]) != 0 for g in range(mj.ngeom)])
        self.rows = []
        self.fall_time = None
        self.fall_reason = None

    def non_foot_contact(self) -> bool:
        """Whether a robot geom other than the feet touches the floor."""
        data = self.robot.solver.mjw_data
        count = min(int(data.nacon.numpy()[0]), data.contact.geom.shape[0])
        if count == 0:
            return False
        geoms = data.contact.geom.numpy()[:count]
        touching = data.contact.dist.numpy()[:count] <= 0.0
        robot = self.robot_geom[geoms]
        other = robot & ~self.foot_geom[geoms]
        return bool(np.any(touching & other.any(axis=1)))

    def update(self, t: float, state: newton.State) -> bool:
        """Record the errors of ``state`` at time ``t`` [s]; returns whether the robot is still on its feet.

        Recording stops at a fall. Samples at or after ``t`` are dropped first (the clock was rewound)."""
        while self.rows and self.rows[-1]["t"] >= t - 1e-9:
            self.rows.pop()
        if self.fall_time is not None and self.fall_time >= t - 1e-9:
            self.fall_time = self.fall_reason = None
        if self.fall_time is not None:
            return False
        q = state.joint_q.numpy().astype(np.float64)
        body_q = state.body_q.numpy().astype(np.float64)
        ref = self.motion.sample(t)
        self.joint_q.assign(ref)
        newton.eval_fk(self.robot.model, self.joint_q, self.robot.model.joint_qd, self.scratch)
        ref_body_q = self.scratch.body_q.numpy().astype(np.float64)
        finite = bool(np.all(np.isfinite(q)) and np.all(np.isfinite(body_q)))
        quat = q[3:7] / np.linalg.norm(q[3:7]) if finite else ref[3:7]
        soles = [foot_points(body_q, f) for f in self.feet]
        ref_soles = [foot_points(ref_body_q, f) for f in self.feet]
        row = {
            "t": t,
            "finite": finite,
            "root_err": float(np.linalg.norm(q[:3] - ref[:3])),
            "root_rot_err": _quat_angle(quat, ref[3:7]),
            "joint_err": q[7:] - ref[7:],
            "wrist_err2": float(np.mean(np.sum((body_q[self.wrists, :3] - ref_body_q[self.wrists, :3]) ** 2, axis=1))),
            "sole_err2": float(np.mean([np.sum((a[0] - b[0]) ** 2) for a, b in zip(soles, ref_soles, strict=True)])),
            "lift": [(b[1] > LIFT_REFERENCE_M, a[1] > LIFT_ROBOT_M) for a, b in zip(soles, ref_soles, strict=True)],
        }
        self.rows.append(row)
        reason = None
        if not finite:
            reason = "state not finite"
        elif q[2] < FALL_HEIGHT_M:
            reason = f"root height {q[2]:.2f} m"
        elif _rotation(quat)[2, 2] < FALL_UP_COS:
            reason = "root tilted over"
        elif self.non_foot_contact():
            reason = "non-foot floor contact"
        if reason is not None:
            self.fall_time, self.fall_reason = t, reason
        return reason is None

    def summary(self) -> dict:
        """Metrics over the recorded samples, up to a fall (errors are infinite if the state stopped being finite)."""
        rows = self.rows
        finite = bool(rows) and all(r["finite"] for r in rows)
        inf = float("inf")

        def rms(values):
            return float(np.sqrt(np.mean(np.square(values)))) if finite else inf

        lifts = [robot for r in rows for ref, robot in r["lift"] if ref]
        errors = np.array([r["joint_err"] for r in rows]) if finite else None
        return {
            "upright": self.fall_time is None and finite,
            "fall_time_s": self.fall_time,
            "fall_reason": self.fall_reason,
            "survival": 1.0 if self.fall_time is None else self.fall_time / self.motion.duration,
            "root_rmse_m": rms([r["root_err"] for r in rows]),
            "root_rot_rmse_deg": float(np.degrees(rms([r["root_rot_err"] for r in rows]))),
            "joint_rmse_rad": rms(errors) if finite else inf,
            "wrist_rmse_m": float(np.sqrt(np.mean([r["wrist_err2"] for r in rows]))) if finite else inf,
            "sole_rmse_m": float(np.sqrt(np.mean([r["sole_err2"] for r in rows]))) if finite else inf,
            "lift_recall": float(np.mean(lifts)) if lifts else None,
            "jitter_mrad": 1000.0 * jitter(errors, CONTROL_DT) if finite else inf,
            "root_err_max_m": max(r["root_err"] for r in rows) if finite else inf,
            "samples": len(rows),
        }


def planning_builder(joint_q: np.ndarray, kp: np.ndarray, kd: np.ndarray) -> newton.ModelBuilder:
    """The robot as in :func:`build_model` (unfinalized), with fixed servo gains, for batched planning rollouts."""
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    builder.add_mjcf(asset_path(), collapse_fixed_joints=True)
    robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
    for i, shape in enumerate(robot_shapes):
        for other in robot_shapes[i + 1 :]:
            builder.add_shape_collision_filter_pair(shape, other)
    builder.joint_armature[6:] = ARMATURE.tolist()
    builder.joint_target_ke[6:] = [float(v) for v in kp]
    builder.joint_target_kd[6:] = [float(v) for v in kd]
    builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * JOINT_COUNT
    builder.custom_attributes["mujoco:ctrl_source"].values = [
        int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
    ] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcerange"].values = [
        (-limit, limit) for limit in builder.joint_effort_limit[6:]
    ]
    builder.joint_q[:] = np.asarray(joint_q, dtype=float).tolist()
    return builder


@wp.kernel
def _set_targets_kernel(
    ref_target: wp.array2d(dtype=float),
    base: wp.array(dtype=int),
    period: int,
    offsets: wp.array3d(dtype=float),
    coords: int,
    target: wp.array(dtype=float),
):
    world, joint = wp.tid()
    k = wp.min(base[0] + period + 1, ref_target.shape[0] - 1)
    target[world * coords + 7 + joint] = ref_target[k, joint] + offsets[world, period, joint]


@wp.kernel
def _cost_kernel(
    joint_q: wp.array(dtype=float),
    joint_qd: wp.array(dtype=float),
    body_q: wp.array(dtype=wp.transform),
    ref_q: wp.array2d(dtype=float),
    ref_v: wp.array2d(dtype=float),
    dofs: int,
    ref_sole: wp.array3d(dtype=float),
    base: wp.array(dtype=int),
    period: int,
    coords: int,
    bodies: int,
    foot_l: int,
    foot_r: int,
    sole_center: wp.vec3,
    w_root: float,
    w_rot: float,
    w_joint: float,
    w_sole: float,
    w_fall: float,
    w_vel: float,
    cost: wp.array(dtype=float),
):
    world = wp.tid()
    k = wp.min(base[0] + period + 1, ref_q.shape[0] - 1)
    o = world * coords
    dp = wp.vec3(joint_q[o] - ref_q[k, 0], joint_q[o + 1] - ref_q[k, 1], joint_q[o + 2] - ref_q[k, 2])
    q = wp.normalize(wp.quat(joint_q[o + 3], joint_q[o + 4], joint_q[o + 5], joint_q[o + 6]))
    qr = wp.quat(ref_q[k, 3], ref_q[k, 4], ref_q[k, 5], ref_q[k, 6])
    d = wp.abs(wp.dot(q, qr))
    ang = 2.0 * wp.acos(wp.min(d, 1.0))
    je = float(0.0)
    for i in range(JOINT_COUNT):
        e = joint_q[o + 7 + i] - ref_q[k, 7 + i]
        je += e * e
    se = float(0.0)
    for f in range(2):
        b = foot_l
        if f == 1:
            b = foot_r
        p = wp.transform_point(body_q[world * bodies + b], sole_center)
        ds = wp.vec3(p[0] - ref_sole[k, f, 0], p[1] - ref_sole[k, f, 1], p[2] - ref_sole[k, f, 2])
        se += wp.dot(ds, ds)
    up = wp.quat_rotate(q, wp.vec3(0.0, 0.0, 1.0))
    fall = float(0.0)
    if joint_q[o + 2] < 0.6 or up[2] < 0.8:
        fall = 1.0
    v = world * dofs
    dv = wp.vec3(joint_qd[v] - ref_v[k, 0], joint_qd[v + 1] - ref_v[k, 1], joint_qd[v + 2] - ref_v[k, 2])
    cost[world] += (
        w_root * wp.dot(dp, dp) + w_rot * ang * ang + w_joint * je + w_sole * se + w_fall * fall + w_vel * wp.dot(dv, dv)
    )


@wp.kernel
def _reset_kernel(cost: wp.array(dtype=float), start_q: wp.array(dtype=float), start_qd: wp.array(dtype=float),
                  joint_q: wp.array(dtype=float), joint_qd: wp.array(dtype=float), coords: int, dofs: int):
    world = wp.tid()
    cost[world] = 0.0
    for i in range(coords):
        joint_q[world * coords + i] = start_q[i]
    for i in range(dofs):
        joint_qd[world * dofs + i] = start_qd[i]


class Controller:
    """Sampling-based model predictive control (MPPI) on GPU-batched rollouts of the robot model.

    While building, the controller computes per control period the joint torques that realize the reference
    accelerations with feasible foot contact forces (inverse dynamics with a small QP for the contact forces), so
    the servo target ``reference + (kd qd_ref + tau_ff) / kp`` tracks the clip without sagging. Every control period
    it then copies the measured state into ``SAMPLES`` parallel worlds of its own MuJoCo-Warp model of the robot and
    simulates them over the horizon (``HORIZON`` control periods, shorter for long clips to stay within the time
    budget), each world servoing toward that target plus the current plan of joint-target offsets and a smooth
    random perturbation of it (linear between knots every ``KNOT`` periods). The rollouts are scored by root
    position, velocity, and orientation, joint, and sole tracking errors and a fall penalty, and the plan is updated
    with the exponentially cost-weighted mean of the perturbations (MPPI, the unperturbed plan included). The first
    period of the plan is sent to the robot and the plan shifts by one period (receding horizon).

    ``model`` is a copy of the plant's model posed at the start (``build_model(motion.sample(0.0))``), the
    controller's to use for planning; the simulated robot is a separate model the controller never sees.
    ``motion`` is the reference clip (a :class:`MotionClip` with the floor shift applied).
    """

    SAMPLES = 512
    HORIZON = 50  # control periods
    KNOT = 10  # control periods between noise knots
    SIGMA = 0.04  # perturbation std [rad] (legs; waist 0.75x, arms 0.5x)
    ITERATIONS = 1  # MPPI updates per control period
    WARM_ITERATIONS = 10  # MPPI updates at the initial state while building
    MIN_HORIZON = 25  # control periods
    FULL_HORIZON_PERIODS = 600  # clips up to this many control periods plan over the full horizon
    TEMPERATURE = 0.5  # fraction of the cost spread
    W_ROOT, W_ROT, W_JOINT, W_SOLE, W_FALL, W_VEL = 400.0, 100.0, 1.0, 200.0, 1000.0, 20.0
    WN = 2.0 * np.pi * 25.0  # servo natural frequency on the armature [rad/s]
    KD_RATIO = 0.03  # kd = KD_RATIO kp [s]
    FF_GAIN = 1.0
    CONTACT_FF_M = 0.02  # feet with reference sole clearance below this [m] carry load in the feedforward
    ARM_SIGMA = 0.5  # arm perturbation relative to SIGMA

    def __init__(self, model: newton.Model, motion: MotionClip):
        self.motion = motion
        self.rng = np.random.default_rng(0)
        self.kp = np.clip(ARMATURE * self.WN**2, *KP_RANGE)
        self.kd = np.clip(self.KD_RATIO * self.kp, *KD_RANGE)
        self.sigma = self.SIGMA * np.array([1.0] * 12 + [0.75] * 3 + [self.ARM_SIGMA] * 14)
        start = motion.sample(0.0)
        self.device = model.device
        n = self.SAMPLES
        batch = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(batch)
        batch.replicate(planning_builder(start, self.kp, self.kd), n)
        self.model = batch.finalize(device=self.device)
        self.solver = make_solver(self.model)
        self.coords = model.joint_coord_count
        self.dofs = model.joint_dof_count
        self.bodies = model.body_count
        self.feet = [body_index(model, name) for name in FEET]

        # Reference per control period (servo target includes the velocity term kd qd / kp).
        self.steps = int(np.ceil(motion.duration / CONTROL_DT)) + self.HORIZON + 3
        times = np.arange(self.steps) * CONTROL_DT
        ref_q = np.array([motion.sample(t) for t in times])
        h = 0.5 * CONTROL_DT
        ref_qd = np.array([(motion.sample(t + h)[7:] - motion.sample(t - h)[7:]) / (2 * h) for t in times])
        self.tau_ff = self._feedforward(model, ref_q, times) * self.FF_GAIN
        self.ref_target = ref_q[:, 7:] + (self.kd * ref_qd + self.tau_ff) / self.kp
        state = model.state()
        sole = np.zeros((self.steps, 2, 3))
        qbuf = wp.zeros(self.coords, dtype=float, device=self.device)
        for k in range(self.steps):
            qbuf.assign(ref_q[k])
            newton.eval_fk(model, qbuf, model.joint_qd, state)
            body_q = state.body_q.numpy().astype(np.float64)
            for i, f in enumerate(self.feet):
                sole[k, i] = foot_points(body_q, f)[0]
        ref_v = np.array([(motion.sample(t + 2 * h)[:3] - motion.sample(t - 2 * h)[:3]) / (4 * h) for t in times])
        self.ref_v = wp.array(ref_v, dtype=float, device=self.device)
        self.ref_q = wp.array(ref_q, dtype=float, device=self.device)
        self.ref_target_gpu = wp.array(self.ref_target, dtype=float, device=self.device)
        self.ref_sole = wp.array(sole, dtype=float, device=self.device)
        self.base = wp.zeros(1, dtype=int, device=self.device)
        self.cost = wp.zeros(n, dtype=float, device=self.device)
        self.start_q = wp.zeros(self.coords, dtype=float, device=self.device)
        self.start_qd = wp.zeros(self.dofs, dtype=float, device=self.device)
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        self.start_state = self.state_0
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        # Plan with the longest horizon that keeps the whole rollout within the time budget (about 0.22 s per control
        # period for the full horizon on this machine), warm-started at the initial state (the robot starts at rest
        # at the clip's first frame). The horizon depends only on the clip length, not on the measured load.
        self.start_q.assign(start)
        self.start_qd.zero_()
        periods = max(1, round(motion.duration / CONTROL_DT))
        horizon = int(np.clip(self.HORIZON * self.FULL_HORIZON_PERIODS / periods, self.MIN_HORIZON, self.HORIZON))
        self._configure(horizon)
        for _ in range(self.WARM_ITERATIONS):
            self._iterate()

    def _configure(self, horizon: int):
        """Allocate the plan for a horizon of ``horizon`` control periods and capture the rollout graph."""
        self.horizon = horizon
        self.offsets = wp.zeros((self.SAMPLES, horizon, JOINT_COUNT), dtype=float, device=self.device)
        self.plan = np.zeros((horizon, JOINT_COUNT))
        knots = np.arange(0, horizon + self.KNOT, self.KNOT)
        self.interp = np.zeros((horizon, len(knots)))
        for j in range(horizon):
            x = j / self.KNOT
            a = int(np.floor(x))
            self.interp[j, a] += 1.0 - (x - a)
            if a + 1 < len(knots):
                self.interp[j, a + 1] += x - a
        self.graph = None
        self._rollout()  # compile
        if self.device.is_cuda:
            with wp.ScopedCapture(device=self.device) as capture:
                self._rollout()
            self.graph = capture.graph

    def _feedforward(self, model: newton.Model, ref_q: np.ndarray, times: np.ndarray) -> np.ndarray:
        """Joint torques [N m] that realize the reference accelerations with feasible foot contact forces (an
        inverse-dynamics QP per control period: least-squares floating-base residual, friction pyramids)."""
        import mujoco
        import osqp
        import scipy.sparse as sp

        mj = make_solver(model).mj_model
        d = mujoco.MjData(mj)
        nv = mj.nv
        feet = [body_index(model, name) + 1 for name in FEET]
        to_mj = lambda q: np.concatenate([q[:3], q[6:7], q[3:6], q[7:]])  # noqa: E731
        h = max(1.0 / self.motion.fps, CONTROL_DT)
        qvel = np.zeros((len(times), nv))
        for k, t in enumerate(times):
            mujoco.mj_differentiatePos(mj, qvel[k], 2 * h, to_mj(self.motion.sample(t - h)), to_mj(self.motion.sample(t + h)))
        steps = max(1, round(h / CONTROL_DT))
        qacc = np.zeros_like(qvel)
        for k in range(len(times)):
            lo, hi = max(0, k - steps), min(len(times) - 1, k + steps)
            if hi > lo:
                qacc[k] = (qvel[hi] - qvel[lo]) / ((hi - lo) * CONTROL_DT)
        tau_max = model.joint_effort_limit.numpy()[6:].astype(np.float64)
        mass = np.zeros((nv, nv))
        jacp = np.zeros((3, nv))
        tau = np.zeros((len(times), JOINT_COUNT))
        mu = 0.7
        for k in range(len(times)):
            d.qpos[:] = to_mj(ref_q[k])
            d.qvel[:] = qvel[k]
            mujoco.mj_forward(mj, d)
            mujoco.mj_fullM(mj, d, mass)
            bias = d.qfrc_bias.copy()
            jc = []
            for b in feet:
                r = d.xmat[b].reshape(3, 3)
                points = d.xpos[b] + SOLE_POINTS @ r.T
                if np.min(points[:, 2]) - SOLE_RADIUS > self.CONTACT_FF_M:
                    continue
                for p in points:
                    mujoco.mj_jac(mj, d, jacp, None, p - np.array([0.0, 0.0, SOLE_RADIUS]), b)
                    jc.append(jacp.copy())
            rhs = mass @ qacc[k] + bias
            if not jc:
                tau[k] = rhs[6:]
                continue
            jc = np.array(jc).reshape(-1, nv)
            nf = jc.shape[0]
            nc = nf // 3
            a_mat = jc[:, :6].T  # base residual: rhs_b - Jc_b^T f
            hess = 1e3 * a_mat.T @ a_mat + 1e-3 * np.eye(nf)
            grad = -1e3 * a_mat.T @ rhs[:6]
            fr = np.zeros((5 * nc, nf))
            for c in range(nc):
                fx, fy, fz = 3 * c, 3 * c + 1, 3 * c + 2
                fr[5 * c, fz] = 1.0
                fr[5 * c + 1, [fx, fz]] = [1.0, -mu]
                fr[5 * c + 2, [fx, fz]] = [-1.0, -mu]
                fr[5 * c + 3, [fy, fz]] = [1.0, -mu]
                fr[5 * c + 4, [fy, fz]] = [-1.0, -mu]
            lower = np.tile([0.0, -np.inf, -np.inf, -np.inf, -np.inf], nc)
            upper = np.tile([np.inf, 0.0, 0.0, 0.0, 0.0], nc)
            prob = osqp.OSQP()
            prob.setup(sp.triu(sp.csc_matrix(hess), format="csc"), grad, sp.csc_matrix(fr), lower, upper,
                       verbose=False, eps_abs=1e-7, eps_rel=1e-7, max_iter=20000, polishing=False)
            f = prob.solve().x
            if f is None or not np.all(np.isfinite(f)):
                f = np.zeros(nf)
            tau[k] = rhs[6:] - jc[:, 6:].T @ f
        return np.clip(tau, -tau_max, tau_max)

    def _rollout(self):
        n = self.SAMPLES
        wp.launch(_reset_kernel, dim=n, inputs=[self.cost, self.start_q, self.start_qd, self.start_state.joint_q,
                                                self.start_state.joint_qd, self.coords, self.dofs], device=self.device)
        s0, s1 = self.start_state, (self.state_1 if self.start_state is self.state_0 else self.state_0)
        for j in range(self.horizon):
            wp.launch(_set_targets_kernel, dim=(n, JOINT_COUNT),
                      inputs=[self.ref_target_gpu, self.base, j, self.offsets, self.coords, self.control.joint_target_q],
                      device=self.device)
            for _ in range(SUBSTEPS):
                s0.clear_forces()
                self.solver.step(s0, s1, self.control, None, SIM_DT)
                s0, s1 = s1, s0
            wp.launch(_cost_kernel, dim=n, inputs=[s0.joint_q, s0.joint_qd, s0.body_q, self.ref_q, self.ref_v,
                                                   self.dofs, self.ref_sole, self.base, j,
                                                   self.coords, self.bodies, self.feet[0], self.feet[1],
                                                   wp.vec3(*SOLE_CENTER), self.W_ROOT, self.W_ROT, self.W_JOINT,
                                                   self.W_SOLE, self.W_FALL, self.W_VEL, self.cost], device=self.device)

    def _iterate(self):
        """One MPPI update of the plan from the state in ``start_q``/``start_qd`` at period ``base``."""
        n = self.SAMPLES
        knots = self.rng.standard_normal((n, self.interp.shape[1], JOINT_COUNT)) * self.sigma
        noise = np.einsum("jk,nkd->njd", self.interp, knots)
        noise[0] = 0.0
        self.offsets.assign((self.plan[None] + noise).astype(np.float32))
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self._rollout()
        cost = self.cost.numpy().astype(np.float64)
        spread = max(np.percentile(cost, 50) - cost.min(), 1e-9)
        w = np.exp(-(cost - cost.min()) / (self.TEMPERATURE * spread))
        w /= w.sum()
        self.plan = self.plan + np.einsum("n,njd->jd", w, noise)
        self.last_cost = float(cost[0]), float(cost.min())

    def compute(self, t: float, joint_q: np.ndarray, joint_qd: np.ndarray) -> Command:
        """Command for the control period starting at ``t`` [s], given the state then: joint_q (root position [m],
        root quaternion xyzw, 29 joint angles [rad]) and joint_qd (root COM linear [m/s] and angular [rad/s]
        velocity in the world frame, 29 joint velocities [rad/s])."""
        k = int(np.clip(round(t / CONTROL_DT), 0, self.steps - 1))
        self.base.assign(np.array([k], dtype=np.int32))
        self.start_q.assign(joint_q)
        self.start_qd.assign(joint_qd)
        for _ in range(self.ITERATIONS):
            self._iterate()
        first = self.plan[0].copy()
        self.plan = np.concatenate([self.plan[1:], self.plan[-1:]])
        target = self.ref_target[min(k + 1, self.steps - 1)] + first
        return Command(q=target, kp=self.kp, kd=self.kd)


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.frame_dt = CONTROL_DT
        self.sim_dt = SIM_DT
        self.sim_time = 0.0
        # The robot starts at rest at the clip's first frame; the controller plans on its own copy of the model.
        self.motion = MotionClip(args.motion, build_model())
        start = self.motion.sample(0.0)
        self.robot = Robot(start)
        planning_model = build_model(start)
        self.controller = Controller(planning_model, MotionClip(args.motion, planning_model))
        self.report = TrackingReport(self.robot, self.motion)
        self.compute_seconds = 0.0
        self.viewer.set_model(self.model)

    # The live host and viewers look for these on the example.
    @property
    def model(self):
        return self.robot.model

    @property
    def solver(self):
        return self.robot.solver

    @property
    def state_0(self):
        return self.robot.state_0

    @property
    def state_1(self):
        return self.robot.state_1

    @property
    def control(self):
        return self.robot.control

    def capture(self):
        self.robot.capture()

    def step(self):
        # Read the state first: the copy waits for the last physics step, which is not the controller's time.
        joint_q = self.state_0.joint_q.numpy().astype(np.float64)
        joint_qd = self.state_0.joint_qd.numpy().astype(np.float64)
        started = time.perf_counter()
        command = self.controller.compute(self.sim_time, joint_q, joint_qd)
        self.compute_seconds += time.perf_counter() - started
        self.robot.apply(command)
        self.robot.advance()
        self.sim_time += self.frame_dt
        self.report.update(self.sim_time, self.state_0)

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def print_report(self):
        summary = self.report.summary()
        print(f"tracked {self.sim_time:.2f} of {self.motion.duration:.2f} s")
        for key, value in summary.items():
            print(f"  {key}: {value:.4f}" if isinstance(value, float) else f"  {key}: {value}")
        print(f"  controller_seconds: {self.compute_seconds:.2f}")

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, default="walk.csv", help="Reference clip (MuJoCo qpos CSV, 30 fps)")
        parser.set_defaults(num_frames=None)
        return parser


if __name__ == "__main__":
    parser = Example.create_parser()
    known, _ = parser.parse_known_args()
    if known.num_frames is None:
        parser.set_defaults(num_frames=round(MotionClip(known.motion).duration / CONTROL_DT))
    viewer, args = newton.examples.init(parser)
    example = Example(viewer, args)
    started = time.perf_counter()
    newton.examples.run(example, args)
    example.print_report()
    print(f"  wall_seconds: {time.perf_counter() - started:.2f}")
