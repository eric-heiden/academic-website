# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure), adds three free fruits
and a shallow wooden tray, and copies the scene into ``num_worlds`` identical
worlds. The fitted geometry, inertias, materials, and servo parameters below are
self-contained; photos and calibration logs are not needed to build or replay it.
``Example`` drives every world with the logged commands as joint position targets,
open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]
GRIPPER_KP = 1500.0  # N/m, single driven slide with the original finger equality
GRIPPER_FORCE = 35.0  # N, actuator squeeze limit

PARAMS = {
    "command_delay": 0.0,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}


# Fitted physical quantities, in SI units. The collision hull of the pear follows
# its broad end and tapered neck; small photographic surface wrinkles are omitted.
ARM_KP = [47.963336, 39.395196, 45.706046, 9.205295, 5.178916, 5.325281]
ARM_KD = [3.494223, 2.775478, 3.533115, 1.44735, 0.879261, 0.950404]
ARM_ARMATURE = [0.047607, 0.0001, 0.022014, 0.001998, 0.000104, 0.001015]
ARM_FRICTION = [0.443779, 0.973627, 0.997339, 0.163622, 0.044679, 0.045799]
ARM_GRAVCOMP = [0.005, 0.802563, 0.907664, 0.997587, 0.842861, 0.729431]
FRUITS = [
    dict(name="pear", position=(0.649, 0.333, 0.776), radii=(0.040, 0.028, 0.026),
         mass=0.130, yaw=-1.05, color=(0.82, 0.65, 0.035)),
    dict(name="orange", position=(0.505, -0.056, 0.781), radii=(0.031, 0.031, 0.031),
         mass=0.140, yaw=0.0, color=(0.95, 0.22, 0.015)),
    dict(name="dark_fruit", position=(0.652, -0.194, 0.783), radii=(0.036, 0.034, 0.033),
         mass=0.180, yaw=0.0, color=(0.12, 0.045, 0.025)),
]
# Surveyed top-camera outline, projected onto the wooden tray's upper floor.
TRAY_OUTLINE = np.array([
    [0.918, 0.140], [0.778, -0.027], [0.747, -0.005],
    [0.717, 0.027], [0.694, 0.067], [0.684, 0.111],
    [0.686, 0.151], [0.700, 0.185],
], dtype=np.float32)


def _convex_mesh(vertices):
    from scipy.spatial import ConvexHull
    vertices = np.asarray(vertices, dtype=np.float32)
    hull = ConvexHull(vertices)
    faces = hull.simplices.copy()
    # Outward triangle winding, for rendering and inertia integration.
    centre = vertices.mean(axis=0)
    for tri in faces:
        a, b, c = vertices[tri]
        if np.dot(np.cross(b - a, c - a), (a + b + c) / 3 - centre) < 0:
            tri[1], tri[2] = tri[2], tri[1]
    return newton.Mesh(vertices=vertices, indices=faces.flatten())


def _add_objects(builder):
    cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=0.1,
        mu_torsional=0.004, mu_rolling=0.0015, gap=0.005)
    contact = {"mujoco:solref": wp.vec2(0.006, 1.0), "mujoco:solref_mode": 1,
               "mujoco:condim": 6}
    for f in FRUITS:
        rx, ry, rz = f["radii"]
        mass = f["mass"]
        inertia = mass / 5 * np.array([ry*ry + rz*rz, rx*rx + rz*rz, rx*rx + ry*ry])
        body = builder.add_body(xform=wp.transform(f["position"],
            wp.quat_from_axis_angle(wp.vec3(0, 0, 1), f["yaw"])),
            mass=mass, inertia=wp.mat33(np.diag(inertia)), lock_inertia=True, label=f["name"])
        if f["name"] == "pear":
            vertices = []
            for x, radius in [(-.038, .001), (-.031, .019), (-.018, .027),
                              (-.005, .028), (.009, .023), (.025, .016),
                              (.039, .009), (.046, .001)]:
                for phi in np.linspace(0, 2*np.pi, 24, endpoint=False):
                    vertices.append([x, radius*np.cos(phi), radius*np.sin(phi)*rz/ry])
            builder.add_shape_convex_hull(body, mesh=_convex_mesh(vertices), cfg=cfg,
                color=f["color"], label=f["name"]+"_surface", custom_attributes=contact)
        elif f["name"] == "orange":
            orange_cfg = cfg.copy()
            orange_cfg.mu_rolling = 0.0008
            builder.add_shape_sphere(body, radius=rx, cfg=orange_cfg,
                color=f["color"], label=f["name"]+"_surface", custom_attributes=contact)
        else:
            builder.add_shape_ellipsoid(body, rx=rx, ry=ry, rz=rz, cfg=cfg,
                color=f["color"], label=f["name"]+"_surface", custom_attributes=contact)
    wood = newton.ModelBuilder.ShapeConfig(density=0.0, mu=0.1,
        mu_torsional=0.001, mu_rolling=0.0008, gap=0.005)
    # Shallow dish: a flat well, with the wooden floor rising toward both ends.
    # Three convex sections leave a continuous upper surface.
    front, back, slope = .725, .790, .15
    def floor_z(x):
        return .758 + slope * (max(0.0, front - float(x)) + max(0.0, float(x) - back))
    def clip_outline(outline, boundary, keep_back):
        out = []
        for a, b in zip(outline, np.roll(outline, -1, axis=0)):
            ina = a[0] >= boundary if keep_back else a[0] <= boundary
            inb = b[0] >= boundary if keep_back else b[0] <= boundary
            if ina:
                out.append(a.tolist())
            if ina != inb:
                alpha = (boundary - a[0]) / (b[0] - a[0])
                out.append((a + alpha * (b-a)).tolist())
        return np.array(out)
    sections = [clip_outline(TRAY_OUTLINE, front, False),
                clip_outline(clip_outline(TRAY_OUTLINE, front, True), back, False),
                clip_outline(TRAY_OUTLINE, back, True)]
    for i, outline in enumerate(sections):
        vertices = [[x, y, .750] for x, y in outline] + [[x, y, floor_z(x)] for x, y in outline]
        builder.add_shape_convex_hull(-1, mesh=_convex_mesh(vertices), cfg=wood,
            color=(0.55, 0.32, 0.12), label=f"tray_floor_{i}", custom_attributes=contact)
    for i, (a, b) in enumerate(zip(TRAY_OUTLINE, np.roll(TRAY_OUTLINE, -1, axis=0))):
        delta = b-a
        normal = np.array([-delta[1], delta[0]]) / np.linalg.norm(delta) * .003
        vertices = []
        for pt in (a+normal, a-normal, b+normal, b-normal):
            vertices.extend([[pt[0], pt[1], .751], [pt[0], pt[1], min(.789, floor_z(pt[0])+.014)]])
        builder.add_shape_convex_hull(-1, mesh=_convex_mesh(vertices), cfg=wood,
            color=(0.62, 0.39, 0.17), label=f"tray_rim_{i}", custom_attributes=contact)


def build_model(num_worlds: int = 1) -> newton.Model:
    """The calibrated station, three free fruits, and a shallow static tray."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    episode = load_episode()
    for j, label in enumerate(station.joint_label):
        name = label.rsplit("/", 1)[-1]
        dof = station.joint_qd_start[j]
        if any(name == f"{side}_joint{k+1}" for side in SIDES for k in range(6)):
            k = int(name[-1])-1
            side = name.split("_", 1)[0]
            station.joint_q[station.joint_q_start[j]] = float(episode[side + "_q"][0, k])
            station.joint_target_ke[dof] = ARM_KP[k]
            station.joint_target_kd[dof] = ARM_KD[k]
            station.joint_armature[dof] = ARM_ARMATURE[k]
            station.joint_friction[dof] = ARM_FRICTION[k]
            station.joint_effort_limit[dof] = 28.0 if k < 3 else 10.0
        elif name in ("left_left_finger", "right_left_finger"):
            station.joint_target_ke[dof] = GRIPPER_KP
            station.joint_effort_limit[dof] = GRIPPER_FORCE
    for j, label in enumerate(station.joint_label):
        name = label.rsplit("/", 1)[-1]
        for side in SIDES:
            for sign, finger in ((1, "left"), (-1, "right")):
                if name == f"{side}_{finger}_finger":
                    station.joint_q[station.joint_q_start[j]] = sign * GRIPPER_TRAVEL * float(episode[side + "_grip"][0])
    station.shape_gap[:] = [0.002] * len(station.shape_gap)
    _add_objects(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    gravity_comp = model.mujoco.gravcomp.numpy()
    for i, label in enumerate(model.body_label):
        name = label.rsplit("/", 1)[-1]
        for side in SIDES:
            if name in [f"{side}_link_{j+1}" for j in range(6)]:
                gravity_comp[i] = ARM_GRAVCOMP[int(name[-1])-1]
            elif f"{side}_arm/" in label and ("finger" in label or "camera" in label):
                gravity_comp[i] = ARM_GRAVCOMP[5]
    model.mujoco.gravcomp.assign(gravity_comp)
    force_range = model.mujoco.actuator_forcerange.numpy()
    force_limited = model.mujoco.actuator_forcelimited.numpy()
    has_range = model.mujoco.actuator_has_forcerange.numpy()
    for i in range(len(force_range)):
        if i % 7 == 6:
            force_range[i] = (-GRIPPER_FORCE, GRIPPER_FORCE)
            force_limited[i] = 1
            has_range[i] = 1
    model.mujoco.actuator_forcerange.assign(force_range)
    model.mujoco.actuator_forcelimited.assign(force_limited)
    model.mujoco.actuator_has_forcerange.assign(has_range)
    # Materials and contact settings live on the model, and survive a solver
    # rebuild or notify_model_changed with every flag enabled.
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=True,
        cone="elliptic", solver="newton", iterations=50, ls_iterations=15,
        njmax=512, nconmax=256, impratio=1.0)


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """MuJoCo computes the convex contacts."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
