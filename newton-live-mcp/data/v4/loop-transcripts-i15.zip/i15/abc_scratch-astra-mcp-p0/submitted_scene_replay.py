# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, together with three passive fruit replicas and a static wooden tray.
``Example`` drives every world with the logged commands as joint position targets,
open loop. All fitted physical parameters are stored below; model construction
requires only the station assets, and replay additionally requires ``episode.npz``.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.0,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}

# Constant servo response fitted to the supplied joint/effort recordings, then
# refined against the episode's measured motion with the original link inertias.
# Gravity-compensation groups are links 1-2, link 3, and the distal assembly.
ARM = {
    "kp": [38.5386, 36.136, 56.1335, 7.1936, 8.782, 8.6212],
    "kd": [3.1504, 3.4911, 5.8643, 1.2083, 1.4153, 1.4094],
    "armature": [0.000108, 0.000108, 0.003617, 0.003617, 0.00045, 0.00045],
    "friction": [0.1, 0.1, 0.1, 0.1, 0.1, 0.1],
    "gravcomp": [0.99793, 0.80003, 0.85987],
    "grip_kp": 1500.0,
    "grip_force": 8.0,
}

# Collision ellipsoids approximate the compliant fruit replicas at their grasped
# sizes. The dimensions also agree with the calibrated top and wrist silhouettes.
# Masses are effective rigid-body estimates; inertia is that of a solid ellipsoid.
FRUITS = [
    {
        "name": "pear", "xy": [0.650, 0.330], "radii": [0.035, 0.028, 0.027],
        "mass": 0.090, "yaw": -1.05, "color": [0.85, 0.67, 0.02],
    },
    {
        "name": "orange", "xy": [0.504, -0.057], "radii": [0.030, 0.030, 0.029],
        "mass": 0.110, "yaw": 0.0, "color": [0.95, 0.23, 0.01],
    },
    {
        "name": "dark_fruit", "xy": [0.653, -0.194], "radii": [0.035, 0.035, 0.031],
        "mass": 0.130, "yaw": 0.0, "color": [0.16, 0.05, 0.022],
    },
]

TRAY = {
    "center": [0.733, 0.088], "floor_z": 0.756, "edge_z": 0.768,
    "flat_radius": 0.025, "rolling": 0.0007,
}


def add_objects(builder):
    """Photo-scale fruit replicas and the shallow, sector-shaped wooden tray."""
    material = newton.ModelBuilder.ShapeConfig(
        density=0.0, mu=1.0, mu_torsional=0.003, mu_rolling=0.0007, margin=0.0, gap=0.002,
    )
    contact = {"mujoco:solref": wp.vec2(0.008, 1.25), "mujoco:condim": 6}
    for fruit in FRUITS:
        a, b, c = fruit["radii"]
        mass = fruit["mass"]
        inertia = np.diag([b*b + c*c, a*a + c*c, a*a + b*b]) * mass / 5.0
        body = builder.add_body(
            xform=wp.transform(
                (*fruit["xy"], 0.75 + c),
                wp.quat_from_axis_angle(wp.vec3(0, 0, 1), fruit["yaw"]),
            ),
            mass=mass, inertia=wp.mat33(inertia), lock_inertia=True, label=fruit["name"],
        )
        builder.add_shape_ellipsoid(
            body, rx=a, ry=b, rz=c, cfg=material, color=fruit["color"],
            label=fruit["name"] + "_skin", custom_attributes=contact,
        )
        if fruit["name"] == "pear":
            stem = newton.ModelBuilder.ShapeConfig(
                density=0.0, has_shape_collision=False, has_particle_collision=False
            )
            builder.add_shape_capsule(
                body, xform=wp.transform(
                    wp.vec3(0.040, 0.0, 0.004),
                    wp.quat_from_axis_angle(wp.vec3(0, 1, 0), math.pi / 2),
                ),
                radius=0.0015, half_height=0.005, cfg=stem,
                color=(0.20, 0.10, 0.035), label="pear_stem",
            )

    wood = newton.ModelBuilder.ShapeConfig(
        density=0.0, mu=0.7, mu_torsional=0.005, mu_rolling=TRAY["rolling"], gap=0.002,
    )
    # The photo's circular sector, with a shallow dished floor. Each floor panel
    # is a convex prism; the 21 panels and ten rim segments total 31 colliders.
    origin = np.array([0.920, 0.137])
    radius = 0.235
    angles = np.linspace(math.radians(169), math.radians(226), 9)
    arc = origin + radius * np.array([np.cos(angles), np.sin(angles)]).T

    def prism(points, low, high, label):
        top = np.broadcast_to(np.asarray(high), len(points))
        vertices = np.array(
            [[*p, low] for p in points] + [[*p, z] for p, z in zip(points, top)], dtype=np.float32,
        )
        n = len(points)
        indices = []
        for i in range(1, n - 1):
            indices.extend([0, i + 1, i, n, n + i, n + i + 1])
        for i in range(n):
            j = (i + 1) % n
            indices.extend([i, j, n + j, i, n + j, n + i])
        mesh = newton.Mesh(vertices, np.array(indices, dtype=np.int32))
        builder.add_shape_mesh(
            -1, mesh=mesh, cfg=wood, color=(0.57, 0.35, 0.15), label=label, custom_attributes=contact,
        )

    boundary = np.vstack([origin, arc])
    center = np.asarray(TRAY["center"])
    delta = boundary - center
    inner = center + delta / np.linalg.norm(delta, axis=1)[:, None] * TRAY["flat_radius"]
    prism(inner, 0.750, TRAY["floor_z"], "tray_floor")
    for i in range(len(boundary)):
        j = (i + 1) % len(boundary)
        prism(
            [inner[i], boundary[i], boundary[j]], 0.750,
            [TRAY["floor_z"], TRAY["edge_z"], TRAY["edge_z"]], f"tray_slope_{i}_a",
        )
        prism(
            [inner[i], boundary[j], inner[j]], 0.750,
            [TRAY["floor_z"], TRAY["edge_z"], TRAY["floor_z"]], f"tray_slope_{i}_b",
        )
    outline = np.vstack([boundary, origin])
    for i, (p, q) in enumerate(zip(outline[:-1], outline[1:])):
        delta = q - p
        mid = (p + q) / 2
        builder.add_shape_box(
            -1, xform=wp.transform(
                (*mid, 0.765),
                wp.quat_from_axis_angle(wp.vec3(0, 0, 1), math.atan2(delta[1], delta[0])),
            ),
            hx=float(np.linalg.norm(delta) / 2 + 0.001), hy=0.003, hz=0.006,
            cfg=wood, color=(0.65, 0.43, 0.22), label=f"tray_rim_{i}", custom_attributes=contact,
        )


def configure_model(model):
    """Author physical settings on Newton's model, including MuJoCo attributes."""
    dofs = model.joint_qd_start.numpy()
    fields = {
        name: getattr(model, name).numpy()
        for name in (
            "joint_target_ke", "joint_target_kd", "joint_armature", "joint_friction", "joint_effort_limit",
        )
    }
    for joint, label in enumerate(model.joint_label):
        name = label.rsplit("/", 1)[-1]
        for side in SIDES:
            if name.startswith(side + "_joint"):
                k = int(name[-1]) - 1
                d = dofs[joint]
                for field, key in (
                    ("joint_target_ke", "kp"), ("joint_target_kd", "kd"),
                    ("joint_armature", "armature"), ("joint_friction", "friction"),
                ):
                    fields[field][d] = ARM[key][k]
                fields["joint_effort_limit"][d] = 28.0 if k < 3 else 10.0
            elif name == side + "_left_finger":
                d = dofs[joint]
                fields["joint_target_ke"][d] = ARM["grip_kp"]
                fields["joint_effort_limit"][d] = ARM["grip_force"]
    for field, value in fields.items():
        getattr(model, field).assign(value)
    # Explicit actuator ranges complement the total joint effort limits.
    transmission = model.mujoco.actuator_trnid.numpy()
    force_range = model.mujoco.actuator_forcerange.numpy()
    for i, (d, _) in enumerate(transmission):
        effort = float(fields["joint_effort_limit"][int(d)])
        force_range[i] = [-effort, effort]
    model.mujoco.actuator_forcerange.assign(force_range)
    model.mujoco.actuator_has_forcerange.fill_(True)
    model.mujoco.actuator_forcelimited.fill_(1)
    grav = model.mujoco.gravcomp.numpy()
    for i, label in enumerate(model.body_label):
        if any(label.rsplit("/", 1)[-1].startswith(s + "_") for s in SIDES):
            group = 2 if any("_link_" + str(k) in label for k in (4, 5, 6)) else (1 if "_link_3" in label else 0)
            grav[i] = ARM["gravcomp"][group]
    model.mujoco.gravcomp.assign(grav)
    # Standard-form compliant contact; all changes survive a full model notification.
    ref = model.mujoco.solref.numpy()
    ref[:] = [0.008, 1.25]
    model.mujoco.solref.assign(ref)
    model.mujoco.solref_mode.fill_(1)
    # The importer's 10 cm speculative gap creates many inactive pairs. A small
    # gap is sufficient at this step size and leaves the collision surfaces intact.
    model.shape_gap.fill_(0.002)


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_objects(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    configure_model(model)
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(
        model, use_mujoco_contacts=True, cone="elliptic",
        iterations=40, ls_iterations=30, nconmax=128, njmax=768,
    )


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
