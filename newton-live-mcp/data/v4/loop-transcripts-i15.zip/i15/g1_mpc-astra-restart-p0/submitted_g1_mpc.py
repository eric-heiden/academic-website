# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 humanoid tracking a reference motion (starter for a controller).

The robot is the floating-base Unitree G1 with 29 actuated joints, standing on
the floor of its MJCF and simulated by SolverMuJoCo with 2 ms steps. A
controller runs at 100 Hz: every 10 ms it reads the robot's state and returns
one :class:`Command` for the next control period. Each joint actuator then
applies, at every 2 ms physics step,

    tau = clip(kp * (q - q_joint) + kd * (qd - qd_joint) + tau_ff, -limit, limit)

with the MJCF torque limit of its joint. The plant (``build_model``,
``make_solver``, :class:`Robot`) is fixed; the controller is the part to develop.

Reference motions are MuJoCo-qpos CSV clips at 30 fps: root position [m], root
quaternion (w, x, y, z), and the 29 joint angles [rad] in MJCF order. The robot
starts at rest at the clip's first frame with its feet 2 mm above the floor.

The :class:`Controller` plans with floating-base contact dynamics and tracks
the motion with full-body feedback and a nonlinear receding-horizon fallback.

Run: ``python g1_mpc.py --motion walk.csv --viewer null`` (the whole clip; ``--num-frames N``
runs N control periods) prints the tracking report.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
import warp as wp

import newton
import newton.examples

SIM_DT = 0.002  # physics step [s]
CONTROL_DT = 0.01  # control period [s] (100 Hz)
SUBSTEPS = round(CONTROL_DT / SIM_DT)
JOINT_COUNT = 29

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)

# Accepted actuator gains: kp [N m/rad] and kd [N m s/rad] per joint.
KP_RANGE = (1.0, 10000.0)
KD_RANGE = (0.0, 500.0)

# The robot has fallen when the root drops below this height [m], its up axis tilts more than 45 degrees
# (cosine below 0.7), or anything but the feet touches the floor.
FALL_HEIGHT_M = 0.55
FALL_UP_COS = 0.7
FEET = ("left_ankle_roll_link", "right_ankle_roll_link")
WRISTS = ("left_wrist_yaw_link", "right_wrist_yaw_link")
# Foot contact spheres (centres in the ankle roll link frame [m]) and their radius [m].
SOLE_POINTS = np.array([[-0.05, -0.025, -0.03], [-0.05, 0.025, -0.03], [0.12, -0.03, -0.03], [0.12, 0.03, -0.03]])
SOLE_RADIUS = 0.005
SOLE_CENTER = np.array([0.035, 0.0, -0.035])
LIFT_REFERENCE_M = 0.03  # lift recall: reference sole clearance above this [m] ...
LIFT_ROBOT_M = 0.02  # ... counts when the robot's sole clearance is above this [m]
JITTER_HZ = 6.0  # jitter: joint-error RMS above this frequency [Hz]


def asset_path() -> str:
    return str(newton.utils.download_asset("unitree_g1") / "mjcf/g1_29dof_rev_1_0.xml")


def build_model(joint_q: np.ndarray | None = None) -> newton.Model:
    """The G1 on the MJCF floor with torque-limited joint actuators, optionally posed at ``joint_q``."""
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    builder.add_mjcf(asset_path(), collapse_fixed_joints=True)
    # Robot self-collision is excluded; the feet and body still collide with the floor.
    robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
    for i, shape in enumerate(robot_shapes):
        for other in robot_shapes[i + 1 :]:
            builder.add_shape_collision_filter_pair(shape, other)
    builder.joint_armature[6:] = ARMATURE.tolist()
    # MuJoCo position servos whose gains and targets Robot.apply sets from each Command.
    builder.joint_target_ke[6:] = [100.0] * JOINT_COUNT
    builder.joint_target_kd[6:] = [2.0] * JOINT_COUNT
    builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * JOINT_COUNT
    builder.custom_attributes["mujoco:ctrl_source"].values = [
        int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
    ] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcerange"].values = [
        (-limit, limit) for limit in builder.joint_effort_limit[6:]
    ]
    if joint_q is not None:
        builder.joint_q[:] = np.asarray(joint_q, dtype=float).tolist()
    return builder.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverMuJoCo:
    return newton.solvers.SolverMuJoCo(
        model, njmax=192, nconmax=64, use_mujoco_contacts=True, integrator="implicitfast", iterations=50
    )


def quat_wxyz_to_xyzw(q: np.ndarray) -> np.ndarray:
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def body_index(model: newton.Model, name: str) -> int:
    return [label.rsplit("/", 1)[-1] for label in model.body_label].index(name)


class MotionClip:
    """A reference clip, linearly interpolated in time (root quaternion by normalized lerp).

    With a model, the clip is shifted vertically so that the lowest foot contact point of its first frame
    is 2 mm above the floor (the robot starts there).
    """

    def __init__(self, path, model: newton.Model | None = None, fps: float = 30.0):
        self.qpos = np.loadtxt(path, delimiter=",", ndmin=2)
        if self.qpos.shape[1] != 7 + JOINT_COUNT or len(self.qpos) < 2:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps
        self.z_offset = 0.0
        if model is not None:
            self.z_offset = floor_offset(model, self.sample(0.0))

    def sample(self, t: float) -> np.ndarray:
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time ``t`` [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        q[2] += self.z_offset
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


def floor_offset(model: newton.Model, joint_q: np.ndarray) -> float:
    """Vertical shift [m] that puts the lowest foot contact point of ``joint_q`` 2 mm above the floor."""
    state = model.state()
    newton.eval_fk(model, wp.array(joint_q, dtype=float, device=model.device), model.joint_qd, state)
    body_q = state.body_q.numpy().astype(np.float64)
    lowest = np.inf
    for name in FEET:
        pose = body_q[body_index(model, name)]
        points = pose[:3] + SOLE_POINTS @ _rotation(pose[3:7]).T
        lowest = min(lowest, float(points[:, 2].min()) - SOLE_RADIUS)
    return float(0.002 - lowest)


@dataclass
class Command:
    """Actuator command for one control period: per-joint arrays of 29 values in MJCF joint order (scalars
    broadcast). Each actuator applies ``clip(kp (q - q_joint) + kd (qd - qd_joint) + tau, -limit, limit)``
    at every physics step of the period."""

    q: np.ndarray
    """Position targets [rad]."""
    kp: np.ndarray | float
    """Stiffness [N m/rad], within KP_RANGE."""
    kd: np.ndarray | float
    """Damping [N m s/rad], within KD_RANGE."""
    qd: np.ndarray | float = 0.0
    """Velocity targets [rad/s]."""
    tau: np.ndarray | float = 0.0
    """Feedforward torques [N m]."""


def command_arrays(command) -> dict[str, np.ndarray]:
    """The command's fields as float64 arrays of 29 values; raises ValueError for invalid commands."""
    out = {}
    for name in ("q", "kp", "kd", "qd", "tau"):
        value = getattr(command, name, 0.0)
        value = np.broadcast_to(np.asarray(0.0 if value is None else value, dtype=np.float64), (JOINT_COUNT,))
        if not np.all(np.isfinite(value)):
            raise ValueError(f"Command.{name} is not finite")
        out[name] = value.copy()
    for name, (low, high) in (("kp", KP_RANGE), ("kd", KD_RANGE)):
        if np.any(out[name] < low) or np.any(out[name] > high):
            raise ValueError(f"Command.{name} must be within [{low:g}, {high:g}]")
    return out


class Robot:
    """The simulated G1 (the plant): model, solver, state, and the actuator command interface."""

    def __init__(self, start_q: np.ndarray):
        self.model = build_model(start_q)
        self.solver = make_solver(self.model)
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.effort_limit = self.model.joint_effort_limit.numpy()[6:].copy()
        # MuJoCo actuator -> actuated joint (0..28), for writing servo gains without a full model update.
        self._actuator_joint = self.solver.mjc_actuator_to_newton_idx.numpy() - 6
        self._gains = None
        self._target = self.model.joint_q.numpy().copy()
        self.graph = None
        self.capture()

    def capture(self):
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def simulate(self):
        """One control period of physics steps."""
        for i in range(SUBSTEPS):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, SIM_DT)
            if SUBSTEPS % 2 == 1 and i == SUBSTEPS - 1:
                self.state_0.assign(self.state_1)
            else:
                self.state_0, self.state_1 = self.state_1, self.state_0

    def apply(self, command) -> None:
        """Set the actuators from a :class:`Command` (the servo target absorbs qd and tau, which is exact)."""
        c = command_arrays(command)
        gains = np.concatenate([c["kp"], c["kd"]])
        if self._gains is None or not np.array_equal(gains, self._gains):
            ke, kd = self.model.joint_target_ke.numpy(), self.model.joint_target_kd.numpy()
            ke[6:], kd[6:] = c["kp"], c["kd"]
            self.model.joint_target_ke.assign(ke)
            self.model.joint_target_kd.assign(kd)
            # Same effect as solver.notify_model_changed(JOINT_DOF_PROPERTIES) on the servos, which is much slower.
            gain, bias = self.solver.mjw_model.actuator_gainprm, self.solver.mjw_model.actuator_biasprm
            gain_np, bias_np = gain.numpy(), bias.numpy()
            gain_np[:, :, 0] = c["kp"][self._actuator_joint]
            bias_np[:, :, 1] = -c["kp"][self._actuator_joint]
            bias_np[:, :, 2] = -c["kd"][self._actuator_joint]
            gain.assign(gain_np)
            bias.assign(bias_np)
            self._gains = gains
        self._target[7:] = c["q"] + (c["kd"] * c["qd"] + c["tau"]) / c["kp"]
        self.control.joint_target_q.assign(self._target)

    def advance(self):
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()


def _quat_angle(a: np.ndarray, b: np.ndarray) -> float:
    """Angle [rad] between two unit quaternions (xyzw)."""
    return float(2.0 * np.arccos(np.clip(abs(np.dot(a, b)), 0.0, 1.0)))


def _rotation(quat_xyzw: np.ndarray) -> np.ndarray:
    x, y, z, w = quat_xyzw / np.linalg.norm(quat_xyzw)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def foot_points(body_q: np.ndarray, foot: int) -> tuple[np.ndarray, float]:
    """Sole centre [m] and sole clearance above the floor [m] of a foot body."""
    rotation = _rotation(body_q[foot, 3:7])
    clearance = float(np.min((body_q[foot, :3] + SOLE_POINTS @ rotation.T)[:, 2]) - SOLE_RADIUS)
    return body_q[foot, :3] + rotation @ SOLE_CENTER, clearance


def jitter(errors: np.ndarray, dt: float, cutoff: float = JITTER_HZ, trim: float = 0.1) -> float:
    """RMS [rad] of the joint errors' content above ``cutoff`` [Hz] (zero-phase, ``trim`` [s] cut at both ends)."""
    k = round(trim / dt)
    errors = errors[k : len(errors) - k]
    if len(errors) < 16:
        return float("nan")
    errors = errors - errors.mean(axis=0)
    spectrum = np.fft.rfft(errors, axis=0)
    spectrum[np.fft.rfftfreq(len(errors), dt) <= cutoff] = 0.0
    return float(np.sqrt(np.mean(np.fft.irfft(spectrum, n=len(errors), axis=0) ** 2)))


class TrackingReport:
    """Tracking errors against a reference clip, sampled after every control period."""

    def __init__(self, robot: Robot, motion: MotionClip):
        self.robot, self.motion = robot, motion
        model = robot.model
        self.scratch = model.state()
        self.joint_q = wp.zeros(model.joint_coord_count, dtype=float, device=model.device)
        self.feet = [body_index(model, name) for name in FEET]
        self.wrists = [body_index(model, name) for name in WRISTS]
        mj = robot.solver.mj_model
        foot_ids = {i for i in range(mj.nbody) if mj.body(i).name.endswith(FEET)}
        # MuJoCo geoms that may touch the floor: those of the feet.
        self.foot_geom = np.array([int(mj.geom_bodyid[g]) in foot_ids for g in range(mj.ngeom)])
        self.robot_geom = np.array([int(mj.geom_bodyid[g]) != 0 for g in range(mj.ngeom)])
        self.rows = []
        self.fall_time = None
        self.fall_reason = None

    def non_foot_contact(self) -> bool:
        """Whether a robot geom other than the feet touches the floor."""
        data = self.robot.solver.mjw_data
        count = min(int(data.nacon.numpy()[0]), data.contact.geom.shape[0])
        if count == 0:
            return False
        geoms = data.contact.geom.numpy()[:count]
        touching = data.contact.dist.numpy()[:count] <= 0.0
        robot = self.robot_geom[geoms]
        other = robot & ~self.foot_geom[geoms]
        return bool(np.any(touching & other.any(axis=1)))

    def update(self, t: float, state: newton.State) -> bool:
        """Record the errors of ``state`` at time ``t`` [s]; returns whether the robot is still on its feet.

        Recording stops at a fall. Samples at or after ``t`` are dropped first (the clock was rewound)."""
        while self.rows and self.rows[-1]["t"] >= t - 1e-9:
            self.rows.pop()
        if self.fall_time is not None and self.fall_time >= t - 1e-9:
            self.fall_time = self.fall_reason = None
        if self.fall_time is not None:
            return False
        q = state.joint_q.numpy().astype(np.float64)
        body_q = state.body_q.numpy().astype(np.float64)
        ref = self.motion.sample(t)
        self.joint_q.assign(ref)
        newton.eval_fk(self.robot.model, self.joint_q, self.robot.model.joint_qd, self.scratch)
        ref_body_q = self.scratch.body_q.numpy().astype(np.float64)
        finite = bool(np.all(np.isfinite(q)) and np.all(np.isfinite(body_q)))
        quat = q[3:7] / np.linalg.norm(q[3:7]) if finite else ref[3:7]
        soles = [foot_points(body_q, f) for f in self.feet]
        ref_soles = [foot_points(ref_body_q, f) for f in self.feet]
        row = {
            "t": t,
            "finite": finite,
            "root_err": float(np.linalg.norm(q[:3] - ref[:3])),
            "root_rot_err": _quat_angle(quat, ref[3:7]),
            "joint_err": q[7:] - ref[7:],
            "wrist_err2": float(np.mean(np.sum((body_q[self.wrists, :3] - ref_body_q[self.wrists, :3]) ** 2, axis=1))),
            "sole_err2": float(np.mean([np.sum((a[0] - b[0]) ** 2) for a, b in zip(soles, ref_soles, strict=True)])),
            "lift": [(b[1] > LIFT_REFERENCE_M, a[1] > LIFT_ROBOT_M) for a, b in zip(soles, ref_soles, strict=True)],
        }
        self.rows.append(row)
        reason = None
        if not finite:
            reason = "state not finite"
        elif q[2] < FALL_HEIGHT_M:
            reason = f"root height {q[2]:.2f} m"
        elif _rotation(quat)[2, 2] < FALL_UP_COS:
            reason = "root tilted over"
        elif self.non_foot_contact():
            reason = "non-foot floor contact"
        if reason is not None:
            self.fall_time, self.fall_reason = t, reason
        return reason is None

    def summary(self) -> dict:
        """Metrics over the recorded samples, up to a fall (errors are infinite if the state stopped being finite)."""
        rows = self.rows
        finite = bool(rows) and all(r["finite"] for r in rows)
        inf = float("inf")

        def rms(values):
            return float(np.sqrt(np.mean(np.square(values)))) if finite else inf

        lifts = [robot for r in rows for ref, robot in r["lift"] if ref]
        errors = np.array([r["joint_err"] for r in rows]) if finite else None
        return {
            "upright": self.fall_time is None and finite,
            "fall_time_s": self.fall_time,
            "fall_reason": self.fall_reason,
            "survival": 1.0 if self.fall_time is None else self.fall_time / self.motion.duration,
            "root_rmse_m": rms([r["root_err"] for r in rows]),
            "root_rot_rmse_deg": float(np.degrees(rms([r["root_rot_err"] for r in rows]))),
            "joint_rmse_rad": rms(errors) if finite else inf,
            "wrist_rmse_m": float(np.sqrt(np.mean([r["wrist_err2"] for r in rows]))) if finite else inf,
            "sole_rmse_m": float(np.sqrt(np.mean([r["sole_err2"] for r in rows]))) if finite else inf,
            "lift_recall": float(np.mean(lifts)) if lifts else None,
            "jitter_mrad": 1000.0 * jitter(errors, CONTROL_DT) if finite else inf,
            "root_err_max_m": max(r["root_err"] for r in rows) if finite else inf,
            "samples": len(rows),
        }


class _DynamicsPlanner:
    """MuJoCo shooting model, reference costs, and a regularized iLQR step.

    Only this private model is used for predictions. Its actuator law has the
    same gains, damping and torque limits as the Commands sent to the robot.
    State perturbations use MuJoCo's 35-dimensional configuration tangent.
    """

    def __init__(self, mj_model, motion, *, period, horizon, physics_dt, feedforward=False):
        import copy
        import mujoco
        from scipy.linalg import cho_factor, cho_solve
        from scipy.ndimage import gaussian_filter1d

        self.mj = mujoco
        self.cho_factor, self.cho_solve = cho_factor, cho_solve
        self.m = copy.copy(mj_model)
        self.motion = motion
        self.dt, self.H, self.physics_dt = period, horizon, physics_dt
        self.substeps = round(period / physics_dt)
        self.m.opt.timestep = physics_dt
        self.m.opt.iterations = 20
        self.m.actuator_forcelimited[:] = 1
        self.kp = np.array([160, 160, 100, 180, 80, 80] * 2 + [140, 100, 100] + [60] * 14, dtype=float)
        self.kd = np.array([8, 8, 5, 8, 4, 4] * 2 + [6, 5, 5] + [3] * 14, dtype=float)
        self.m.actuator_gainprm[:, 0] = self.kp
        self.m.actuator_biasprm[:, 1] = -self.kp
        self.m.actuator_biasprm[:, 2] = -self.kd
        self.margin = .9 * self.m.actuator_forcerange[:, 1] / self.kp
        self.feet = [next(i for i in range(self.m.nbody) if self.m.body(i).name.endswith(name)) for name in FEET]

        padding = 25 if feedforward else horizon
        times = np.arange(0, motion.duration + period * (padding + 2), period)
        qs = np.array([motion.sample(t) for t in times])
        qs[:, 3:7] = qs[:, [6, 3, 4, 5]]
        for i in range(1, len(qs)):
            if qs[i, 3:7] @ qs[i - 1, 3:7] < 0:
                qs[i, 3:7] *= -1
        # Smooth the 30 Hz interpolation corners without changing clip timing.
        qs = gaussian_filter1d(qs, .01 / period, axis=0, mode="nearest")
        qs[:, 3:7] /= np.linalg.norm(qs[:, 3:7], axis=1)[:, None]
        vs = np.zeros((len(qs), 35))
        for i in range(len(qs)):
            a, b = max(0, i - 1), min(len(qs) - 1, i + 1)
            mujoco.mj_differentiatePos(self.m, vs[i], (b - a) * period, qs[a], qs[b])
        self.qs, self.vs = qs, vs
        self.us = qs[:, 7:] + self.kd / self.kp * vs[:, 6:]
        self.ps = np.zeros((len(qs), 2, 3))
        d = mujoco.MjData(self.m)
        for i, q in enumerate(qs):
            d.qpos[:] = q
            mujoco.mj_kinematics(self.m, d)
            for f, body in enumerate(self.feet):
                self.ps[i, f] = d.xpos[body] + d.xmat[body].reshape(3, 3) @ SOLE_CENTER
        if feedforward:
            self._reference_torques(d)

        self.data = [mujoco.MjData(self.m) for _ in range(horizon + 1)]
        self.trial = [mujoco.MjData(self.m) for _ in range(horizon + 1)]
        self.mid = mujoco.MjData(self.m)
        self.A = np.zeros((horizon, 70, 70))
        self.B = np.zeros((horizon, 70, 29))
        self.A0, self.B0 = np.zeros((70, 70)), np.zeros((70, 29))
        self.K, self.k = np.zeros((horizon, 29, 70)), np.zeros((horizon, 29))
        self.W = np.r_[np.full(3, 3000.), np.full(3, 500.),
                       np.full(12, 30.), np.full(3, 80.), np.full(14, 20.),
                       [30, 30, 15, 5, 5, 5], np.full(29, .15)]
        self.R = np.full(29, 2.)
        self.U = self.us[:horizon].copy()
        self.reg = 10.
        self.jp = np.zeros((3, 35))
        self.last_t = None

    def _reference_torques(self, d):
        """Inverse-dynamics seed with unilateral, friction-limited foot forces.

        This is an initial guess, not an assumed contact schedule. The shooting
        optimizer subsequently evaluates the actual collision dynamics.
        """
        import osqp
        from scipy import sparse

        mj, m = self.mj, self.m
        cone = np.zeros((40, 24))
        for p in range(8):
            cone[5*p:5*p+5, 3*p:3*p+3] = [[1, 0, -.6], [-1, 0, -.6],
                                          [0, 1, -.6], [0, -1, -.6], [0, 0, 1]]
        template = sparse.csc_matrix(np.triu(np.ones((24, 24))))
        rows = template.indices
        cols = np.repeat(np.arange(24), np.diff(template.indptr))
        lower, upper = np.full(40, -np.inf), np.zeros(40)
        lower[4::5], upper[4::5] = 0, 450
        qp = osqp.OSQP()
        qp.setup(P=template, q=np.zeros(24), A=sparse.csc_matrix(cone), l=lower, u=upper,
                 verbose=False, eps_abs=1e-3, eps_rel=1e-3, max_iter=200, polishing=False)
        accs = np.gradient(self.vs, self.dt, axis=0)
        mass, jac = np.zeros((35, 35)), np.zeros((24, 35))
        for i, q in enumerate(self.qs):
            d.qpos[:], d.qvel[:] = q, self.vs[i]
            mj.mj_forward(m, d)
            mj.mj_fullM(m, d, mass)
            net = mass @ accs[i] + d.qfrc_bias - d.qfrc_passive
            heights = np.zeros(8)
            for f, body in enumerate(self.feet):
                points = d.xpos[body] + SOLE_POINTS @ d.xmat[body].reshape(3, 3).T
                for k in range(4):
                    p = 4*f + k
                    heights[p] = points[k, 2] - SOLE_RADIUS
                    mj.mj_jac(m, d, jac[3*p:3*p+3], None, points[k], body)
            fitting = jac[:, :6].T * np.array([1, 1, 1, 3, 3, 3])[:, None]
            target = net[:6] * [1, 1, 1, 3, 3, 3]
            penalty = np.repeat(.001 * (1 + np.maximum(0, heights) * 1000), 3)
            hessian = fitting.T @ fitting + np.diag(penalty)
            upper[4::5] = np.where(heights < .03, 450, 0)
            qp.update(Px=hessian[rows, cols], q=-fitting.T @ target, u=upper)
            force = qp.solve(raise_error=False).x
            if force is not None and np.all(np.isfinite(force)):
                tau = net[6:] - jac[:, 6:].T @ force
                limit = .8 * m.actuator_forcerange[:, 1]
                self.us[i] += np.clip(tau, -limit, limit) / self.kp

    def state(self, joint_q, joint_qd):
        """Newton COM/world twist -> MuJoCo origin/body twist."""
        q = np.array(joint_q, dtype=float)
        q[3:7] = q[[6, 3, 4, 5]]
        rotation = _rotation(joint_q[3:7])
        v = np.array(joint_qd, dtype=float)
        v[:3] -= np.cross(joint_qd[3:6], rotation @ self.m.body_ipos[1])
        v[3:6] = rotation.T @ joint_qd[3:6]
        return q, v

    def cost(self, d, index, derivatives=False, terminal=False):
        mj, m = self.mj, self.m
        index = min(index, len(self.qs) - 1)
        error = np.zeros(70)
        mj.mj_differentiatePos(m, error[:35], 1., self.qs[index], d.qpos)
        error[35:] = d.qvel - self.vs[index]
        weight = self.W * (4 if terminal else 1)
        value = .5 * np.dot(weight * error, error)
        if derivatives:
            gradient, hessian = weight * error, np.diag(weight)
        mj.mj_kinematics(m, d)
        mj.mj_comPos(m, d)
        foot_weight = 1200. * (4 if terminal else 1)
        for f, body in enumerate(self.feet):
            point = d.xpos[body] + d.xmat[body].reshape(3, 3) @ SOLE_CENTER
            residual = point - self.ps[index, f]
            value += .5 * foot_weight * np.dot(residual, residual)
            if derivatives:
                mj.mj_jac(m, d, self.jp, None, point, body)
                gradient[:35] += foot_weight * self.jp.T @ residual
                hessian[:35, :35] += foot_weight * self.jp.T @ self.jp
        return (value, gradient, hessian) if derivatives else value

    def bounded_target(self, d, target):
        center = d.qpos[7:] + self.kd / self.kp * d.qvel[6:]
        # Stay inside saturation at the shooting nodes; the simulated actuator
        # still clips torque at every internal physics step.
        return np.clip(target, center - self.margin, center + self.margin)

    def advance(self, d):
        for _ in range(self.substeps):
            self.mj.mj_step(self.m, d)

    def backward(self, index=0, gaps=None, deadline=None):
        mj, m = self.mj, self.m
        m.opt.timestep = self.physics_dt
        gradients, hessians = [], []
        for h, d in enumerate(self.data[:-1]):
            if deadline is not None and time.perf_counter() >= deadline:
                return False
            _, gradient, hessian = self.cost(d, index+h, True)
            gradients.append(gradient)
            hessians.append(hessian)
            mj.mj_copyData(self.mid, m, d)
            a, b = np.eye(70), np.zeros((70, 29))
            for _ in range(self.substeps):
                mj.mj_forward(m, self.mid)
                mj.mjd_transitionFD(m, self.mid, 1e-5, False, self.A0, self.B0, None, None)
                b = self.A0 @ b + self.B0
                a = self.A0 @ a
                mj.mj_step(m, self.mid)
            self.A[h], self.B[h] = a, b
        _, vx, vxx = self.cost(self.data[-1], index+self.H, True, True)
        regularizer = np.diag(self.R + self.reg)
        for h in range(self.H - 1, -1, -1):
            a, b = self.A[h], self.B[h]
            if gaps is not None:
                vx = vx + vxx @ gaps[h]
            qx = gradients[h] + a.T @ vx
            qu = self.R * (self.U[h] - self.us[index+h]) + b.T @ vx
            qux = b.T @ vxx @ a
            quu = b.T @ vxx @ b + regularizer
            try:
                factor = self.cho_factor(quu, lower=True, check_finite=False)
                self.k[h] = -self.cho_solve(factor, qu, check_finite=False)
                self.K[h] = -self.cho_solve(factor, qux, check_finite=False)
            except np.linalg.LinAlgError:
                return False
            vx = qx + qux.T @ self.k[h]
            closed = a + b @ self.K[h]
            # This form avoids cancellation in the Riccati Hessian at impacts.
            vxx = hessians[h] + self.K[h].T @ regularizer @ self.K[h] + closed.T @ vxx @ closed
            vxx = .5 * (vxx + vxx.T)
        return np.all(np.isfinite(self.K)) and np.all(np.isfinite(self.k))

    def rollout(self, q, v, index, *, alpha=None):
        mj, m = self.mj, self.m
        m.opt.timestep = self.physics_dt
        ds = self.data if alpha is None else self.trial
        ds[0].qpos[:], ds[0].qvel[:] = q, v
        ds[0].qacc_warmstart[:] = 0
        value, controls = 0., np.empty_like(self.U)
        delta = np.zeros(70)
        for h in range(self.H):
            d = ds[h]
            target = self.U[h]
            if alpha is not None:
                mj.mj_differentiatePos(m, delta[:35], 1., self.data[h].qpos, d.qpos)
                delta[35:] = d.qvel - self.data[h].qvel
                target = target + alpha * self.k[h] + self.K[h] @ delta
            target = self.bounded_target(d, target)
            controls[h], d.ctrl[:] = target, target
            value += self.cost(d, index+h)
            du = target - self.us[index+h]
            value += .5 * np.dot(self.R * du, du)
            mj.mj_copyData(ds[h+1], m, d)
            self.advance(ds[h+1])
        value += self.cost(ds[-1], index+self.H, terminal=True)
        return value, controls

    def compute(self, t, joint_q, joint_qd):
        """A 350 ms receding horizon, warm-started at each 10 ms update."""
        q, v = self.state(joint_q, joint_qd)
        index = min(round(t / self.dt), len(self.qs) - self.H - 1)
        if self.last_t is None or t < self.last_t:
            self.U = self.us[index:index+self.H].copy()
            initial = True
        else:
            initial = False
            shift = max(0, round((t - self.last_t) / self.dt))
            if shift >= self.H:
                self.U = self.us[index:index+self.H].copy()
            elif shift:
                self.U = np.concatenate([self.U[shift:], self.us[index+self.H-shift:index+self.H]])
        self.last_t = t
        self.reg = min(self.reg, 100.)
        value, self.U = self.rollout(q, v, index)
        iterations = 20 if initial else (2 if index % 3 == 0 else 1)
        for _ in range(iterations):
            if not self.backward(index):
                self.reg = min(self.reg * 10, 1e6)
                continue
            for alpha in (1., .5, .25, .1, .03):
                candidate, controls = self.rollout(q, v, index, alpha=alpha)
                if np.isfinite(candidate) and candidate < value:
                    value, self.U = candidate, controls
                    self.data, self.trial = self.trial, self.data
                    self.reg = max(.1, self.reg * .7)
                    break
            else:
                self.reg = min(self.reg * 5, 1e6)
        return Command(self.U[0].copy(), self.kp, self.kd)


class _ClipPlan(_DynamicsPlanner):
    """Feasibility-driven shooting over the complete supplied motion.

    Initial states follow the clip and need not obey dynamics. Shooting gaps
    are progressively closed before accepting the resulting physical rollout.
    This supplies the long preview needed by repeated hops and weight shifts.
    """

    def __init__(self, mj_model, motion, start_q, deadline):
        super().__init__(mj_model, motion, period=.02, horizon=round(motion.duration/.02),
                         physics_dt=SIM_DT, feedforward=True)
        mj, m = self.mj, self.m
        self.start_q = np.array(start_q, dtype=float)
        self.start_q[3:7] = self.start_q[[6, 3, 4, 5]]
        self.gaps = np.zeros((self.H, 70))
        self.gap_weights = np.r_[np.full(35, 10000.), np.full(35, 100.)]
        for h, d in enumerate(self.data):
            d.qpos[:], d.qvel[:] = self.qs[h], self.vs[h]
            if h < self.H:
                self.U[h] = self.bounded_target(d, self.U[h])
                d.ctrl[:] = self.U[h]
        self.data[0].qpos[:], self.data[0].qvel[:] = self.start_q, 0
        self.reg = 100.
        merit, _, gap = self.evaluate(self.data, self.U, save=True)
        rejected = 0
        for _ in range(24):
            if time.perf_counter() >= deadline:
                break
            if not self.backward(gaps=self.gaps, deadline=deadline):
                self.reg = min(1e8, self.reg * 10)
                rejected += 1
                if rejected >= 4:
                    break
                continue
            accepted = False
            for alpha in (1., .5, .25, .1, .03, .01):
                controls = self.shooting_rollout(alpha)
                candidate, _, _ = self.evaluate(self.trial, controls, save=False)
                if np.isfinite(candidate) and candidate < merit:
                    self.U = controls
                    self.data, self.trial = self.trial, self.data
                    merit, _, gap = self.evaluate(self.data, self.U, save=True)
                    self.reg = min(1e7, self.reg * 3) if alpha < .25 else max(20., self.reg * .7)
                    accepted = True
                    rejected = 0
                    break
            if not accepted:
                self.reg = min(1e8, self.reg * 10)
                rejected += 1
                if rejected >= 4:
                    break
        self.usable = gap < 1e-3
        self.metrics = {}
        if self.usable:
            # The optimization trust parameter can become large at convergence.
            # Recompute a useful tracking gain, independently of that parameter.
            saved_gain = self.K.copy()
            self.reg = 20.
            if not self.backward(deadline=deadline + 15.):
                self.K[:] = saved_gain
            self.make_policy()

    def evaluate(self, ds, controls, *, save):
        mj, m = self.mj, self.m
        value, defect_cost, maximum = 0., 0., 0.
        gap = np.zeros(70)
        for h, d in enumerate(ds[:-1]):
            # Keep infeasible iterates near the intended upright trajectory.
            if np.linalg.norm(d.qpos[:3] - self.qs[h, :3]) > .2 or d.qpos[2] < .58:
                return np.inf, np.inf, np.inf
            value += self.cost(d, h)
            du = controls[h] - self.us[h]
            value += .5 * np.dot(self.R * du, du)
            mj.mj_copyData(self.mid, m, d)
            self.mid.ctrl[:] = controls[h]
            self.advance(self.mid)
            mj.mj_differentiatePos(m, gap[:35], 1., ds[h+1].qpos, self.mid.qpos)
            gap[35:] = self.mid.qvel - ds[h+1].qvel
            if save:
                self.gaps[h] = gap
            defect_cost += .5 * np.dot(self.gap_weights * gap, gap)
            maximum = max(maximum, np.abs(gap).max())
        value += self.cost(ds[-1], self.H, terminal=True)
        return value + defect_cost, value, maximum

    def shooting_rollout(self, alpha):
        mj, m, ds = self.mj, self.m, self.trial
        ds[0].qpos[:], ds[0].qvel[:] = self.start_q, 0
        ds[0].qacc_warmstart[:] = 0
        delta, controls = np.zeros(70), np.zeros_like(self.U)
        for h in range(self.H):
            d = ds[h]
            mj.mj_differentiatePos(m, delta[:35], 1., self.data[h].qpos, d.qpos)
            delta[35:] = d.qvel - self.data[h].qvel
            target = self.U[h] + alpha * self.k[h] + self.K[h] @ delta
            target = self.bounded_target(d, target)
            controls[h], d.ctrl[:] = target, target
            mj.mj_copyData(ds[h+1], m, d)
            self.advance(ds[h+1])
            if alpha < 1:
                mj.mj_integratePos(m, ds[h+1].qpos, self.gaps[h, :35], -(1-alpha))
                ds[h+1].qvel[:] -= (1-alpha) * self.gaps[h, 35:]
        return controls

    def make_policy(self):
        """Validate a physical rollout, and retain its states and feedback gains."""
        mj, m = self.mj, self.m
        d, reference_data = mj.MjData(m), mj.MjData(m)
        d.qpos[:], d.qvel[:] = self.start_q, 0
        qs, vs, us, gains = [], [], [], []
        errors = []
        safe = True
        delta = np.zeros(70)
        allowed = set(self.feet)
        for h in range(self.H):
            mj.mj_differentiatePos(m, delta[:35], 1., self.data[h].qpos, d.qpos)
            delta[35:] = d.qvel - self.data[h].qvel
            target = self.bounded_target(d, self.U[h] + self.K[h] @ delta)
            d.ctrl[:] = target
            for _ in range(2):
                qs.append(d.qpos.copy())
                vs.append(d.qvel.copy())
                us.append(target.copy())
                gains.append(self.K[h].copy())
                for _ in range(SUBSTEPS):
                    mj.mj_step(m, d)
                t = len(qs) * CONTROL_DT
                reference = self.motion.sample(t)
                reference_data.qpos[:] = reference
                reference_data.qpos[3:7] = reference[[6, 3, 4, 5]]
                mj.mj_kinematics(m, d)
                mj.mj_kinematics(m, reference_data)
                root_error = np.sum((d.qpos[:3] - reference[:3])**2)
                rotation_error = _quat_angle(d.qpos[[4, 5, 6, 3]], reference[3:7])**2
                joint_error = np.mean((d.qpos[7:] - reference[7:])**2)
                foot_error = 0.
                for body in self.feet:
                    p = d.xpos[body] + d.xmat[body].reshape(3, 3) @ SOLE_CENTER
                    r = reference_data.xpos[body] + reference_data.xmat[body].reshape(3, 3) @ SOLE_CENTER
                    foot_error += .5 * np.sum((p-r)**2)
                errors.append([root_error, rotation_error, joint_error, foot_error])
                safe &= d.qpos[2] > .56 and _rotation(d.qpos[[4, 5, 6, 3]])[2, 2] > .73
                for contact in d.contact[:d.ncon]:
                    if contact.dist <= 0:
                        bodies = m.geom_bodyid[contact.geom]
                        if any(body != 0 and body not in allowed for body in bodies):
                            safe = False
        self.nom_q, self.nom_v = np.array(qs), np.array(vs)
        self.nom_u, self.nom_K = np.array(us), np.array(gains)
        rms = np.sqrt(np.mean(errors, axis=0))
        self.metrics = dict(root=float(rms[0]), rotation=float(np.degrees(rms[1])),
                            joint=float(rms[2]), sole=float(rms[3]))
        self.usable = bool(safe and np.all(np.isfinite(rms)) and
                           np.all(rms < [.057, np.radians(9.5), .114, .0665]))

    def command(self, t, joint_q, joint_qd):
        q, v = self.state(joint_q, joint_qd)
        i = min(round(t / CONTROL_DT), len(self.nom_u) - 1)
        delta = np.zeros(70)
        self.mj.mj_differentiatePos(self.m, delta[:35], 1., self.nom_q[i], q)
        delta[35:] = v - self.nom_v[i]
        target = self.nom_u[i] + self.nom_K[i] @ delta
        return Command(target, self.kp, self.kd), delta


class Controller:
    """Whole-body optimal control, using only the supplied model and motion.

    A full-clip, feasibility-driven dynamics optimization handles long sequences
    of weight transfers and flights. A validated plan is tracked with a
    time-varying feedback policy. If the full plan cannot be made feasible, or
    the measured state departs from it, a warm-started 350 ms nonlinear MPC
    controls the robot directly. No plant state is accessed except compute's
    arguments, and all physical actuation goes through the returned Command.
    """

    def __init__(self, model: newton.Model, motion: MotionClip):
        from threadpoolctl import threadpool_limits

        started = time.perf_counter()
        self._threadpool_limits = threadpool_limits
        self.motion = motion
        # Scope this setting to our work; restore library settings before returning.
        with threadpool_limits(limits=1, user_api="blas"):
            self._solver = make_solver(model)
            self._mpc = _DynamicsPlanner(self._solver.mj_model, motion, period=CONTROL_DT,
                                         horizon=35, physics_dt=.005)
            self._plan = _ClipPlan(self._solver.mj_model, motion, model.joint_q.numpy(), started + 90.)
        self.strategy = "full-clip plan with feedback" if self._plan.usable else "receding-horizon MPC"
        self._use_plan = self._plan.usable
        self.planning_seconds = time.perf_counter() - started

    def compute(self, t: float, joint_q: np.ndarray, joint_qd: np.ndarray) -> Command:
        """Return one 10 ms joint actuator command from the current full state."""
        with self._threadpool_limits(limits=1, user_api="blas"):
            if self._use_plan:
                command, delta = self._plan.command(t, joint_q, joint_qd)
                # Numerical contact differences are normally tiny. Replan if the
                # observed trajectory has moved substantially away from the policy.
                if np.linalg.norm(delta[:3]) < .04 and np.linalg.norm(delta[3:6]) < .18:
                    return command
                self._use_plan = False
                self.strategy = "receding-horizon MPC"
            return self._mpc.compute(t, joint_q, joint_qd)


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.frame_dt = CONTROL_DT
        self.sim_dt = SIM_DT
        self.sim_time = 0.0
        # The robot starts at rest at the clip's first frame; the controller plans on its own copy of the model.
        self.motion = MotionClip(args.motion, build_model())
        start = self.motion.sample(0.0)
        self.robot = Robot(start)
        planning_model = build_model(start)
        self.controller = Controller(planning_model, MotionClip(args.motion, planning_model))
        self.report = TrackingReport(self.robot, self.motion)
        self.compute_seconds = 0.0
        self.viewer.set_model(self.model)

    # The live host and viewers look for these on the example.
    @property
    def model(self):
        return self.robot.model

    @property
    def solver(self):
        return self.robot.solver

    @property
    def state_0(self):
        return self.robot.state_0

    @property
    def state_1(self):
        return self.robot.state_1

    @property
    def control(self):
        return self.robot.control

    def capture(self):
        self.robot.capture()

    def step(self):
        # Read the state first: the copy waits for the last physics step, which is not the controller's time.
        joint_q = self.state_0.joint_q.numpy().astype(np.float64)
        joint_qd = self.state_0.joint_qd.numpy().astype(np.float64)
        started = time.perf_counter()
        command = self.controller.compute(self.sim_time, joint_q, joint_qd)
        self.compute_seconds += time.perf_counter() - started
        self.robot.apply(command)
        self.robot.advance()
        self.sim_time += self.frame_dt
        self.report.update(self.sim_time, self.state_0)

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def print_report(self):
        summary = self.report.summary()
        print(f"tracked {self.sim_time:.2f} of {self.motion.duration:.2f} s")
        for key, value in summary.items():
            print(f"  {key}: {value:.4f}" if isinstance(value, float) else f"  {key}: {value}")
        print(f"  controller_seconds: {self.compute_seconds:.2f}")
        print(f"  controller_build_seconds: {self.controller.planning_seconds:.2f}")
        print(f"  controller_strategy: {self.controller.strategy}")

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, default="walk.csv", help="Reference clip (MuJoCo qpos CSV, 30 fps)")
        parser.set_defaults(num_frames=None)
        return parser


if __name__ == "__main__":
    parser = Example.create_parser()
    known, _ = parser.parse_known_args()
    if known.num_frames is None:
        parser.set_defaults(num_frames=round(MotionClip(known.motion).duration / CONTROL_DT))
    viewer, args = newton.examples.init(parser)
    example = Example(viewer, args)
    started = time.perf_counter()
    newton.examples.run(example, args)
    example.print_report()
    print(f"  wall_seconds: {time.perf_counter() - started:.2f}")
