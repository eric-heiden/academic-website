# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, adds three free fruits and a static wooden tray, and ``Example`` drives every
world with the logged commands as joint position targets, open loop. Geometry and
physical calibration are stored below; building the scene does not read the photos
or arm logs.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.035,
    "dt": 0.002,
    # Shared arm calibration: torque/command fits from arm_logs, refined against
    # the measured episode trajectory with the station's unchanged rigid links.
    "kp": [60.89935, 45.6955, 53.9797, 11.33233, 4.90631, 2.0],
    "kd": [2.72314, 2.30976, 2.74489, 1.33575, 0.65221, 0.2951],
    "armature": [0.0182738, 5e-05, 5e-05, 5e-05, 5e-05, 5e-05],
    "joint_friction": [0.486, 0.99998, 0.99998, 0.26317, 0.04664, 0.01624],
    "gripper_kp": 1000.0,
    "gripper_force": 14.0,
    "fruit_friction": 1.2,
    "rolling_friction": 0.0001,
    "gravcomp": [0.99878, 0.79561, 0.9797, 1.0, 1.0, 0.15651],
}


def add_scene(builder):
    """Photo-calibrated fruit and the shallow, sector-shaped wooden dish."""
    from scipy.spatial import ConvexHull

    def convex_mesh(points):
        points = np.asarray(points, dtype=np.float32)
        hull = ConvexHull(points)
        faces = hull.simplices.copy()
        for i, face in enumerate(faces):
            a, b, c = points[face]
            if np.dot(np.cross(b - a, c - a), hull.equations[i, :3]) < 0:
                faces[i, [1, 2]] = faces[i, [2, 1]]
        return newton.Mesh(points, faces.astype(np.int32).ravel())

    cfg = newton.ModelBuilder.ShapeConfig(
        density=0.0,
        mu=PARAMS["fruit_friction"],
        mu_torsional=0.002,
        mu_rolling=PARAMS["rolling_friction"],
        margin=0.0,
        gap=0.005,
    )

    def fruit(name, pos, radii, mass, color, yaw=0.0, pear=False):
        r = np.array(radii)
        inertia = mass / 5.0 * (np.sum(r * r) - r * r)
        rotation = wp.quat_from_axis_angle(wp.vec3(0, 0, 1), yaw)
        if pear:
            # Place the mass frame in the broad bulb, 10 mm from the profile origin.
            pos = np.asarray(pos) + np.asarray(wp.quat_rotate(rotation, wp.vec3(0, -.010, 0)))
        body = builder.add_body(
            label=name,
            xform=wp.transform(pos, rotation),
            mass=mass,
            com=wp.vec3(0, 0, 0),
            inertia=wp.mat33(np.diag(inertia)),
            lock_inertia=True,
        )
        if pear:
            fruit_cfg = cfg.copy()
            fruit_cfg.mu = .08
            # A convex pear profile lying on its side; broad base, tapered neck.
            points = []
            for y, radius in [
                (-.041, .004), (-.036, .017), (-.025, .026), (-.012, .028),
                (.0, .024), (.016, .017), (.030, .012), (.039, .004),
            ]:
                for angle in np.linspace(0, 2 * np.pi, 24, endpoint=False):
                    points.append([radius * np.cos(angle), y + .010, 1.05 * radius * np.sin(angle)])
            points = np.array(points, dtype=np.float32)
            mesh = convex_mesh(points)
            builder.add_shape_mesh(body, mesh=mesh, cfg=fruit_cfg, color=color, label=name + "_skin")
        else:
            builder.add_shape_ellipsoid(
                body, rx=r[0], ry=r[1], rz=r[2], cfg=cfg, color=color, label=name + "_skin"
            )

    # SI units. Each fruit has one collision shape, solid-ellipsoid inertia,
    # and no drives, damping, armature, or gravity compensation.
    fruit("pear", (.650, .334, .7794), (.028, .040, .0294), .10, (.82, .66, .02), yaw=-2.75, pear=True)
    fruit("orange", (.502, -.052, .778), (.031, .031, .028), .10, (.9, .20, .015))
    fruit("dark_fruit", (.651, -.187, .784), (.035, .035, .034), .12, (.12, .045, .025))

    # Outline deprojected from the initial photograph onto the table.
    outline = np.array(
        [[.9271, .1463], [.7721, -.0332], [.7118, .0157], [.6769, .0927],
         [.6847, .1839], [.7449, .1930], [.8441, .1813]],
        dtype=np.float32,
    )
    tray_cfg = newton.ModelBuilder.ShapeConfig(
        density=0.0, mu=.08, mu_torsional=.002, mu_rolling=.0012, margin=0.0, gap=.005
    )
    basin = np.array([.706, .072], dtype=np.float32)
    directions = outline - basin
    inner = basin + directions / np.linalg.norm(directions, axis=1)[:, None] * .025
    edge_z = [.784, .771, .769, .770, .779, .782, .770]
    vertices = np.array([[x, y, z] for z in [.750, .755] for x, y in inner], dtype=np.float32)
    builder.add_shape_mesh(
        -1, mesh=convex_mesh(vertices), cfg=tray_cfg, color=(.56, .34, .14), label="tray_floor"
    )
    # A shallow dished floor: seven pairs of planar wooden facets surround
    # a low central area. The rim and all floor vertices remain below 4 cm.
    for k in range(len(outline)):
        j = (k + 1) % len(outline)
        for n, triangle in enumerate([
            [(inner[k], .755), (outline[k], edge_z[k]), (outline[j], edge_z[j])],
            [(inner[k], .755), (outline[j], edge_z[j]), (inner[j], .755)],
        ]):
            vertices = [[float(p[0]), float(p[1]), .750] for p, z in triangle]
            vertices += [[float(p[0]), float(p[1]), z] for p, z in triangle]
            builder.add_shape_mesh(
                -1, mesh=convex_mesh(vertices), cfg=tray_cfg,
                color=(.56, .34, .14), label=f"tray_slope_{k}_{n}",
            )
    for k, a in enumerate(outline):
        b = outline[(k + 1) % len(outline)]
        tangent = (b - a) / np.linalg.norm(b - a)
        inward = np.array([tangent[1], -tangent[0]])
        vertices = []
        # The wooden rim has an inward bevel, rather than a flat balancing ledge.
        for end in [a - .002 * tangent, b + .002 * tangent]:
            for offset, z in [(-.004, .750), (.004, .750), (.004, .775), (-.004, .784)]:
                p = end + offset * inward
                vertices.append([p[0], p[1], z])
        builder.add_shape_mesh(
            -1, mesh=convex_mesh(vertices), cfg=tray_cfg,
            color=(.65, .43, .20), label=f"tray_rim_{k}",
        )


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    for j, label in enumerate(station.joint_label):
        name = label.rsplit("/", 1)[-1]
        d = station.joint_qd_start[j]
        if any(name == f"{side}_joint{k+1}" for side in SIDES for k in range(6)):
            k = int(name[-1]) - 1
            station.joint_target_ke[d] = PARAMS["kp"][k]
            station.joint_target_kd[d] = PARAMS["kd"][k]
            station.joint_armature[d] = PARAMS["armature"][k]
            station.joint_friction[d] = PARAMS["joint_friction"][k]
            station.joint_effort_limit[d] = 28.0 if k < 3 else 10.0
        elif name in [f"{s}_left_finger" for s in SIDES]:
            station.joint_target_ke[d] = PARAMS["gripper_kp"]
            station.joint_effort_limit[d] = PARAMS["gripper_force"]
    add_scene(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    gc = model.mujoco.gravcomp.numpy()
    for i, label in enumerate(model.body_label):
        name = label.rsplit("/", 1)[-1]
        if name in [f"{side}_link_{k+1}" for side in SIDES for k in range(6)]:
            gc[i] = PARAMS["gravcomp"][int(name[-1]) - 1]
    model.mujoco.gravcomp.assign(gc)
    torsion = model.shape_material_mu_torsional.numpy()
    rolling = model.shape_material_mu_rolling.numpy()
    for i, label in enumerate(model.shape_label):
        if '/left_arm/' in label or '/right_arm/' in label:
            torsion[i] = .002
            rolling[i] = .00005
    model.shape_material_mu_torsional.assign(torsion)
    model.shape_material_mu_rolling.assign(rolling)
    # Store authored contact properties on the model, including the solref mode,
    # so a complete SolverMuJoCo model refresh preserves them.
    model.mujoco.solref.assign(np.tile([.008, 1.0], (model.shape_count, 1)).astype(np.float32))
    model.mujoco.solref_mode.fill_(1)
    dims = model.mujoco.condim.numpy()
    for i, label in enumerate(model.shape_label):
        if label.startswith(("pear_", "orange_", "dark_fruit_", "tray_")):
            dims[i] = 6
    model.mujoco.condim.assign(dims)
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(
        model, use_mujoco_contacts=True, cone="elliptic",
        iterations=80, ls_iterations=50, nconmax=4096, njmax=8192,
    )


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
