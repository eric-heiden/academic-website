# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 humanoid tracking a reference motion (starter for a controller).

The robot is the floating-base Unitree G1 with 29 actuated joints, standing on
the floor of its MJCF and simulated by SolverMuJoCo with 2 ms steps. A
controller runs at 100 Hz: every 10 ms it reads the robot's state and returns
one :class:`Command` for the next control period. Each joint actuator then
applies, at every 2 ms physics step,

    tau = clip(kp * (q - q_joint) + kd * (qd - qd_joint) + tau_ff, -limit, limit)

with the MJCF torque limit of its joint. The plant (``build_model``,
``make_solver``, :class:`Robot`) is fixed; the controller is the part to develop.

Reference motions are MuJoCo-qpos CSV clips at 30 fps: root position [m], root
quaternion (w, x, y, z), and the 29 joint angles [rad] in MJCF order. The robot
starts at rest at the clip's first frame with its feet 2 mm above the floor.

The baseline :class:`Controller` servos every joint toward the reference angles.
It ignores balance and falls within about a second.

Run: ``python g1_mpc.py --motion walk.csv --viewer null`` (the whole clip; ``--num-frames N``
runs N control periods) prints the tracking report.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
import warp as wp

import newton
import newton.examples

SIM_DT = 0.002  # physics step [s]
CONTROL_DT = 0.01  # control period [s] (100 Hz)
SUBSTEPS = round(CONTROL_DT / SIM_DT)
JOINT_COUNT = 29

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)

# Accepted actuator gains: kp [N m/rad] and kd [N m s/rad] per joint.
KP_RANGE = (1.0, 10000.0)
KD_RANGE = (0.0, 500.0)

# The robot has fallen when the root drops below this height [m], its up axis tilts more than 45 degrees
# (cosine below 0.7), or anything but the feet touches the floor.
FALL_HEIGHT_M = 0.55
FALL_UP_COS = 0.7
FEET = ("left_ankle_roll_link", "right_ankle_roll_link")
WRISTS = ("left_wrist_yaw_link", "right_wrist_yaw_link")
# Foot contact spheres (centres in the ankle roll link frame [m]) and their radius [m].
SOLE_POINTS = np.array([[-0.05, -0.025, -0.03], [-0.05, 0.025, -0.03], [0.12, -0.03, -0.03], [0.12, 0.03, -0.03]])
SOLE_RADIUS = 0.005
SOLE_CENTER = np.array([0.035, 0.0, -0.035])
LIFT_REFERENCE_M = 0.03  # lift recall: reference sole clearance above this [m] ...
LIFT_ROBOT_M = 0.02  # ... counts when the robot's sole clearance is above this [m]
JITTER_HZ = 6.0  # jitter: joint-error RMS above this frequency [Hz]


def asset_path() -> str:
    return str(newton.utils.download_asset("unitree_g1") / "mjcf/g1_29dof_rev_1_0.xml")


def build_model(joint_q: np.ndarray | None = None) -> newton.Model:
    """The G1 on the MJCF floor with torque-limited joint actuators, optionally posed at ``joint_q``."""
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    builder.add_mjcf(asset_path(), collapse_fixed_joints=True)
    # Robot self-collision is excluded; the feet and body still collide with the floor.
    robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
    for i, shape in enumerate(robot_shapes):
        for other in robot_shapes[i + 1 :]:
            builder.add_shape_collision_filter_pair(shape, other)
    builder.joint_armature[6:] = ARMATURE.tolist()
    # MuJoCo position servos whose gains and targets Robot.apply sets from each Command.
    builder.joint_target_ke[6:] = [100.0] * JOINT_COUNT
    builder.joint_target_kd[6:] = [2.0] * JOINT_COUNT
    builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * JOINT_COUNT
    builder.custom_attributes["mujoco:ctrl_source"].values = [
        int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
    ] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcerange"].values = [
        (-limit, limit) for limit in builder.joint_effort_limit[6:]
    ]
    if joint_q is not None:
        builder.joint_q[:] = np.asarray(joint_q, dtype=float).tolist()
    return builder.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverMuJoCo:
    return newton.solvers.SolverMuJoCo(
        model, njmax=192, nconmax=64, use_mujoco_contacts=True, integrator="implicitfast", iterations=50
    )


def quat_wxyz_to_xyzw(q: np.ndarray) -> np.ndarray:
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def body_index(model: newton.Model, name: str) -> int:
    return [label.rsplit("/", 1)[-1] for label in model.body_label].index(name)


class MotionClip:
    """A reference clip, linearly interpolated in time (root quaternion by normalized lerp).

    With a model, the clip is shifted vertically so that the lowest foot contact point of its first frame
    is 2 mm above the floor (the robot starts there).
    """

    def __init__(self, path, model: newton.Model | None = None, fps: float = 30.0):
        self.qpos = np.loadtxt(path, delimiter=",", ndmin=2)
        if self.qpos.shape[1] != 7 + JOINT_COUNT or len(self.qpos) < 2:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps
        self.z_offset = 0.0
        if model is not None:
            self.z_offset = floor_offset(model, self.sample(0.0))

    def sample(self, t: float) -> np.ndarray:
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time ``t`` [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        q[2] += self.z_offset
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


def floor_offset(model: newton.Model, joint_q: np.ndarray) -> float:
    """Vertical shift [m] that puts the lowest foot contact point of ``joint_q`` 2 mm above the floor."""
    state = model.state()
    newton.eval_fk(model, wp.array(joint_q, dtype=float, device=model.device), model.joint_qd, state)
    body_q = state.body_q.numpy().astype(np.float64)
    lowest = np.inf
    for name in FEET:
        pose = body_q[body_index(model, name)]
        points = pose[:3] + SOLE_POINTS @ _rotation(pose[3:7]).T
        lowest = min(lowest, float(points[:, 2].min()) - SOLE_RADIUS)
    return float(0.002 - lowest)


@dataclass
class Command:
    """Actuator command for one control period: per-joint arrays of 29 values in MJCF joint order (scalars
    broadcast). Each actuator applies ``clip(kp (q - q_joint) + kd (qd - qd_joint) + tau, -limit, limit)``
    at every physics step of the period."""

    q: np.ndarray
    """Position targets [rad]."""
    kp: np.ndarray | float
    """Stiffness [N m/rad], within KP_RANGE."""
    kd: np.ndarray | float
    """Damping [N m s/rad], within KD_RANGE."""
    qd: np.ndarray | float = 0.0
    """Velocity targets [rad/s]."""
    tau: np.ndarray | float = 0.0
    """Feedforward torques [N m]."""


def command_arrays(command) -> dict[str, np.ndarray]:
    """The command's fields as float64 arrays of 29 values; raises ValueError for invalid commands."""
    out = {}
    for name in ("q", "kp", "kd", "qd", "tau"):
        value = getattr(command, name, 0.0)
        value = np.broadcast_to(np.asarray(0.0 if value is None else value, dtype=np.float64), (JOINT_COUNT,))
        if not np.all(np.isfinite(value)):
            raise ValueError(f"Command.{name} is not finite")
        out[name] = value.copy()
    for name, (low, high) in (("kp", KP_RANGE), ("kd", KD_RANGE)):
        if np.any(out[name] < low) or np.any(out[name] > high):
            raise ValueError(f"Command.{name} must be within [{low:g}, {high:g}]")
    return out


class Robot:
    """The simulated G1 (the plant): model, solver, state, and the actuator command interface."""

    def __init__(self, start_q: np.ndarray):
        self.model = build_model(start_q)
        self.solver = make_solver(self.model)
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.effort_limit = self.model.joint_effort_limit.numpy()[6:].copy()
        # MuJoCo actuator -> actuated joint (0..28), for writing servo gains without a full model update.
        self._actuator_joint = self.solver.mjc_actuator_to_newton_idx.numpy() - 6
        self._gains = None
        self._target = self.model.joint_q.numpy().copy()
        self.graph = None
        self.capture()

    def capture(self):
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def simulate(self):
        """One control period of physics steps."""
        for i in range(SUBSTEPS):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, SIM_DT)
            if SUBSTEPS % 2 == 1 and i == SUBSTEPS - 1:
                self.state_0.assign(self.state_1)
            else:
                self.state_0, self.state_1 = self.state_1, self.state_0

    def apply(self, command) -> None:
        """Set the actuators from a :class:`Command` (the servo target absorbs qd and tau, which is exact)."""
        c = command_arrays(command)
        gains = np.concatenate([c["kp"], c["kd"]])
        if self._gains is None or not np.array_equal(gains, self._gains):
            ke, kd = self.model.joint_target_ke.numpy(), self.model.joint_target_kd.numpy()
            ke[6:], kd[6:] = c["kp"], c["kd"]
            self.model.joint_target_ke.assign(ke)
            self.model.joint_target_kd.assign(kd)
            # Same effect as solver.notify_model_changed(JOINT_DOF_PROPERTIES) on the servos, which is much slower.
            gain, bias = self.solver.mjw_model.actuator_gainprm, self.solver.mjw_model.actuator_biasprm
            gain_np, bias_np = gain.numpy(), bias.numpy()
            gain_np[:, :, 0] = c["kp"][self._actuator_joint]
            bias_np[:, :, 1] = -c["kp"][self._actuator_joint]
            bias_np[:, :, 2] = -c["kd"][self._actuator_joint]
            gain.assign(gain_np)
            bias.assign(bias_np)
            self._gains = gains
        self._target[7:] = c["q"] + (c["kd"] * c["qd"] + c["tau"]) / c["kp"]
        self.control.joint_target_q.assign(self._target)

    def advance(self):
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()


def _quat_angle(a: np.ndarray, b: np.ndarray) -> float:
    """Angle [rad] between two unit quaternions (xyzw)."""
    return float(2.0 * np.arccos(np.clip(abs(np.dot(a, b)), 0.0, 1.0)))


def _rotation(quat_xyzw: np.ndarray) -> np.ndarray:
    x, y, z, w = quat_xyzw / np.linalg.norm(quat_xyzw)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def foot_points(body_q: np.ndarray, foot: int) -> tuple[np.ndarray, float]:
    """Sole centre [m] and sole clearance above the floor [m] of a foot body."""
    rotation = _rotation(body_q[foot, 3:7])
    clearance = float(np.min((body_q[foot, :3] + SOLE_POINTS @ rotation.T)[:, 2]) - SOLE_RADIUS)
    return body_q[foot, :3] + rotation @ SOLE_CENTER, clearance


def jitter(errors: np.ndarray, dt: float, cutoff: float = JITTER_HZ, trim: float = 0.1) -> float:
    """RMS [rad] of the joint errors' content above ``cutoff`` [Hz] (zero-phase, ``trim`` [s] cut at both ends)."""
    k = round(trim / dt)
    errors = errors[k : len(errors) - k]
    if len(errors) < 16:
        return float("nan")
    errors = errors - errors.mean(axis=0)
    spectrum = np.fft.rfft(errors, axis=0)
    spectrum[np.fft.rfftfreq(len(errors), dt) <= cutoff] = 0.0
    return float(np.sqrt(np.mean(np.fft.irfft(spectrum, n=len(errors), axis=0) ** 2)))


class TrackingReport:
    """Tracking errors against a reference clip, sampled after every control period."""

    def __init__(self, robot: Robot, motion: MotionClip):
        self.robot, self.motion = robot, motion
        model = robot.model
        self.scratch = model.state()
        self.joint_q = wp.zeros(model.joint_coord_count, dtype=float, device=model.device)
        self.feet = [body_index(model, name) for name in FEET]
        self.wrists = [body_index(model, name) for name in WRISTS]
        mj = robot.solver.mj_model
        foot_ids = {i for i in range(mj.nbody) if mj.body(i).name.endswith(FEET)}
        # MuJoCo geoms that may touch the floor: those of the feet.
        self.foot_geom = np.array([int(mj.geom_bodyid[g]) in foot_ids for g in range(mj.ngeom)])
        self.robot_geom = np.array([int(mj.geom_bodyid[g]) != 0 for g in range(mj.ngeom)])
        self.rows = []
        self.fall_time = None
        self.fall_reason = None

    def non_foot_contact(self) -> bool:
        """Whether a robot geom other than the feet touches the floor."""
        data = self.robot.solver.mjw_data
        count = min(int(data.nacon.numpy()[0]), data.contact.geom.shape[0])
        if count == 0:
            return False
        geoms = data.contact.geom.numpy()[:count]
        touching = data.contact.dist.numpy()[:count] <= 0.0
        robot = self.robot_geom[geoms]
        other = robot & ~self.foot_geom[geoms]
        return bool(np.any(touching & other.any(axis=1)))

    def update(self, t: float, state: newton.State) -> bool:
        """Record the errors of ``state`` at time ``t`` [s]; returns whether the robot is still on its feet.

        Recording stops at a fall. Samples at or after ``t`` are dropped first (the clock was rewound)."""
        while self.rows and self.rows[-1]["t"] >= t - 1e-9:
            self.rows.pop()
        if self.fall_time is not None and self.fall_time >= t - 1e-9:
            self.fall_time = self.fall_reason = None
        if self.fall_time is not None:
            return False
        q = state.joint_q.numpy().astype(np.float64)
        body_q = state.body_q.numpy().astype(np.float64)
        ref = self.motion.sample(t)
        self.joint_q.assign(ref)
        newton.eval_fk(self.robot.model, self.joint_q, self.robot.model.joint_qd, self.scratch)
        ref_body_q = self.scratch.body_q.numpy().astype(np.float64)
        finite = bool(np.all(np.isfinite(q)) and np.all(np.isfinite(body_q)))
        quat = q[3:7] / np.linalg.norm(q[3:7]) if finite else ref[3:7]
        soles = [foot_points(body_q, f) for f in self.feet]
        ref_soles = [foot_points(ref_body_q, f) for f in self.feet]
        row = {
            "t": t,
            "finite": finite,
            "root_err": float(np.linalg.norm(q[:3] - ref[:3])),
            "root_rot_err": _quat_angle(quat, ref[3:7]),
            "joint_err": q[7:] - ref[7:],
            "wrist_err2": float(np.mean(np.sum((body_q[self.wrists, :3] - ref_body_q[self.wrists, :3]) ** 2, axis=1))),
            "sole_err2": float(np.mean([np.sum((a[0] - b[0]) ** 2) for a, b in zip(soles, ref_soles, strict=True)])),
            "lift": [(b[1] > LIFT_REFERENCE_M, a[1] > LIFT_ROBOT_M) for a, b in zip(soles, ref_soles, strict=True)],
        }
        self.rows.append(row)
        reason = None
        if not finite:
            reason = "state not finite"
        elif q[2] < FALL_HEIGHT_M:
            reason = f"root height {q[2]:.2f} m"
        elif _rotation(quat)[2, 2] < FALL_UP_COS:
            reason = "root tilted over"
        elif self.non_foot_contact():
            reason = "non-foot floor contact"
        if reason is not None:
            self.fall_time, self.fall_reason = t, reason
        return reason is None

    def summary(self) -> dict:
        """Metrics over the recorded samples, up to a fall (errors are infinite if the state stopped being finite)."""
        rows = self.rows
        finite = bool(rows) and all(r["finite"] for r in rows)
        inf = float("inf")

        def rms(values):
            return float(np.sqrt(np.mean(np.square(values)))) if finite else inf

        lifts = [robot for r in rows for ref, robot in r["lift"] if ref]
        errors = np.array([r["joint_err"] for r in rows]) if finite else None
        return {
            "upright": self.fall_time is None and finite,
            "fall_time_s": self.fall_time,
            "fall_reason": self.fall_reason,
            "survival": 1.0 if self.fall_time is None else self.fall_time / self.motion.duration,
            "root_rmse_m": rms([r["root_err"] for r in rows]),
            "root_rot_rmse_deg": float(np.degrees(rms([r["root_rot_err"] for r in rows]))),
            "joint_rmse_rad": rms(errors) if finite else inf,
            "wrist_rmse_m": float(np.sqrt(np.mean([r["wrist_err2"] for r in rows]))) if finite else inf,
            "sole_rmse_m": float(np.sqrt(np.mean([r["sole_err2"] for r in rows]))) if finite else inf,
            "lift_recall": float(np.mean(lifts)) if lifts else None,
            "jitter_mrad": 1000.0 * jitter(errors, CONTROL_DT) if finite else inf,
            "root_err_max_m": max(r["root_err"] for r in rows) if finite else inf,
            "samples": len(rows),
        }


# ----------------------------------------------------------------------------------------------------------------------
# Sampling-based model predictive control (MPPI) on a batch of copies of the robot simulated on the GPU.
#
# The decision variables are offsets of the joint position targets from the reference, given at a few knots over the
# horizon and linearly interpolated. Every replan resets all planning worlds to the measured state, rolls out the
# nominal plan and noisy variations of it with the plant's own dynamics (same model, solver and time step), scores
# each rollout against the reference (root pose and velocity, joint angles, feet), and moves the nominal plan to the
# cost-weighted mean. The whole horizon is one captured CUDA graph.

# Command gains [N m/rad] and [N m s/rad] per joint (legs, waist, arms).
_LEG_KP = [250.0, 250.0, 150.0, 300.0, 120.0, 80.0]
_LEG_KD = [6.0, 6.0, 4.0, 8.0, 3.0, 2.0]
_ARM_KP = [80.0, 80.0, 60.0, 60.0, 30.0, 30.0, 30.0]
_ARM_KD = [3.0, 3.0, 2.0, 2.0, 1.0, 1.0, 1.0]
CONTROL_KP = np.array(_LEG_KP * 2 + [250.0, 200.0, 200.0] + _ARM_KP * 2)
CONTROL_KD = np.array(_LEG_KD * 2 + [6.0, 5.0, 5.0] + _ARM_KD * 2)
# Sampling noise on the target offsets [rad] per joint.
_LEG_SIGMA = [0.12, 0.10, 0.06, 0.12, 0.12, 0.10]
_ARM_SIGMA = [0.10, 0.08, 0.06, 0.08, 0.05, 0.05, 0.05]
NOISE_SIGMA = np.array(_LEG_SIGMA * 2 + [0.08, 0.06, 0.06] + _ARM_SIGMA * 2)
# Cost weights of the joint angle errors (the waist is weighted up: the planner otherwise bends it to balance).
JOINT_WEIGHT = np.array([3.0] * 12 + [30.0] * 3 + [1.5] * 14)


def _robot_builder(joint_q: np.ndarray, kp: np.ndarray, kd: np.ndarray) -> newton.ModelBuilder:
    """Same robot as :func:`build_model` (for the planner's own batched copy), with the given servo gains."""
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    builder.add_mjcf(asset_path(), collapse_fixed_joints=True)
    robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
    for i, shape in enumerate(robot_shapes):
        for other in robot_shapes[i + 1 :]:
            builder.add_shape_collision_filter_pair(shape, other)
    builder.joint_armature[6:] = ARMATURE.tolist()
    builder.joint_target_ke[6:] = [float(v) for v in kp]
    builder.joint_target_kd[6:] = [float(v) for v in kd]
    builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * JOINT_COUNT
    builder.custom_attributes["mujoco:ctrl_source"].values = [
        int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
    ] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcerange"].values = [
        (-limit, limit) for limit in builder.joint_effort_limit[6:]
    ]
    builder.joint_q[:] = np.asarray(joint_q, dtype=float).tolist()
    return builder


@wp.kernel
def _reset_worlds(
    x_q: wp.array[float],
    x_qd: wp.array[float],
    joint_q: wp.array[float],
    joint_qd: wp.array[float],
    cost: wp.array[float],
):
    w = wp.tid()
    for i in range(36):
        joint_q[w * 36 + i] = x_q[i]
    for i in range(35):
        joint_qd[w * 35 + i] = x_qd[i]
    cost[w] = 0.0


@wp.kernel
def _set_targets(
    k: int,
    knot: int,
    alpha: float,
    knot_count: int,
    t_index: wp.array[int],
    ref_target: wp.array2d[float],
    offsets: wp.array3d[float],
    target: wp.array[float],
):
    w, j = wp.tid()
    i = wp.min(t_index[0] + k, ref_target.shape[0] - 1)
    u = offsets[w, knot, j]
    if alpha > 0.0:
        u = (1.0 - alpha) * u + alpha * offsets[w, wp.min(knot + 1, knot_count - 1), j]
    target[w * 36 + 7 + j] = ref_target[i, j] + u


@wp.kernel
def _accumulate_cost(
    k: int,
    weight: float,
    t_index: wp.array[int],
    joint_q: wp.array[float],
    joint_qd: wp.array[float],
    body_q: wp.array[wp.transform],
    bodies_per_world: int,
    feet: wp.array[int],
    ref_q: wp.array2d[float],
    ref_qd: wp.array2d[float],
    ref_feet: wp.array3d[float],
    joint_weight: wp.array[float],
    w_pos: float,
    w_height: float,
    w_rot: float,
    w_vel: float,
    w_ang: float,
    w_foot: float,
    w_foot_z: float,
    cost: wp.array[float],
):
    w = wp.tid()
    i = wp.min(t_index[0] + k, ref_q.shape[0] - 1)
    q0 = w * 36
    d0 = w * 35
    c = float(0.0)
    dx = joint_q[q0 + 0] - ref_q[i, 0]
    dy = joint_q[q0 + 1] - ref_q[i, 1]
    dz = joint_q[q0 + 2] - ref_q[i, 2]
    c += w_pos * (dx * dx + dy * dy) + w_height * dz * dz
    q = wp.quat(joint_q[q0 + 3], joint_q[q0 + 4], joint_q[q0 + 5], joint_q[q0 + 6])
    r = wp.quat(ref_q[i, 3], ref_q[i, 4], ref_q[i, 5], ref_q[i, 6])
    e = wp.quat_inverse(r) * q
    s = wp.where(e[3] < 0.0, -2.0, 2.0)
    c += w_rot * s * s * (e[0] * e[0] + e[1] * e[1] + e[2] * e[2]) * 1.0
    for j in range(3):
        v = joint_qd[d0 + j] - ref_qd[i, j]
        c += w_vel * v * v
        a = joint_qd[d0 + 3 + j] - ref_qd[i, 3 + j]
        c += w_ang * a * a
    for j in range(29):
        d = joint_q[q0 + 7 + j] - ref_q[i, 7 + j]
        c += joint_weight[j] * d * d
    for f in range(2):
        p = wp.transform_point(body_q[w * bodies_per_world + feet[f]], wp.vec3(0.035, 0.0, -0.035))
        fx = p[0] - ref_feet[i, f, 0]
        fy = p[1] - ref_feet[i, f, 1]
        fz = p[2] - ref_feet[i, f, 2]
        c += w_foot * (fx * fx + fy * fy) + w_foot_z * fz * fz
    # Falling: root too low or tilted.
    up = wp.quat_rotate(q, wp.vec3(0.0, 0.0, 1.0))
    if joint_q[q0 + 2] < 0.6 or up[2] < 0.8:
        c += 1000.0
    cost[w] = cost[w] + weight * c


class Controller:
    """Sampling-based MPC (MPPI) of the joint position targets around the reference, planned on a GPU batch of
    copies of the robot.

    ``model`` is a copy of the plant's model posed at the start (``build_model(motion.sample(0.0))``), the
    controller's to use for planning; the simulated robot is a separate model the controller never sees.
    ``motion`` is the reference clip (a :class:`MotionClip` with the floor shift applied).
    """

    samples = 512
    horizon = 60  # control periods
    knot_spacing = 10  # control periods between knots
    temperature = 0.1  # MPPI temperature relative to the cost spread
    lookahead = 1  # control periods by which the nominal targets lead the reference
    rollout_budget = 145.0  # wall time [s] for all compute() calls and the physics of a clip
    weights = dict(
        w_pos=200.0, w_height=60.0, w_rot=100.0, w_vel=30.0, w_ang=2.0, w_foot=100.0, w_foot_z=120.0
    )

    def __init__(self, model: newton.Model, motion: MotionClip):
        self.motion = motion
        self.kp = CONTROL_KP.copy()
        self.kd = CONTROL_KD.copy()
        self.device = model.device
        self.rng = np.random.default_rng(0)
        start = motion.sample(0.0)
        n = self.samples
        robot = _robot_builder(start, self.kp, self.kd)
        batch = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(batch)
        batch.replicate(robot, n)
        self.plan_model = batch.finalize()
        self.solver = make_solver(self.plan_model)
        self.states = [self.plan_model.state(), self.plan_model.state()]
        self.control = self.plan_model.control()
        self.bodies_per_world = self.plan_model.body_count // n
        self.feet = wp.array([body_index(model, name) for name in FEET], dtype=int, device=self.device)

        # Reference at every control period (plus a horizon past the end).
        steps = int(round(motion.duration / CONTROL_DT)) + self.horizon + 2
        times = np.arange(steps) * CONTROL_DT
        ref_q = np.array([motion.sample(t) for t in times])
        ref_qd = np.zeros((steps, 35))
        dq = np.gradient(ref_q, CONTROL_DT, axis=0)
        ref_qd[:, :3] = dq[:, :3]
        ref_qd[:, 6:] = dq[:, 7:]
        for i in range(steps):
            # Angular velocity (world frame) from the quaternion derivative: omega = 2 dq/dt q^-1.
            x, y, z, w = ref_q[i, 3:7]
            dx, dy, dz, dw = dq[i, 3:7]
            ref_qd[i, 3] = 2 * (dx * w - dw * x - dy * z + dz * y)
            ref_qd[i, 4] = 2 * (dy * w - dw * y - dz * x + dx * z)
            ref_qd[i, 5] = 2 * (dz * w - dw * z - dx * y + dy * x)
        state = model.state()
        ref_feet = np.zeros((steps, 2, 3))
        foot_ids = [body_index(model, name) for name in FEET]
        q_dev = wp.zeros(model.joint_coord_count, dtype=float, device=self.device)
        for i in range(steps):
            q_dev.assign(ref_q[i])
            newton.eval_fk(model, q_dev, model.joint_qd, state)
            body_q = state.body_q.numpy().astype(np.float64)
            for f, b in enumerate(foot_ids):
                ref_feet[i, f] = body_q[b, :3] + _rotation(body_q[b, 3:7]) @ SOLE_CENTER
        self.ref_q_np, self.ref_qd_np = ref_q, ref_qd
        # Nominal targets: the reference one control period ahead, with its velocities through the damping.
        ahead = np.minimum(np.arange(steps) + self.lookahead, steps - 1)
        self.ref_target_np = ref_q[ahead, 7:] + self.kd / self.kp * ref_qd[ahead, 6:]
        self.ref_q = wp.array(ref_q, dtype=float, device=self.device)
        self.ref_qd = wp.array(ref_qd, dtype=float, device=self.device)
        self.ref_feet = wp.array(ref_feet, dtype=float, device=self.device)
        self.ref_target = wp.array(self.ref_target_np, dtype=float, device=self.device)
        self.joint_weight = wp.array(JOINT_WEIGHT, dtype=float, device=self.device)

        self.knot_count = self.horizon // self.knot_spacing + 1
        self.nominal = np.zeros((self.knot_count, JOINT_COUNT))
        self.offsets = wp.zeros((n, self.knot_count, JOINT_COUNT), dtype=float, device=self.device)
        self.x_q = wp.zeros(36, dtype=float, device=self.device)
        self.x_qd = wp.zeros(35, dtype=float, device=self.device)
        self.t_index = wp.zeros(1, dtype=int, device=self.device)
        self.cost = wp.zeros(n, dtype=float, device=self.device)
        # Wall-time bookkeeping for the rollout budget.
        self.total_steps = int(round(motion.duration / CONTROL_DT))
        self._started = self._returned = self._overhead = self._last_index = None
        self._plan_seconds = 0.0
        self._credit = 0.0
        self.graph = None
        self._rollout()  # compile and warm up
        if wp.get_device(self.device).is_cuda:
            with wp.ScopedCapture(device=self.device) as capture:
                self._rollout()
            self.graph = capture.graph

    def _rollout(self):
        n = self.samples
        s0, s1 = self.states
        wp.launch(_reset_worlds, dim=n, inputs=[self.x_q, self.x_qd, s0.joint_q, s0.joint_qd, self.cost])
        for k in range(self.horizon):
            knot, rem = divmod(k, self.knot_spacing)
            wp.launch(
                _set_targets,
                dim=(n, JOINT_COUNT),
                inputs=[
                    k,
                    knot,
                    rem / self.knot_spacing,
                    self.knot_count,
                    self.t_index,
                    self.ref_target,
                    self.offsets,
                    self.control.joint_target_q,
                ],
            )
            for _ in range(SUBSTEPS):
                s0.clear_forces()
                self.solver.step(s0, s1, self.control, None, SIM_DT)
                s0, s1 = s1, s0
            weight = 1.0 if k < self.horizon - 1 else 5.0
            wp.launch(
                _accumulate_cost,
                dim=n,
                inputs=[
                    k + 1,
                    weight,
                    self.t_index,
                    s0.joint_q,
                    s0.joint_qd,
                    s0.body_q,
                    self.bodies_per_world,
                    self.feet,
                    self.ref_q,
                    self.ref_qd,
                    self.ref_feet,
                    self.joint_weight,
                    *self.weights.values(),
                    self.cost,
                ],
            )

    def _shift_nominal(self, periods: int):
        """Advance the nominal knots by ``periods`` control periods (holding the last knot)."""
        if periods <= 0:
            return
        old_t = np.arange(self.knot_count) * self.knot_spacing
        new_t = old_t + periods
        self.nominal = np.stack([np.interp(new_t, old_t, self.nominal[:, j]) for j in range(JOINT_COUNT)], axis=1)

    def plan(self, t_index: int, joint_q: np.ndarray, joint_qd: np.ndarray):
        n = self.samples
        self.x_q.assign(joint_q)
        self.x_qd.assign(joint_qd)
        self.t_index.assign(np.array([t_index], dtype=np.int32))
        noise = self.rng.standard_normal((n, self.knot_count, JOINT_COUNT)) * NOISE_SIGMA
        noise[0] = 0.0
        candidates = self.nominal[None] + noise
        self.offsets.assign(candidates.astype(np.float32))
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self._rollout()
        cost = self.cost.numpy().astype(np.float64)
        cost += 0.05 * np.sum((candidates / NOISE_SIGMA) ** 2, axis=(1, 2)) / self.knot_count
        cost = np.where(np.isfinite(cost), cost, np.inf)
        best = np.min(cost)
        spread = max(np.median(cost) - best, 1e-6)
        weights = np.exp(-(cost - best) / (self.temperature * spread))
        weights /= weights.sum()
        self.nominal = np.einsum("n,nkj->kj", weights, candidates)
        self.last_cost = best

    def _should_plan(self, t_index: int, now: float) -> bool:
        """Whether to replan in this period: replan every period unless the rollout would exceed its time budget,
        then replan in the fraction of periods that fits (at least every 4th)."""
        if self._started is None:
            self._started = now
            return True
        if self._returned is not None:
            gap = now - self._returned  # physics and bookkeeping between calls
            self._overhead = gap if self._overhead is None else 0.9 * self._overhead + 0.1 * gap
        remaining = max(self.total_steps - t_index, 1)
        spare = self.rollout_budget - (now - self._started) - remaining * (self._overhead or 0.0)
        fraction = float(np.clip(spare / (remaining * max(self._plan_seconds, 1e-3)), 0.25, 1.0))
        self._credit += fraction
        if self._credit >= 1.0:
            self._credit -= 1.0
            return True
        return False

    def compute(self, t: float, joint_q: np.ndarray, joint_qd: np.ndarray) -> Command:
        """Command for the control period starting at ``t`` [s], given the state then: joint_q (root position [m],
        root quaternion xyzw, 29 joint angles [rad]) and joint_qd (root COM linear [m/s] and angular [rad/s]
        velocity in the world frame, 29 joint velocities [rad/s])."""
        now = time.perf_counter()
        t_index = int(round(t / CONTROL_DT))
        if self._last_index is not None:
            self._shift_nominal(t_index - self._last_index)
        self._last_index = t_index
        if self._should_plan(t_index, now):
            self.plan(t_index, joint_q, joint_qd)
            seconds = time.perf_counter() - now
            self._plan_seconds = seconds if self._plan_seconds == 0.0 else 0.8 * self._plan_seconds + 0.2 * seconds
        self._returned = time.perf_counter()
        i = min(t_index, len(self.ref_target_np) - 1)
        target = self.ref_target_np[i] + self.nominal[0]
        return Command(q=target, kp=self.kp, kd=self.kd)


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.frame_dt = CONTROL_DT
        self.sim_dt = SIM_DT
        self.sim_time = 0.0
        # The robot starts at rest at the clip's first frame; the controller plans on its own copy of the model.
        self.motion = MotionClip(args.motion, build_model())
        start = self.motion.sample(0.0)
        self.robot = Robot(start)
        planning_model = build_model(start)
        self.controller = Controller(planning_model, MotionClip(args.motion, planning_model))
        self.report = TrackingReport(self.robot, self.motion)
        self.compute_seconds = 0.0
        self.viewer.set_model(self.model)

    # The live host and viewers look for these on the example.
    @property
    def model(self):
        return self.robot.model

    @property
    def solver(self):
        return self.robot.solver

    @property
    def state_0(self):
        return self.robot.state_0

    @property
    def state_1(self):
        return self.robot.state_1

    @property
    def control(self):
        return self.robot.control

    def capture(self):
        self.robot.capture()

    def step(self):
        # Read the state first: the copy waits for the last physics step, which is not the controller's time.
        joint_q = self.state_0.joint_q.numpy().astype(np.float64)
        joint_qd = self.state_0.joint_qd.numpy().astype(np.float64)
        started = time.perf_counter()
        command = self.controller.compute(self.sim_time, joint_q, joint_qd)
        self.compute_seconds += time.perf_counter() - started
        self.robot.apply(command)
        self.robot.advance()
        self.sim_time += self.frame_dt
        self.report.update(self.sim_time, self.state_0)

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def print_report(self):
        summary = self.report.summary()
        print(f"tracked {self.sim_time:.2f} of {self.motion.duration:.2f} s")
        for key, value in summary.items():
            print(f"  {key}: {value:.4f}" if isinstance(value, float) else f"  {key}: {value}")
        print(f"  controller_seconds: {self.compute_seconds:.2f}")

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, default="walk.csv", help="Reference clip (MuJoCo qpos CSV, 30 fps)")
        parser.set_defaults(num_frames=None)
        return parser


if __name__ == "__main__":
    parser = Example.create_parser()
    known, _ = parser.parse_known_args()
    if known.num_frames is None:
        parser.set_defaults(num_frames=round(MotionClip(known.motion).duration / CONTROL_DT))
    viewer, args = newton.examples.init(parser)
    example = Example(viewer, args)
    started = time.perf_counter()
    newton.examples.run(example, args)
    example.print_report()
    print(f"  wall_seconds: {time.perf_counter() - started:.2f}")
