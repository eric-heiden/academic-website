# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 humanoid tracking a reference motion with nonlinear MPC.

The robot is the floating-base Unitree G1 with 29 actuated joints, standing on
the floor of its MJCF and simulated by SolverMuJoCo with 2 ms steps. A
controller runs at 100 Hz: every 10 ms it reads the robot's state and returns
one :class:`Command` for the next control period. Each joint actuator then
applies, at every 2 ms physics step,

    tau = clip(kp * (q - q_joint) + kd * (qd - qd_joint) + tau_ff, -limit, limit)

with the MJCF torque limit of its joint. The plant (``build_model``,
``make_solver``, :class:`Robot`) is fixed; the controller is the part to develop.

Reference motions are MuJoCo-qpos CSV clips at 30 fps: root position [m], root
quaternion (w, x, y, z), and the 29 joint angles [rad] in MJCF order. The robot
starts at rest at the clip's first frame with its feet 2 mm above the floor.

The :class:`Controller` optimizes a rolling 300 ms trajectory on its own model.
Its objective tracks the pose, soles, and center of mass, with a terminal
balance cost. Only the returned joint actuator command drives the plant.

Run: ``python g1_mpc.py --motion walk.csv --viewer null`` (the whole clip; ``--num-frames N``
runs N control periods) prints the tracking report.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
import warp as wp

import newton
import newton.examples

SIM_DT = 0.002  # physics step [s]
CONTROL_DT = 0.01  # control period [s] (100 Hz)
SUBSTEPS = round(CONTROL_DT / SIM_DT)
JOINT_COUNT = 29

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)

# Accepted actuator gains: kp [N m/rad] and kd [N m s/rad] per joint.
KP_RANGE = (1.0, 10000.0)
KD_RANGE = (0.0, 500.0)

# The robot has fallen when the root drops below this height [m], its up axis tilts more than 45 degrees
# (cosine below 0.7), or anything but the feet touches the floor.
FALL_HEIGHT_M = 0.55
FALL_UP_COS = 0.7
FEET = ("left_ankle_roll_link", "right_ankle_roll_link")
WRISTS = ("left_wrist_yaw_link", "right_wrist_yaw_link")
# Foot contact spheres (centres in the ankle roll link frame [m]) and their radius [m].
SOLE_POINTS = np.array([[-0.05, -0.025, -0.03], [-0.05, 0.025, -0.03], [0.12, -0.03, -0.03], [0.12, 0.03, -0.03]])
SOLE_RADIUS = 0.005
SOLE_CENTER = np.array([0.035, 0.0, -0.035])
LIFT_REFERENCE_M = 0.03  # lift recall: reference sole clearance above this [m] ...
LIFT_ROBOT_M = 0.02  # ... counts when the robot's sole clearance is above this [m]
JITTER_HZ = 6.0  # jitter: joint-error RMS above this frequency [Hz]


def asset_path() -> str:
    return str(newton.utils.download_asset("unitree_g1") / "mjcf/g1_29dof_rev_1_0.xml")


def build_model(joint_q: np.ndarray | None = None) -> newton.Model:
    """The G1 on the MJCF floor with torque-limited joint actuators, optionally posed at ``joint_q``."""
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    builder.add_mjcf(asset_path(), collapse_fixed_joints=True)
    # Robot self-collision is excluded; the feet and body still collide with the floor.
    robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
    for i, shape in enumerate(robot_shapes):
        for other in robot_shapes[i + 1 :]:
            builder.add_shape_collision_filter_pair(shape, other)
    builder.joint_armature[6:] = ARMATURE.tolist()
    # MuJoCo position servos whose gains and targets Robot.apply sets from each Command.
    builder.joint_target_ke[6:] = [100.0] * JOINT_COUNT
    builder.joint_target_kd[6:] = [2.0] * JOINT_COUNT
    builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * JOINT_COUNT
    builder.custom_attributes["mujoco:ctrl_source"].values = [
        int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
    ] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcerange"].values = [
        (-limit, limit) for limit in builder.joint_effort_limit[6:]
    ]
    if joint_q is not None:
        builder.joint_q[:] = np.asarray(joint_q, dtype=float).tolist()
    return builder.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverMuJoCo:
    return newton.solvers.SolverMuJoCo(
        model, njmax=192, nconmax=64, use_mujoco_contacts=True, integrator="implicitfast", iterations=50
    )


def quat_wxyz_to_xyzw(q: np.ndarray) -> np.ndarray:
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def body_index(model: newton.Model, name: str) -> int:
    return [label.rsplit("/", 1)[-1] for label in model.body_label].index(name)


class MotionClip:
    """A reference clip, linearly interpolated in time (root quaternion by normalized lerp).

    With a model, the clip is shifted vertically so that the lowest foot contact point of its first frame
    is 2 mm above the floor (the robot starts there).
    """

    def __init__(self, path, model: newton.Model | None = None, fps: float = 30.0):
        self.qpos = np.loadtxt(path, delimiter=",", ndmin=2)
        if self.qpos.shape[1] != 7 + JOINT_COUNT or len(self.qpos) < 2:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps
        self.z_offset = 0.0
        if model is not None:
            self.z_offset = floor_offset(model, self.sample(0.0))

    def sample(self, t: float) -> np.ndarray:
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time ``t`` [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        q[2] += self.z_offset
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


def floor_offset(model: newton.Model, joint_q: np.ndarray) -> float:
    """Vertical shift [m] that puts the lowest foot contact point of ``joint_q`` 2 mm above the floor."""
    state = model.state()
    newton.eval_fk(model, wp.array(joint_q, dtype=float, device=model.device), model.joint_qd, state)
    body_q = state.body_q.numpy().astype(np.float64)
    lowest = np.inf
    for name in FEET:
        pose = body_q[body_index(model, name)]
        points = pose[:3] + SOLE_POINTS @ _rotation(pose[3:7]).T
        lowest = min(lowest, float(points[:, 2].min()) - SOLE_RADIUS)
    return float(0.002 - lowest)


@dataclass
class Command:
    """Actuator command for one control period: per-joint arrays of 29 values in MJCF joint order (scalars
    broadcast). Each actuator applies ``clip(kp (q - q_joint) + kd (qd - qd_joint) + tau, -limit, limit)``
    at every physics step of the period."""

    q: np.ndarray
    """Position targets [rad]."""
    kp: np.ndarray | float
    """Stiffness [N m/rad], within KP_RANGE."""
    kd: np.ndarray | float
    """Damping [N m s/rad], within KD_RANGE."""
    qd: np.ndarray | float = 0.0
    """Velocity targets [rad/s]."""
    tau: np.ndarray | float = 0.0
    """Feedforward torques [N m]."""


def command_arrays(command) -> dict[str, np.ndarray]:
    """The command's fields as float64 arrays of 29 values; raises ValueError for invalid commands."""
    out = {}
    for name in ("q", "kp", "kd", "qd", "tau"):
        value = getattr(command, name, 0.0)
        value = np.broadcast_to(np.asarray(0.0 if value is None else value, dtype=np.float64), (JOINT_COUNT,))
        if not np.all(np.isfinite(value)):
            raise ValueError(f"Command.{name} is not finite")
        out[name] = value.copy()
    for name, (low, high) in (("kp", KP_RANGE), ("kd", KD_RANGE)):
        if np.any(out[name] < low) or np.any(out[name] > high):
            raise ValueError(f"Command.{name} must be within [{low:g}, {high:g}]")
    return out


class Robot:
    """The simulated G1 (the plant): model, solver, state, and the actuator command interface."""

    def __init__(self, start_q: np.ndarray):
        self.model = build_model(start_q)
        self.solver = make_solver(self.model)
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.effort_limit = self.model.joint_effort_limit.numpy()[6:].copy()
        # MuJoCo actuator -> actuated joint (0..28), for writing servo gains without a full model update.
        self._actuator_joint = self.solver.mjc_actuator_to_newton_idx.numpy() - 6
        self._gains = None
        self._target = self.model.joint_q.numpy().copy()
        self.graph = None
        self.capture()

    def capture(self):
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def simulate(self):
        """One control period of physics steps."""
        for i in range(SUBSTEPS):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, SIM_DT)
            if SUBSTEPS % 2 == 1 and i == SUBSTEPS - 1:
                self.state_0.assign(self.state_1)
            else:
                self.state_0, self.state_1 = self.state_1, self.state_0

    def apply(self, command) -> None:
        """Set the actuators from a :class:`Command` (the servo target absorbs qd and tau, which is exact)."""
        c = command_arrays(command)
        gains = np.concatenate([c["kp"], c["kd"]])
        if self._gains is None or not np.array_equal(gains, self._gains):
            ke, kd = self.model.joint_target_ke.numpy(), self.model.joint_target_kd.numpy()
            ke[6:], kd[6:] = c["kp"], c["kd"]
            self.model.joint_target_ke.assign(ke)
            self.model.joint_target_kd.assign(kd)
            # Same effect as solver.notify_model_changed(JOINT_DOF_PROPERTIES) on the servos, which is much slower.
            gain, bias = self.solver.mjw_model.actuator_gainprm, self.solver.mjw_model.actuator_biasprm
            gain_np, bias_np = gain.numpy(), bias.numpy()
            gain_np[:, :, 0] = c["kp"][self._actuator_joint]
            bias_np[:, :, 1] = -c["kp"][self._actuator_joint]
            bias_np[:, :, 2] = -c["kd"][self._actuator_joint]
            gain.assign(gain_np)
            bias.assign(bias_np)
            self._gains = gains
        self._target[7:] = c["q"] + (c["kd"] * c["qd"] + c["tau"]) / c["kp"]
        self.control.joint_target_q.assign(self._target)

    def advance(self):
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()


def _quat_angle(a: np.ndarray, b: np.ndarray) -> float:
    """Angle [rad] between two unit quaternions (xyzw)."""
    return float(2.0 * np.arccos(np.clip(abs(np.dot(a, b)), 0.0, 1.0)))


def _rotation(quat_xyzw: np.ndarray) -> np.ndarray:
    x, y, z, w = quat_xyzw / np.linalg.norm(quat_xyzw)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def foot_points(body_q: np.ndarray, foot: int) -> tuple[np.ndarray, float]:
    """Sole centre [m] and sole clearance above the floor [m] of a foot body."""
    rotation = _rotation(body_q[foot, 3:7])
    clearance = float(np.min((body_q[foot, :3] + SOLE_POINTS @ rotation.T)[:, 2]) - SOLE_RADIUS)
    return body_q[foot, :3] + rotation @ SOLE_CENTER, clearance


def jitter(errors: np.ndarray, dt: float, cutoff: float = JITTER_HZ, trim: float = 0.1) -> float:
    """RMS [rad] of the joint errors' content above ``cutoff`` [Hz] (zero-phase, ``trim`` [s] cut at both ends)."""
    k = round(trim / dt)
    errors = errors[k : len(errors) - k]
    if len(errors) < 16:
        return float("nan")
    errors = errors - errors.mean(axis=0)
    spectrum = np.fft.rfft(errors, axis=0)
    spectrum[np.fft.rfftfreq(len(errors), dt) <= cutoff] = 0.0
    return float(np.sqrt(np.mean(np.fft.irfft(spectrum, n=len(errors), axis=0) ** 2)))


class TrackingReport:
    """Tracking errors against a reference clip, sampled after every control period."""

    def __init__(self, robot: Robot, motion: MotionClip):
        self.robot, self.motion = robot, motion
        model = robot.model
        self.scratch = model.state()
        self.joint_q = wp.zeros(model.joint_coord_count, dtype=float, device=model.device)
        self.feet = [body_index(model, name) for name in FEET]
        self.wrists = [body_index(model, name) for name in WRISTS]
        mj = robot.solver.mj_model
        foot_ids = {i for i in range(mj.nbody) if mj.body(i).name.endswith(FEET)}
        # MuJoCo geoms that may touch the floor: those of the feet.
        self.foot_geom = np.array([int(mj.geom_bodyid[g]) in foot_ids for g in range(mj.ngeom)])
        self.robot_geom = np.array([int(mj.geom_bodyid[g]) != 0 for g in range(mj.ngeom)])
        self.rows = []
        self.fall_time = None
        self.fall_reason = None

    def non_foot_contact(self) -> bool:
        """Whether a robot geom other than the feet touches the floor."""
        data = self.robot.solver.mjw_data
        count = min(int(data.nacon.numpy()[0]), data.contact.geom.shape[0])
        if count == 0:
            return False
        geoms = data.contact.geom.numpy()[:count]
        touching = data.contact.dist.numpy()[:count] <= 0.0
        robot = self.robot_geom[geoms]
        other = robot & ~self.foot_geom[geoms]
        return bool(np.any(touching & other.any(axis=1)))

    def update(self, t: float, state: newton.State) -> bool:
        """Record the errors of ``state`` at time ``t`` [s]; returns whether the robot is still on its feet.

        Recording stops at a fall. Samples at or after ``t`` are dropped first (the clock was rewound)."""
        while self.rows and self.rows[-1]["t"] >= t - 1e-9:
            self.rows.pop()
        if self.fall_time is not None and self.fall_time >= t - 1e-9:
            self.fall_time = self.fall_reason = None
        if self.fall_time is not None:
            return False
        q = state.joint_q.numpy().astype(np.float64)
        body_q = state.body_q.numpy().astype(np.float64)
        ref = self.motion.sample(t)
        self.joint_q.assign(ref)
        newton.eval_fk(self.robot.model, self.joint_q, self.robot.model.joint_qd, self.scratch)
        ref_body_q = self.scratch.body_q.numpy().astype(np.float64)
        finite = bool(np.all(np.isfinite(q)) and np.all(np.isfinite(body_q)))
        quat = q[3:7] / np.linalg.norm(q[3:7]) if finite else ref[3:7]
        soles = [foot_points(body_q, f) for f in self.feet]
        ref_soles = [foot_points(ref_body_q, f) for f in self.feet]
        row = {
            "t": t,
            "finite": finite,
            "root_err": float(np.linalg.norm(q[:3] - ref[:3])),
            "root_rot_err": _quat_angle(quat, ref[3:7]),
            "joint_err": q[7:] - ref[7:],
            "wrist_err2": float(np.mean(np.sum((body_q[self.wrists, :3] - ref_body_q[self.wrists, :3]) ** 2, axis=1))),
            "sole_err2": float(np.mean([np.sum((a[0] - b[0]) ** 2) for a, b in zip(soles, ref_soles, strict=True)])),
            "lift": [(b[1] > LIFT_REFERENCE_M, a[1] > LIFT_ROBOT_M) for a, b in zip(soles, ref_soles, strict=True)],
        }
        self.rows.append(row)
        reason = None
        if not finite:
            reason = "state not finite"
        elif q[2] < FALL_HEIGHT_M:
            reason = f"root height {q[2]:.2f} m"
        elif _rotation(quat)[2, 2] < FALL_UP_COS:
            reason = "root tilted over"
        elif self.non_foot_contact():
            reason = "non-foot floor contact"
        if reason is not None:
            self.fall_time, self.fall_reason = t, reason
        return reason is None

    def summary(self) -> dict:
        """Metrics over the recorded samples, up to a fall (errors are infinite if the state stopped being finite)."""
        rows = self.rows
        finite = bool(rows) and all(r["finite"] for r in rows)
        inf = float("inf")

        def rms(values):
            return float(np.sqrt(np.mean(np.square(values)))) if finite else inf

        lifts = [robot for r in rows for ref, robot in r["lift"] if ref]
        errors = np.array([r["joint_err"] for r in rows]) if finite else None
        return {
            "upright": self.fall_time is None and finite,
            "fall_time_s": self.fall_time,
            "fall_reason": self.fall_reason,
            "survival": 1.0 if self.fall_time is None else self.fall_time / self.motion.duration,
            "root_rmse_m": rms([r["root_err"] for r in rows]),
            "root_rot_rmse_deg": float(np.degrees(rms([r["root_rot_err"] for r in rows]))),
            "joint_rmse_rad": rms(errors) if finite else inf,
            "wrist_rmse_m": float(np.sqrt(np.mean([r["wrist_err2"] for r in rows]))) if finite else inf,
            "sole_rmse_m": float(np.sqrt(np.mean([r["sole_err2"] for r in rows]))) if finite else inf,
            "lift_recall": float(np.mean(lifts)) if lifts else None,
            "jitter_mrad": 1000.0 * jitter(errors, CONTROL_DT) if finite else inf,
            "root_err_max_m": max(r["root_err"] for r in rows) if finite else inf,
            "samples": len(rows),
        }


class Controller:
    """Nonlinear whole-body MPC, solved with regularized iterative LQR.

    Thirty 10 ms shooting intervals predict all 35 velocities, the floating
    pose, contacts, actuator saturation, and joint limits. Finite-difference
    dynamics and Gauss--Newton task Hessians produce feedback search directions;
    a nonlinear rollout accepts only cost-reducing updates. The next call shifts
    the plan and optimizes again from the measured state.

    Center-of-mass tracking and a terminal ``position + 0.25 * velocity`` error
    discourage plans that track the pelvis while accumulating a balance error.
    The waist receives extra posture weight to preserve torso configuration.
    Contact phases come from forward dynamics, with no clip-specific schedule.

    ``model`` is exclusively the controller's planning copy. Its coarser time
    step is a planning approximation; the separate plant retains its 2 ms step.
    """

    def __init__(self, model: newton.Model, motion: MotionClip):
        import mujoco
        from scipy.linalg import cho_factor, cho_solve
        from threadpoolctl import threadpool_limits

        # Small Riccati matrices are faster with one BLAS worker.
        self._blas_threads = threadpool_limits(limits=1, user_api="blas")
        self.mj = mujoco
        self.cho_factor = cho_factor
        self.cho_solve = cho_solve
        self.motion = motion
        # Export the supplied planning model, including the plant's inertias,
        # armature, collision geometry, friction, and actuator force limits.
        self.solver = make_solver(model)
        self.m = self.solver.mj_model
        self.m.opt.timestep = 0.01
        self.m.opt.iterations = 50
        self.m.opt.tolerance = 1e-10
        self.kp = np.array([100, 100, 80, 150, 40, 40] * 2 + [120, 100, 100] + [40] * 14, dtype=float)
        self.kd = np.array([5, 5, 4, 8, 3, 3] * 2 + [6, 5, 5] + [3] * 14, dtype=float)
        self.m.actuator_gainprm[:, 0] = self.kp
        self.m.actuator_biasprm[:, 1] = -self.kp
        self.m.actuator_biasprm[:, 2] = -self.kd
        self.d = mujoco.MjData(self.m)
        self.fd = mujoco.MjData(self.m)
        self.feet = [next((i for i in range(self.m.nbody) if self.m.body(i).name.endswith(name))) for name in FEET]
        self.N = 30
        self.dt = 0.01
        self.wq = np.r_[[4000, 4000, 4000], [500, 500, 500], np.full(12, 30.0), np.full(3, 200.0), np.full(14, 30.0)]
        self.wv = np.r_[[40, 40, 40], [2, 2, 2], np.full(29, 0.1)]
        self.wu = 0.5
        self.wfoot = 1000.0
        self.baseH = np.diag(np.r_[self.wq, self.wv])
        self.reg = 1.0
        # Use sample(time), rather than a clip filename or an assumed playback
        # rate. This also handles a MotionClip constructed with a different fps.
        self.times = np.arange(round(motion.duration / self.dt) + self.N + 3) * self.dt
        self.refs = np.array([self._qpos(motion.sample(t)) for t in self.times])
        self.vels = np.zeros((len(self.times), 35))
        self.refsoles = np.zeros((len(self.times), 2, 3))
        self.refcom = np.zeros((len(self.times), 3))
        self.refcomvel = np.zeros_like(self.refcom)
        for (i, t) in enumerate(self.times):
            # A centered secant smooths the velocity of the 30 Hz linear input.
            h = 0.02
            tt = np.clip(t, h, motion.duration - h)
            mujoco.mj_differentiatePos(
                self.m, self.vels[i], 2 * h,
                self._qpos(motion.sample(tt - h)), self._qpos(motion.sample(tt + h)),
            )
            if t > motion.duration:
                self.vels[i] = 0
            self.fd.qpos[:] = self.refs[i]
            mujoco.mj_kinematics(self.m, self.fd)
            mujoco.mj_comPos(self.m, self.fd)
            Jc = np.zeros((3, 35))
            mujoco.mj_jacSubtreeCom(self.m, self.fd, Jc, 1)
            self.refcom[i] = self.fd.subtree_com[1]
            self.refcomvel[i] = Jc @ self.vels[i]
            for (j, f) in enumerate(self.feet):
                self.refsoles[i, j] = self.fd.xpos[f] + self.fd.xmat[f].reshape(3, 3) @ SOLE_CENTER
        # Absorb nominal velocity feedforward into the position-servo target.
        self.urefs = self.refs[:, 7:] + self.vels[:, 6:] * self.kd / self.kp
        self.us = self.urefs[:self.N].copy()
        self.last_index = 0
        self.debug = {}
        q = self._qpos(model.joint_q.numpy().astype(float))
        v = np.zeros(35)
        (self.us, self.last_cost) = self._optimize(q, v, 0, self.us, 12)

    def _qpos(self, q):
        """Newton xyzw root quaternion -> MuJoCo wxyz quaternion."""
        return np.r_[q[:3], q[6], q[3:6], q[7:]]

    def _difference(self, q1, v1, q2, v2):
        """State displacement in the 70-dimensional tangent space."""
        x = np.empty(70)
        self.mj.mj_differentiatePos(self.m, x[:35], 1.0, q1, q2)
        x[35:] = v2 - v1
        return x

    def _cost(self, d, index, u=None, derivatives=False, terminal=False):
        """Task cost and positive semidefinite Gauss--Newton approximation."""
        index = min(index, len(self.refs) - 1)
        err = np.empty(35)
        self.mj.mj_differentiatePos(self.m, err, 1.0, self.refs[index], d.qpos)
        ve = d.qvel - self.vels[index]
        fac = 4.0 if terminal else 1.0
        cost = 0.5 * fac * (np.dot(self.wq * err, err) + np.dot(self.wv * ve, ve))
        if derivatives:
            lx = fac * np.r_[self.wq * err, self.wv * ve]
            H = fac * self.baseH.copy()
        for (j, f) in enumerate(self.feet):
            p = d.xpos[f] + d.xmat[f].reshape(3, 3) @ SOLE_CENTER
            ep = p - self.refsoles[index, j]
            cost += 0.5 * fac * self.wfoot * np.dot(ep, ep)
            if derivatives:
                J = np.zeros((3, 35))
                self.mj.mj_jac(self.m, d, J, None, p, f)
                lx[:35] += fac * self.wfoot * (J.T @ ep)
                H[:35, :35] += fac * self.wfoot * (J.T @ J)
        Jc = np.zeros((3, 35))
        self.mj.mj_jacSubtreeCom(self.m, d, Jc, 1)
        ce = d.subtree_com[1] - self.refcom[index]
        cv = Jc @ d.qvel - self.refcomvel[index]
        cost += 0.5 * fac * (2000 * np.dot(ce, ce) + 40 * np.dot(cv, cv))
        if derivatives:
            lx[:35] += fac * 2000 * Jc.T @ ce
            lx[35:] += fac * 40 * Jc.T @ cv
            H[:35, :35] += fac * 2000 * Jc.T @ Jc
            H[35:, 35:] += fac * 40 * Jc.T @ Jc
        if terminal:
            # Approximate the unstable horizontal COM mode beyond the horizon.
            capture = ce[:2] + 0.25 * cv[:2]
            cost += 0.5 * 20000 * np.dot(capture, capture)
            if derivatives:
                E = np.c_[Jc[:2], 0.25 * Jc[:2]]
                lx += 20000 * E.T @ capture
                H += 20000 * E.T @ E
        if u is not None:
            eu = u - self.urefs[index]
            cost += 0.5 * self.wu * np.dot(eu, eu)
        if derivatives:
            return (cost, lx, H)
        return cost

    def _rollout(self, q, v, index, us, nominal=None, ks=None, Ks=None, alpha=1.0):
        """Evaluate a candidate on the private nonlinear contact model."""
        d = self.d
        mj = self.mj
        m = self.m
        d.qpos[:] = q
        d.qvel[:] = v
        d.qacc_warmstart[:] = 0
        qs = np.empty((self.N + 1, 36))
        vs = np.empty((self.N + 1, 35))
        nu = us.copy()
        cost = 0.0
        for k in range(self.N):
            qs[k] = d.qpos
            vs[k] = d.qvel
            if ks is not None:
                dx = self._difference(nominal[0][k], nominal[1][k], d.qpos, d.qvel)
                nu[k] = us[k] + alpha * ks[k] + Ks[k] @ dx
                nu[k] = np.clip(nu[k], self.urefs[index + k] - 1.5, self.urefs[index + k] + 1.5)
            d.ctrl[:] = nu[k]
            mj.mj_forward(m, d)
            cost += self._cost(d, index + k, nu[k])
            mj.mj_step(m, d)
        qs[-1] = d.qpos
        vs[-1] = d.qvel
        mj.mj_forward(m, d)
        cost += self._cost(d, index + self.N, terminal=True)
        return (cost, qs, vs, nu)

    def _optimize(self, q, v, index, us, iterations):
        (mj, m, d) = (self.mj, self.m, self.fd)
        (cost, qs, vs, us) = self._rollout(q, v, index, us)
        # A second seed lets a poor warm start escape after a contact transition.
        (nc, nq, nv, nu) = self._rollout(q, v, index, self.urefs[index:index + self.N])
        if nc < cost:
            (cost, qs, vs, us) = (nc, nq, nv, nu)
        self.reg = min(self.reg, 100.0)
        for iteration in range(iterations):
            As = np.empty((self.N, 70, 70))
            Bs = np.empty((self.N, 70, 29))
            lxs = []
            Hs = []
            for k in range(self.N + 1):
                d.qpos[:] = qs[k]
                d.qvel[:] = vs[k]
                d.qacc_warmstart[:] = 0
                if k < self.N:
                    d.ctrl[:] = us[k]
                mj.mj_forward(m, d)
                (_, lx, H) = self._cost(d, index + k, derivatives=True, terminal=k == self.N)
                lxs.append(lx)
                Hs.append(H)
                if k < self.N:
                    mj.mjd_transitionFD(m, d, 0.0001, False, As[k], Bs[k], None, None)
            Vx = lxs[-1]
            Vxx = Hs[-1]
            ks = np.empty((self.N, 29))
            Ks = np.empty((self.N, 29, 70))
            try:
                # Regularized Riccati recursion: feedforward increments and
                # feedback gains for a closed-loop nonlinear line search.
                for k in range(self.N - 1, -1, -1):
                    (A, B) = (As[k], Bs[k])
                    Qx = lxs[k] + A.T @ Vx
                    Qu = self.wu * (us[k] - self.urefs[index + k]) + B.T @ Vx
                    Qxx = Hs[k] + A.T @ Vxx @ A
                    Qux = B.T @ Vxx @ A
                    Quu = B.T @ Vxx @ B + np.eye(29) * (self.wu + self.reg)
                    C = self.cho_factor(Quu, check_finite=False)
                    ks[k] = -self.cho_solve(C, Qu, check_finite=False)
                    Ks[k] = -self.cho_solve(C, Qux, check_finite=False)
                    Vx = Qx + Qux.T @ ks[k]
                    Vxx = Qxx + Qux.T @ Ks[k]
                    Vxx = 0.5 * (Vxx + Vxx.T)
            except np.linalg.LinAlgError:
                self.reg = min(self.reg * 10, 100000000.0)
                continue
            accepted = False
            for alpha in (1.0, 0.5, 0.25, 0.1):
                (nc, nq, nv, nu) = self._rollout(q, v, index, us, (qs, vs), ks, Ks, alpha)
                if nc < cost:
                    (cost, qs, vs, us) = (nc, nq, nv, nu)
                    accepted = True
                    self.reg = max(0.01, self.reg * 0.5)
                    break
            if not accepted:
                self.reg = min(100000000.0, self.reg * 10)
        return (us, cost)

    def compute(self, t: float, joint_q: np.ndarray, joint_qd: np.ndarray) -> Command:
        """Return one 10 ms servo command using only the supplied robot state."""
        index = min(round(t / self.dt), len(self.refs) - self.N - 1)
        shift = index - self.last_index
        if shift > 0:
            self.us = np.vstack((self.us[min(shift, self.N):], self.urefs[index + self.N - min(shift, self.N):index + self.N]))
        self.last_index = index
        q = self._qpos(joint_q)
        v = joint_qd.copy()
        R = _rotation(joint_q[3:7])
        # Newton gives root-body COM linear velocity and world angular velocity;
        # MuJoCo needs body-origin linear velocity and body-frame angular velocity.
        v[:3] -= np.cross(v[3:6], R @ self.m.body_ipos[1])
        v[3:6] = R.T @ v[3:6]
        (self.us, self.last_cost) = self._optimize(q, v, index, self.us, 3)
        self.debug = {'status': f'cost {self.last_cost:.1f} reg {self.reg:.2g}'}
        return Command(q=self.us[0], kp=self.kp, kd=self.kd)


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.frame_dt = CONTROL_DT
        self.sim_dt = SIM_DT
        self.sim_time = 0.0
        # The robot starts at rest at the clip's first frame; the controller plans on its own copy of the model.
        self.motion = MotionClip(args.motion, build_model())
        start = self.motion.sample(0.0)
        self.robot = Robot(start)
        planning_model = build_model(start)
        self.controller = Controller(planning_model, MotionClip(args.motion, planning_model))
        self.report = TrackingReport(self.robot, self.motion)
        self.compute_seconds = 0.0
        self.viewer.set_model(self.model)

    # The live host and viewers look for these on the example.
    @property
    def model(self):
        return self.robot.model

    @property
    def solver(self):
        return self.robot.solver

    @property
    def state_0(self):
        return self.robot.state_0

    @property
    def state_1(self):
        return self.robot.state_1

    @property
    def control(self):
        return self.robot.control

    def capture(self):
        self.robot.capture()

    def step(self):
        # Read the state first: the copy waits for the last physics step, which is not the controller's time.
        joint_q = self.state_0.joint_q.numpy().astype(np.float64)
        joint_qd = self.state_0.joint_qd.numpy().astype(np.float64)
        started = time.perf_counter()
        command = self.controller.compute(self.sim_time, joint_q, joint_qd)
        self.compute_seconds += time.perf_counter() - started
        self.robot.apply(command)
        self.robot.advance()
        self.sim_time += self.frame_dt
        self.report.update(self.sim_time, self.state_0)

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def print_report(self):
        summary = self.report.summary()
        print(f"tracked {self.sim_time:.2f} of {self.motion.duration:.2f} s")
        for key, value in summary.items():
            print(f"  {key}: {value:.4f}" if isinstance(value, float) else f"  {key}: {value}")
        print(f"  controller_seconds: {self.compute_seconds:.2f}")

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, default="walk.csv", help="Reference clip (MuJoCo qpos CSV, 30 fps)")
        parser.set_defaults(num_frames=None)
        return parser


if __name__ == "__main__":
    parser = Example.create_parser()
    known, _ = parser.parse_known_args()
    if known.num_frames is None:
        parser.set_defaults(num_frames=round(MotionClip(known.motion).duration / CONTROL_DT))
    viewer, args = newton.examples.init(parser)
    example = Example(viewer, args)
    started = time.perf_counter()
    newton.examples.run(example, args)
    example.print_report()
    print(f"  wall_seconds: {time.perf_counter() - started:.2f}")
