# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, and ``Example`` drives every world with the logged commands as joint position
targets, open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.075,  # latency from a logged command to the joint targets [s]
    "dt": 0.001,  # physics step [s]
}


TABLE_Z = 0.75  # table top [m]

# Fruits seen by the top camera at the start (photos/01_top.jpg, blob centroids cast onto the
# table at the fruit's centre height). Sizes from the gripper gap while holding (pear 5.1 cm,
# orange 5.8 cm, dark fruit 6.9 cm) and the top-camera blobs (pear about 7.5 cm long, orange
# 5.4 to 6.2 cm); the soft orange is squeezed, so it is modeled at 5.5 cm.
# Each fruit: spheres (local centre [m], radius [m]) in a body frame whose origin sits
# ``lift`` above the table, its start xy [m] and heading about z [rad], and its mass [kg].
FRUITS = {
    "pear": {
        "spheres": [((-0.010, 0.0, 0.0), 0.026), ((0.021, 0.0, -0.007), 0.019)],
        "lift": 0.026,
        "xy": (0.648, 0.343),
        "yaw": -1.14,  # stem toward -y and slightly +x
        "mass": 0.045,
        "material": {"mu": 0.3},  # waxy skin: the orange shoves it across the tray, as in the recording
    },
    "orange": {
        "spheres": [((0.0, 0.0, 0.0), 0.0275)],
        "lift": 0.0275,
        "xy": (0.495, -0.037),  # 4 mm to +y keeps it out of a fingertip cage at its grasp
        "yaw": 0.0,
        "mass": 0.050,
    },
    "dark_fruit": {
        "spheres": [((0.0, 0.0, 0.0), 0.0345)],
        "lift": 0.0345,
        "xy": (0.650, -0.188),
        "yaw": 0.0,
        "mass": 0.100,
        "material": {"mu_rolling": 0.005, "mu_torsional": 0.02},  # bumpy skin: settles where it lands
    },
}
# MuJoCo derives a geom's solref from ke and kd: (2 / kd, kd / (2 sqrt(ke))) = (0.02 s, 1).
FRUIT_MATERIAL = {"mu": 0.8, "mu_torsional": 0.01, "mu_rolling": 0.002, "restitution": 0.0, "ke": 2500.0, "kd": 100.0}

# Wedge-shaped wooden tray: outer outline at its rim (top camera, start), clockwise in the
# image, so counter-clockwise in the world after reversing; rim height, wall and floor thickness.
TRAY_OUTLINE = [
    (0.906, 0.135),
    (0.856, 0.058),
    (0.772, -0.021),
    (0.751, -0.021),
    (0.699, 0.027),
    (0.677, 0.067),
    (0.671, 0.103),
    (0.678, 0.154),
    (0.698, 0.183),
    (0.779, 0.182),
    (0.869, 0.160),
]
TRAY = {"rim": 0.022, "wall": 0.008, "floor": 0.005, "strips": 6, "floor_margin": 0.012, "mu": 0.3, "ramp_width": 0.05, "ramp_rise": 0.016}


def add_fruits(builder: newton.ModelBuilder) -> list[int]:
    bodies = []
    for name, spec in FRUITS.items():
        volume = sum(4.0 / 3.0 * math.pi * r**3 for _, r in spec["spheres"])
        cfg = newton.ModelBuilder.ShapeConfig(density=spec["mass"] / volume, **{**FRUIT_MATERIAL, **spec.get("material", {})})
        x, y = spec["xy"]
        xform = wp.transform(wp.vec3(x, y, TABLE_Z + spec["lift"]), wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), spec["yaw"]))
        body = builder.add_body(xform=xform, label=name)
        for k, (pos, radius) in enumerate(spec["spheres"]):
            builder.add_shape_sphere(body, xform=wp.transform(wp.vec3(*pos)), radius=radius, cfg=cfg, label=f"{name}_{k}")
        bodies.append(body)
    return bodies


def add_tray(builder: newton.ModelBuilder) -> None:
    """Static tray: a floor of strips across the wedge and a vertical rim wall along every outline edge."""
    poly = np.asarray(TRAY_OUTLINE[::-1], dtype=float)  # counter-clockwise
    cfg = newton.ModelBuilder.ShapeConfig(
        density=0.0, mu=TRAY["mu"], mu_torsional=0.005, mu_rolling=0.0005, restitution=0.0, ke=2500.0, kd=100.0
    )
    rim, wall, floor = TRAY["rim"], TRAY["wall"], TRAY["floor"]
    n = len(poly)
    for i in range(n):
        a, b = poly[i], poly[(i + 1) % n]
        d = b - a
        length = float(np.linalg.norm(d))
        d /= length
        inward = np.array([-d[1], d[0]])
        c = 0.5 * (a + b) + inward * 0.5 * wall
        yaw = math.atan2(d[1], d[0])
        builder.add_shape_box(
            -1,
            xform=wp.transform(wp.vec3(c[0], c[1], TABLE_Z + 0.5 * rim), wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), yaw)),
            hx=0.5 * length + 0.5 * wall,
            hy=0.5 * wall,
            hz=0.5 * rim,
            cfg=cfg,
            label=f"tray_wall_{i}",
        )
        # the floor curves up toward the rim: a ramp along the inside of every wall
        span, rise = TRAY["ramp_width"], TRAY["ramp_rise"]
        tilt = math.atan2(rise, span)
        half = 0.002
        c = 0.5 * (a + b) + inward * (wall + 0.5 * span)
        top = TABLE_Z + floor + 0.5 * rise
        q = wp.mul(wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), yaw), wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), -tilt))
        builder.add_shape_box(
            -1,
            xform=wp.transform(wp.vec3(c[0], c[1], top - half / math.cos(tilt)), q),
            hx=0.5 * length,
            hy=0.5 * math.hypot(span, rise),
            hz=half,
            cfg=cfg,
            label=f"tray_ramp_{i}",
        )
    # floor strips along the wedge axis (tip to arc), each spanning the outline across it
    tip = np.asarray(TRAY_OUTLINE[0])
    axis = poly.mean(axis=0) - tip
    axis /= np.linalg.norm(axis)
    side = np.array([-axis[1], axis[0]])
    s = (poly - tip) @ axis
    s0, s1 = 0.0, float(s.max())
    edges = np.linspace(s0, s1, TRAY["strips"] + 1)
    yaw = math.atan2(axis[1], axis[0])
    for k in range(TRAY["strips"]):
        lo, hi = edges[k], edges[k + 1]
        # outline width over this strip (boundary samples), clipped to the width across its middle
        # plus a margin, so the strip ends under the rim instead of reaching far past it
        mid = tip + axis * 0.5 * (lo + hi)
        pts, cuts = [], []
        for i in range(n):
            a, b = poly[i], poly[(i + 1) % n]
            for u in np.linspace(0.0, 1.0, 21):
                p = a + u * (b - a)
                if lo - 1e-9 <= (p - tip) @ axis <= hi + 1e-9:
                    pts.append((p - mid) @ side)
            den = (b - a) @ axis
            if abs(den) > 1e-12:
                u = (mid - a) @ axis / den
                if 0.0 <= u <= 1.0:
                    cuts.append((a + u * (b - a) - mid) @ side)
        w0 = max(min(pts), min(cuts) - TRAY["floor_margin"])
        w1 = min(max(pts), max(cuts) + TRAY["floor_margin"])
        c = mid + side * 0.5 * (w0 + w1)
        builder.add_shape_box(
            -1,
            xform=wp.transform(wp.vec3(c[0], c[1], TABLE_Z + 0.5 * floor), wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), yaw)),
            hx=0.5 * (hi - lo),
            hy=0.5 * (w1 - w0),
            hz=0.5 * floor,
            cfg=cfg,
            label=f"tray_floor_{k}",
        )


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station with the three fruits and the tray in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_tray(station)
    add_fruits(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    configure(model)
    return model


def configure(model: newton.Model) -> None:
    """Arm, gripper, and contact settings (through the model, so the solver compiles them)."""
    shape_names = [label.rsplit("/", 1)[-1] for label in model.shape_label]
    condim = model.mujoco.condim.numpy()
    solimp = model.mujoco.geom_solimp.numpy()
    for i, name in enumerate(shape_names):
        if any(name.startswith(f) for f in FRUITS) or name.startswith("tray_"):
            condim[i] = 6
            solimp[i] = CONTACT_SOLIMP
    model.mujoco.condim.assign(condim)
    model.mujoco.geom_solimp.assign(solimp)
    joint_names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
    qd_start = model.joint_qd_start.numpy()
    ke, kd = model.joint_target_ke.numpy(), model.joint_target_kd.numpy()
    for j, name in enumerate(joint_names):
        for side in SIDES:
            for k in range(6):
                if name == f"{side}_joint{k + 1}":
                    ke[qd_start[j]], kd[qd_start[j]] = ARM["kp"][k], ARM["kv"][k]
    for j, name in enumerate(joint_names):
        if name in ("left_left_finger", "right_left_finger"):
            ke[qd_start[j]] = GRIPPER["kp"]
    model.joint_target_ke.assign(ke)
    model.joint_target_kd.assign(kd)
    # effort limits as the actuators' force ranges (28 N m on joints 1-3, 10 N m on 4-6, the squeeze)
    effort = model.joint_effort_limit.numpy()
    for j, name in enumerate(joint_names):
        for side in SIDES:
            for k in range(6):
                if name == f"{side}_joint{k + 1}":
                    effort[qd_start[j]] = 28.0 if k < 3 else 10.0
            if name == f"{side}_left_finger":
                effort[qd_start[j]] = GRIPPER["force"]
    model.joint_effort_limit.assign(effort)
    gravcomp = model.mujoco.gravcomp.numpy()
    gravcomp[gravcomp > 0.0] = ARM["gravcomp"]
    model.mujoco.gravcomp.assign(gravcomp)
    # gripper squeeze force
    labels = list(model.mujoco.actuator_label)
    forcerange = model.mujoco.actuator_forcerange.numpy()
    limited = model.mujoco.actuator_forcelimited.numpy()
    has_range = model.mujoco.actuator_has_forcerange.numpy()
    for a, label in enumerate(labels):
        if label.endswith("gripper"):
            forcerange[a] = (-GRIPPER["force"], GRIPPER["force"])
            limited[a] = 1
            has_range[a] = True
    model.mujoco.actuator_forcerange.assign(forcerange)
    model.mujoco.actuator_forcelimited.assign(limited)
    model.mujoco.actuator_has_forcerange.assign(has_range)


# Arm servos fitted to the episode's measured joints (joints 1-6, both arms): position gain
# [N m/rad], damping [N m s/rad], and no gravity compensation (the real joint 2 holds about
# 20 N m with a few hundredths of a radian of sag, so it is stiff, not compensated).
ARM = {"kp": [80.0, 400.0, 250.0, 60.0, 15.0, 15.0], "kv": [4.0, 10.0, 8.0, 2.0, 0.5, 0.5], "gravcomp": 0.0}
GRIPPER = {"kp": 400.0, "force": 5.0}  # finger slide gain [N/m] and squeeze force limit [N]
CONTACT_SOLIMP = (0.95, 0.99, 0.001, 0.5, 2.0)  # fruit and tray contacts: stiff once touching


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=False, cone="elliptic", impratio=1.0)


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return newton.CollisionPipeline(model)


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
