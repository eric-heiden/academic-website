# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) with the scene recreated from
the photos and logs (a pear, an orange, and a dark round fruit, and the wedge-shaped
tray they are put into) in ``num_worlds`` identical worlds, and ``Example`` drives
every world with the logged commands as joint position targets, open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.0,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
    "arm_gravcomp": 0.9,  # gravity compensation of the arm links (the real arms sag slightly)
    "gripper_kp": 1000.0,  # finger slide position gain [N/m]
    "gripper_force": 8.0,  # squeeze force limit of the finger actuator [N]
}

# The scene fitted to the photos (top camera rays) and to the arm kinematics at each grasp;
# world frame, metres and kilograms.
TABLE_Z = 0.75
FRUIT_INERTIA_SCALE = 1.3  # times a solid ellipsoid of the same extents (a thin shell is 5/3)
FRUIT_MATERIAL = {"mu": 0.8, "mu_torsional": 0.01, "mu_rolling": 0.0005, "gap": 0.02}
TRAY_MATERIAL = {"mu": 0.6, "mu_torsional": 0.005, "mu_rolling": 0.0005, "gap": 0.02}
# Each fruit starts where the simulated gripper closes on it (1-2.5 cm from the top camera's view of the
# real fruit); sizes match the gripper opening the real fruit was held at and the photos.
FRUITS = [
    # A pear lying on its side, grasped across the bulb: bulb and neck spheres along body x,
    # the stem end pointing along `axis` (top camera), tilted so that both spheres touch the table.
    {
        "label": "pear",
        "pos": (0.6417, 0.3302),
        "axis": (0.496, -0.868),
        "spheres": (((0.0, 0.0, 0.0), 0.027), ((0.032, 0.0, 0.0), 0.018)),
        "mass": 0.15,
        "com": (0.008, 0.0, 0.0),
        "material": {"mu_rolling": 0.002},  # a pear hardly rolls
    },
    {"label": "orange", "pos": (0.4918, -0.0499), "axis": (1.0, 0.0), "spheres": (((0.0, 0.0, 0.0), 0.0285),), "mass": 0.09},
    {"label": "dark_fruit", "pos": (0.6536, -0.1910), "axis": (1.0, 0.0), "spheres": (((0.0, 0.0, 0.0), 0.033),), "mass": 0.11},
]
# Wedge-shaped wooden tray (static): outline of its rim seen by the top camera (convex, rounded corners),
# a thin floor and inclined walls that rise from the floor to the rim.
TRAY = {
    # Rim outline from the top camera; the arc (near) side is moved back by the outer face of the rim
    # that the camera sees there.
    "outline": (
        (0.906, 0.141), (0.890, 0.095), (0.845, 0.043), (0.790, -0.012), (0.765, -0.022), (0.733, 0.010),
        (0.698, 0.057), (0.693, 0.105), (0.697, 0.160), (0.715, 0.184), (0.760, 0.185), (0.840, 0.172),
    ),
    "offset": (-0.005, -0.003),  # the tray shifts about 1 cm during the episode; take the middle
    "floor_top": 0.755,  # floor height at its lowest (arc) end
    "floor_thickness": 0.005,
    "floor_strips": 6,
    "downhill": (-1.0, 0.12),  # toward the arc, the way the orange rolled after its release
    "slope_deg": 2.5,
    "rim_height": 0.02,  # rim above the floor
    "wall_inset": 0.012,  # the walls meet the floor this far inside the outline [m]
    "wall_outset": 0.006,  # and reach the rim this far outside it [m]
    "wall_thickness": 0.008,
}


def _quat_from_matrix(rot: np.ndarray) -> wp.quat:
    return wp.quat_from_matrix(wp.mat33(*rot.flatten().tolist()))


def add_fruits(builder: newton.ModelBuilder) -> list[int]:
    """Three free fruit bodies resting on the table; returns their collision shapes."""
    shapes = []
    for fruit in FRUITS:
        centers = np.array([c for c, _ in fruit["spheres"]], dtype=float)
        radii = np.array([r for _, r in fruit["spheres"]], dtype=float)
        # Tilt about body y so that every sphere touches the table (two spheres at most).
        pitch = 0.0
        if len(radii) == 2:
            pitch = math.asin((radii[0] - radii[1]) / np.linalg.norm(centers[1] - centers[0]))
        yaw = math.atan2(fruit["axis"][1], fruit["axis"][0])
        cy, sy, cp, sp = math.cos(yaw), math.sin(yaw), math.cos(pitch), math.sin(pitch)
        rot = np.array([[cy, -sy, 0.0], [sy, cy, 0.0], [0.0, 0.0, 1.0]]) @ np.array(
            [[cp, 0.0, sp], [0.0, 1.0, 0.0], [-sp, 0.0, cp]]
        )
        pos = np.array([fruit["pos"][0], fruit["pos"][1], TABLE_Z + radii[0]])
        # Inertia of the collision extents (body axes) about the centre of mass: between a solid and a
        # thin-shell ellipsoid (fake fruits are partly hollow).
        lo, hi = (centers - radii[:, None]).min(0), (centers + radii[:, None]).max(0)
        a = 0.5 * (hi - lo)
        mass = fruit["mass"]
        inertia = FRUIT_INERTIA_SCALE * 0.2 * mass * np.diag([a[1] ** 2 + a[2] ** 2, a[0] ** 2 + a[2] ** 2, a[0] ** 2 + a[1] ** 2])
        body = builder.add_body(
            xform=wp.transform(wp.vec3(*pos), _quat_from_matrix(rot)),
            com=wp.vec3(*fruit.get("com", (0.0, 0.0, 0.0))),
            inertia=wp.mat33(*inertia.flatten().tolist()),
            mass=mass,
            label=fruit["label"],
            lock_inertia=True,
        )
        cfg = newton.ModelBuilder.ShapeConfig(density=0.0, **{**FRUIT_MATERIAL, **fruit.get("material", {})})
        for center, radius in zip(centers, radii, strict=True):
            shapes.append(
                builder.add_shape_sphere(body, xform=wp.transform(wp.vec3(*center), wp.quat_identity()), radius=radius, cfg=cfg)
            )
    return shapes


def add_tray(builder: newton.ModelBuilder) -> list[int]:
    """The tray as static boxes: floor strips in one plane that falls toward the arc (all three fruits come
    to rest against the arc side of the real tray) and one inclined wall slab per outline edge."""
    tray = TRAY
    poly = np.array(tray["outline"], dtype=float) + np.array(tray["offset"])
    centroid = poly.mean(0)
    down = np.array(tray["downhill"], dtype=float)
    down /= np.linalg.norm(down)
    side = np.array([-down[1], down[0]])
    s_poly, t_poly = poly @ down, poly @ side
    slope = math.tan(math.radians(tray["slope_deg"]))

    def floor_z(p):  # floor top height at plan point(s) p
        return tray["floor_top"] + slope * (s_poly.max() - np.asarray(p) @ down)

    cfg = newton.ModelBuilder.ShapeConfig(density=0.0, **TRAY_MATERIAL)
    shapes = []
    half_floor = 0.5 * tray["floor_thickness"]
    yaw = math.atan2(down[1], down[0])
    pitch = math.atan(slope)  # body x points downhill
    cy, sy, cp, sp = math.cos(yaw), math.sin(yaw), math.cos(pitch), math.sin(pitch)
    floor_rot = np.array([[cy, -sy, 0.0], [sy, cy, 0.0], [0.0, 0.0, 1.0]]) @ np.array(
        [[cp, 0.0, sp], [0.0, 1.0, 0.0], [-sp, 0.0, cp]]
    )
    normal = floor_rot[:, 2]
    # Floor: strips across the downhill direction, each as wide as the outline within its range.
    ss = np.linspace(s_poly.min(), s_poly.max(), tray["floor_strips"] + 1)
    for s0, s1 in zip(ss[:-1], ss[1:], strict=True):
        ts = [t for s, t in zip(s_poly, t_poly, strict=True) if s0 <= s <= s1]
        for i in range(len(poly)):
            j = (i + 1) % len(poly)
            for s in np.linspace(s0, s1, 9):
                if (s_poly[i] - s) * (s_poly[j] - s) <= 0.0 and s_poly[i] != s_poly[j]:
                    ts.append(t_poly[i] + (s - s_poly[i]) / (s_poly[j] - s_poly[i]) * (t_poly[j] - t_poly[i]))
        t0, t1 = min(ts), max(ts)
        plan = 0.5 * (s0 + s1) * down + 0.5 * (t0 + t1) * side
        top = np.array([*plan, floor_z(plan)])
        center = top - normal * half_floor
        xform = wp.transform(wp.vec3(*center), _quat_from_matrix(floor_rot))
        hx = 0.5 * (s1 - s0) / math.cos(math.atan(slope))
        shapes.append(builder.add_shape_box(-1, xform=xform, hx=hx, hy=0.5 * (t1 - t0), hz=half_floor, cfg=cfg))
    # Walls: slabs whose top face rises from the floor (inside the outline) to the rim (just outside it).
    half_t = 0.5 * tray["wall_thickness"]
    for i in range(len(poly)):
        p, q = poly[i], poly[(i + 1) % len(poly)]
        along = (q - p) / np.linalg.norm(q - p)
        inward = np.array([-along[1], along[0]])
        if np.dot(inward, centroid - 0.5 * (p + q)) < 0.0:
            inward = -inward
        b0, b1 = p + inward * tray["wall_inset"], q + inward * tray["wall_inset"]
        bottom0 = np.array([*b0, floor_z(b0)])
        bottom1 = np.array([*b1, floor_z(b1)])
        up = np.array([*(-inward * (tray["wall_inset"] + tray["wall_outset"])), tray["rim_height"]])
        e = (bottom1 - bottom0) / np.linalg.norm(bottom1 - bottom0)
        u = up - np.dot(up, e) * e
        width = np.linalg.norm(u)
        u /= width
        n = np.cross(e, u)
        if n[2] < 0.0:
            e, n = -e, -n
        center = 0.5 * (bottom0 + bottom1) + 0.5 * up - n * half_t
        rot = np.stack([e, u, n], axis=1)  # box axes: x along the edge, y up the slope, z the slab normal
        length = np.linalg.norm(bottom1 - bottom0) + 0.02
        xform = wp.transform(wp.vec3(*center), _quat_from_matrix(rot))
        shapes.append(builder.add_shape_box(-1, xform=xform, hx=0.5 * length, hy=0.5 * width, hz=half_t, cfg=cfg))
    return shapes


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station with the fruits and the tray in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_fruits(station)
    add_tray(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()

    # Arm and gripper drives (MJCF kinematics and finger geometry unchanged).
    bodies = [label.rsplit("/", 1)[-1] for label in model.body_label]
    joints = [label.rsplit("/", 1)[-1] for label in model.joint_label]
    gravcomp = model.mujoco.gravcomp.numpy()
    for b, name in enumerate(bodies):
        if any(name in (*(f"{side}_link_{k}" for k in range(1, 7)), f"{side}_camera_d405", f"{side}_camera_frame") for side in SIDES):
            gravcomp[b] = PARAMS["arm_gravcomp"]
    model.mujoco.gravcomp.assign(gravcomp)
    qd_start = model.joint_qd_start.numpy()
    ke, effort = model.joint_target_ke.numpy(), model.joint_effort_limit.numpy()
    for j, name in enumerate(joints):
        if name in [f"{side}_left_finger" for side in SIDES]:
            ke[qd_start[j]] = PARAMS["gripper_kp"]
            effort[qd_start[j]] = PARAMS["gripper_force"]
    model.joint_target_ke.assign(ke)
    model.joint_effort_limit.assign(effort)

    # Fruit contacts resist rolling and spinning (condim 6).
    fruit_bodies = [b for b, name in enumerate(bodies) if name in {fruit["label"] for fruit in FRUITS}]
    condim = model.mujoco.condim.numpy()
    condim[np.isin(model.shape_body.numpy(), fruit_bodies)] = 6
    model.mujoco.condim.assign(condim)
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=False, cone="elliptic")


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return newton.CollisionPipeline(model)


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
