# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, and ``Example`` drives every world with the logged commands as joint position
targets, open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Scene (fitted to ``photos/`` and the logs): three free fruits start on the table where the
top camera and the measured grasps place them (a pear lying on its side, an orange, and a dark
round fruit, with their widths from the measured gripper openings during the carries), and a
static wedge-shaped wooden tray (a 60 degree slice) sits where the top camera sees it. Its
shallow conical floor sinks toward the apex, so the round fruits roll into the apex corner as
in the recording. The arms keep the MJCF gains; 92 % gravity compensation reproduces part of
the measured sag of the real arms (a quarter less shoulder tracking error than full
compensation, and grasps within a few millimeters of the measured heights). The grippers
squeeze with at most 8 N.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.0,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}


# Scene fitted to the photos and logs (world frame, meters, kilograms).
TABLE_Z = 0.75
# Fruits: name, start [x, y] of the centre of the collision geometry (body origin and centre of mass), yaw about z
# [rad], mass [kg], and collision spheres (centre xyz, radius); each starts resting on the table.
FRUITS = [
    # lying on its side: bulb, neck, stem, and two bumps of the flattened underside
    {"name": "pear", "xy": (0.655, 0.328), "yaw": -0.5, "mass": 0.04, "mu_rolling": 0.005,
     "spheres": [((0.0, 0.0, 0.0), 0.026), ((0.031, 0.0, -0.006), 0.019), ((0.053, 0.0, -0.008), 0.007),
                 ((0.0, 0.010, -0.011), 0.015), ((0.0, -0.010, -0.011), 0.015)]},
    {"name": "orange", "xy": (0.503, -0.057), "yaw": 0.0, "mass": 0.07,
     "spheres": [((0.0, 0.0, 0.0), 0.0295)]},
    {"name": "dark_fruit", "xy": (0.653, -0.195), "yaw": 0.0, "mass": 0.08,
     "spheres": [((0.0, 0.0, 0.0), 0.0325)]},
]
FRUIT_MATERIAL = {"mu": 0.27, "mu_torsional": 0.005, "mu_rolling": 0.0003}
# Wedge-shaped wooden tray (static), a 60 degree slice seen from the top camera: apex, directions of the
# straight edges [rad], radius, a shallow conical floor that rises away from the apex (round fruits roll into the
# apex corner, as in the recording), rims along the left edge and the arc, and a low rounded lip on the right edge.
TRAY = {
    "apex": (0.687, 0.182), "angles": (-1.26, -0.09), "radius": 0.232,
    "floor_apex": 0.748, "floor_slope": 0.11, "floor_thickness": 0.006,
    "rim_top": 0.789, "rim_thickness": 0.008, "lip_radius": 0.005,
    "mu": 0.27, "mu_torsional": 0.005, "mu_rolling": 0.0003,
}
# Arms: per joint 1-6 position gain [N m/rad], damping [N m s/rad], effort limit [N m], armature, friction.
ARM = {
    "kp": (40.0, 40.0, 40.0, 20.0, 10.0, 10.0),
    "kd": (2.5, 2.5, 2.5, 0.5, 1.0, 1.0),
    "effort": (28.0, 28.0, 28.0, 10.0, 10.0, 10.0),
    "armature": (0.032, 0.032, 0.032, 0.0018, 0.0018, 0.0018),
    "friction": (0.1, 0.1, 0.1, 0.1, 0.1, 0.1),
    "gravcomp": (0.92, 0.92, 0.92, 0.92, 0.92),  # links 2-6 (and the gripper with link 6); the real arm sags
}
GRIPPER = {"kp": 400.0, "squeeze": 8.0}
ROBOT_MATERIAL = {"mu": 0.5, "mu_torsional": 0.02, "mu_rolling": 0.005}
CONTACT_GAP = 0.01  # speculative contact distance of every shape [m]


def _quat_z(yaw: float):
    return wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), float(yaw))


def add_fruits(builder: newton.ModelBuilder):
    for fruit in FRUITS:
        lo = np.min([np.asarray(c) - r for c, r in fruit["spheres"]], axis=0)
        hi = np.max([np.asarray(c) + r for c, r in fruit["spheres"]], axis=0)
        center, ext = 0.5 * (lo + hi), hi - lo
        spheres = [(np.asarray(c) - center, r) for c, r in fruit["spheres"]]  # about the geometry centre
        z = TABLE_Z + 0.5 * ext[2] + 0.0005
        m = fruit["mass"]
        # between a solid (1/5) and a thin-shell (1/3) ellipsoid of the extents
        a2 = (0.5 * ext) ** 2
        inertia = 0.25 * m * np.array([a2[1] + a2[2], a2[0] + a2[2], a2[0] + a2[1]])
        body = builder.add_body(
            xform=wp.transform(wp.vec3(fruit["xy"][0], fruit["xy"][1], z), _quat_z(fruit["yaw"])),
            com=wp.vec3(0.0, 0.0, 0.0),
            mass=m,
            inertia=wp.mat33(*np.diag(inertia).flatten().tolist()),
            lock_inertia=True,
            label=fruit["name"],
        )
        cfg = newton.ModelBuilder.ShapeConfig(
            density=0.0, mu=FRUIT_MATERIAL["mu"], mu_torsional=FRUIT_MATERIAL["mu_torsional"],
            mu_rolling=fruit.get("mu_rolling", FRUIT_MATERIAL["mu_rolling"]),
        )
        for c, r in spheres:
            builder.add_shape_sphere(
                body, xform=wp.transform(wp.vec3(*c.tolist()), wp.quat_identity()), radius=r, cfg=cfg,
                custom_attributes={"mujoco:condim": 6},
            )


def add_tray(builder: newton.ModelBuilder):
    tr = TRAY
    cfg = newton.ModelBuilder.ShapeConfig(mu=tr["mu"], mu_torsional=tr["mu_torsional"], mu_rolling=tr["mu_rolling"])
    attrs = {"mujoco:condim": 6}
    ax, ay = tr["apex"]
    a0, a1 = tr["angles"]
    R, th, slope = tr["radius"], tr["rim_thickness"], tr["floor_slope"]
    # floor: spokes from the apex, each covering a sector and rising with the slope
    n = 6
    for i in range(n):
        ang = a0 + (i + 0.5) * (a1 - a0) / n
        half_w = R * math.sin(0.5 * abs(a1 - a0) / n) + 0.002
        L = R * math.cos(0.5 * abs(a1 - a0) / n)
        q = _quat_z(ang) * wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), -math.atan(slope))
        h = 0.5 * tr["floor_thickness"]
        zc = tr["floor_apex"] + 0.5 * L * slope - h
        c = (ax + 0.5 * L * math.cos(ang), ay + 0.5 * L * math.sin(ang), zc)
        builder.add_shape_box(-1, xform=wp.transform(wp.vec3(*c), q), hx=0.5 * L, hy=half_w, hz=h, cfg=cfg,
                              custom_attributes=attrs)
    # rim along the left edge and the arc, a low rounded lip along the right edge
    rh = 0.5 * (tr["rim_top"] - TABLE_Z)
    nx, ny = math.sin(a1), -math.cos(a1)  # inward normal of the left edge
    c = (ax + 0.5 * R * math.cos(a1) + 0.5 * th * nx, ay + 0.5 * R * math.sin(a1) + 0.5 * th * ny, TABLE_Z + rh)
    builder.add_shape_box(-1, xform=wp.transform(wp.vec3(*c), _quat_z(a1)), hx=0.5 * R, hy=0.5 * th, hz=rh,
                          cfg=cfg, custom_attributes=attrs)
    lr = tr["lip_radius"]
    zl = tr["floor_apex"] + 0.5 * R * slope
    c = (ax + 0.5 * R * math.cos(a0), ay + 0.5 * R * math.sin(a0), zl)
    q = _quat_z(a0) * wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), 0.5 * math.pi - math.atan(slope))
    builder.add_shape_capsule(-1, xform=wp.transform(wp.vec3(*c), q), radius=lr, half_height=0.5 * R, cfg=cfg,
                              custom_attributes=attrs)
    m = 6
    for i in range(m):
        ang = a0 + (i + 0.5) * (a1 - a0) / m
        r = R - 0.5 * th
        c = (ax + r * math.cos(ang), ay + r * math.sin(ang), TABLE_Z + rh)
        half = r * math.sin(0.5 * abs(a1 - a0) / m) + 0.003
        builder.add_shape_box(-1, xform=wp.transform(wp.vec3(*c), _quat_z(ang)), hx=0.5 * th, hy=half, hz=rh,
                              cfg=cfg, custom_attributes=attrs)


def tune_station(model: newton.Model):
    """Arm and gripper calibration, the same in every world."""
    names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
    qd_start = model.joint_qd_start.numpy()
    ke, kd = model.joint_target_ke.numpy(), model.joint_target_kd.numpy()
    effort, armature, friction = model.joint_effort_limit.numpy(), model.joint_armature.numpy(), model.joint_friction.numpy()
    forcerange = model.mujoco.actuator_forcerange.numpy()
    act_names = [label.rsplit("/", 1)[-1] for label in model.mujoco.actuator_label]
    bnames = [label.rsplit("/", 1)[-1] for label in model.body_label]
    gravcomp = model.mujoco.gravcomp.numpy()
    for j, name in enumerate(names):
        d = qd_start[j]
        for side in SIDES:
            for k in range(6):
                if name == f"{side}_joint{k + 1}":
                    ke[d], kd[d] = ARM["kp"][k], ARM["kd"][k]
                    effort[d], armature[d], friction[d] = ARM["effort"][k], ARM["armature"][k], ARM["friction"][k]
            if name == f"{side}_left_finger":
                ke[d] = GRIPPER["kp"]
                effort[d] = GRIPPER["squeeze"]
    for a, name in enumerate(act_names):
        for side in SIDES:
            for k in range(6):
                if name == f"{side}_joint{k + 1}":
                    forcerange[a] = (-ARM["effort"][k], ARM["effort"][k])
            if name == f"{side}_gripper":
                forcerange[a] = (-GRIPPER["squeeze"], GRIPPER["squeeze"])
    for b, name in enumerate(bnames):
        for side in SIDES:
            for k in range(2, 7):
                if name == f"{side}_link_{k}":
                    gravcomp[b] = ARM["gravcomp"][k - 2]
            if name.startswith(f"{side}_") and any(t in name for t in ("finger", "lf_", "rf_")):
                gravcomp[b] = ARM["gravcomp"][4]
    model.joint_target_ke.assign(ke)
    model.joint_target_kd.assign(kd)
    model.joint_effort_limit.assign(effort)
    model.joint_armature.assign(armature)
    model.joint_friction.assign(friction)
    model.mujoco.actuator_forcerange.assign(forcerange)
    has = model.mujoco.actuator_has_forcerange.numpy()
    has[:] = 1
    model.mujoco.actuator_has_forcerange.assign(has)
    model.mujoco.gravcomp.assign(gravcomp)
    model.shape_gap.fill_(CONTACT_GAP)
    # robot collision shapes (arms, fingers, pads): one material within the fitted ranges
    shape_body = model.shape_body.numpy()
    robot = np.array([b >= 0 and any(bnames[b].startswith(f"{side}_") for side in SIDES) for b in shape_body])
    for attr, value in (("mu", ROBOT_MATERIAL["mu"]), ("mu_torsional", ROBOT_MATERIAL["mu_torsional"]),
                        ("mu_rolling", ROBOT_MATERIAL["mu_rolling"])):
        arr = getattr(model, f"shape_material_{attr}")
        values = arr.numpy()
        values[robot] = value
        arr.assign(values)


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station with the fruits and the tray in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_tray(station)
    add_fruits(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    tune_station(model)
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(
        model, use_mujoco_contacts=False, cone="elliptic", impratio=1.0, iterations=100, ls_iterations=50,
        njmax=1000, nconmax=300,
    )


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return newton.CollisionPipeline(model)


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
