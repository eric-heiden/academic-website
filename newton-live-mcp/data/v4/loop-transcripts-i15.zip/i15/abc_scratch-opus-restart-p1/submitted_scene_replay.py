# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, and ``Example`` drives every world with the logged commands as joint position
targets, open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

The scene is recreated from ``photos/`` and the logs: three fake fruits (a pear and an
orange picked by the left arm, a dark round fruit by the right) as free bodies of spheres,
sized from the top camera and the gripper openings while held, placed where the logged
grasps close (within ~2 cm of where the top camera sees them), and a static wedge-shaped
tray along the outline the top camera sees, with chamfered rims and a shallow V floor
whose low line is where the real fruits came to rest. Fruit and tray contacts use
``condim`` 6 so their rolling and torsional friction act; the solver uses MuJoCo's
elliptic friction cone, and the grippers squeeze with at most ``GRIPPER_FORCE``.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.0,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}


# Scene recreated from the photos and the logs (world frame of the station MJCF, table top at z = 0.75 m).
TABLE_Z = 0.75

# Fruits: free bodies of spheres. Positions are where the logged grasps close (finger-pad midpoint at
# the table-height constraint), within a few cm of where the top camera sees them at the start.
# Each entry: label, mass [kg], body position (x, y) [m], long-axis yaw [rad], spheres (offset along
# the long axis [m], radius [m]) in the body frame (body origin = centre of mass).
FRUITS = (
    # pear: bulb (grasped) and neck, lying on its side, neck pointing away from the left wrist camera
    ("pear", 0.060, (0.657, 0.327), math.atan2(-0.47, 0.88), ((-0.008, 0.028), (0.028, 0.021))),
    ("orange", 0.065, (0.498, -0.050), 0.0, ((0.0, 0.030),)),
    ("dark_fruit", 0.065, (0.642, -0.182), 0.0, ((0.0, 0.034),)),
)
FRUIT_MU = 1.0
FRUIT_TORSIONAL = 0.02
FRUIT_ROLLING = 0.001
CONTACT_GAP = 0.02  # contact detection gap of the added shapes [m]

# Wedge-shaped wooden tray (static): outline seen by the top camera at the start (x, y) [m], counter-clockwise,
# apex first, then the far end of the curved side and the arc back to the near end of the apex edge.
TRAY_OUTLINE = (
    (0.918, 0.142),
    (0.694, 0.187),
    (0.679, 0.155),
    (0.672, 0.100),
    (0.679, 0.056),
    (0.701, 0.020),
    (0.740, -0.012),
    (0.772, -0.025),
)
TRAY_FLOOR = 0.006  # floor thickness [m]
TRAY_RIM = 0.020  # rim height above the table [m]
TRAY_WALL = 0.006  # rim wall thickness [m]
TRAY_CHAMFER = 0.025  # inner chamfer of the rim: horizontal run from the outline down to the floor [m]
TRAY_CREST_OUT = 0.015  # the rim crest lies this far outside the outline seen by the camera [m]
TRAY_VALLEY_X = 0.765  # the floor is lowest along this line (x) [m]
TRAY_SLOPE = 0.07  # floor slope toward the valley
TRAY_MU = 0.6

GRIPPER_KP = 400.0  # finger position gain [N/m]
GRIPPER_FORCE = 8.0  # squeeze force limit per finger [N]


def _quat_z(yaw: float) -> wp.quat:
    return wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), float(yaw))


def _fruit_layout(spheres):
    """Sphere centres in the body frame (long axis tilted so every sphere touches the table) and the body height."""
    if len(spheres) == 1:
        return [(np.zeros(3), spheres[0][1])], spheres[0][1]
    (s0, r0), (s1, r1) = spheres
    tilt = math.asin((r0 - r1) / (s1 - s0))  # both spheres touch the table
    axis = np.array([math.cos(tilt), 0.0, -math.sin(tilt)])  # long axis in the yawed frame (neck lower)
    centres = [s0 * axis, s1 * axis]
    height = r0 - centres[0][2]  # body origin height above the table
    return list(zip(centres, (r0, r1))), height


def add_fruits(builder: newton.ModelBuilder):
    cfg = newton.ModelBuilder.ShapeConfig(
        density=0.0, mu=FRUIT_MU, mu_torsional=FRUIT_TORSIONAL, mu_rolling=FRUIT_ROLLING, restitution=0.0,
        gap=CONTACT_GAP,
    )
    for label, mass, (x, y), yaw, spheres in FRUITS:
        layout, height = _fruit_layout(spheres)
        # inertia: 1.2x a solid ellipsoid of the fruit's extents (within solid and thin-shell)
        lo = np.min([c - r for c, r in layout], axis=0)
        hi = np.max([c + r for c, r in layout], axis=0)
        a, b, c = (hi - lo) / 2.0
        inertia = 1.2 * mass / 5.0 * np.diag([b * b + c * c, a * a + c * c, a * a + b * b])
        body = builder.add_body(
            xform=wp.transform(wp.vec3(x, y, TABLE_Z + height), _quat_z(yaw)),
            mass=mass,
            inertia=wp.mat33(*inertia.flatten().tolist()),
            label=label,
            lock_inertia=True,
        )
        for k, (centre, radius) in enumerate(layout):
            builder.add_shape_sphere(
                body, xform=wp.transform(wp.vec3(*centre.tolist()), wp.quat_identity()), radius=radius, cfg=cfg,
                label=f"{label}_sphere{k}", custom_attributes={"mujoco:condim": 6},
            )


def add_tray(builder: newton.ModelBuilder):
    """Static tray: a shallow V floor of strips across the wedge (lowest along TRAY_VALLEY_X, where the real fruits
    settle) and a rim along every outline edge whose inner side is a chamfer down to the floor."""
    cfg = newton.ModelBuilder.ShapeConfig(
        density=0.0, mu=TRAY_MU, mu_torsional=FRUIT_TORSIONAL, mu_rolling=FRUIT_ROLLING, restitution=0.0,
        gap=CONTACT_GAP,
    )
    attrs = {"mujoco:condim": 6}
    poly = np.asarray(TRAY_OUTLINE)
    apex = poly[0]
    far = poly[1:].mean(axis=0)
    u = (far - apex) / np.linalg.norm(far - apex)
    v = np.array([-u[1], u[0]])
    s_all, t_all = (poly - apex) @ u, (poly - apex) @ v
    s_valley = (apex[0] - TRAY_VALLEY_X) / -u[0] if u[0] != 0.0 else s_all.max() / 2.0
    edges = np.unique(np.concatenate([np.linspace(0.0, s_valley, 4), np.linspace(s_valley, s_all.max(), 3)]))
    yaw = math.atan2(u[1], u[0])

    def section(s):
        ts = []
        for i in range(len(poly)):
            (s0, t0), (s1, t1) = (s_all[i], t_all[i]), (s_all[(i + 1) % len(poly)], t_all[(i + 1) % len(poly)])
            if (s0 - s) * (s1 - s) <= 0.0 and s0 != s1:
                ts.append(t0 + (s - s0) / (s1 - s0) * (t1 - t0))
        return (min(ts), max(ts)) if ts else None

    def floor_top(s):
        return TRAY_FLOOR + TRAY_SLOPE * abs(s - s_valley)

    for i in range(len(edges) - 1):
        s0, s1 = edges[i], edges[i + 1]
        sec = [section(s) for s in np.linspace(s0 + 1e-4, s1 - 1e-4, 5)]
        sec = [q for q in sec if q is not None]
        lo, hi = min(q[0] for q in sec), max(q[1] for q in sec)
        sc, tc = (s0 + s1) / 2.0, (lo + hi) / 2.0
        pitch = math.atan2(floor_top(s1) - floor_top(s0), s1 - s0)  # rise along u
        half_len = (s1 - s0) / 2.0 / math.cos(pitch)
        # top face through floor_top(sc) at the strip centre; the strip is TRAY_FLOOR thick
        n_top = np.array([-math.sin(pitch), 0.0, math.cos(pitch)])  # top normal in the strip frame (x along u)
        centre_local = np.array([0.0, 0.0, floor_top(sc)]) - n_top * TRAY_FLOOR / 2.0
        p = apex + (sc + centre_local[0]) * u + tc * v
        rot = wp.mul(_quat_z(yaw), wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), -pitch))
        builder.add_shape_box(
            -1, xform=wp.transform(wp.vec3(p[0], p[1], TABLE_Z + centre_local[2]), rot),
            hx=half_len, hy=(hi - lo) / 2.0, hz=TRAY_FLOOR / 2.0, cfg=cfg, label=f"tray_floor{i}",
            custom_attributes=attrs,
        )
    centroid = poly.mean(axis=0)
    for i in range(len(poly)):
        a, b = poly[i], poly[(i + 1) % len(poly)]
        d = b - a
        length = float(np.linalg.norm(d))
        n = np.array([d[1], -d[0]]) / length
        if np.dot(centroid - a, n) > 0.0:
            n = -n  # outward normal
        # chamfer: top face from the rim crest (TRAY_CREST_OUT outside the outline) down to the floor TRAY_CHAMFER inside it
        drop = TRAY_RIM - TRAY_FLOOR
        run = TRAY_CHAMFER + TRAY_CREST_OUT
        tilt = math.atan2(drop, run)
        width = math.hypot(drop, run)
        top_mid = (a + b) / 2.0 + n * (TRAY_CREST_OUT - run / 2.0)
        top_z = TRAY_FLOOR + drop / 2.0
        normal = np.array([-n[0] * math.sin(tilt), -n[1] * math.sin(tilt), math.cos(tilt)])  # leans inward
        centre = np.array([top_mid[0], top_mid[1], top_z]) - normal * TRAY_WALL / 2.0
        edge_dir = d / length
        # box frame: x along the edge, y across (inward), z up; tilt about x so the outer side is high
        inward = -n
        cross_z = edge_dir[0] * inward[1] - edge_dir[1] * inward[0]
        sign = -1.0 if cross_z > 0.0 else 1.0
        rot = wp.mul(_quat_z(math.atan2(d[1], d[0])), wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), sign * tilt))
        builder.add_shape_box(
            -1, xform=wp.transform(wp.vec3(centre[0], centre[1], TABLE_Z + centre[2]), rot),
            hx=length / 2.0 + 0.004, hy=width / 2.0, hz=TRAY_WALL / 2.0, cfg=cfg, label=f"tray_rim{i}",
            custom_attributes=attrs,
        )


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station with the fruits and the tray in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_tray(station)
    add_fruits(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    tune_model(model)
    return model


def tune_model(model: newton.Model):
    """Gripper gain and squeeze force (the finger actuators' force range)."""
    names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
    qd_start = model.joint_qd_start.numpy()
    ke, effort = model.joint_target_ke.numpy(), model.joint_effort_limit.numpy()
    for j, name in enumerate(names):
        if name.endswith("_finger"):
            ke[qd_start[j]] = GRIPPER_KP
            effort[qd_start[j]] = GRIPPER_FORCE
    model.joint_target_ke.assign(ke)
    model.joint_effort_limit.assign(effort)
    mj = model.mujoco
    labels = list(mj.actuator_label) if not hasattr(mj.actuator_label, "numpy") else list(mj.actuator_label.numpy())
    frc, has_frc, limited = mj.actuator_forcerange.numpy(), mj.actuator_has_forcerange.numpy(), mj.actuator_forcelimited.numpy()
    gain, bias = mj.actuator_gainprm.numpy(), mj.actuator_biasprm.numpy()
    for i, label in enumerate(labels):
        if str(label).endswith("_gripper"):
            frc[i] = (-GRIPPER_FORCE, GRIPPER_FORCE)
            has_frc[i] = 1
            limited[i] = 1
            gain[i, 0] = GRIPPER_KP
            bias[i, 1] = -GRIPPER_KP
    mj.actuator_forcerange.assign(frc)
    mj.actuator_has_forcerange.assign(has_frc)
    mj.actuator_forcelimited.assign(limited)
    mj.actuator_gainprm.assign(gain)
    mj.actuator_biasprm.assign(bias)


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=False, cone="elliptic", impratio=1.0)


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return newton.CollisionPipeline(model)


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
