# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 tracking a Kimodo motion with constrained whole-body control.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A 50 Hz inverse-dynamics controller tracks the root and joint
reference while balancing on both feet. It commands only the 29 joint servos.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import warp as wp
from scipy import sparse

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Realize inverse-dynamics torques through position-servo offsets.
        # Small inner gains avoid resisting motion during the 20 ms target hold;
        # posture stiffness and damping are supplied by the controller below.
        self.kp = np.full(29, 1.0)
        self.kd = np.full(29, 0.02)
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self._init_controller()
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def _init_controller(self):
        self._dynamics_model = self.solver.mj_model
        self._dynamics_data = mujoco.MjData(self._dynamics_model)
        self._feet = [
            i for i in range(self._dynamics_model.nbody)
            if "ankle_roll_link" in self._dynamics_model.body(i).name
        ]
        self._foot_geoms = [
            i for i in range(self._dynamics_model.ngeom)
            if self._dynamics_model.geom_bodyid[i] in self._feet
        ]
        q = self.reference(0)
        self._dynamics_data.qpos[:] = self._mujoco_qpos(q)
        mujoco.mj_forward(self._dynamics_model, self._dynamics_data)
        self._foot_pos = self._dynamics_data.xpos[self._feet].copy()
        self._foot_pos[:, 2] = 0.035
        self._foot_rot = []
        for foot in self._feet:
            mat = self._dynamics_data.xmat[foot].reshape(3, 3)
            yaw = np.arctan2(mat[1, 0], mat[0, 0])
            self._foot_rot.append(np.array([np.cos(yaw / 2), 0, 0, np.sin(yaw / 2)]))
        self._qp_solution = None

    @staticmethod
    def _mujoco_qpos(q):
        return np.r_[q[:3], q[6], q[3:6], q[7:]]

    def _target(self, t):
        """Solve for feasible accelerations/support forces, then command joint torques.

        The six unactuated dynamics equations are equality constraints. Contact
        forces are optimization variables only: the simulator generates the
        actual ground reactions, and receives no external body or base forces.
        """
        m, d = self._dynamics_model, self._dynamics_data
        actual = self.state_0.joint_q.numpy()
        d.qpos[:] = self._mujoco_qpos(actual)
        d.qvel[:] = self.solver.mjw_data.qvel.numpy()[0]
        mujoco.mj_forward(m, d)

        # Differentiate the public reference, so feedforward follows the input's
        # playback rate. The centered window smooths the piecewise-linear clip.
        h = self.frame_dt
        qref = self._mujoco_qpos(self.reference(t))
        qm = self._mujoco_qpos(self.reference(t - h))
        qp = self._mujoco_qpos(self.reference(t + h))
        # A small controller-only height allowance avoids locking the nearly
        # straight knees when both soles settle flat. reference() is unchanged.
        for q in (qm, qref, qp):
            q[2] -= 0.007
        vm = np.zeros(m.nv)
        vp = np.zeros(m.nv)
        error = np.zeros(m.nv)
        mujoco.mj_differentiatePos(m, vm, h, qm, qref)
        mujoco.mj_differentiatePos(m, vp, h, qref, qp)
        velocity = (vm + vp) / 2
        acceleration = (vp - vm) / h
        mujoco.mj_differentiatePos(m, error, 1.0, d.qpos, qref)
        kp = np.r_[np.full(6, 100.0), np.full(29, 400.0)]
        kd = np.r_[np.full(6, 20.0), np.full(29, 40.0)]
        desired = acceleration + kp * error + kd * (velocity - d.qvel)

        mass = np.zeros((m.nv, m.nv))
        mujoco.mj_fullM(m, d, mass)
        bias = d.qfrc_bias - d.qfrc_passive
        contact_jac = []
        for geom in self._foot_geoms:
            jp = np.zeros((3, m.nv))
            mujoco.mj_jac(m, d, jp, None, d.geom_xpos[geom], int(m.geom_bodyid[geom]))
            contact_jac.append(jp)
        contact_jac = np.vstack(contact_jac)

        # Hold the initial support locations and yaw, with level soles. The
        # acceleration constraints include J-dot*qdot and damp contact drift.
        stance_jac = []
        stance_acc = []
        for k, foot in enumerate(self._feet):
            jp = np.zeros((3, m.nv))
            jr = np.zeros((3, m.nv))
            dp = np.zeros((3, m.nv))
            dr = np.zeros((3, m.nv))
            mujoco.mj_jacBody(m, d, jp, jr, foot)
            mujoco.mj_jacDot(m, d, dp, dr, d.xpos[foot], foot)
            jac = np.vstack([jp, jr])
            rotation_error = np.zeros(3)
            mujoco.mju_subQuat(rotation_error, self._foot_rot[k], d.xquat[foot])
            rotation_error = d.xmat[foot].reshape(3, 3) @ rotation_error
            foot_error = np.r_[self._foot_pos[k] - d.xpos[foot], rotation_error]
            stance_jac.append(jac)
            stance_acc.append(100 * foot_error - 20 * jac @ d.qvel - np.vstack([dp, dr]) @ d.qvel)

        # Variables are generalized accelerations and the eight corner forces.
        # Root tracking takes priority over posture; a small force penalty
        # selects a distributed support load. M*a + bias = S*tau + J.T*f.
        nf = len(contact_jac)
        n = m.nv + nf
        weights = np.r_[np.full(6, 100.0), np.ones(29), np.full(nf, 0.0001)]
        a_base = np.hstack([mass[:6], -contact_jac[:, :6].T])
        a_feet = np.hstack([np.vstack(stance_jac), np.zeros((12, nf))])
        a_tau = np.hstack([mass[6:], -contact_jac[:, 6:].T])

        # Unilateral support and a conservative friction pyramid at each corner.
        cone = []
        for k in range(len(self._foot_geoms)):
            row = np.zeros(n)
            row[m.nv + 3 * k + 2] = 1
            cone.append(row)
            for axis in (0, 1):
                for sign in (-1, 1):
                    row = np.zeros(n)
                    row[m.nv + 3 * k + axis] = sign
                    row[m.nv + 3 * k + 2] = 0.7
                    cone.append(row)
        constraints = np.vstack([a_base, a_feet, a_tau, cone])
        equality = np.r_[-bias[:6], np.concatenate(stance_acc)]
        limits = m.actuator_forcerange[:, 1]
        lower = np.r_[equality, -limits - bias[6:], np.zeros(len(cone))]
        upper = np.r_[equality, limits - bias[6:], np.full(len(cone), np.inf)]
        optimizer = osqp.OSQP()
        optimizer.setup(
            P=sparse.diags(weights, format="csc"),
            q=-weights * np.r_[desired, np.zeros(nf)],
            A=sparse.csc_matrix(constraints),
            l=lower,
            u=upper,
            verbose=False,
            eps_abs=1e-4,
            eps_rel=1e-4,
            max_iter=4000,
            polishing=True,
        )
        if self._qp_solution is not None:
            optimizer.warm_start(x=self._qp_solution)
        result = optimizer.solve(raise_error=False)
        self._qp_status = result.info.status_val
        if result.info.status_val in (1, 2):
            self._qp_solution = result.x
            torque = a_tau @ result.x + bias[6:]
        else:
            # If the support problem is infeasible, retain bounded joint damping.
            torque = -5 * d.qvel[6:]
        torque = np.clip(torque, -limits, limits)

        # tau = kp*(target - q) - kd*qdot. Only actuated coordinates are changed;
        # MuJoCo's original actuator force limits also remain active in substeps.
        target = actual.copy()
        target[7:] += (torque + self.kd * d.qvel[6:]) / self.kp
        return target

    def step(self):
        target = self._target(self.sim_time)
        self.control.joint_target_q.assign(target)
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
