You are working on a Newton physics simulation task.

Workspace: /home/horde/artifacts/newton-live-mcp-v4/loop/i3/dp_real-opus-restart-p0
Newton source tree (read-only reference, including docs and examples): /home/horde/apps/newton-live-mcp

double_pendulum.py models a real robot: the DFKI torque-controlled double pendulum (two quasi-direct-drive AK80-6 motors with 6:1 planetary gearing, one at the shoulder and one at the elbow; shoulder-to-elbow distance 0.2 m, second link 0.3 m). train_00.csv ... train_09.csv are recordings from the real hardware: measured joint angles and velocities and the measured motor torques (about 500 Hz). Problem: the model uses nominal CAD guesses, and its predictions drift quickly away from the recordings.

Goal: calibrate the model so it predicts the real robot. Verification imports the script's build_model(num_worlds) and make_solver(model) and runs its own multiple-shooting evaluation (the same protocol as the script's rollout/window_errors, 2 ms steps) on two held-out recordings of the same robot: a 20 s excitation run and a 75 s run with full swings. Each 0.5 s window starts from the measured state and is driven open loop by the measured torques. The mean joint-angle RMSE over the windows must be at most 0.06 rad on the 20 s run and at most 0.15 rad on the 75 s run. The starter scores about 0.14 and 0.34 rad.
Constraints (checked): keep the two revolute joints, the 0.2 m shoulder-to-elbow offset, gravity, positive masses and valid inertias, and the build_model/make_solver interface. Any physical parameter (masses, centers of mass, inertias, armature, damping, friction, ...) and the solver settings may change, and other Newton modeling features may be used inside build_model/make_solver. Keep the file runnable (`python double_pendulum.py --viewer null`).

Deliverable: the edited double_pendulum.py in the workspace, then a brief report. You have 30 minutes; working efficiently matters. Do not modify files outside the workspace, do not look for other trials or hidden verification data, and do not use subagents.

Workflow: this is a script-based setup. Run the simulation with
  uv run --no-sync --project /home/horde/apps/newton-live-mcp python double_pendulum.py --viewer null --num-frames <N>
or write your own scripts that import the Example class; each run starts a fresh simulator process. There is no display; to look at the scene, render images yourself (for example with newton.sensors.SensorTiledCamera) and open them with your image-viewing tool.
