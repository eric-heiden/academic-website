# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with whole-body balance feedback.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A contact-constrained inverse-dynamics controller sets servo
targets at 250 Hz, using MuJoCo, SciPy, and OSQP for the controller workspace.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import warp as wp
from scipy import sparse

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Inner position servos: kp [N m/rad], kd [N m s/rad]. The balance
        # controller below converts its joint torques to position offsets.
        self.kp = np.array([600, 600, 400, 600, 300, 300] * 2 + [500, 500, 500] + [150] * 14, dtype=float)
        self.kd = np.array([15, 15, 10, 15, 8, 8] * 2 + [12, 12, 12] + [4] * 14, dtype=float)
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self._init_controller()
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self._simulate_control_interval()
            self.graph = capture.graph

    def _init_controller(self):
        """Build a read-only dynamics workspace for the contact-aware controller."""
        self._dynamics_model = self.solver.mj_model
        model = self._dynamics_model
        self._dynamics_data = mujoco.MjData(model)
        self._lookahead_data = mujoco.MjData(model)
        self._feet = [
            body
            for body in range(model.nbody)
            if (mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, body) or "").endswith("ankle_roll_link")
        ]
        self._corners = np.array([[x, y, -0.035] for x in (-0.05, 0.12) for y in (-0.025, 0.025)])
        self._mass_matrix = np.zeros((model.nv, model.nv))
        self._reference_velocity = np.zeros(model.nv)
        self._position_error = np.zeros(model.nv)
        self._acceleration_kp = np.array([150, 150, 200, 150, 150, 150] + [300] * 15 + [2500] * 14)
        self._acceleration_kd = 2.0 * np.sqrt(self._acceleration_kp)
        self._tracking_weights = np.array([20, 20, 20, 10, 10, 10] + [1] * 29)
        self._last_qp = None
        self._control_substeps = 2  # Balance feedback at 250 Hz; physics remains at 500 Hz.

        # Four unilateral point forces per sole, in world coordinates. These are
        # optimization variables only: the simulator produces the actual forces.
        friction_pyramid = np.array([[0, 0, 1], [1, 0, -0.7], [-1, 0, -0.7], [0, 1, -0.7], [0, -1, -0.7]])
        self._friction_constraints = np.zeros((40, model.nv + 24))
        for corner in range(8):
            rows = slice(5 * corner, 5 * corner + 5)
            columns = slice(model.nv + 3 * corner, model.nv + 3 * corner + 3)
            self._friction_constraints[rows, columns] = friction_pyramid
        self._force_lower = np.tile([0, -np.inf, -np.inf, -np.inf, -np.inf], 8)
        self._force_upper = np.tile([500, 0, 0, 0, 0], 8)

    def _native_reference(self, t):
        """Convert the unchanged reference to MuJoCo's wxyz quaternion layout."""
        q = self.reference(t)
        return np.concatenate((q[:3], q[6:7], q[3:6], q[7:]))

    def _balance(self, t):
        """Choose joint torques satisfying unactuated-base dynamics and contact limits.

        The QP minimizes root/posture acceleration error and supporting-foot
        acceleration. Its variables are generalized accelerations and eight
        ground reaction forces. Only the resulting 29 joint torques are sent to
        the simulation, through offsets of the existing position servos.
        """
        model, data = self._dynamics_model, self._dynamics_data
        nv = model.nv
        native_data = self.solver.mjw_data
        data.qpos[:] = native_data.qpos.numpy()[0]
        data.qvel[:] = native_data.qvel.numpy()[0]
        mujoco.mj_forward(model, data)
        mujoco.mj_fullM(model, data, self._mass_matrix)

        # Differentiate reference samples in physical time, so feedforward also
        # adapts to faster clips. Quaternion differences use the tangent space.
        h = 0.01
        reference = self._native_reference(t)
        previous = self._native_reference(t - h)
        following = self._native_reference(t + h)
        mujoco.mj_differentiatePos(model, self._reference_velocity, 2 * h, previous, following)
        mujoco.mj_differentiatePos(model, self._position_error, 1.0, data.qpos, reference)
        velocity_before, velocity_after = np.zeros(nv), np.zeros(nv)
        mujoco.mj_differentiatePos(model, velocity_before, h, previous, reference)
        mujoco.mj_differentiatePos(model, velocity_after, h, reference, following)
        acceleration = np.clip((velocity_after - velocity_before) / h, -100.0, 100.0)
        acceleration += self._acceleration_kp * self._position_error
        acceleration += self._acceleration_kd * (self._reference_velocity - data.qvel)

        contact_jacobian = np.zeros((24, nv))
        foot_jacobian = np.zeros((12, nv))
        for foot, body in enumerate(self._feet):
            mujoco.mj_jacBody(
                model,
                data,
                foot_jacobian[6 * foot : 6 * foot + 3],
                foot_jacobian[6 * foot + 3 : 6 * foot + 6],
                body,
            )
            for corner, local_point in enumerate(self._corners):
                point = data.xpos[body] + data.xmat[body].reshape(3, 3) @ local_point
                row = 12 * foot + 3 * corner
                mujoco.mj_jac(model, data, contact_jacobian[row : row + 3], None, point, body)

        # Evaluate Jdot*v in a separate kinematic workspace. This does not
        # integrate or overwrite the simulated state.
        lookahead = self._lookahead_data
        lookahead.qpos[:] = data.qpos
        lookahead.qvel[:] = data.qvel
        epsilon = 1.0e-4
        mujoco.mj_integratePos(model, lookahead.qpos, data.qvel, epsilon)
        mujoco.mj_fwdPosition(model, lookahead)
        next_jacobian = np.zeros_like(foot_jacobian)
        for foot, body in enumerate(self._feet):
            mujoco.mj_jacBody(
                model,
                lookahead,
                next_jacobian[6 * foot : 6 * foot + 3],
                next_jacobian[6 * foot + 3 : 6 * foot + 6],
                body,
            )
        foot_acceleration = -(next_jacobian - foot_jacobian) @ data.qvel / epsilon
        foot_acceleration -= 40.0 * (foot_jacobian @ data.qvel)

        # Soft stance constraints allow small reference/contact inconsistencies
        # without sacrificing balance. Regularization distributes sole forces.
        size = nv + 24
        hessian = np.zeros((size, size))
        hessian[:nv, :nv] = np.diag(self._tracking_weights) + 100.0 * foot_jacobian.T @ foot_jacobian
        hessian[nv:, nv:] = 1.0e-5 * np.eye(24)
        gradient = np.zeros(size)
        gradient[:nv] = -self._tracking_weights * acceleration - 100.0 * foot_jacobian.T @ foot_acceleration
        dynamics = np.hstack((self._mass_matrix, -contact_jacobian.T))
        bias = data.qfrc_bias - data.qfrc_passive

        # M*a + bias - J.T*f = [0, joint_torque]. The first six rows are
        # equalities with zero base actuation; the rest enforce the MJCF limits.
        lower = np.concatenate((-bias[:6], model.actuator_forcerange[:, 0] - bias[6:], self._force_lower))
        upper = np.concatenate((-bias[:6], model.actuator_forcerange[:, 1] - bias[6:], self._force_upper))
        qp = osqp.OSQP()
        qp.setup(
            P=sparse.csc_matrix(np.triu(hessian)),
            q=gradient,
            A=sparse.csc_matrix(np.vstack((dynamics, self._friction_constraints))),
            l=lower,
            u=upper,
            verbose=False,
            eps_abs=1.0e-4,
            eps_rel=1.0e-4,
            max_iter=1000,
            polishing=False,
        )
        if self._last_qp is not None:
            qp.warm_start(x=self._last_qp)
        result = qp.solve()
        target = self.reference(t)
        if result.x is not None and result.info.status_val in (1, 2):
            self._last_qp = result.x
            torque = (dynamics @ result.x + bias)[6:]
            torque = np.clip(torque, model.actuator_forcerange[:, 0], model.actuator_forcerange[:, 1])
            # Invert tau = kp*(target-q) - kd*v. Between feedback updates,
            # the native implicit position servo supplies local damping.
            target[7:] = data.qpos[7:] + (torque + self.kd * data.qvel[6:]) / self.kp
        # If the optimization fails, retain bounded reference-position servos.
        # No floating-base actuator exists; only target[7:] drives actuators.
        self.control.joint_target_q.assign(target)

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def _simulate_control_interval(self):
        for _ in range(self._control_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def simulate(self):
        for substep in range(0, self.sim_substeps, self._control_substeps):
            self._balance(self.sim_time + substep * self.sim_dt)
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self._simulate_control_interval()

    def step(self):
        self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
