You are working on a Newton physics simulation task.

Workspace: /home/horde/artifacts/newton-live-mcp-v4/loop/i1/g1_track-opus-mcp-p0
Newton source tree (read-only reference, including docs and examples): /home/horde/apps/newton-live-mcp

g1_track.py simulates a floating-base Unitree G1 humanoid (SolverMuJoCo, 50 Hz frames, 2 ms substeps) that should follow a Kimodo reference motion (wave.csv: root pose and 29 joint angles at 30 fps) using position servos with torque limits. Problem: with the current controller the robot falls.

Goal: set up the controller so the robot follows the reference motion without falling. Verification runs the script in a fresh process on wave.csv and on an unseen faster playback of the same clip: the root must stay upright (height above 0.6 m), root position RMSE at most 4 cm, and joint-angle RMSE at most 0.05 rad. It also reports a harder stretch clip (high5.csv) that is not required.
Constraints (checked): do not change the robot model (bodies, masses, armature, torque limits), the timestep, or the motion input and playback, and apply no forces or torques to the floating base. The controller (gains, targets, feedforward, feedback, anything in the step logic) may change. Keep the file runnable as a Newton example (`python g1_track.py --motion wave.csv --viewer null`).

Deliverable: the edited g1_track.py in the workspace, then a brief report. You have 30 minutes; working efficiently matters. Do not modify files outside the workspace, do not look for other trials or hidden verification data, and do not use subagents.

Workflow: g1_track.py is already running live, hosted by the Newton MCP (`newton` server: newton_execute, newton_observe, newton_filmstrip, newton_describe, newton_rebuild). Images returned by MCP tools appear directly in your context, and Python state persists between calls. After editing the script on disk, newton_rebuild reloads it in the live process. You may also run scripts (uv run --no-sync --project /home/horde/apps/newton-live-mcp python g1_track.py --viewer null --num-frames <N> --motion wave.csv) when that is more efficient; each such run starts a fresh process.
Start by calling newton_describe once to confirm the connection. If no newton tools are available to you, reply only with NEWTON_TOOLS_UNAVAILABLE and stop.
Hosted Newton example: /home/horde/artifacts/newton-live-mcp-v4/loop/i1/g1_track-opus-mcp-p0/g1_track.py (class Example, args ['--motion', 'wave.csv']).
- `example` is the live Example instance and `module` its script module; one step is one example frame of ? s. Use rollout(...) or session.dispatch('step', {'count': n}) rather than example.step() so time, recordings, and bindings stay in sync.
- Checkpoints (session.dispatch('checkpoint'/'restore', {'name': ...})) and reset include the example's own Warp arrays and scalar attributes, so controller phases and timers rewind with the physics state. Branch candidates from one checkpoint instead of re-simulating the approach each time.
- Live edits: change model arrays and call example.solver.notify_model_changed(newton.ModelFlags....); assign example attributes (gains, amplitudes) or replace example.solver with a new solver. After each cell the host recaptures the example's CUDA graph if any example attribute changed (reported as `note`); call recapture() after in-place changes it cannot see, such as solver option arrays.
- Python errors in a cell are reported but keep the scene valid; statements before the failing line keep their effects.
- After editing the script on disk, newton_rebuild reloads and reconstructs it in this process (Python variables survive; pass arguments={"argv": [...]} to change example arguments). Rebuild once to confirm the edited script reproduces your live result.
