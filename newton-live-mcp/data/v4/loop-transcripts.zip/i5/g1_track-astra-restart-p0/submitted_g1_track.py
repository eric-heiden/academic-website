# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Balanced Unitree G1 motion tracking through torque-limited position servos.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A small OSQP inverse-dynamics problem balances root tracking,
joint tracking, and stance-foot stabilization at 50 Hz. Servo targets are
advanced at each 2 ms physics substep.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import warp as wp
from scipy import sparse

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


@wp.kernel
def servo_targets(
    plan: wp.array2d(dtype=float),
    gains: wp.array2d(dtype=float),
    dt: float,
    target: wp.array(dtype=float),
):
    # The servo implements tau_ff + kp*(q_plan-q) + kd*(v_plan-v).
    # Only the 29 joint targets are written; the floating base is unactuated.
    i = wp.tid()
    q = plan[0, i] + dt * plan[1, i] + 0.5 * dt * dt * plan[2, i]
    v = plan[1, i] + dt * plan[2, i]
    target[7 + i] = q + (plan[3, i] + gains[1, i] * v) / gains[0, i]


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # for local stabilization around the inverse-dynamics trajectory.
        self.kp = np.array(
            [160, 160, 120, 200, 80, 60] * 2 + [120, 80, 80] + [80, 80, 60, 60, 25, 15, 15] * 2,
            dtype=float,
        )
        self.kd = np.array(
            [8, 8, 6, 10, 4, 3] * 2 + [6, 4, 4] + [4, 4, 3, 3, 1.5, 1, 1] * 2,
            dtype=float,
        )
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self._init_balance_controller()
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def _init_balance_controller(self):
        """Allocate a separate dynamics workspace and a double-support controller."""
        self._mj = self.solver.mj_model
        self._data = mujoco.MjData(self._mj)
        self._future = mujoco.MjData(self._mj)
        self._feet = [
            i for i in range(self._mj.nbody)
            if mujoco.mj_id2name(self._mj, mujoco.mjtObj.mjOBJ_BODY, i).endswith("ankle_roll_link")
        ]
        self._mass = np.zeros((35, 35))
        # A conservative support polygon inside each sole. These points do not
        # add or change collision geometry.
        self._points = np.array([[x, y, -0.035] for x in [-0.05, 0.12] for y in [-0.025, 0.025]])
        self._plan = wp.zeros((4, 29), dtype=float, device=self.model.device)
        self._gains = wp.array(np.stack([self.kp, self.kd]), dtype=float, device=self.model.device)
        self._qp = None
        self._weights = np.array([120, 120, 120, 80, 80, 80] + [1.0] * 29)
        self._p_rows, self._p_cols = np.triu_indices(59)
        self._a_rows = np.tile(np.arange(75), 59)
        self._a_indptr = np.arange(60) * 75

    @staticmethod
    def _mj_q(q):
        return np.concatenate([q[:3], q[[6, 3, 4, 5]], q[7:]])

    def _contact_jacobian(self, data):
        jac = []
        for body in self._feet:
            rot = data.xmat[body].reshape(3, 3)
            for local in self._points:
                jp = np.zeros((3, 35))
                mujoco.mj_jac(self._mj, data, jp, None, data.xpos[body] + rot @ local, body)
                jac.append(jp)
        return np.vstack(jac)

    def _balance(self):
        """Solve for accelerations and support forces, then command joint servos.

        M a + bias = J.T f + S.T tau, with zero actuation on the six root DOFs.
        Contact forces f are planning variables only: actual contacts are always
        resolved by the unchanged physics solver. The QP also bounds joint
        torques and keeps planned contact forces inside unilateral friction cones.
        """
        m, d = self._mj, self._data
        # Read the simulator; this MjData is only a dynamics workspace.
        d.qpos[:] = self.solver.mjw_data.qpos.numpy()[0]
        d.qvel[:] = self.solver.mjw_data.qvel.numpy()[0]
        mujoco.mj_forward(m, d)
        mujoco.mj_fullM(m, d, self._mass)
        J = self._contact_jacobian(d)
        # Directional derivative of the contact Jacobian along current velocity.
        fdata = self._future
        fdata.qpos[:] = d.qpos
        fdata.qvel[:] = d.qvel
        mujoco.mj_integratePos(m, fdata.qpos, d.qvel, 1.0e-4)
        mujoco.mj_forward(m, fdata)
        jdotv = ((self._contact_jacobian(fdata) - J) @ d.qvel) / 1.0e-4

        # Differentiate the public reference sampler, so feedforward follows its
        # actual playback rate. Quaternion errors use the tangent-space rotation.
        t = self.sim_time
        h = 0.01
        qr = self._mj_q(self.reference(t))
        qm = self._mj_q(self.reference(max(0.0, t - h)))
        qp = self._mj_q(self.reference(t + h))
        vr = np.zeros(35)
        vl = np.zeros(35)
        vu = np.zeros(35)
        mujoco.mj_differentiatePos(m, vr, 2 * h, qm, qp)
        mujoco.mj_differentiatePos(m, vl, h, qm, qr)
        mujoco.mj_differentiatePos(m, vu, h, qr, qp)
        ar = (vu - vl) / h
        # Linear CSV interpolation has velocity jumps at keyframes. Bound the
        # resulting feedforward acceleration without changing the reference.
        ar = np.clip(ar, -100, 100)
        err = np.zeros(35)
        mujoco.mj_differentiatePos(m, err, 1.0, d.qpos, qr)
        acc = ar + 400 * err + 40 * (vr - d.qvel)
        acc[:6] = ar[:6] + 120 * err[:6] + 22 * (vr[:6] - d.qvel[:6])

        # Root tracking has priority over posture. Soft stance constraints damp
        # foot velocity while accommodating imperfectly level reference feet.
        weights = self._weights
        W = np.diag(weights)
        H = np.zeros((59, 59))
        H[:35, :35] = W + 30 * J.T @ J
        H[35:, 35:] = np.eye(24) * 1.0e-4
        foot_acc = -jdotv - 20 * (J @ d.qvel)
        g = np.zeros(59)
        g[:35] = -weights * acc - 30 * J.T @ foot_acc
        D = np.hstack([self._mass, -J.T])
        # The six unactuated equations have exactly zero commanded wrench.
        limits = m.actuator_forcerange[:, 1]
        low = np.r_[-d.qfrc_bias[:6], -limits - d.qfrc_bias[6:]]
        high = np.r_[-d.qfrc_bias[:6], limits - d.qfrc_bias[6:]]
        F = np.zeros((40, 59))
        for i in range(8):
            j = 35 + 3 * i
            F[5 * i : 5 * i + 5, j : j + 3] = [
                [0, 0, 1], [1, 0, -0.7], [-1, 0, -0.7], [0, 1, -0.7], [0, -1, -0.7]
            ]
        A = np.vstack([D, F])
        low = np.r_[low, np.tile([0, -np.inf, -np.inf, -np.inf, -np.inf], 8)]
        high = np.r_[high, np.tile([np.inf, 0, 0, 0, 0], 8)]
        # Store explicit zeros to keep the sparsity pattern fixed across frames.
        P = sparse.csc_matrix((H[self._p_rows, self._p_cols], (self._p_rows, self._p_cols)), shape=H.shape)
        As = sparse.csc_matrix((A.T.ravel(), self._a_rows, self._a_indptr), shape=A.shape)
        if self._qp is None:
            self._qp = osqp.OSQP()
            self._qp.setup(
                P=P, q=g, A=As, l=low, u=high, verbose=False,
                eps_abs=1.0e-4, eps_rel=1.0e-4, max_iter=3000, polishing=True,
            )
        else:
            self._qp.update(Px=P.data, q=g, Ax=As.data, l=low, u=high)
        result = self._qp.solve()
        self._last_qp_result = result
        if result.info.status_val not in (1, 2) or not np.all(np.isfinite(result.x)):
            raise RuntimeError(f"Balance inverse dynamics failed: {result.info.status}")
        a = result.x[:35]
        tau = (D @ result.x + d.qfrc_bias)[6:]
        tau = np.clip(tau, -limits, limits)
        self._plan.assign(np.stack([d.qpos[7:], d.qvel[6:], a[6:], tau]))

    def simulate(self):
        for i in range(self.sim_substeps):
            wp.launch(
                servo_targets,
                dim=29,
                inputs=[self._plan, self._gains, (i + 0.5) * self.sim_dt],
                outputs=[self.control.joint_target_q],
                device=self.model.device,
            )
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        self._balance()
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
