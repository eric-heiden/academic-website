# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

###########################################################################
# Example SDF Grinding
#
# A cylindrical grinding wheel is driven kinematically across an ellipsoidal
# workpiece. The workpiece is a mesh shape whose collision geometry is a sparse
# texture SDF (``workpiece_sdf``, built by ``Mesh.build_sdf``); hydroelastic
# SDF-SDF collision reports the contact surface and normal load every frame,
# without a dynamics solver. The rendered workpiece surface is extracted from
# the same SDF.
#
# Material removal: every frame the volume swept by the wheel since the
# previous frame is subtracted from the workpiece SDF with a CSG difference,
# ``d_new = max(d_workpiece, -d_swept_wheel)``. The edit is applied to the
# sparse texture SDF in place (narrow-band subgrid texels and coarse
# background texels), so the collision pipeline, which samples the very same
# textures, and the extracted render surface both see the machined groove.
#
# Command: python sdf_grinding.py
#
###########################################################################

import math

import numpy as np
import warp as wp

import newton
import newton.examples

WORKPIECE_RADII = (0.45, 0.25, 0.12)
WORKPIECE_RESOLUTION = 256
GRINDER_RADIUS = 0.13
GRINDER_HALF_WIDTH = 0.04
GRIND_DEPTH = 0.035
GRIND_FRAMES = 270
HYDROELASTIC_STIFFNESS = 1.0e8


@wp.kernel(enable_backward=False)
def _compute_normal_load(
    contact_count: wp.array[wp.int32],
    contact_distance: wp.array[wp.float32],
    contact_stiffness: wp.array[wp.float32],
    normal_load: wp.array[wp.float32],
):
    contact = wp.tid()
    if contact < contact_count[0]:
        normal_load[contact] = wp.max(-contact_distance[contact] * contact_stiffness[contact], 0.0)
    else:
        normal_load[contact] = 0.0


@wp.func
def _swept_wheel_sdf(p: wp.vec3, seg_start: wp.vec3, radius: float, half_width: float) -> float:
    """Signed distance [m] to a wheel swept along a straight segment.

    ``p`` and ``seg_start`` are given in the wheel frame of the current pose
    (wheel axis = local +Z, centered at the origin); ``seg_start`` is the
    wheel center of the previous pose. The swept solid of a disk translated
    in its own plane is a 2D stadium extruded along the axis, so the SDF is
    exact for in-plane motion.
    """
    a = wp.vec2(seg_start[0], seg_start[1])
    q = wp.vec2(p[0], p[1])
    ab = -a
    denom = wp.dot(ab, ab)
    t = float(0.0)
    if denom > 1.0e-20:
        t = wp.clamp(wp.dot(q - a, ab) / denom, 0.0, 1.0)
    dr = wp.length(q - (a + t * ab)) - radius
    # Axial extent covers both endpoints (the tool path has no axial motion).
    z_hi = wp.max(seg_start[2], 0.0) + half_width
    z_lo = wp.min(seg_start[2], 0.0) - half_width
    da = wp.max(p[2] - z_hi, z_lo - p[2])
    return wp.min(wp.max(dr, da), 0.0) + wp.length(wp.vec2(wp.max(dr, 0.0), wp.max(da, 0.0)))


@wp.kernel(enable_backward=False)
def _carve_subgrid_texels(
    subgrid_values: wp.array3d[wp.float32],
    subgrid_start_slots: wp.array3d[wp.uint32],
    subgrid_size: int,
    sdf_box_lower: wp.vec3,
    voxel_size: wp.vec3,
    value_min: float,
    value_range: float,
    workpiece_to_wheel: wp.transform,
    seg_start: wp.vec3,
    radius: float,
    half_width: float,
):
    bx, by, bz, local = wp.tid()
    slot = subgrid_start_slots[bx, by, bz]
    if slot >= wp.uint32(0xFFFFFFFE):
        # Empty or linearized cell: sampled from the coarse texture instead.
        return
    samples = subgrid_size + 1
    lx = local % samples
    ly = (local // samples) % samples
    lz = local // (samples * samples)

    # Local position of the texel's fine-grid vertex in the workpiece frame.
    ix = bx * subgrid_size + lx
    iy = by * subgrid_size + ly
    iz = bz * subgrid_size + lz
    p = sdf_box_lower + wp.cw_mul(wp.vec3(float(ix), float(iy), float(iz)), voxel_size)
    tool_distance = _swept_wheel_sdf(wp.transform_point(workpiece_to_wheel, p), seg_start, radius, half_width)

    # Packed texel address (see sdf_texture._read_cell_corners).
    tx = int(slot & wp.uint32(0x3FF)) * samples + lx
    ty = int((slot >> wp.uint32(10)) & wp.uint32(0x3FF)) * samples + ly
    tz = int((slot >> wp.uint32(20)) & wp.uint32(0x3FF)) * samples + lz
    old_distance = subgrid_values[tz, ty, tx] * value_range + value_min
    if -tool_distance > old_distance:
        subgrid_values[tz, ty, tx] = (-tool_distance - value_min) / value_range


@wp.kernel(enable_backward=False)
def _carve_coarse_texels(
    coarse_values: wp.array3d[wp.float32],
    subgrid_size: int,
    sdf_box_lower: wp.vec3,
    voxel_size: wp.vec3,
    workpiece_to_wheel: wp.transform,
    seg_start: wp.vec3,
    radius: float,
    half_width: float,
):
    cz, cy, cx = wp.tid()
    p = sdf_box_lower + wp.cw_mul(
        wp.vec3(float(cx * subgrid_size), float(cy * subgrid_size), float(cz * subgrid_size)), voxel_size
    )
    tool_distance = _swept_wheel_sdf(wp.transform_point(workpiece_to_wheel, p), seg_start, radius, half_width)
    coarse_values[cz, cy, cx] = wp.max(coarse_values[cz, cy, cx], -tool_distance)


class Example:
    def __init__(self, viewer, _args):
        self.viewer = viewer
        self.frame_dt = 1.0 / 60.0
        self.sim_time = 0.0
        self.frame = 0

        # A gently curved blank keeps fine SDF subgrids resident around the
        # entire machined surface, which makes this compact in-place demo
        # independent of Newton's linear-subgrid storage optimization.
        workpiece_mesh = newton.Mesh.create_ellipsoid(
            *WORKPIECE_RADII,
            num_latitudes=32,
            num_longitudes=64,
            compute_normals=False,
            compute_uvs=False,
            compute_inertia=False,
        )
        self.workpiece_sdf = workpiece_mesh.build_sdf(
            max_resolution=WORKPIECE_RESOLUTION,
            narrow_band_range=(-0.08, 0.08),
            margin=0.04,
            texture_format="float32",
            paired_samples=False,
        )

        shape_cfg = newton.ModelBuilder.ShapeConfig(
            margin=0.0,
            gap=0.005,
            kh=HYDROELASTIC_STIFFNESS,
            density=0.0,
            is_hydroelastic=True,
        )
        workpiece_cfg = shape_cfg.copy()
        workpiece_cfg.is_visible = False
        grinder_cfg = shape_cfg.copy()
        grinder_cfg.sdf_max_resolution = 64
        grinder_cfg.sdf_narrow_band_range = (-0.06, 0.06)
        grinder_cfg.sdf_padding = 0.01

        builder = newton.ModelBuilder()
        builder.sdf_texture_paired_samples = False
        self.workpiece_shape = builder.add_shape_mesh(
            body=-1,
            mesh=workpiece_mesh,
            cfg=workpiece_cfg,
            label="workpiece",
        )

        initial_pose = self._grinder_pose(0)
        self.grinder_body = builder.add_body(xform=initial_pose, label="grinder")
        self.grinder_shape = builder.add_shape_cylinder(
            body=self.grinder_body,
            radius=GRINDER_RADIUS,
            half_height=GRINDER_HALF_WIDTH,
            cfg=grinder_cfg,
            color=(0.18, 0.20, 0.23),
            opacity=0.4,
            label="grinding_wheel",
        )

        self.model = builder.finalize()
        self.state_0 = self.model.state()
        self.collision_pipeline = newton.CollisionPipeline(
            self.model,
            sdf_hydroelastic_config=newton.geometry.HydroelasticSDF.Config(
                output_contact_surface=True,
            ),
        )
        self.contacts = self.collision_pipeline.contacts()
        self.contact_surface = self.collision_pipeline.hydroelastic_sdf.get_contact_surface()
        self.contact_distance = wp.empty(
            self.contacts.rigid_contact_max,
            dtype=wp.float32,
            device=self.model.device,
        )
        self.normal_load = wp.empty_like(self.contact_distance)
        self.total_normal_load = 0.0

        self.body_q = self.state_0.body_q.numpy()
        self._set_grinder_pose(initial_pose)
        self._init_material_removal()
        self._update_workpiece_surface()

        self.viewer.set_model(self.model)
        self.viewer.show_hydro_contact_surface = True
        self.viewer.set_camera(pos=wp.vec3(0.8, -0.85, 0.5), pitch=-18.0, yaw=132.0)

    @staticmethod
    def _grinder_pose(frame: int) -> wp.transform:
        x_start = -0.36
        x_end = 0.36
        x = x_start + min(frame / GRIND_FRAMES, 1.0) * (x_end - x_start)
        radial_fraction = min((x / WORKPIECE_RADII[0]) ** 2, 1.0)
        surface_z = WORKPIECE_RADII[2] * math.sqrt(1.0 - radial_fraction)
        z = surface_z + GRINDER_RADIUS - GRIND_DEPTH
        rotation = wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), -0.5 * math.pi)
        return wp.transform(wp.vec3(x, 0.0, z), rotation)

    def _set_grinder_pose(self, pose: wp.transform) -> None:
        self.body_q[self.grinder_body] = np.asarray(pose)
        self.state_0.body_q.assign(self.body_q)

    def _init_material_removal(self) -> None:
        """Mirror the workpiece SDF textures into editable Warp arrays.

        The model's texture SDF table references the same ``wp.Texture3D``
        objects as ``self.workpiece_sdf``, so writing the edited arrays back
        into these textures updates the collision geometry in place.
        """
        sdf = self.workpiece_sdf.texture_data
        self._subgrid_texture = self.workpiece_sdf._subgrid_texture
        self._coarse_texture = self.workpiece_sdf._coarse_texture
        for tex in (self._subgrid_texture, self._coarse_texture):
            if tex.num_channels != 1 or tex.dtype != wp.float32:
                raise RuntimeError("Material removal requires unpaired float32 SDF textures.")

        device = self.model.device
        self._subgrid_values = wp.empty(
            (self._subgrid_texture.depth, self._subgrid_texture.height, self._subgrid_texture.width),
            dtype=wp.float32,
            device=device,
        )
        self._coarse_values = wp.empty(
            (self._coarse_texture.depth, self._coarse_texture.height, self._coarse_texture.width),
            dtype=wp.float32,
            device=device,
        )
        self._subgrid_texture.copy_to(self._subgrid_values)
        self._coarse_texture.copy_to(self._coarse_values)
        self._subgrid_start_slots = sdf.subgrid_start_slots
        self._subgrid_size = int(sdf.subgrid_size)
        self._sdf_box_lower = wp.vec3(sdf.sdf_box_lower)
        self._voxel_size = wp.vec3(sdf.voxel_size)
        self._value_min = float(sdf.subgrids_min_sdf_value)
        self._value_range = float(sdf.subgrids_sdf_value_range)

        shape_transform = self.model.shape_transform.numpy()
        self._workpiece_xform = wp.transform(*shape_transform[self.workpiece_shape])
        self._wheel_shape_xform = wp.transform(*shape_transform[self.grinder_shape])
        # The first frame sweeps from the initial (already plunged) pose, so the
        # material occupied by the wheel at frame 0 is removed as well.
        self._previous_wheel_xform = self._wheel_xform()

    def _wheel_xform(self) -> wp.transform:
        """World transform of the grinding wheel shape."""
        body_xform = wp.transform(*self.body_q[self.grinder_body])
        return wp.transform_multiply(body_xform, self._wheel_shape_xform)

    def _remove_swept_material(self) -> None:
        """Subtract the wheel volume swept since the last call from the workpiece SDF."""
        wheel_xform = self._wheel_xform()
        previous_xform = self._previous_wheel_xform
        self._previous_wheel_xform = wheel_xform

        # Workpiece-local points -> current wheel frame; previous wheel center in that frame.
        world_to_wheel = wp.transform_inverse(wheel_xform)
        workpiece_to_wheel = wp.transform_multiply(world_to_wheel, self._workpiece_xform)
        seg_start = wp.transform_point(world_to_wheel, wp.transform_get_translation(previous_xform))
        device = self.model.device

        slots_shape = self._subgrid_start_slots.shape
        samples = (self._subgrid_size + 1) ** 3
        wp.launch(
            _carve_subgrid_texels,
            dim=(slots_shape[0], slots_shape[1], slots_shape[2], samples),
            inputs=[
                self._subgrid_values,
                self._subgrid_start_slots,
                self._subgrid_size,
                self._sdf_box_lower,
                self._voxel_size,
                self._value_min,
                self._value_range,
                workpiece_to_wheel,
                seg_start,
                GRINDER_RADIUS,
                GRINDER_HALF_WIDTH,
            ],
            device=device,
        )
        wp.launch(
            _carve_coarse_texels,
            dim=self._coarse_values.shape,
            inputs=[
                self._coarse_values,
                self._subgrid_size,
                self._sdf_box_lower,
                self._voxel_size,
                workpiece_to_wheel,
                seg_start,
                GRINDER_RADIUS,
                GRINDER_HALF_WIDTH,
            ],
            device=device,
        )
        # Write back into the textures shared by the SDF and the collision pipeline.
        self._subgrid_texture.copy_from(self._subgrid_values)
        self._coarse_texture.copy_from(self._coarse_values)

    def _update_workpiece_surface(self) -> None:
        surface = self.workpiece_sdf.extract_isomesh(device=self.model.device)
        if surface is None:
            raise RuntimeError("Grinding removed the complete workpiece.")
        self.workpiece_points = wp.array(surface.vertices, dtype=wp.vec3, device=self.model.device)
        self.workpiece_indices = wp.array(surface.indices.reshape(-1), dtype=wp.int32, device=self.model.device)

    def step(self):
        self.frame += 1
        grinder_pose = self._grinder_pose(self.frame)
        self._set_grinder_pose(grinder_pose)

        # Run hydroelastic SDF-SDF collision before editing the workpiece.
        self.collision_pipeline.collide(self.state_0, self.contacts)
        newton.eval_rigid_contact_kinematics(
            self.model,
            self.state_0,
            self.contacts,
            out_distance=self.contact_distance,
        )
        wp.launch(
            _compute_normal_load,
            dim=self.contacts.rigid_contact_max,
            inputs=[
                self.contacts.rigid_contact_count,
                self.contact_distance,
                self.contacts.rigid_contact_stiffness,
                self.normal_load,
            ],
            device=self.model.device,
        )
        self.total_normal_load = float(wp.utils.array_sum(self.normal_load))
        # Remove the material the grinding wheel swept through during this frame.
        self._remove_swept_material()
        self._update_workpiece_surface()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.log_mesh(
            "/workpiece_sdf",
            self.workpiece_points,
            self.workpiece_indices,
            color=(0.55, 0.62, 0.68),
            roughness=0.65,
            metallic=0.25,
            dynamic=True,
        )
        self.viewer.log_hydro_contact_surface(self.contact_surface)
        self.viewer.log_scalar("Hydroelastic normal load [N]", self.total_normal_load)
        self.viewer.end_frame()


if __name__ == "__main__":
    viewer, args = newton.examples.init()
    newton.examples.run(Example(viewer, args), args)
