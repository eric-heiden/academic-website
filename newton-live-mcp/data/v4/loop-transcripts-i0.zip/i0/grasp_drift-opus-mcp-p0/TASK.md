You are working on a Newton physics simulation task.

Workspace: /home/horde/artifacts/newton-live-mcp-v4/loop/i0/grasp_drift-opus-mcp-p0
Newton source tree (read-only reference, including docs and examples): /home/horde/apps/newton-live-mcp

franka_cube_shake.py is a Newton simulation (SolverMuJoCo, Newton collision pipeline) of a Franka FR3 that grasps a 4 cm cube, lifts it, and shakes it along a Lissajous path. Problem: the grasp is not reliable. With a 10 cm / 1 Hz shake (`--shake-amplitude 0.1`) the cube slips and is dropped, and smaller shakes also let it creep.

Goal: change the scene so the grasp holds. Verification runs the script's Example in a fresh process and measures the cube position in the hand (TCP) frame from the start of the shake: over 11.5 s of 3 cm / 1 Hz shaking it must move less than 1 mm, and over 6 s of 10 cm / 1 Hz shaking it must stay in the hand and move less than 5 mm.
Constraints (checked): do not change the scripted motion (phases, durations, IK, shake path), joint gains or effort limits, gripper commands, the cube's size, density, or mass, gravity, or the timestep (60 Hz frames, 16 substeps), and do not add bodies, joints, or constraints between gripper and cube. Contact, material, collision, and solver settings may change. Keep the file runnable as a Newton example (`python franka_cube_shake.py --viewer null`). Report the root cause you found.

Deliverable: the edited franka_cube_shake.py in the workspace, then a brief report. You have 30 minutes; working efficiently matters. Do not modify files outside the workspace, do not look for other trials or hidden verification data, and do not use subagents.

Workflow: franka_cube_shake.py is already running live, hosted by the Newton MCP (`newton` server: newton_execute, newton_observe, newton_filmstrip, newton_describe, newton_rebuild). Images returned by MCP tools appear directly in your context, and Python state persists between calls. After editing the script on disk, newton_rebuild reloads it in the live process. You may also run scripts (uv run --no-sync --project /home/horde/apps/newton-live-mcp python franka_cube_shake.py --viewer null --num-frames <N>) when that is more efficient; each such run starts a fresh process.
Start by calling newton_describe once to confirm the connection. If no newton tools are available to you, reply only with NEWTON_TOOLS_UNAVAILABLE and stop.
Hosted Newton example: /home/horde/artifacts/newton-live-mcp-v4/loop/i0/grasp_drift-opus-mcp-p0/franka_cube_shake.py (class Example, args []).
- `example` is the live Example instance and `module` its script module; `example.step()` advances one frame of ? s. Prefer session.dispatch('step', {'count': n}) so time, recordings, and bindings stay in sync.
- Checkpoints (session.dispatch('checkpoint'/'restore', {'name': ...})) and reset include the example's own Warp arrays and scalar attributes, so controller phases and timers rewind with the physics state.
- After editing the script on disk, newton_rebuild reloads and reconstructs it in this process (Python variables survive; pass arguments={"argv": [...]} to change example arguments).
- Model parameters can also be changed in place: edit model arrays in Python and call solver.notify_model_changed(newton.ModelFlags....) for the categories you touched.
