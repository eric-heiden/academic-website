# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import numpy as np
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def _quat_rotate(q, v):
    """Rotate vector v by quaternion q (xyzw)."""
    u, w = np.asarray(q[:3], dtype=float), float(q[3])
    return v + 2.0 * np.cross(u, np.cross(u, v) + w * v)


def _quat_rotate_inv(q, v):
    return _quat_rotate(np.array([-q[0], -q[1], -q[2], q[3]]), v)


def _rotation(axis, angle):
    """Rotation matrix about a unit axis (Rodrigues)."""
    k = np.array([[0.0, -axis[2], axis[1]], [axis[2], 0.0, -axis[0]], [-axis[1], axis[0], 0.0]])
    return np.eye(3) + np.sin(angle) * k + (1.0 - np.cos(angle)) * (k @ k)


def _quat_matrix(q):
    """Rotation matrix of a quaternion (xyzw)."""
    x, y, z, w = q
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def _log_rotation(r):
    """Axis-angle vector of a rotation matrix."""
    angle = np.arccos(np.clip(0.5 * (np.trace(r) - 1.0), -1.0, 1.0))
    v = 0.5 * np.array([r[2, 1] - r[1, 2], r[0, 2] - r[2, 0], r[1, 0] - r[0, 1]])
    return v if angle < 1e-6 else v * (angle / np.sin(angle))


def _yaw_only(r):
    yaw = np.arctan2(r[1, 0], r[0, 0])
    return _rotation(np.array([0.0, 0.0, 1.0]), yaw)


class Leg:
    """Serial pelvis-to-foot chain (6 revolute joints) with numerical IK."""

    def __init__(self, model, joint_indices):
        q_start = model.joint_q_start.numpy()
        qd_start = model.joint_qd_start.numpy()
        axes = model.joint_axis.numpy()
        x_p = model.joint_X_p.numpy()
        self.q_index = np.array([q_start[j] for j in joint_indices])
        self.foot_body = int(model.joint_child.numpy()[joint_indices[-1]])
        self.offsets = [(x_p[j, :3].astype(float), _quat_matrix(x_p[j, 3:7].astype(float))) for j in joint_indices]
        self.axes = [axes[qd_start[j]].astype(float) for j in joint_indices]

    def fk(self, angles):
        """Foot pose (position, rotation) in the pelvis frame."""
        p, r = np.zeros(3), np.eye(3)
        for (offset, offset_rot), axis, angle in zip(self.offsets, self.axes, angles):
            p = p + r @ offset
            r = r @ offset_rot @ _rotation(axis, angle)
        return p, r

    def ik(self, angles, p_target, r_target, iterations=4, damping=1e-3):
        """Leg angles placing the foot at (p_target, r_target) in the pelvis frame, from an initial guess."""
        q = np.array(angles, dtype=float)
        eps = 1e-5
        for _ in range(iterations):
            p, r = self.fk(q)
            err = np.concatenate([p_target - p, _log_rotation(r_target @ r.T)])
            if np.linalg.norm(err) < 1e-6:
                break
            jac = np.zeros((6, 6))
            for i in range(6):
                dq = q.copy()
                dq[i] += eps
                pi, ri = self.fk(dq)
                jac[:3, i] = (pi - p) / eps
                jac[3:, i] = _log_rotation(ri @ r.T) / eps
            step = np.linalg.solve(jac.T @ jac + damping * np.eye(6), jac.T @ err)
            q += step * min(1.0, 0.2 / max(np.abs(step).max(), 1e-12))
        return q


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, from a natural frequency and damping ratio on the
        # reflected armature (the link inertia adds to it, so the loop is slower).
        natural_frequency = 2.0 * np.pi * 50.0
        damping_ratio = 1.0
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * damping_ratio * ARMATURE * natural_frequency
        # Servo targets lead the reference by this much [s].
        self.lookahead = self.frame_dt
        # Planted feet: the legs are re-solved by IK so that each foot stays flat at
        # the pose where the reference put it down (the clips pivot and rock the
        # feet, which real contact cannot follow) while the pelvis follows the
        # reference pose corrected by the balance feedback below.
        self.planted_feet = True
        self.lift_height = 0.03  # reference foot rise [m] that releases the anchor
        # Balance feedback on the pelvis target: tilt error [rad/rad], tilt rate
        # [rad s/rad], horizontal position error [m/m] and velocity error [m s/m].
        self.tilt_kp = 0.0
        self.tilt_kd = 0.0
        self.pos_kp = 0.7
        self.pos_kd = 0.1
        # The pelvis yaw target follows the reference yaw through a critically damped
        # low-pass [Hz]: fast reference turns would spin the feet on the floor (the
        # hip yaw joints absorb the lag).
        self.yaw_filter_hz = 3.0
        self._yaw = self._yaw_rate = 0.0
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)

        joint_labels = [label.rsplit("/", 1)[-1] for label in self.model.joint_label]
        chain = ("hip_pitch", "hip_roll", "hip_yaw", "knee", "ankle_pitch", "ankle_roll")
        self.legs = [
            Leg(self.model, [joint_labels.index(f"{side}_{name}_joint") for name in chain])
            for side in ("left", "right")
        ]
        self.anchors = [None, None]
        self.foot_height0 = [None, None]

        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        target = self.controller_targets()
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def _feet(self, q):
        """World foot poses of joint_q-layout pose q."""
        p_root, r_root = q[:3], _quat_matrix(q[3:7])
        feet = []
        for leg in self.legs:
            p, r = leg.fk(q[leg.q_index])
            feet.append((p_root + r_root @ p, r_root @ r))
        return feet

    def controller_targets(self):
        """Servo position targets (Newton joint_q layout) for the next frame."""
        t = self.sim_time + self.lookahead
        target = self.reference(t)
        if not self.planted_feet:
            return target

        # Pelvis target: reference pose plus balance feedback.
        q = self.state_0.joint_q.numpy()
        qd = self.state_0.joint_qd.numpy()
        ref = self.reference(self.sim_time)
        ref_prev = self.reference(self.sim_time - self.frame_dt)
        r_meas, r_ref = _quat_matrix(q[3:7]), _quat_matrix(ref[3:7])
        tilt = np.cross(r_ref[:, 2], r_meas[:, 2])  # rotation axis * angle, ref -> measured up-axis
        tilt_rate = qd[3:6] - (0.0 if self.sim_time <= 0.0 else _log_rotation(r_ref @ _quat_matrix(ref_prev[3:7]).T) / self.frame_dt)
        tilt_rate[2] = 0.0
        correction = -self.tilt_kp * tilt - self.tilt_kd * tilt_rate
        r_target = _quat_matrix(target[3:7])
        yaw_ref = np.arctan2(r_target[1, 0], r_target[0, 0])
        if self.sim_time <= 0.0:
            self._yaw, self._yaw_rate = yaw_ref, 0.0
        if self.yaw_filter_hz > 0.0:
            w = 2.0 * np.pi * self.yaw_filter_hz
            yaw_err = np.arctan2(np.sin(yaw_ref - self._yaw), np.cos(yaw_ref - self._yaw))
            self._yaw_rate += self.frame_dt * (w * w * yaw_err - 2.0 * w * self._yaw_rate)
            self._yaw += self.frame_dt * self._yaw_rate
            r_target = _rotation(np.array([0.0, 0.0, 1.0]), self._yaw - yaw_ref) @ r_target
        r_pelvis = _rotation(correction / max(np.linalg.norm(correction), 1e-12), np.linalg.norm(correction)) @ r_target
        v_ref = (ref[:3] - ref_prev[:3]) / self.frame_dt if self.sim_time > 0.0 else np.zeros(3)
        p_pelvis = target[:3] + self.pos_kp * (ref[:3] - q[:3]) + self.pos_kd * (v_ref - qd[:3])
        p_pelvis[2] = target[2]

        feet = self._feet(target)
        for i, leg in enumerate(self.legs):
            p_foot, r_foot = feet[i]
            if self.foot_height0[i] is None or self.sim_time <= 0.0:
                self.foot_height0[i] = p_foot[2]
                self.anchors[i] = None
            if p_foot[2] > self.foot_height0[i] + self.lift_height:
                self.anchors[i] = None  # swing: follow the reference foot
            else:
                if self.anchors[i] is None:
                    self.anchors[i] = (np.array([p_foot[0], p_foot[1], self.foot_height0[i]]), _yaw_only(r_foot))
                p_foot, r_foot = self.anchors[i]
            angles = leg.ik(target[leg.q_index], r_pelvis.T @ (p_foot - p_pelvis), r_pelvis.T @ r_foot)
            target[leg.q_index] = angles
        return target

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
