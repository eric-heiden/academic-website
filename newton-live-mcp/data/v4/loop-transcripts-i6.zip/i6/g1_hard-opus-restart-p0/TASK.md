You are working on a Newton physics simulation task.

Workspace: /home/horde/artifacts/newton-live-mcp-v4/loop/i6/g1_hard-opus-restart-p0
Newton source tree (read-only reference, including docs and examples): /home/horde/apps/newton-live-mcp

g1_track.py simulates a floating-base Unitree G1 humanoid (SolverMuJoCo, 50 Hz frames, 2 ms substeps) that should follow Kimodo reference motions (root pose and 29 joint angles at 30 fps) using position servos with torque limits. Problem: with the current controller the robot falls, and high5.csv, a clip in which the root turns and shifts its weight, defeats plain joint-space PD tuning.

Goal: set up a controller that follows both wave.csv and high5.csv without falling. Verification runs the script in a fresh process on wave.csv, on high5.csv, and on an unseen slower (0.9x) playback of high5.csv: the root must stay upright (height above 0.6 m), root position RMSE at most 4 cm, and joint-angle RMSE at most 0.05 rad on every run. The same controller code must handle every clip (select the clip only through --motion).
Constraints (checked): do not change the robot model (bodies, masses, armature, torque limits), the timestep, or the motion input and playback, and apply no forces or torques to the floating base. The controller (gains, targets, feedforward, feedback, estimation, anything in the step logic, and additional Python packages already installed) may change. Keep the file runnable as a Newton example (`python g1_track.py --motion high5.csv --viewer null`).

Deliverable: the edited g1_track.py in the workspace, then a brief report. You have 60 minutes; working efficiently matters. Do not modify files outside the workspace, do not look for other trials or hidden verification data, and do not use subagents.

Workflow: this is a script-based setup. Run the simulation with
  uv run --no-sync --project /home/horde/apps/newton-live-mcp python g1_track.py --viewer null --num-frames <N> --motion high5.csv
or write your own scripts that import the Example class; each run starts a fresh simulator process. There is no display; to look at the scene, render images yourself (for example with newton.sensors.SensorTiledCamera) and open them with your image-viewing tool.
