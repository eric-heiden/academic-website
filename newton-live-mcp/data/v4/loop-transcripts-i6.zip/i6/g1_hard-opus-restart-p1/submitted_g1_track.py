# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import os

import mujoco
import numpy as np
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def quat_xyzw_to_wxyz(q):
    return np.concatenate([q[..., 3:4], q[..., :3]], axis=-1)


def _param(name, default):
    return float(os.environ.get(name, default))


def rotvec(R):
    """Rotation vector (axis * angle) of a rotation matrix."""
    q = np.zeros(4)
    mujoco.mju_mat2Quat(q, R.reshape(-1))
    v = np.zeros(3)
    mujoco.mju_quat2Vel(v, q, 1.0)
    return v


def rotmat(v):
    q = np.zeros(4)
    angle = np.linalg.norm(v)
    if angle < 1e-12:
        return np.eye(3)
    mujoco.mju_axisAngle2Quat(q, v / angle, angle)
    R = np.zeros(9)
    mujoco.mju_quat2Mat(R, q)
    return R.reshape(3, 3)


def yaw_only(R):
    yaw = np.arctan2(R[1, 0], R[0, 0])
    c, s = np.cos(yaw), np.sin(yaw)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def convex_hull(points):
    """Counter-clockwise convex hull of 2D points (monotone chain)."""
    pts = sorted(map(tuple, points))

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)
    return np.array(lower[:-1] + upper[:-1])


def clamp_to_polygon(x, hull, margin):
    """Project a 2D point into a convex polygon shrunk by margin (iterated half-plane projection)."""
    x = x.copy()
    edges = []
    for i in range(len(hull)):
        a, b = hull[i], hull[(i + 1) % len(hull)]
        t = (b - a) / np.linalg.norm(b - a)
        n = np.array([-t[1], t[0]])  # inward normal for a CCW polygon
        edges.append((n, n @ a + margin))
    for _ in range(10):
        for n, d in edges:
            v = n @ x - d
            if v < 0.0:
                x -= v * n
    return x


class StanceController:
    """Double-support whole-body controller built on a MuJoCo CPU copy of the G1 kinematics.

    Both feet stay flat where they currently stand. Each frame the controller
    1. commands a pelvis pose: the reference root pose plus PI feedback on the measured root pose error,
    2. solves leg inverse kinematics from the measured (flattened) foot poses to that pelvis pose,
    3. adds gravity-compensation feedforward (contact wrenches split between the feet) as servo target offsets.
    Waist and arms track the reference joint angles.
    """

    FOOT_SOLE = np.array([0.035, 0.0, -0.035])  # sole center in the ankle roll frame [m]
    FOOT_CORNERS = np.array([[-0.05, 0.025, -0.035], [-0.05, -0.025, -0.035], [0.12, 0.03, -0.035], [0.12, -0.03, -0.035]])

    def __init__(self, mjcf_path, kp, dt):
        self.m = mujoco.MjModel.from_xml_path(mjcf_path)
        self.d = mujoco.MjData(self.m)
        self.kp = kp
        self.dt = dt
        self.feet = [mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_BODY, f"{s}_ankle_roll_link") for s in ("left", "right")]
        self.leg_dofs = [np.arange(6, 12), np.arange(12, 18)]
        self.jnt_range = self.m.jnt_range[1:].copy()
        self.pos_gain = _param("ROOT_KP", 1.0)
        self.pos_ki = _param("ROOT_KI", 0.5)
        self.rot_gain = _param("ROT_KP", 1.0)
        self.rot_ki = _param("ROT_KI", 0.5)
        self.ff_scale = _param("FF", 1.0)
        self.w_foot_rot = _param("W_FR", 0.3)
        self.w_pelvis_pos = _param("W_PP", 0.3)
        self.w_pelvis_rot = _param("W_PR", 0.05)
        self.w_joint = _param("W_Q", 0.01)
        self.ik_iters = int(_param("IK_ITERS", 6))
        self.reanchor = _param("REANCHOR", 0.0)
        self.com_margin = _param("COM_MARGIN", 0.06)
        self.com_gain = _param("COM_GAIN", 1.3)
        self.vel_gain = _param("ROOT_KD", 0.05)
        self.mass = self.m.body_mass.copy()
        self.hull = None
        self.p_meas_prev = None
        self.p_ref_prev = None
        self.pos_int = np.zeros(3)
        self.rot_int = np.zeros(3)
        self.foot_targets = None
        self.q_prev = None

    def _fk(self, qpos):
        self.d.qpos[:] = qpos
        mujoco.mj_kinematics(self.m, self.d)
        mujoco.mj_comPos(self.m, self.d)

    def _foot_pose(self, b):
        R = self.d.xmat[b].reshape(3, 3).copy()
        return self.d.xpos[b].copy(), R

    def _to_mj(self, q):
        return np.concatenate([q[:3], quat_xyzw_to_wxyz(q[3:7]), q[7:]])

    def compute(self, q_sim, q_ref):
        """Servo targets (29,) from the measured Newton joint_q and the reference joint_q."""
        qa = self._to_mj(q_sim)
        qr = self._to_mj(q_ref)

        # measured feet, flattened onto the floor
        self._fk(qa)
        flat = []
        for b in self.feet:
            p, R = self._foot_pose(b)
            Rf = yaw_only(R)
            p = p + R @ self.FOOT_SOLE - Rf @ self.FOOT_SOLE
            p[2] = 0.035
            flat.append((p, Rf))
        if self.foot_targets is None:
            self.foot_targets = flat
        elif self.reanchor > 0.0:
            # slowly follow the measured feet so a slipped foot does not leave a stale target
            a = self.reanchor
            self.foot_targets = [
                ((1 - a) * pt + a * p, yaw_only(rotmat(a * rotvec(R @ Rt.T)) @ Rt))
                for (pt, Rt), (p, R) in zip(self.foot_targets, flat)
            ]
        corners = [(p + R @ c)[:2] for p, R in self.foot_targets for c in self.FOOT_CORNERS]
        self.hull = convex_hull(np.array(corners))
        Ra = self.d.xmat[1].reshape(3, 3).copy()
        pa = self.d.xpos[1].copy()

        # commanded pelvis pose: reference + PI feedback on measured error
        Rr = np.zeros(9)
        mujoco.mju_quat2Mat(Rr, qr[3:7])
        Rr = Rr.reshape(3, 3)
        # keep the reference CoM inside the support polygon (with margin) by shifting the pelvis
        self._fk(qr)
        com_ref = (self.mass[:, None] * self.d.xipos).sum(0) / self.mass.sum()
        shift = np.zeros(3)
        shift[:2] = self.com_gain * (clamp_to_polygon(com_ref[:2], self.hull, self.com_margin) - com_ref[:2])
        p_goal = qr[:3] + shift
        v_meas = np.zeros(3) if self.p_meas_prev is None else (pa - self.p_meas_prev) / self.dt
        v_ref = np.zeros(3) if self.p_ref_prev is None else (p_goal - self.p_ref_prev) / self.dt
        self.p_meas_prev, self.p_ref_prev = pa.copy(), p_goal.copy()
        e_p = p_goal - pa
        e_r = rotvec(Rr @ Ra.T)
        self.pos_int += e_p * self.dt
        self.rot_int += e_r * self.dt
        p_cmd = p_goal + self.pos_gain * e_p + self.pos_ki * self.pos_int + self.vel_gain * (v_ref - v_meas)
        R_cmd = rotmat(self.rot_gain * e_r + self.rot_ki * self.rot_int) @ Rr
        quat_cmd = np.zeros(4)
        mujoco.mju_mat2Quat(quat_cmd, R_cmd.reshape(-1))

        # weighted IK over pelvis pose + leg joints: feet (hard), pelvis position, pelvis orientation, reference legs
        q = qr.copy() if self.q_prev is None else self.q_prev.copy()
        q[19:] = qr[19:]
        nd = 18  # free joint (6) + legs (12)
        jacp, jacr = np.zeros((3, self.m.nv)), np.zeros((3, self.m.nv))
        w_fp, w_fr, w_pp, w_pr, w_q = 1.0, self.w_foot_rot, self.w_pelvis_pos, self.w_pelvis_rot, self.w_joint
        for _ in range(self.ik_iters):
            self._fk(q)
            rows, errs = [], []
            for b, (pt, Rt) in zip(self.feet, self.foot_targets):
                p, R = self._foot_pose(b)
                mujoco.mj_jacBody(self.m, self.d, jacp, jacr, b)
                rows += [w_fp * jacp[:, :nd], w_fr * jacr[:, :nd]]
                errs += [w_fp * (pt - p), w_fr * rotvec(Rt @ R.T)]
            mujoco.mj_jacBody(self.m, self.d, jacp, jacr, 1)
            R1 = self.d.xmat[1].reshape(3, 3)
            rows += [w_pp * jacp[:, :nd], w_pr * jacr[:, :nd]]
            errs += [w_pp * (p_cmd - self.d.xpos[1]), w_pr * rotvec(R_cmd @ R1.T)]
            Jq = np.zeros((12, nd))
            Jq[:, 6:] = np.eye(12) * w_q
            rows.append(Jq)
            errs.append(w_q * (qr[7:19] - q[7:19]))
            J, e = np.vstack(rows), np.concatenate(errs)
            dq = np.linalg.solve(J.T @ J + 1e-6 * np.eye(nd), J.T @ e)
            dq *= min(1.0, 0.2 / (np.abs(dq).max() + 1e-12))
            full = np.zeros(self.m.nv)
            full[:nd] = dq
            mujoco.mj_integratePos(self.m, q, full, 1.0)
            q[7:19] = np.clip(q[7:19], self.jnt_range[:12, 0], self.jnt_range[:12, 1])
        err_max = np.abs(e[:12]).max()
        # gravity compensation with the feet carrying the floating-base load
        self._fk(q)
        self.d.qvel[:] = 0.0
        bias = np.zeros(self.m.nv)
        mujoco.mj_rne(self.m, self.d, 0, bias)
        Jc = []
        for b in self.feet:
            p, R = self._foot_pose(b)
            mujoco.mj_jac(self.m, self.d, jacp, jacr, p + R @ self.FOOT_SOLE, b)
            Jc.append(np.vstack([jacp, jacr]))
        Jc = np.vstack(Jc)  # (12, nv)
        f = np.linalg.lstsq(Jc[:, :6].T, bias[:6], rcond=None)[0]
        tau = bias[6:] - Jc[:, 6:].T @ f
        return q[7:] + self.ff_scale * tau / self.kp


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, here derived from a 10 Hz natural frequency.
        natural_frequency = 2.0 * np.pi * _param("NF", 45.0)
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 4.0 * ARMATURE * natural_frequency
        self.controller = StanceController(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), self.kp, self.frame_dt)
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        # Position targets for the servos: stance controller on the reference one frame ahead.
        ref = self.reference(self.sim_time + self.frame_dt)
        target = ref.copy()
        target[7:] = self.controller.compute(self.state_0.joint_q.numpy(), ref)
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
