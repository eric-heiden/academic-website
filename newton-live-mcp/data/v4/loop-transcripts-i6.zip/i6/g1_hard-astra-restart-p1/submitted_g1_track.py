# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo motion with contact-aware inverse dynamics.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A whole-body controller updates their targets every 4 ms to
track the root and joints while balancing through the two feet. Neither the
floating base nor the contact forces are actuated directly.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import warp as wp
from scipy import sparse

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class WholeBodyController:
    """Inverse dynamics for the double-support motions, using a small convex QP.

    Variables are generalized acceleration and eight sole contact forces.
    Floating-base dynamics, unilateral friction and actuator torque bounds are
    hard constraints. Root/joint acceleration tracking and stationary feet are
    weighted objectives, allowing the imperfect reference poses to balance.

    MuJoCo's model is only read; the separate MjData is used for estimation.
    The contact forces are predictions, never forces applied to the simulator.
    """

    def __init__(self, example):
        self.example = example
        self.m = example.solver.mj_model
        self.d = mujoco.MjData(self.m)
        self.nv = self.m.nv
        self.geoms = [
            g for g in range(self.m.ngeom)
            if self.m.geom_type[g] == mujoco.mjtGeom.mjGEOM_SPHERE
            and self.m.body(int(self.m.geom_bodyid[g])).name.endswith("ankle_roll_link")
        ]
        self.nc = len(self.geoms)
        self.nx = self.nv + 3 * self.nc
        self.mass = np.zeros((self.nv, self.nv))
        self.jac = np.zeros((3 * self.nc, self.nv))
        self.jdot = np.zeros((3, self.nv))
        self.error = np.zeros(self.nv)
        self.limits = self.m.actuator_forcerange[:, 1].copy()
        self.gains = np.r_[np.full(3, 100.0), np.full(3, 150.0), np.full(29, 400.0)]
        self.weights = np.r_[np.full(3, 100.0), np.full(3, 30.0), np.ones(29)]
        self.friction = np.zeros((5 * self.nc, self.nx))
        for k in range(self.nc):
            self.friction[5*k:5*k+5, self.nv+3*k:self.nv+3*k+3] = [
                [1, 0, -0.8], [-1, 0, -0.8], [0, 1, -0.8], [0, -1, -0.8], [0, 0, -1]
            ]
        # Fixed, dense sparsity patterns permit updates when entries cross zero.
        self.pi, self.pj = np.triu_indices(self.nx)
        nrows = self.nv + 5 * self.nc
        self.ai = np.tile(np.arange(nrows), self.nx)
        self.aj = np.repeat(np.arange(self.nx), nrows)
        self.qp = None

    def qpos(self, t):
        """Sample the unchanged reference in MuJoCo's quaternion convention."""
        q = self.example.reference(t)
        return np.r_[q[:3], q[6], q[3:6], q[7:]]

    def compute(self, t):
        ex, m, d = self.example, self.m, self.d
        if ex.solver.use_mujoco_cpu:
            d.qpos[:] = ex.solver.mj_data.qpos
            d.qvel[:] = ex.solver.mj_data.qvel
        else:
            d.qpos[:] = ex.solver.mjw_data.qpos.numpy()[0]
            d.qvel[:] = ex.solver.mjw_data.qvel.numpy()[0]
        mujoco.mj_forward(m, d)
        mujoco.mj_fullM(m, d, self.mass)
        qref = self.qpos(t)
        # Differentiate the sampler, so feedforward also follows playback speed.
        # A frame-wide stencil avoids acceleration spikes at CSV knots.
        h = ex.frame_dt
        qm, qp = self.qpos(t - h), self.qpos(t + h)
        vm, vp = np.zeros(self.nv), np.zeros(self.nv)
        mujoco.mj_differentiatePos(m, vm, h, qm, qref)
        mujoco.mj_differentiatePos(m, vp, h, qref, qp)
        vref = 0.5 * (vm + vp)
        aref = (vp - vm) / h
        mujoco.mj_differentiatePos(m, self.error, 1.0, d.qpos, qref)
        desired = aref + self.gains * self.error + 2 * np.sqrt(self.gains) * (vref - d.qvel)
        contact_acc = np.zeros(3 * self.nc)
        for k, g in enumerate(self.geoms):
            body = int(m.geom_bodyid[g])
            p = d.geom_xpos[g].copy()
            p[2] -= m.geom_size[g, 0]
            j = self.jac[3*k:3*k+3]
            mujoco.mj_jac(m, d, j, None, p, body)
            mujoco.mj_jacDot(m, d, self.jdot, None, p, body)
            acc = -50 * (j @ d.qvel) - self.jdot @ d.qvel
            # A small compression accommodates the simulator's soft contacts.
            acc[2] -= 1000 * (p[2] + 0.0005)
            contact_acc[3*k:3*k+3] = acc
        P = np.zeros((self.nx, self.nx))
        P[:self.nv, :self.nv] = np.diag(self.weights) + 100 * self.jac.T @ self.jac
        P[self.nv:, self.nv:] = np.eye(3 * self.nc) * 1e-4
        linear = np.r_[
            -self.weights * desired - 100 * self.jac.T @ contact_acc, np.zeros(3 * self.nc)
        ]
        dyn = np.hstack([self.mass, -self.jac.T])
        # Floating-base dynamics are an equality. The remaining dynamics define
        # joint torques, constrained by the unmodified actuator force ranges.
        lower = np.r_[-d.qfrc_bias[:6], -self.limits - d.qfrc_bias[6:]]
        upper = np.r_[-d.qfrc_bias[:6], self.limits - d.qfrc_bias[6:]]
        A = np.vstack([dyn, self.friction])
        lower = np.r_[lower, np.full(5 * self.nc, -np.inf)]
        upper = np.r_[upper, np.zeros(5 * self.nc)]
        Ps = sparse.csc_matrix((P[self.pi, self.pj], (self.pi, self.pj)), shape=P.shape)
        As = sparse.csc_matrix((A.T.ravel(), (self.ai, self.aj)), shape=A.shape)
        if self.qp is None:
            self.qp = osqp.OSQP()
            self.qp.setup(
                P=Ps, q=linear, A=As, l=lower, u=upper, verbose=False,
                eps_abs=1e-5, eps_rel=1e-5, max_iter=3000, polishing=False,
            )
        else:
            self.qp.update(Px=Ps.data, q=linear, Ax=As.data, l=lower, u=upper)
        solution = self.qp.solve(raise_error=False)
        if solution.x is None or solution.info.status_val not in (1, 2):
            raise RuntimeError(f"Whole-body QP failed: {solution.info.status}")
        tau = dyn[6:] @ solution.x + d.qfrc_bias[6:]
        tau = np.clip(tau, -self.limits, self.limits)
        # Encode the inverse-dynamics torque as an offset of a position servo.
        # Its stiffness and damping remain active between controller updates.
        target = ex.reference(t)
        target[7:] = d.qpos[7:] + (tau + ex.kd * d.qvel[6:]) / ex.kp
        return target


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Servo gains [N m/rad, N m s/rad]. Tracking feedback is in the
        # acceleration objective; gentle local gains avoid braking fast motion
        # while the inverse-dynamics command is held between 4 ms updates.
        self.kp = np.full(29, 20.0)
        self.kd = np.full(29, 0.1)
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self.controller = WholeBodyController(self)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self._physics_chunk()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def _physics_chunk(self):
        # Two original 2 ms substeps, with an even number of state-buffer swaps.
        for _ in range(2):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def simulate(self):
        for i in range(self.sim_substeps // 2):
            target = self.controller.compute(self.sim_time + 2 * i * self.sim_dt)
            self.control.joint_target_q.assign(target)
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self._physics_chunk()

    def step(self):
        self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
