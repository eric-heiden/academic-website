# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following Kimodo motions with floating-base whole-body control.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A contact-constrained inverse-dynamics QP tracks the root and
joints, then realizes its torques through servo targets every frame.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import scipy.sparse as sp
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class WholeBodyController:
    """Floating-base inverse dynamics, realized through the joint position servos.

    The QP chooses generalized accelerations and eight sole-corner reaction
    forces. Its first six dynamics equations have *no* actuator term: balance
    must come from ground contact. The remaining equations give joint torques,
    constrained to the unchanged actuator limits. Reaction forces are only
    optimization variables; they are never applied to the simulation.
    """

    def __init__(self, example):
        self.example = example
        self.m = example.solver.mj_model
        # A separate CPU data object provides dynamics/Jacobians without touching
        # the solver's state or changing the robot model.
        self.d = mujoco.MjData(self.m)
        self.nv = self.m.nv
        self.geoms = np.array([
            i for i in range(self.m.ngeom)
            if self.m.body(int(self.m.geom_bodyid[i])).name.endswith("ankle_roll_link")
        ])
        self.M = np.zeros((self.nv, self.nv))
        self.J = np.zeros((len(self.geoms) * 3, self.nv))
        self.Jdot = np.zeros_like(self.J)
        self.com = example.model.body_com.numpy()[0].astype(float)

        # Favor root pose while allowing small leg deviations to maintain support.
        self.weights = np.r_[np.full(3, 100.0), np.full(3, 50.0), np.ones(12), np.full(17, 2.0)]
        self.kp = np.full(self.nv, 800.0)
        self.kd = 2.0 * np.sqrt(self.kp)
        self.foot_weight = 100.0
        self.foot_kd = 30.0
        self.force_reg = 1.0e-4
        self.last = None
        self.failures = 0

        # Linearized friction bounds with coefficient 0.8 (model sole mu=1).
        # Each corner can push up but cannot pull on the floor.
        self.friction = np.zeros((5 * len(self.geoms), self.nv + self.J.shape[0]))
        for i in range(len(self.geoms)):
            self.friction[5*i:5*i+5, self.nv+3*i:self.nv+3*i+3] = [
                [1, 0, -0.8], [-1, 0, -0.8],
                [0, 1, -0.8], [0, -1, -0.8], [0, 0, -1],
            ]

    @staticmethod
    def mj_q(q):
        """Newton xyzw -> MuJoCo wxyz, without modifying the reference."""
        q = np.array(q, dtype=float, copy=True)
        q[3:7] = q[[6, 3, 4, 5]]
        return q

    def compute(self, t):
        m, d, e = self.m, self.d, self.example
        q = e.state_0.joint_q.numpy().astype(float)
        v = e.state_0.joint_qd.numpy().astype(float)
        d.qpos[:] = self.mj_q(q)
        rotation = np.asarray(wp.quat_to_matrix(wp.quat(*q[3:7]))).reshape(3, 3).astype(float)
        # Newton stores root COM linear velocity and world angular velocity;
        # MuJoCo uses root-origin linear velocity and local angular velocity.
        d.qvel[:] = v
        d.qvel[:3] -= np.cross(v[3:6], rotation @ self.com)
        d.qvel[3:6] = rotation.T @ v[3:6]
        mujoco.mj_forward(m, d)

        # Differentiate the public reference sampler, so timing comes entirely
        # from the supplied clip/playback. Quaternion differences use SO(3).
        h = e.frame_dt
        qr = self.mj_q(e.reference(t))
        qm = self.mj_q(e.reference(t - h))
        qp = self.mj_q(e.reference(t + h))
        vr, vm, vp, error = (np.zeros(self.nv) for _ in range(4))
        mujoco.mj_differentiatePos(m, vr, 2.0 * h, qm, qp)
        mujoco.mj_differentiatePos(m, vm, h, qm, qr)
        mujoco.mj_differentiatePos(m, vp, h, qr, qp)
        mujoco.mj_differentiatePos(m, error, 1.0, d.qpos, qr)
        desired_acc = (vp - vm) / h + self.kp * error + self.kd * (vr - d.qvel)

        mujoco.mj_fullM(m, d, self.M)
        bias = d.qfrc_bias - d.qfrc_passive
        for i, geom in enumerate(self.geoms):
            point = d.geom_xpos[geom].copy()
            point[2] -= m.geom_size[geom, 0]  # bottom of the sole collision sphere
            body = int(m.geom_bodyid[geom])
            rows = slice(3 * i, 3 * i + 3)
            mujoco.mj_jac(m, d, self.J[rows], None, point, body)
            mujoco.mj_jacDot(m, d, self.Jdot[rows], None, point, body)

        J = self.J
        # Soft stance stabilization accommodates the small foot rolls in the
        # reference instead of imposing incompatible rigid foot constraints.
        foot_acc = -self.Jdot @ d.qvel - self.foot_kd * (J @ d.qvel)
        n, nf = self.nv, J.shape[0]
        P = np.zeros((n + nf, n + nf))
        linear = np.zeros(n + nf)
        P[:n, :n] = np.diag(self.weights) + self.foot_weight * J.T @ J
        linear[:n] = -self.weights * desired_acc - self.foot_weight * J.T @ foot_acc
        P[n:, n:] = self.force_reg * np.eye(nf)

        # M a + bias = S.T tau + J.T force.
        base_dynamics = np.c_[self.M[:6], -J.T[:6]]
        joint_dynamics = np.c_[self.M[6:], -J.T[6:]]
        A = np.vstack([base_dynamics, joint_dynamics, self.friction])
        lower = np.r_[
            -bias[:6], m.actuator_forcerange[:, 0] - bias[6:],
            np.full(len(self.friction), -np.inf),
        ]
        upper = np.r_[
            -bias[:6], m.actuator_forcerange[:, 1] - bias[6:],
            np.zeros(len(self.friction)),
        ]
        qp_solver = osqp.OSQP()
        qp_solver.setup(
            P=sp.csc_matrix(np.triu(P)), q=linear, A=sp.csc_matrix(A), l=lower, u=upper,
            verbose=False, eps_abs=1.0e-5, eps_rel=1.0e-5, max_iter=2000, polishing=False,
        )
        if self.last is not None:
            qp_solver.warm_start(x=self.last)
        result = qp_solver.solve()
        if result.info.status_val in (1, 2) and np.all(np.isfinite(result.x)):
            self.last = result.x
            torque = joint_dynamics @ result.x + bias[6:]
            acc = result.x[6:n]
        else:
            # Do not pass an infeasibility certificate to the actuators.
            self.failures += 1
            self.last = None
            torque = bias[6:] + 30.0 * error[6:] - 2.0 * v[6:]
            acc = np.zeros(n - 6)
        torque = np.clip(torque, m.actuator_forcerange[:, 0], m.actuator_forcerange[:, 1])
        self.torque = torque

        # Invert tau = kp*(target-q) - kd*v at the predicted midpoint of
        # the held command. This compensates servo damping/position change over
        # a 20 ms frame while retaining the original 2 ms physics substeps.
        dt = e.frame_dt * 0.5
        target = q.copy()
        target[7:] = (
            q[7:] + v[6:] * dt + 0.5 * acc * dt**2
            + (torque + e.kd * (v[6:] + acc * dt)) / e.kp
        )
        e.control.joint_target_q.assign(target)


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Inner servo stiffness [N m/rad] and damping [N m s/rad].
        # WholeBodyController compensates these when forming the targets.
        self.kp = np.full(29, 150.0)
        self.kd = np.full(29, 5.0)
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.controller = WholeBodyController(self)
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        # Balance and tracking use the reference at the midpoint of this frame.
        self.controller.compute(self.sim_time + self.frame_dt * 0.5)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
