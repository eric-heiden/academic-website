You are working on a Newton physics simulation task.

Workspace: /home/horde/artifacts/newton-live-mcp-v4/loop/i6/cube_toss-opus-restart-p0
Newton source tree (read-only reference, including docs and examples): /home/horde/apps/newton-live-mcp

cube_toss.py simulates real measurements: an acrylic cube (0.1048 m, 0.37 kg, inertia 0.00081 kg m^2, all measured) tossed by hand onto a wooden table and tracked by cameras at 148 Hz (ContactNets dataset). tosses.npz holds 400 recorded tosses (positions, orientations, and world-frame linear and angular velocities per frame). Each toss is one Newton world that starts from the first measured frame and runs open loop through the impacts, bounces, and slides. Problem: with the current contact model the simulated cubes bounce and slide far from the recordings.

Goal: calibrate the simulation so it reproduces the real tosses. Verification imports the script's build_model(num_worlds), make_solver(model), make_pipeline(model), and SUBSTEPS, and runs its own open-loop rollout (the same protocol as the script's rollout/evaluate) on 170 held-out tosses of the same cube. The mean over tosses of the time-averaged position error must be at most 0.02 m, and of the orientation error at most 0.45 rad. The starter scores about 0.10 m and 1.07 rad.
Constraints (checked): keep one cube per world with the measured size, mass, and inertia, and keep gravity. Contact and material parameters, table height, collision settings, solver type and settings, and the number of substeps per frame (1 to 100) may change. Keep the file runnable (`python cube_toss.py --viewer null`).

Deliverable: the edited cube_toss.py in the workspace, then a brief report. You have 30 minutes; working efficiently matters. Do not modify files outside the workspace, do not look for other trials or hidden verification data, and do not use subagents.

Workflow: this is a script-based setup. Run the simulation with
  uv run --no-sync --project /home/horde/apps/newton-live-mcp python cube_toss.py --viewer null --num-frames <N>
or write your own scripts that import the Example class; each run starts a fresh simulator process. There is no display; to look at the scene, render images yourself (for example with newton.sensors.SensorTiledCamera) and open them with your image-viewing tool.
