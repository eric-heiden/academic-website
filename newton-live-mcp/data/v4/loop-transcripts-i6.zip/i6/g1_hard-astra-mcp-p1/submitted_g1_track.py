# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 tracking a Kimodo motion with constrained whole-body control.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A 250 Hz inverse-dynamics controller tracks the root pose and
joint angles while balancing through the feet. Physics remains at 2 ms and
viewer frames at 50 Hz. Requires mujoco, scipy, and osqp.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import warp as wp
from scipy import sparse

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # The whole-body controller supplies feedback and damping. A low servo
        # stiffness lets its torque command be expressed as a position offset,
        # with little extra position feedback during each 4 ms control interval.
        self.kp = np.ones(29)
        self.kd = np.zeros(29)

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self._init_controller()
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    @staticmethod
    def _mjq(q):
        """Newton xyzw root quaternion to MuJoCo wxyz generalized position."""
        return np.concatenate([q[:3], q[[6, 3, 4, 5]], q[7:]])

    def _init_controller(self):
        # This data object is for estimation only; simulation state is never
        # overwritten by inverse dynamics or by the reference trajectory.
        self.cm = self.solver.mj_model
        self.cd = mujoco.MjData(self.cm)
        self.mass = np.zeros((35, 35))
        self.foot_geoms = [
            i for i in range(self.cm.ngeom)
            if self.cm.geom_type[i] == mujoco.mjtGeom.mjGEOM_SPHERE
            and self.cm.body(self.cm.geom_bodyid[i]).name.endswith("ankle_roll_link")
        ]
        if len(self.foot_geoms) != 8:
            raise ValueError("Whole-body controller expects four contact spheres per G1 foot")
        self.qp = None
        self.acc_kp = np.array([200] * 6 + [3600] * 29, dtype=float)
        self.acc_kd = 2 * np.sqrt(self.acc_kp)
        self.task_weight = np.array([100] * 6 + [1] * 29, dtype=float)
        self.contact_weight = 20.0
        self.torque_limit = self.model.joint_effort_limit.numpy()[6:].astype(float)
        self.last_tau = np.zeros(29)
        self.qp_failures = 0

    def _controller(self, t):
        """Solve for feasible accelerations/ground reactions, then command joints."""
        m, d = self.cm, self.cd
        # Read the simulator's generalized state in MuJoCo coordinates.
        d.qpos[:] = self.solver.mjw_data.qpos.numpy()[0]
        d.qvel[:] = self.solver.mjw_data.qvel.numpy()[0]
        mujoco.mj_forward(m, d)
        mujoco.mj_fullM(m, d, self.mass)
        h = d.qfrc_bias - d.qfrc_passive
        # Differentiate the unchanged interpolated reference, including its
        # quaternion. A symmetric window reduces noise at CSV frame boundaries.
        eps = 0.02
        qm = self._mjq(self.reference(t - eps))
        qr = self._mjq(self.reference(t))
        qp = self._mjq(self.reference(t + eps))
        vm, vp, err = np.zeros(35), np.zeros(35), np.zeros(35)
        mujoco.mj_differentiatePos(m, vm, eps, qm, qr)
        mujoco.mj_differentiatePos(m, vp, eps, qr, qp)
        mujoco.mj_differentiatePos(m, err, 1.0, d.qpos, qr)
        vref = 0.5 * (vm + vp)
        aref = (vp - vm) / eps
        ades = aref + self.acc_kp * err + self.acc_kd * (vref - d.qvel)
        J = np.zeros((24, 35))
        jdotv = np.zeros(24)
        ades_contact = np.zeros(24)
        for k, g in enumerate(self.foot_geoms):
            b = m.geom_bodyid[g]
            p = d.geom_xpos[g].copy()
            p[2] -= m.geom_size[g, 0]
            jp, jr = np.zeros((3, 35)), np.zeros((3, 35))
            jdp, jdr = np.zeros((3, 35)), np.zeros((3, 35))
            mujoco.mj_jac(m, d, jp, jr, p, b)
            mujoco.mj_jacDot(m, d, jdp, jdr, p, b)
            J[3*k:3*k+3] = jp
            jdotv[3*k:3*k+3] = jdp @ d.qvel
            ac = -40 * (jp @ d.qvel)
            ac[2] -= 400 * p[2]
            ades_contact[3*k:3*k+3] = ac
        # x = [generalized accelerations, eight world-frame contact forces].
        # M qdd + h = [0; tau] + J.T f. Eliminating tau gives the map T;
        # the six unactuated base equations remain hard equality constraints.
        T = np.hstack([self.mass[6:], -J[:, 6:].T])
        P = np.diag(np.r_[self.task_weight, np.full(24, 1e-4)])
        P[:35, :35] += self.contact_weight * (J.T @ J)
        P += 1e-5 * (T.T @ T)
        cost = np.r_[-self.task_weight * ades, np.zeros(24)]
        cost[:35] -= self.contact_weight * J.T @ (ades_contact - jdotv)
        cost += 1e-5 * T.T @ h[6:]
        base = np.hstack([self.mass[:6], -J[:, :6].T])
        # Unilateral ground contact and a conservative friction pyramid.
        # Contact accelerations are soft tasks: the recorded poses need not
        # have perfectly flat feet or be exactly dynamically feasible.
        friction = np.zeros((40, 59))
        for k in range(8):
            ix = 35 + 3 * k
            friction[5*k:5*k+5, ix:ix+3] = [
                [1, 0, -0.7], [-1, 0, -0.7], [0, 1, -0.7], [0, -1, -0.7], [0, 0, 1]
            ]
        A = np.vstack([base, T, friction])
        lo = np.r_[-h[:6], -self.torque_limit - h[6:], np.tile([-np.inf] * 4 + [0], 8)]
        hi = np.r_[-h[:6], self.torque_limit - h[6:], np.tile([0] * 4 + [500], 8)]
        # Fixed dense sparsity allows OSQP to reuse its workspace and warm start.
        rows, cols = np.triu_indices(59)
        Psp = sparse.csc_matrix((P[rows, cols], (rows, cols)), shape=(59, 59))
        Asp = sparse.csc_matrix(
            (A.ravel(order="F"), np.tile(np.arange(75), 59), np.arange(60) * 75), shape=(75, 59)
        )
        if self.qp is None:
            self.qp = osqp.OSQP()
            self.qp.setup(
                P=Psp, q=cost, A=Asp, l=lo, u=hi, verbose=False,
                eps_abs=1e-4, eps_rel=1e-4, max_iter=1000, polishing=False,
            )
        else:
            self.qp.update(Px=Psp.data, q=cost, Ax=Asp.data, l=lo, u=hi)
        result = self.qp.solve(raise_error=False)
        if result.x is not None and result.info.status_val in (1, 2):
            tau = T @ result.x + h[6:]
            self.last_tau = np.clip(tau, -self.torque_limit, self.torque_limit)
        else:
            self.qp_failures += 1
        # Invert tau = kp*(target-q) - kd*qvel. The existing MuJoCo
        # actuator force limits still apply at every physics substep.
        # Optimized contact forces are never applied as external body forces.
        target = self.reference(t)
        target[7:] = d.qpos[7:] + (self.last_tau + self.kd * d.qvel[6:]) / self.kp
        self.control.joint_target_q.assign(target)

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        # Two substeps return the ping-pong state buffers to the same order,
        # so this CUDA graph can be launched repeatedly without dropping steps.
        for _ in range(2):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # Five feedback updates, each followed by two 2 ms physics steps.
        for k in range(self.sim_substeps // 2):
            self._controller(self.sim_time + k * 2 * self.sim_dt)
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
