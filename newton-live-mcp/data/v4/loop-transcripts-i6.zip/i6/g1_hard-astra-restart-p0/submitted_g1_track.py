# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 tracking Kimodo motions with contact-aware whole-body control.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A whole-body inverse-dynamics QP updates servo targets at
250 Hz; physics remains at 2 ms substeps and rendering at 50 Hz. No actuator
or applied wrench acts on the floating base.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import warp as wp
from scipy import sparse

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class WholeBodyController:
    """Track the floating root and joints using only limited joint servos.

    A small inverse-dynamics QP chooses generalized accelerations and eight
    ground-contact forces. The floating-base equations have *zero* applied
    wrench. Contact forces are predictions used to calculate joint torques;
    only the simulator's contact solver can actually apply ground forces.

    Both clips are standing motions. Each foot maintains translational,
    roll and pitch support, while yaw is free to follow the reference turn.
    Locking yaw would preserve a slipped foot angle indefinitely.
    """

    def __init__(self, example):
        self.example = example
        self.model = example.solver.mj_model
        # Separate scratch data for dynamics/kinematics; never integrate it or
        # copy it back to the simulated state.
        self.data = mujoco.MjData(self.model)
        self.feet = [
            i for i in range(self.model.nbody)
            if self.model.body(i).name.endswith("ankle_roll_link")
        ]
        self.points = [
            i for i in range(self.model.ngeom)
            if self.model.geom_bodyid[i] in self.feet
        ]
        self.nv = self.model.nv
        self.nf = len(self.points) * 3
        self.mass = np.zeros((self.nv, self.nv))
        self.limits = self.model.actuator_forcerange[:, 1].copy()

        # Acceleration tracking weights, and critically damped pose feedback.
        # Translation is in metres; orientation and joints are in radians.
        self.weights = np.r_[np.full(3, 100.0), np.full(3, 30.0), np.ones(29)]
        self.position_gain = np.r_[np.full(6, 100.0), np.full(29, 400.0)]
        self.position_gain[[8, 14]] = 1000.0  # left/right hip yaw
        self.velocity_gain = 2.0 * np.sqrt(self.position_gain)
        self.hessian = sparse.diags(
            np.r_[self.weights, np.full(self.nf, 1.0e-5)], format="csc"
        )

        # Conservative friction pyramids and unilateral normal forces at the
        # actual foot collision spheres. These also bound each foot's moment.
        mu = 0.8
        self.friction = np.zeros((len(self.points) * 5, self.nv + self.nf))
        for k in range(len(self.points)):
            start = self.nv + 3 * k
            self.friction[5 * k : 5 * k + 5, start : start + 3] = [
                [1, 0, -mu], [-1, 0, -mu], [0, 1, -mu],
                [0, -1, -mu], [0, 0, -1],
            ]
        self.previous = None
        self.last_torque = np.zeros(29)

    @staticmethod
    def _mujoco_qpos(q):
        """Newton xyzw quaternion to MuJoCo wxyz quaternion."""
        return np.r_[q[:3], q[6], q[3:6], q[7:]]

    def update(self, t):
        example, model, data = self.example, self.model, self.data
        # This conversion also handles Newton's COM/world-frame free-joint
        # velocity versus MuJoCo's origin/body-frame velocity convention.
        example.solver._update_mjc_data(data, example.model, example.state_0)
        mujoco.mj_forward(model, data)

        # Differentiate the unchanged playback sampler, including quaternion
        # differences. This automatically follows the supplied clip's timing.
        h = 0.01
        qref = self._mujoco_qpos(example.reference(t))
        qminus = self._mujoco_qpos(example.reference(t - h))
        qplus = self._mujoco_qpos(example.reference(t + h))
        velocity = np.zeros(self.nv)
        vminus = np.zeros(self.nv)
        vplus = np.zeros(self.nv)
        error = np.zeros(self.nv)
        mujoco.mj_differentiatePos(model, velocity, 2 * h, qminus, qplus)
        mujoco.mj_differentiatePos(model, vminus, h, qminus, qref)
        mujoco.mj_differentiatePos(model, vplus, h, qref, qplus)
        mujoco.mj_differentiatePos(model, error, 1.0, data.qpos, qref)
        desired_acceleration = (
            (vplus - vminus) / h
            + self.position_gain * error
            + self.velocity_gain * (velocity - data.qvel)
        )

        mujoco.mj_fullM(model, data, self.mass)
        bias = data.qfrc_bias - data.qfrc_passive
        contact_jacobian = np.zeros((self.nf, self.nv))
        for k, geom in enumerate(self.points):
            point = data.geom_xpos[geom].copy()
            point[2] -= model.geom_size[geom, 0]
            mujoco.mj_jac(
                model, data, contact_jacobian[3 * k : 3 * k + 3], None,
                point, int(model.geom_bodyid[geom]),
            )

        foot_jacobian = np.zeros((12, self.nv))
        foot_acceleration = np.zeros(12)
        for k, body in enumerate(self.feet):
            jac = foot_jacobian[6 * k : 6 * k + 6]
            jac_dot = np.zeros((6, self.nv))
            mujoco.mj_jacBody(model, data, jac[:3], jac[3:], body)
            mujoco.mj_jacDot(model, data, jac_dot[:3], jac_dot[3:], data.xpos[body], body)
            foot_acceleration[6 * k : 6 * k + 6] = (
                -jac_dot @ data.qvel - 30.0 * (jac @ data.qvel)
            )

        # x = [qdd, contact forces]; tau = M qdd + bias - J.T f.
        # Enforce zero torque on the six unactuated floating-base DOFs.
        dynamics = np.c_[self.mass, -contact_jacobian.T]
        support_axes = [0, 1, 2, 3, 4, 6, 7, 8, 9, 10]  # omit each foot's yaw
        equality = np.vstack([
            dynamics[:6],
            np.c_[foot_jacobian[support_axes], np.zeros((10, self.nf))],
        ])
        equality_rhs = np.r_[-bias[:6], foot_acceleration[support_axes]]
        constraints = np.vstack([equality, dynamics[6:], self.friction])
        lower = np.r_[
            equality_rhs, -self.limits - bias[6:],
            np.full(len(self.friction), -np.inf),
        ]
        upper = np.r_[
            equality_rhs, self.limits - bias[6:], np.zeros(len(self.friction)),
        ]
        cost = np.r_[-self.weights * desired_acceleration, np.zeros(self.nf)]
        qp = osqp.OSQP()
        qp.setup(
            P=self.hessian, q=cost, A=sparse.csc_matrix(constraints),
            l=lower, u=upper, verbose=False, eps_abs=1.0e-5,
            eps_rel=1.0e-5, max_iter=2000, polishing=True,
        )
        if self.previous is not None:
            qp.warm_start(x=self.previous)
        result = qp.solve()
        if result.info.status_val in (1, 2) and np.all(np.isfinite(result.x)):
            self.previous = result.x
            torque = dynamics[6:] @ result.x + bias[6:]
            acceleration = result.x[6 : self.nv]
            self.last_torque = np.clip(torque, -self.limits, self.limits)
        else:
            # Retain the last valid support torque if a QP fails transiently.
            torque = self.last_torque
            acceleration = np.zeros(29)

        # Real actuators remain position servos with their original torque
        # limits. Choose a target yielding the requested average torque over
        # this control interval, accounting for both spring and damping terms.
        # Omitting the velocity/acceleration prediction causes severe arm lag.
        dt = example.control_substeps * example.sim_dt
        target = example.reference(t)
        target[7:] = (
            data.qpos[7:] + data.qvel[6:] * dt / 2 + acceleration * dt * dt / 6
            + (torque + example.kd * (data.qvel[6:] + acceleration * dt / 2)) / example.kp
        )
        example.control.joint_target_q.assign(target)


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.control_substeps = 2
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # Inner position servos. The controller supplies inverse-dynamics
        # feedforward through their targets, retaining the MJCF torque limits.
        self.kp = np.full(29, 200.0)
        self.kd = np.full(29, 10.0)

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self._simulate_control_interval()
            self.graph = capture.graph

        self.controller = WholeBodyController(self)

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def _simulate_control_interval(self):
        # An even number of substeps keeps the captured state buffers fixed.
        for _ in range(self.control_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def simulate(self):
        for substep in range(0, self.sim_substeps, self.control_substeps):
            self.controller.update(self.sim_time + substep * self.sim_dt)
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self._simulate_control_interval()

    def step(self):
        self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
