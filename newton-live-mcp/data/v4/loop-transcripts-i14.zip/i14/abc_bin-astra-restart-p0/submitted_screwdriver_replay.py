# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Physical replay of a real pick-and-place episode from ABC-130k: put the screwdriver in the bin.

The recording comes from ABC-130k (https://abc.bot/#data), episode "put the
screwdriver in the bin": at a bimanual station of two 6-DoF YAM arms with
parallel grippers, teleoperated by streaming joint-position commands from
leader arms at about 30 Hz, the right arm picks up a screwdriver lying on the
table by its handle, carries it over, and drops it into a pink plastic bin.
``episodes/main.npz`` holds the measured joints, gripper openings and efforts,
and the logged commands; ``scenes/main.json`` holds the station layout (arm
bases, the bin, and the screwdriver: its handle profile, start pose, grasping
arm, and the camera frames of the real grasp events). FORMAT.md describes the
files and the clocks; ``gt/`` and ``frames/`` hold the ground truth and the
recorded top and wrist videos.

``build_model`` retains the station's kinematics and finger geometry, and uses
arm gains and command latency calibrated against the supplied robot logs.
The force-limited gripper holds a free screwdriver with a convex tapered
handle and capsule shaft. Contact and finger-mirror compliance use standard
MuJoCo solref parameters; an elliptic friction cone remains stable in the
low-friction control. No object forces or grasp constraints are applied.
``replay_common.Replay`` applies the logged commands as position targets, and
``replay_common.score`` compares the resulting motion with the recording.

Run: ``python screwdriver_replay.py --viewer null`` replays the whole episode
and prints the metrics (``--seconds`` stops early, ``--num-worlds`` adds
copies, ``--jitter`` perturbs their starts, ``--episode sib_1`` selects another
episode).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import replay_common as rc
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
FRAME_DT = 1.0 / 30.0  # camera frame period [s]

# ---------------- Replay parameters (tunable) ----------------
PARAMS = {
    "command_delay": 0.06,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}
# Upper bounds of the station shapes' friction coefficients: the MJCF's (sliding 2-4, torsional 0.1 m,
# rolling 0.01 m) are clipped to the task's material bounds.
STATION_MATERIAL_MAX = {"mu": 1.5, "mu_torsional": 0.01, "mu_rolling": 0.001}
# Shared by both arms and all episodes; fitted offline from the supplied logs.
ARM_KP = [75.0, 80.0, 80.0, 10.0, 10.0, 5.0]
ARM_KD = [4.0, 4.0, 4.0, 1.3, 1.3, 0.5]
ARM_ARMATURE = [0.032, 0.032, 0.032, 0.0018, 0.0018, 0.0018]
ARM_FRICTION = [0.1] * 6
GRIPPER_KP = 6000.0
GRIPPER_KD = 14.0  # retain the imported gripper velocity gain
PINCH_FORCE = 25.0  # force per pad; the sole motor drives both pads through the mirror
CONTACT_TIME = 0.004  # 2 dt, critically damped; MuJoCo refsafe remains enabled
TABLE_MU = 0.5
# Screwdriver: rubber handle and steel shaft. Torsional friction [m] is a contact patch radius, rolling
# friction [m] a rolling-resistance length.
HANDLE_MATERIAL = {"mu": 1.0, "mu_torsional": 0.004, "mu_rolling": 0.0001}
SHAFT_MATERIAL = {"mu": 0.4, "mu_torsional": 0.0016, "mu_rolling": 0.0001}
BIN_MASS = 0.35  # [kg] (polypropylene)
BIN_MU = 0.4
# Contacts are detected this far ahead of touching [m]; Newton's default (0.1 m) fills the contact
# buffers of large batches with distant shape pairs.
CONTACT_GAP = 0.01
START_CLEARANCE = 0.0005  # the screwdriver starts this far above its resting height [m]
HANDLE_COLOR = (0.95, 0.80, 0.05)
SHAFT_COLOR = (0.75, 0.75, 0.78)
BIN_COLOR = (0.93, 0.66, 0.60)


def build_station() -> newton.ModelBuilder:
    """One station from the MJCF (arm bases where the MJCF puts them)."""
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    builder.rigid_gap = CONTACT_GAP
    # The bin may reach past the MJCF's back wall (x = 0.9 m); the real station's wall stands farther back.
    builder.add_mjcf(str(STATION), ignore_names=["back_wall_collision"])
    for i, label in enumerate(builder.shape_label):
        builder.shape_material_mu[i] = min(builder.shape_material_mu[i], STATION_MATERIAL_MAX["mu"])
        builder.shape_material_mu_torsional[i] = min(
            builder.shape_material_mu_torsional[i], STATION_MATERIAL_MAX["mu_torsional"]
        )
        builder.shape_material_mu_rolling[i] = min(
            builder.shape_material_mu_rolling[i], STATION_MATERIAL_MAX["mu_rolling"]
        )
        if label.endswith("table_plane"):
            builder.shape_material_mu[i] = TABLE_MU
    for j, label in enumerate(builder.joint_label):
        name = label.rsplit("/", 1)[-1]
        if name in [f"{side}_joint{k}" for side in rc.SIDES for k in range(1, 7)]:
            k = int(name[-1]) - 1
            d = builder.joint_qd_start[j]
            builder.joint_target_ke[d] = ARM_KP[k]
            builder.joint_target_kd[d] = ARM_KD[k]
            builder.joint_armature[d] = ARM_ARMATURE[k]
            builder.joint_friction[d] = ARM_FRICTION[k]
            builder.joint_effort_limit[d] = 28.0 if k < 3 else 10.0
        elif name in [f"{side}_left_finger" for side in rc.SIDES]:
            d = builder.joint_qd_start[j]
            builder.joint_target_ke[d] = GRIPPER_KP
            builder.joint_target_kd[d] = GRIPPER_KD
            builder.joint_effort_limit[d] = 2.0 * PINCH_FORCE
    attrs = builder.custom_attributes
    for i in range(len(builder.shape_label)):
        attrs["mujoco:solref"].values[i] = wp.vec2(CONTACT_TIME, 1.0)
        attrs["mujoco:solref_mode"].values[i] = 1  # authored MuJoCo solref
    attrs["mujoco:eq_solref"].values = [wp.vec2(CONTACT_TIME, 1.0)] * 2
    for a in (6, 13):
        attrs["mujoco:actuator_has_forcerange"].values[a] = True
        attrs["mujoco:actuator_forcelimited"].values[a] = 1
        attrs["mujoco:actuator_forcerange"].values[a] = wp.vec2(-2 * PINCH_FORCE, 2 * PINCH_FORCE)
    return builder


def add_bin(builder: newton.ModelBuilder, scene: dict) -> None:
    """The bin as one dynamic body labelled ``bin``: a floor slab and four walls leaning out to the rim.

    Bin frame x is the bin's length (scene ``bin``: footprint centre and yaw, outer sizes at the table and at
    the rim, height, wall and floor thickness).
    """
    spec, table_z = scene["bin"], scene["table_z"]
    height, wall, floor = spec["height_m"], spec["wall_m"], spec["floor_m"]
    (lb, wb), (lt, wt) = spec["bottom_size_m"], spec["top_size_m"]
    parts = [((0.0, 0.0, floor / 2), wp.quat_identity(), (lb / 2, wb / 2, floor / 2))]  # (centre, rotation, half)
    for axis, (bottom, top, other_b, other_t) in enumerate(((lb, lt, wb, wt), (wb, wt, lb, lt))):
        lean = (top - bottom) / 2  # outward lean of a wall over the height
        tilt = math.atan2(lean, height)
        slant = math.hypot(lean, height)
        for sign in (-1.0, 1.0):
            centre = [0.0, 0.0, height / 2]
            centre[axis] = (bottom / 2 + lean / 2 - wall / 2 * math.cos(tilt)) * sign
            if axis == 0:  # walls at +-x, spanning y, tilted about y
                rotation = wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), sign * tilt)
                half = (wall / 2, max(other_b, other_t) / 2, slant / 2)
            else:  # walls at +-y, spanning x, tilted about x
                rotation = wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), -sign * tilt)
                half = (max(other_b, other_t) / 2, wall / 2, slant / 2)
            parts.append((tuple(centre), rotation, half))
    cx, cy = spec["center_xy"]
    root = wp.transform(
        wp.vec3(cx, cy, table_z + 0.0005),
        wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), math.radians(spec["yaw_deg"])),
    )
    body = builder.add_body(xform=root, label=rc.BIN_BODY)
    volume = sum(8.0 * h[0] * h[1] * h[2] for _, _, h in parts)
    cfg = newton.ModelBuilder.ShapeConfig(density=BIN_MASS / volume, mu=BIN_MU)
    for k, (centre, rotation, half) in enumerate(parts):
        builder.add_shape_box(
            body,
            xform=wp.transform(wp.vec3(*centre), rotation),
            hx=half[0],
            hy=half[1],
            hz=half[2],
            cfg=cfg,
            color=BIN_COLOR,
            label=f"bin_{k}",
        )


def handle_mesh(profile: np.ndarray) -> newton.Mesh:
    """Convex surface of revolution following the measured handle silhouette.

    Convexification fills the shallow waist by at most 0.71 mm. The 48-sided
    rings introduce under 0.04 mm radial error. Preserve all hull vertices:
    the default 64-vertex reduction can cut away the ends of the handle.
    """
    from scipy.spatial import ConvexHull

    angles = np.arange(48) * (2.0 * math.pi / 48)
    vertices = np.array([(x, r * math.cos(a), r * math.sin(a)) for x, r in profile for a in angles])
    hull = ConvexHull(vertices)
    faces = hull.simplices.copy()
    for i, face in enumerate(faces):
        a, b, c = vertices[face]
        if np.dot(np.cross(b - a, c - a), hull.equations[i, :3]) < 0:
            faces[i] = face[::-1]
    return newton.Mesh(vertices=vertices.astype(np.float32), indices=faces.flatten().astype(np.int32), maxhullvert=256)


def add_screwdriver(builder: newton.ModelBuilder, scene: dict) -> None:
    """A free body with a tapered handle and steel shaft, with the scene's axial COM."""
    obj = scene["objects"]["screwdriver"]
    geometry = obj["geometry"]
    profile = np.asarray(geometry["handle_profile"], dtype=np.float64)
    mesh = handle_mesh(profile)
    radius = float(geometry["shaft_radius_m"])
    collar, tip = float(profile[-1, 0]), float(obj["tip_local"][0])
    shaft_length = tip - collar - 2.0 * radius
    shaft_volume = math.pi * radius**2 * shaft_length + 4.0 / 3.0 * math.pi * radius**3
    shaft_x = 0.5 * (collar + tip)
    mass = float(geometry.get("mass_kg", 0.07))
    handle_mass = mass * (shaft_x - float(obj["com_local"][0])) / (shaft_x - float(mesh.com[0]))
    start = obj["start"]
    position = np.asarray(start["pos"], dtype=np.float64)
    position[2] += START_CLEARANCE
    body = builder.add_body(xform=wp.transform(wp.vec3(*position), wp.quat(*start["quat_xyzw"])), label=rc.OBJECTS[0])
    attributes = {"mujoco:condim": 6, "mujoco:solref": wp.vec2(CONTACT_TIME, 1.0), "mujoco:solref_mode": 1}
    builder.add_shape_convex_hull(
        body,
        mesh=mesh,
        cfg=newton.ModelBuilder.ShapeConfig(density=float(handle_mass / mesh.mass), **HANDLE_MATERIAL),
        color=HANDLE_COLOR,
        label="screwdriver_handle",
        custom_attributes=attributes,
    )
    along_x = wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), math.pi / 2)
    builder.add_shape_capsule(
        body,
        xform=wp.transform(wp.vec3(shaft_x, 0.0, 0.0), along_x),
        radius=radius,
        half_height=shaft_length / 2.0,
        cfg=newton.ModelBuilder.ShapeConfig(density=float((mass - handle_mass) / shaft_volume), **SHAFT_MATERIAL),
        color=SHAFT_COLOR,
        label="screwdriver_shaft",
        custom_attributes=attributes,
    )


def build_world(station: newton.ModelBuilder, scene: dict) -> newton.ModelBuilder:
    """One world: a copy of the station with the scene's arm bases, the bin, and the screwdriver."""
    world = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(world)
    world.rigid_gap = CONTACT_GAP
    world.add_builder(station)
    rc.set_arm_bases(world, scene["bases"])
    add_bin(world, scene)
    add_screwdriver(world, scene)
    return world


def build_model(scenes: list[dict]) -> newton.Model:
    """Model with one world per scene; the worlds share one layout (shape types and counts)."""
    station = build_station()  # parsed once (about 1-2 s), copied into every world
    top = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(top)
    for scene in scenes:
        top.add_world(build_world(station, scene))
    return top.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    # Elliptic contacts avoid the pyramidal cone's low-friction instability.
    return newton.solvers.SolverMuJoCo(
        model,
        use_mujoco_contacts=False,
        cone="elliptic",
        impratio=5,
        iterations=50,
        ls_iterations=20,
    )


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    return newton.CollisionPipeline(model)


# -----------------------------------------------------------


def load_reference(name: str) -> dict | None:
    """Ground truth of an episode for :func:`replay_common.score` (``gt/<name>.npz``), if present."""
    path = HERE / "gt" / f"{name}.npz"
    return rc.load_gt(path) if path.exists() else None


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.name = Path(args.episode).stem
        self.episode = rc.load_episode(args.episode)
        scene = rc.load_scene(self.name if args.scene is None else args.scene)
        # Extra worlds are copies of the scene; with --jitter their screwdriver starts are perturbed like the
        # verifier's.
        rng = np.random.default_rng(args.seed)
        self.scenes = [scene] + [
            rc.jitter_scene(scene, rng) if args.jitter else scene for _ in range(args.num_worlds - 1)
        ]
        self.reference = load_reference(self.name)
        self.camera = rc.load_camera() if (HERE / "camera.json").exists() else None

        self.model = build_model(self.scenes)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.replay = rc.Replay(
            self.model,
            self.solver,
            self.collision_pipeline,
            self.episode,
            dt=PARAMS["dt"],
            command_delay=PARAMS["command_delay"],
        )
        # The MCP host binds these, and its checkpoints rewind the replay's cursor and history arrays.
        self.state_0, self.state_1 = self.replay.state_0, self.replay.state_1
        self.control, self.contacts = self.replay.control, self.replay.contacts
        for attribute, array in self.replay.checkpoint_arrays().items():
            setattr(self, attribute, array)
        self.graph = self.replay.graph

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        self.viewer.set_model(self.model)

    def capture(self):
        """Re-record the replay step, e.g. after replacing the solver or the collision pipeline."""
        self.replay.solver, self.replay.collision_pipeline = self.solver, self.collision_pipeline
        self.replay.contacts = self.contacts
        self.replay.capture()
        self.graph = self.replay.graph

    def step(self):
        self.replay.step(self.substeps)
        self.sim_time += self.frame_dt

    def run(self, seconds: float | None = None) -> float:
        """Replay to ``seconds`` after the episode start (default: the end); returns the wall time [s]."""
        wall = self.replay.run(seconds)
        self.sim_time = self.replay.sim_time
        return wall

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def evaluate(self) -> list[dict]:
        """Metrics of every world so far (:func:`replay_common.score`), one dict per world."""
        recordings = self.replay.recordings()
        return [
            rc.score(recording, scene, self.reference, self.camera)
            for recording, scene in zip(recordings, self.scenes, strict=True)
        ]

    def report(self, results: list[dict] | None = None) -> list[dict]:
        """Print per-world metrics, :func:`replay_common.check` failures, and the ensemble summary."""
        results = self.evaluate() if results is None else results

        def show(value, scale=1.0, digits=1):
            return "-" if value is None else f"{value * scale:.{digits}f}"

        for world, result in enumerate(results):
            arm = result["arm_rmse_rad"]
            print(
                f"world {world}: held={result['all_held']} placed={result['all_placed']} "
                f"complete={result['complete']} arm_rmse_rad left={arm['left']:.4f} right={arm['right']:.4f}"
            )
            for name, m in result["objects"].items():
                print(
                    f"  {name} held={m['held_fraction']:.2f} rot={show(m['inhand_rot_deg'])}deg "
                    f"slip={show(m['slip_m'], 1000)}mm gap_err={show(m['grip_gap_err_mm'])}mm "
                    f"liftoff_err={show(m['liftoff_err_rows'], 1, 0)}rows track={show(m['carry_track_err_m'], 100)}cm "
                    f"moved={show(m['moved_before_grasp_m'], 100)}cm placed={m['placed']} "
                    f"tip_wall={show(m['tip_wall_m'], 100)}cm com_wall={show(m['com_wall_m'], 100)}cm "
                    f"speed={show(m['final_speed_mps'], 100, 2)}cm/s final_tip_err={show(m['final_tip_xy_err_m'], 100)}cm "
                    f"yaw_err={show(m['final_yaw_err_deg'])}deg max_rise={show(m['max_rise_m'], 100)}cm"
                )
            failed = rc.check(result)["failed"]
            print(f"  check: {'pass' if not failed else 'fail ' + ', '.join(failed)}")
        if len(results) > 1:
            summary = rc.summarize(results)
            arm = summary["arm_rmse_rad"]
            for name, m in summary["objects"].items():
                print(
                    f"summary ({summary['copies']} copies): {name} held {m['held']} placed {m['placed']} "
                    f"held+placed+rot<={rc.HELDOUT_ROT_MAX_DEG:g}deg {m['held_placed_rot_ok']}; medians: "
                    f"rot {show(m['inhand_rot_deg'])}deg slip {show(m['slip_m'], 1000)}mm "
                    f"gap_err {show(m['grip_gap_err_mm'])}mm arm_rmse left {arm['left']:.4f} right {arm['right']:.4f}"
                )
        return results

    def test_final(self):
        results = self.report()
        for recording in self.replay.recordings():
            for name in rc.OBJECTS:
                assert np.all(np.isfinite(recording[f"{name}_pos"])), f"{name} left the valid state space"
        assert all(len(result["objects"]) == len(rc.OBJECTS) for result in results)

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--episode", default="main", help="Episode name (episodes/<name>.npz) or .npz path")
        parser.add_argument("--scene", default=None, help="Scene name or .json path (default: the episode's name)")
        parser.add_argument("--num-worlds", type=int, default=1, help="Copies of the scene, one world each")
        parser.add_argument("--jitter", action="store_true", help="Perturb the screwdriver starts of the extra copies")
        parser.add_argument("--seed", type=int, default=0, help="Seed of --jitter")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s] (main run)")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    wall = example.run(args.seconds)
    print(f"replayed {example.sim_time:.2f} s of {len(example.scenes)} world(s) in {wall:.1f} s")
    example.report()
