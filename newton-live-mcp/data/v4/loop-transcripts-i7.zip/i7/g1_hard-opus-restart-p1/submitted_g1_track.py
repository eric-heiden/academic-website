# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Controller: an offline balance plan shifts the reference pelvis so the ZMP of the motion stays inside
the feet, leg IK keeps both feet flat on the floor while the pelvis follows that target, and
floating-base gravity compensation is fed forward through the servo targets.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import warp as wp
from scipy.optimize import lsq_linear
from scipy.spatial import ConvexHull

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


# ---------------- Controller parameters ----------------
SERVO_FREQUENCY = 30.0  # servo natural frequency on the reflected inertia [Hz]
SERVO_DAMPING_RATIO = 1.0
FOOT_Z = 0.034  # ankle-roll-link height of a loaded flat foot [m]
FOOT_CORNERS = [np.array([x, y, -0.035]) for x in (-0.05, 0.12) for y in (-0.025, 0.025)]  # sole, ankle frame
CONTACT_FORCE_REG = 1e-3  # regularization of the contact-force distribution
IK_ITERATIONS = 6
IK_DAMPING = 1e-4
ZMP_DIFF_STEP = 0.1  # time step for differentiating the reference to get its ZMP [s]
ZMP_MARGIN = 0.025  # keep the planned ZMP this far inside the support polygon [m]
PLAN_W_DEVIATION = 0.3  # weight of the pelvis deviation from the reference in the balance plan
PLAN_W_VELOCITY = 0.02  # weight of the pelvis-offset velocity (smoothness) in the balance plan
COM_RATIO = 0.9  # CoM shift per pelvis shift


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, derived from a natural frequency on the reflected inertia.
        natural_frequency = 2.0 * np.pi * SERVO_FREQUENCY
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * SERVO_DAMPING_RATIO * ARMATURE * natural_frequency
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self._init_controller()
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    # ---------------- Controller (tunable) ----------------
    # Per frame: (1) the reference pelvis position is shifted by an offline balance plan that keeps
    # the ZMP inside the feet, (2) leg IK keeps both feet flat at their initial floor poses while the
    # pelvis follows that target, and (3) floating-base gravity compensation (contact forces
    # distributed over the foot corners) is added as servo feedforward through the position targets.
    def _init_controller(self):
        self.mj_model = self.solver.mj_model  # CPU MuJoCo model for kinematics and dynamics
        self.mj_data = mujoco.MjData(self.mj_model)
        self.nv = self.mj_model.nv
        names = [self.mj_model.body(i).name for i in range(self.mj_model.nbody)]
        self.foot_bodies = [
            next(i for i, n in enumerate(names) if n.endswith(f"{side}_ankle_roll_link")) for side in ("left", "right")
        ]
        # Leg dofs (qvel indices): hip pitch/roll/yaw, knee, ankle pitch/roll.
        self.leg_dofs = [np.arange(6, 12), np.arange(12, 18)]
        self.jnt_lo = self.mj_model.jnt_range[1:, 0].copy()
        self.jnt_hi = self.mj_model.jnt_range[1:, 1].copy()
        self.foot_anchors = None
        self._plan_balance()

    @staticmethod
    def _to_mj_qpos(q):
        """Newton joint_q (root quat xyzw) -> MuJoCo qpos (root quat wxyz)."""
        qpos = q.copy()
        qpos[3:7] = [q[6], q[3], q[4], q[5]]
        return qpos

    def _gravity_compensation(self, q):
        """Joint torques holding configuration q statically with both feet on the floor: contact
        forces at the foot corners (normal force >= 0) balance the unactuated floating-base rows."""
        m, d = self.mj_model, self.mj_data
        d.qpos[:] = self._to_mj_qpos(q)
        d.qvel[:] = 0.0
        mujoco.mj_forward(m, d)
        bias = d.qfrc_bias.copy()
        jacp = np.zeros((3, self.nv))
        jacs = []
        for b in self.foot_bodies:
            R = d.xmat[b].reshape(3, 3)
            for corner in FOOT_CORNERS:
                mujoco.mj_jac(m, d, jacp, None, d.xpos[b] + R @ corner, b)
                jacs.append(jacp.copy())
        J = np.concatenate(jacs, axis=0)
        n = J.shape[0]
        A = np.vstack([J[:, :6].T, CONTACT_FORCE_REG * np.eye(n)])
        rhs = np.concatenate([bias[:6], np.zeros(n)])
        lo = np.full(n, -np.inf)
        lo[2::3] = 0.0
        f = lsq_linear(A, rhs, bounds=(lo, np.full(n, np.inf)), method="bvls").x
        return bias[6:] - J[:, 6:].T @ f

    def _foot_poses(self, q):
        """Foot (ankle roll link) poses of q, flattened onto the floor: keep x, y and yaw."""
        m, d = self.mj_model, self.mj_data
        d.qpos[:] = self._to_mj_qpos(q)
        mujoco.mj_kinematics(m, d)
        poses = []
        for b in self.foot_bodies:
            R = d.xmat[b].reshape(3, 3)
            yaw = np.arctan2(R[1, 0], R[0, 0])
            c, s = np.cos(yaw), np.sin(yaw)
            pos = d.xpos[b].copy()
            pos[2] = FOOT_Z
            poses.append((pos, np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])))
        return poses

    def _leg_ik(self, q_des, feet):
        """Leg joints that put both feet at the given flat poses with the root at its pose in q_des."""
        m, d = self.mj_model, self.mj_data
        d.qpos[:] = self._to_mj_qpos(q_des)
        mujoco.mj_kinematics(m, d)
        # The reference legs are nearly straight, so keep the reference foot height (the root height
        # follows from the legs) and only correct the horizontal foot position and the foot tilt.
        feet = [(np.array([p[0], p[1], d.xpos[b][2]]), R) for (p, R), b in zip(feet, self.foot_bodies)]
        jacp = np.zeros((3, self.nv))
        jacr = np.zeros((3, self.nv))
        for _ in range(IK_ITERATIONS):
            mujoco.mj_kinematics(m, d)
            mujoco.mj_comPos(m, d)
            for (pos, R_des), b, dofs in zip(feet, self.foot_bodies, self.leg_dofs):
                R_err = R_des @ d.xmat[b].reshape(3, 3).T
                e_r = 0.5 * np.array([R_err[2, 1] - R_err[1, 2], R_err[0, 2] - R_err[2, 0], R_err[1, 0] - R_err[0, 1]])
                mujoco.mj_jacBody(m, d, jacp, jacr, b)
                J = np.vstack([jacp[:, dofs], jacr[:, dofs]])
                dq = np.linalg.solve(J.T @ J + IK_DAMPING * np.eye(6), J.T @ np.concatenate([pos - d.xpos[b], e_r]))
                qi = dofs + 1  # hinge qpos index = dof index + 1 (free joint: 7 qpos, 6 dofs)
                d.qpos[qi] = np.clip(d.qpos[qi] + dq, self.jnt_lo[dofs - 6], self.jnt_hi[dofs - 6])
        out = q_des.copy()
        out[7:] = d.qpos[7:]
        return out

    def _reference_zmp(self, t):
        """ZMP on the floor [m] and CoM of the reference motion at time t (full multibody dynamics)."""
        m, d = self.mj_model, self.mj_data
        h = ZMP_DIFF_STEP
        qa, q0, qb = (self._to_mj_qpos(self.reference(t + k * h)) for k in (-1, 0, 1))
        v0, v1 = np.zeros(self.nv), np.zeros(self.nv)
        mujoco.mj_differentiatePos(m, v0, h, qa, q0)
        mujoco.mj_differentiatePos(m, v1, h, q0, qb)
        d.qpos[:] = q0
        d.qvel[:] = 0.5 * (v0 + v1)
        mujoco.mj_forward(m, d)
        d.qacc[:] = (v1 - v0) / h
        wrench = np.zeros(self.nv)
        mujoco.mj_rne(m, d, 1, wrench)
        force = wrench[:3]
        torque = d.xmat[1].reshape(3, 3) @ wrench[3:6]  # free-joint torque is in the pelvis frame
        o = d.xpos[1]
        px = o[0] + (-o[2] * force[0] - torque[1]) / force[2]
        py = o[1] + (torque[0] - o[2] * force[1]) / force[2]
        return np.array([px, py]), d.subtree_com[1].copy()

    def _plan_balance(self):
        """Offline plan of smooth horizontal pelvis offsets that move the (table-cart) ZMP of the
        reference inside the support polygon of the flat feet while staying close to the reference."""
        dt = self.frame_dt
        n = int(np.ceil(self.motion.duration / dt)) + 3
        zmp, com = zip(*(self._reference_zmp(k * dt) for k in range(n)))
        zmp, com = np.array(zmp), np.array(com)
        corners = [
            pos[:2] + R[:2, :2] @ np.array([x, y])
            for pos, R in self._foot_poses(self.reference(0.0))
            for x in (-0.05, 0.12)
            for y in (-0.03, 0.03)
        ]
        hull = ConvexHull(np.array(corners))
        normals, offsets = hull.equations[:, :2], -hull.equations[:, 2] - ZMP_MARGIN
        goal = zmp.copy()
        for _ in range(20):  # project the reference ZMP onto the shrunken support polygon
            violation = goal @ normals.T - offsets
            k = np.argmax(violation, axis=1)
            v = np.maximum(violation[np.arange(n), k], 0.0)
            goal -= v[:, None] * normals[k]
        zc = np.mean(com[:, 2]) - FOOT_Z + 0.035  # CoM height above the floor
        D2 = (np.eye(n, k=-1) - 2 * np.eye(n) + np.eye(n, k=1)) / dt**2
        D2[[0, -1], :] = 0.0
        D1 = (np.eye(n, k=1) - np.eye(n)) / dt
        # ZMP change of a CoM offset delta (table-cart model): delta - zc / g * delta''.
        A = np.vstack([np.eye(n) - (zc / 9.81) * D2, PLAN_W_DEVIATION * np.eye(n), PLAN_W_VELOCITY * D1])
        self.balance_offset = np.zeros((n, 2))
        for axis in range(2):
            rhs = np.concatenate([goal[:, axis] - zmp[:, axis], np.zeros(2 * n)])
            self.balance_offset[:, axis] = np.linalg.lstsq(A, rhs, rcond=None)[0] / COM_RATIO

    def _balance_offset(self, t):
        x = np.clip(t / self.frame_dt, 0, len(self.balance_offset) - 1.001)
        i = int(x)
        a = x - i
        return (1 - a) * self.balance_offset[i] + a * self.balance_offset[i + 1]

    def step(self):
        q = self.state_0.joint_q.numpy()
        t_next = self.sim_time + self.frame_dt
        # Reference one frame ahead; its root pose (plus balance offset) is only used by the leg IK.
        target = self.reference(t_next)
        target[:2] += self._balance_offset(t_next)
        if self.foot_anchors is None:
            self.foot_anchors = self._foot_poses(q)
        target = self._leg_ik(target, self.foot_anchors)
        # Servo force kp * (target - q) - kd * qd; shifting the target by tau / kp adds feedforward tau.
        target[7:] += self._gravity_compensation(q) / self.kp
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
