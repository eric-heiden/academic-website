# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and updates their targets every
substep.

Plain joint tracking is not enough to keep balance: the kinematic reference
lifts heels / tilts soles while the feet should stay planted, and fast arm
motions (high-five) push the ZMP past the toes. The controller therefore adds a
balance stabilizer on top of stiff joint servos (see ``_setup_balance``):

* flat-foot ankle targets computed from the reference shank orientation,
* a CoM trajectory re-planned once from the clip so that the multi-body ZMP of
  the reference stays inside the foot support,
* CoM position/velocity feedback realized by ankle lean (sagittal) and
  parallel hip/ankle roll (lateral) offsets, and
* sole-tilt feedback that backs the ankles off when a heel or edge lifts.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import numpy as np
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)

# Foot contact spheres in the ankle roll link frame (from the MJCF) [m].
FOOT_CORNERS = np.array([[-0.05, 0.025, -0.035], [-0.05, -0.025, -0.035], [0.12, 0.03, -0.035], [0.12, -0.03, -0.035]])

# Stabilizer patterns over the 29 actuated joints, applied to both legs: sagittal lean
# about the ankles (ankle pitch) and lateral parallel leg tilt (hip roll -, ankle roll +).
STAB_PATTERNS = np.zeros((2, 29))
for _leg in (0, 6):
    STAB_PATTERNS[0, _leg + 4] = -1.0
    STAB_PATTERNS[1, _leg + 1], STAB_PATTERNS[1, _leg + 5] = -1.0, 1.0


def _quat_to_matrix(q):
    """Rotation matrices from xyzw quaternions, shape (n, 3, 3)."""
    x, y, z, w = q[:, 0], q[:, 1], q[:, 2], q[:, 3]
    return np.stack(
        [
            np.stack([1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)], -1),
            np.stack([2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)], -1),
            np.stack([2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)], -1),
        ],
        -2,
    )


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, from a 40 Hz natural frequency (w.r.t. the reflected
        # inertia) and damping ratio 2. Torques stay clamped to the MJCF limits.
        natural_frequency = 2.0 * np.pi * 40.0
        damping_ratio = 2.0
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * damping_ratio * ARMATURE * natural_frequency
        # Balance stabilizer (see _setup_balance).
        self.support_margin = (0.03, 0.06, 0.04)  # ZMP margin from heel, toe, side edges [m]
        self.kp_com = 3.0  # CoM position feedback [m/m]
        self.kd_com = 0.3  # CoM velocity feedback [m/(m/s)]
        self.k_sole = 1.0  # sole-tilt feedback [rad/rad]
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self._setup_balance()
        self.viewer.set_model(self.model)
        # The stabilizer updates the servo targets every substep from the measured
        # state, so the substep loop runs from Python (no CUDA graph capture).

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    # ---------------- Controller (tunable) ----------------
    # Balance stabilizer. The kinematic reference is not always dynamically feasible
    # for flat feet (e.g. the high-five swings the ZMP past the toes), so the CoM
    # trajectory is re-planned once from the clip (preview over the whole motion) to
    # keep the reference ZMP inside the foot support. The CoM offset and a CoM
    # position/velocity feedback term are realized by leaning about the ankles
    # (sagittal) and by a parallel hip/ankle roll tilt of both legs (lateral).
    def _com(self, body_q):
        rot = _quat_to_matrix(body_q[:, 3:7])
        return (self._mass[:, None] * (body_q[:, :3] + np.einsum("bij,bj->bi", rot, self._com_local))).sum(0) / (
            self._mass.sum()
        )

    def _feet_points(self, body_q):
        pts = []
        for b in self._feet:
            rot = _quat_to_matrix(body_q[b : b + 1, 3:7])[0]
            pts.append(body_q[b, :3] + FOOT_CORNERS @ rot.T)
        return np.concatenate(pts)

    def _setup_balance(self):
        model = self.model
        self._mass = model.body_mass.numpy()
        self._com_local = model.body_com.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in model.body_label]
        self._feet = [labels.index("left_ankle_roll_link"), labels.index("right_ankle_roll_link")]
        shins = [labels.index("left_knee_link"), labels.index("right_knee_link")]
        state = model.state()
        joint_q = wp.zeros_like(model.joint_q)

        def fk(q):
            joint_q.assign(q)
            newton.eval_fk(model, joint_q, model.joint_qd, state)
            return state.body_q.numpy()

        q0 = self.reference(0.0)
        foot0 = _quat_to_matrix(fk(q0)[self._feet[1] : self._feet[1] + 1, 3:7])[0]

        def com_rel(q):
            # CoM relative to the feet, with the (right) foot held at its initial orientation.
            body_q = fk(q)
            foot = _quat_to_matrix(body_q[self._feet[1] : self._feet[1] + 1, 3:7])[0]
            return foot0 @ foot.T @ (self._com(body_q) - self._feet_points(body_q).mean(0))

        # CoM shift (relative to the feet) of the two stabilizer patterns [m/rad].
        eps = 1e-3
        cols = []
        for pattern in STAB_PATTERNS:
            dq = np.zeros_like(q0)
            dq[7:] = pattern * eps
            cols.append((com_rel(q0 + dq) - com_rel(q0 - dq))[:2] / (2 * eps))
        self._stab_inv = np.linalg.inv(np.array(cols).T)

        # Reference CoM and support box sampled at the frame rate (1 s past the end).
        # The reference sometimes lifts heels / tilts the soles while the feet should stay
        # planted; the ankle targets are replaced by the angles that keep each sole flat
        # under the reference shank orientation (closed form for pitch-then-roll ankles).
        dt = self.frame_dt
        n = int(np.ceil(self.motion.duration / dt)) + int(1.0 / dt)
        com, feet_mid, lo, hi, body_com = [], [], [], [], []
        self._flat_ankles = np.zeros((n, 4))
        for k in range(n):
            q = self.reference(k * dt)
            body_q = fk(q)
            for leg, shin in enumerate(shins):
                up = _quat_to_matrix(body_q[shin : shin + 1, 3:7])[0].T @ np.array([0.0, 0.0, 1.0])
                pitch, roll = np.arctan2(up[0], up[2]), -np.arcsin(np.clip(up[1], -1, 1))
                i = 7 + 6 * leg + 4
                self._flat_ankles[k, 2 * leg : 2 * leg + 2] = np.array([pitch, roll]) - q[i : i + 2]
                q[i : i + 2] += self._flat_ankles[k, 2 * leg : 2 * leg + 2]
            body_q = fk(q)
            pts = self._feet_points(body_q)
            com.append(self._com(body_q))
            body_com.append(body_q[:, :3] + np.einsum("bij,bj->bi", _quat_to_matrix(body_q[:, 3:7]), self._com_local))
            feet_mid.append(pts.mean(0))
            lo.append(pts[:, :2].min(0))
            hi.append(pts[:, :2].max(0))
        com, feet_mid, lo, hi, body_com = map(np.array, (com, feet_mid, lo, hi, body_com))
        margin_heel, margin_toe, margin_side = self.support_margin
        lo = lo + np.array([margin_heel, margin_side])
        hi = hi - np.array([margin_toe, margin_side])

        # Smoothed body trajectories -> reference ZMP; smallest CoM offset (LIPM response)
        # that keeps it inside the margin-shrunk support box (penalty active-set solve).
        kernel = np.exp(-0.5 * (np.arange(-6, 7) / 2.0) ** 2)
        kernel /= kernel.sum()
        flat = body_com.reshape(n, -1)
        padded = np.pad(flat, ((6, 6), (0, 0)), mode="edge")
        body_s = np.stack([np.convolve(padded[:, i], kernel, mode="valid") for i in range(flat.shape[1])], 1)
        body_s = body_s.reshape(body_com.shape)
        com_s = (self._mass[None, :, None] * body_s).sum(1) / self._mass.sum()
        ground = feet_mid[:, 2:3] - 0.035
        omega2 = 9.81 / np.mean(com_s[:, 2] - ground[:, 0])
        d2 = (np.eye(n, k=1) - 2 * np.eye(n) + np.eye(n, k=-1)) / dt**2
        d2[0, :] = 0.0
        d2[-1, :] = 0.0
        d1 = (np.eye(n, k=1) - np.eye(n))[:-1] / dt
        a = np.eye(n) - d2 / omega2
        # Multi-body (point mass) ZMP of the reference, including the swinging arms.
        acc = np.einsum("ij,jbk->ibk", d2, body_s)
        mz = self._mass[None, :] * (acc[:, :, 2] + 9.81)
        height = body_s[:, :, 2] - ground
        zmp = np.stack(
            [(mz * body_s[:, :, i] - self._mass[None, :] * acc[:, :, i] * height).sum(1) / mz.sum(1) for i in range(2)],
            1,
        )
        reg = np.eye(n) + 0.002 * d1.T @ d1
        offset = np.zeros((n, 2))
        for axis in range(2):
            x = np.zeros(n)
            for _ in range(50):
                p = zmp[:, axis] + a @ x
                w = ((p > hi[:, axis]) | (p < lo[:, axis])).astype(float) * 1e4
                bound = np.where(p > hi[:, axis], hi[:, axis], lo[:, axis])
                x_new = np.linalg.solve(reg + a.T @ (w[:, None] * a), a.T @ (w * (bound - zmp[:, axis])))
                if np.allclose(x_new, x, atol=1e-6):
                    break
                x = x_new
            offset[:, axis] = x
        self._com_offset = offset
        self._com_plan_rel = com[:, :2] + offset - feet_mid[:, :2]
        self._com_plan_vel = np.gradient(self._com_plan_rel, dt, axis=0)

    def _balance_offsets(self, t):
        """Joint target offsets [rad] for the 29 actuated joints at time t [s]."""
        x = min(t / self.frame_dt, len(self._com_offset) - 1.0)
        k = min(int(x), len(self._com_offset) - 2)
        a = x - k
        plan = (1 - a) * self._com_plan_rel[k] + a * self._com_plan_rel[k + 1]
        plan_vel = (1 - a) * self._com_plan_vel[k] + a * self._com_plan_vel[k + 1]
        com_offset = (1 - a) * self._com_offset[k] + a * self._com_offset[k + 1]
        flat = (1 - a) * self._flat_ankles[k] + a * self._flat_ankles[k + 1]
        body_q = self.state_0.body_q.numpy()
        body_qd = self.state_0.body_qd.numpy()
        com_rel = (self._com(body_q) - self._feet_points(body_q).mean(0))[:2]
        com_vel = (self._mass[:, None] * body_qd[:, :2]).sum(0) / self._mass.sum()
        err = com_rel - plan
        derr = com_vel - plan_vel
        shift = com_offset - self.kp_com * err - self.kd_com * derr
        shift = np.clip(shift, -0.08, 0.08)
        s = self._stab_inv @ shift
        offsets = s[0] * STAB_PATTERNS[0] + s[1] * STAB_PATTERNS[1]
        offsets[[4, 5, 10, 11]] += flat
        # Sole-tilt feedback: when a heel/edge lifts, back the ankle off so the foot lands flat.
        rot = _quat_to_matrix(body_q[self._feet, 3:7])
        offsets[[4, 10]] += self.k_sole * rot[:, 2, 0]
        offsets[[5, 11]] -= self.k_sole * rot[:, 2, 1]
        return offsets

    # -------------------------------------------------------

    def simulate(self):
        for i in range(self.sim_substeps):
            # ---------------- Controller (tunable) ----------------
            # Servo targets: the reference joint angles at the end of the substep plus
            # the balance stabilizer offsets computed from the current state.
            t = self.sim_time + i * self.sim_dt
            target = self.reference(t + self.sim_dt)
            target[7:] += self._balance_offsets(t)
            self.control.joint_target_q.assign(target)
            # -------------------------------------------------------
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
