# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Controller (the floating base is unactuated, so balance comes from the legs):

* Stiff servos (60 Hz natural frequency on the reflected armature).
* Leg inverse kinematics keeps both feet flat on their initial floor anchors
  while the pelvis follows the reference pose; the root, legs and waist follow
  a time-smoothed clip (sigma 0.1 s) so the balance-relevant motion stays
  within what flat feet can react.
* Horizontal pelvis-position feedback moves the pelvis target against the
  measured root drift.
* Floating-base inverse dynamics (MuJoCo RNE on a CPU model copy) with the root
  wrench distributed over both foot wrenches gives feedforward joint torques,
  applied through the servo targets so the actuator torque limits still hold.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def quat_log(q):
    """Rotation vector [rad] of an xyzw quaternion."""
    v = np.array([q[0], q[1], q[2]])
    w = float(q[3])
    if w < 0.0:
        v, w = -v, -w
    n = np.linalg.norm(v)
    return v * (2.0 * np.arctan2(n, w) / n) if n > 1e-9 else 2.0 * v


def rot_z(yaw):
    c, s = np.cos(yaw), np.sin(yaw)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


class WholeBodyController:
    """Model-based double-support helpers on a CPU copy of the MuJoCo model.

    ``solve_legs`` finds leg joint angles that put both feet flat on their floor
    anchors for a given pelvis pose; ``joint_torques`` computes feedforward joint
    torques from floating-base inverse dynamics with the root wrench distributed
    over the two feet. The controller realizes the torques through the position
    servos as target offsets (tau / kp), so the actuator torque limits still apply.
    """

    FOOT_HEIGHT = 0.035  # ankle-roll origin height when the foot is flat on the floor [m]
    FOOT_CENTER = np.array([0.035, 0.0, -0.035])  # sole center in the ankle-roll frame [m]

    def __init__(self, mj_model):
        self.m = mj_model
        self.d = mujoco.MjData(mj_model)
        names = [mujoco.mj_id2name(mj_model, mujoco.mjtObj.mjOBJ_BODY, b) or "" for b in range(mj_model.nbody)]
        self.foot_body = [next(i for i, n in enumerate(names) if n.endswith(f"{side}_ankle_roll_link")) for side in ("left", "right")]
        # velocity-space columns of the 6 leg joints per side (after the 6 free-joint dofs)
        self.leg_dofs = [np.arange(6, 12), np.arange(12, 18)]
        self.jacp = np.zeros((3, mj_model.nv))
        self.jacr = np.zeros((3, mj_model.nv))

    @staticmethod
    def to_mj(q):
        """Newton joint_q (root quat xyzw) to MuJoCo qpos (root quat wxyz)."""
        return np.concatenate([q[:3], [q[6], q[3], q[4], q[5]], q[7:]])

    def _set_qpos(self, q):
        self.d.qpos[:] = self.to_mj(q)

    def flat_foot_poses(self, q):
        """Foot poses of configuration q projected flat onto the floor [(pos, R), ...]."""
        self._set_qpos(q)
        mujoco.mj_kinematics(self.m, self.d)
        poses = []
        for b in self.foot_body:
            R = self.d.xmat[b].reshape(3, 3)
            pos = np.array([self.d.xpos[b][0], self.d.xpos[b][1], self.FOOT_HEIGHT])
            poses.append((pos, rot_z(np.arctan2(R[1, 0], R[0, 0]))))
        return poses

    def solve_legs(self, q_ref, foot_targets, iterations=6, height_weight=0.3, joint_weight=0.05):
        """Return q_ref with leg joints (and pelvis height, softly) changed so the feet reach foot_targets."""
        q = q_ref.copy()
        m, d = self.m, self.d
        for _ in range(iterations):
            self._set_qpos(q)
            mujoco.mj_kinematics(m, d)
            mujoco.mj_comPos(m, d)
            J = np.zeros((12 + 13, 13))  # unknowns: pelvis height, 6 left leg, 6 right leg
            r = np.zeros(12 + 13)
            for side in range(2):
                b = self.foot_body[side]
                pos_t, rot_t = foot_targets[side]
                R = d.xmat[b].reshape(3, 3)
                e_rot = rot_t @ R.T
                rows = slice(6 * side, 6 * side + 6)
                r[rows] = np.concatenate(
                    [pos_t - d.xpos[b], 0.5 * np.array([e_rot[2, 1] - e_rot[1, 2], e_rot[0, 2] - e_rot[2, 0], e_rot[1, 0] - e_rot[0, 1]])]
                )
                mujoco.mj_jacBody(m, d, self.jacp, self.jacr, b)
                dofs = self.leg_dofs[side]
                J[rows, 1 + 6 * side : 7 + 6 * side] = np.vstack([self.jacp[:, dofs], self.jacr[:, dofs]])
                J[6 * side + 2, 0] = 1.0
            J[12, 0] = height_weight
            r[12] = height_weight * (q_ref[2] - q[2])
            J[13:, 1:] = joint_weight * np.eye(12)
            r[13:] = joint_weight * (q_ref[7:19] - q[7:19])
            dx = np.linalg.lstsq(J, r, rcond=None)[0]
            q[2] += dx[0]
            q[7:19] += dx[1:]
        return q

    def velocity(self, q_a, q_b, dt):
        """Generalized (MuJoCo) velocity moving from q_a to q_b in dt [s]."""
        v = np.zeros(self.m.nv)
        mujoco.mj_differentiatePos(self.m, v, dt, self.to_mj(q_a), self.to_mj(q_b))
        return v

    def joint_torques(self, q, qvel, qacc, moment_weight=20.0):
        """Joint torques realizing (q, qvel, qacc) with the root wrench supplied by both feet.

        Inverse dynamics (RNE plus armature) gives the generalized forces; the six
        floating-base rows must come from the foot contact wrenches, which are
        distributed by weighted least norm (moments penalized so that the load
        is carried by forces near the sole centers).
        """
        m, d = self.m, self.d
        self._set_qpos(q)
        d.qvel[:] = qvel
        d.qacc[:] = qacc
        mujoco.mj_kinematics(m, d)
        mujoco.mj_comPos(m, d)
        mujoco.mj_comVel(m, d)
        tau = np.zeros(m.nv)
        mujoco.mj_rne(m, d, 1, tau)
        tau += m.dof_armature * qacc
        rows = []
        for b in self.foot_body:
            point = d.xpos[b] + d.xmat[b].reshape(3, 3) @ self.FOOT_CENTER
            mujoco.mj_jac(m, d, self.jacp, self.jacr, point, b)
            rows += [self.jacp.copy(), self.jacr.copy()]
        Jc = np.vstack(rows)  # 12 x nv, rows: [F_L, M_L, F_R, M_R]
        A = Jc[:, :6].T
        w_inv = np.ones(12)
        w_inv[3:6] = w_inv[9:12] = 1.0 / moment_weight
        Winv = np.diag(w_inv)
        wrench = Winv @ A.T @ np.linalg.solve(A @ Winv @ A.T, tau[:6])
        return tau[6:] - Jc[:, 6:].T @ wrench


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


def smoothed_clip(clip, sigma):
    """Copy of clip with a Gaussian of sigma [s] applied along time (edges held)."""
    smooth = MotionClip.__new__(MotionClip)
    smooth.fps, smooth.duration = clip.fps, clip.duration
    smooth.qpos = clip.qpos.copy()
    if sigma > 0.0:
        radius = int(np.ceil(3.0 * sigma * clip.fps))
        k = np.exp(-0.5 * (np.arange(-radius, radius + 1) / (sigma * clip.fps)) ** 2)
        k /= k.sum()
        padded = np.concatenate([np.repeat(clip.qpos[:1], radius, 0), clip.qpos, np.repeat(clip.qpos[-1:], radius, 0)])
        smooth.qpos = np.stack([np.convolve(padded[:, j], k, mode="valid") for j in range(clip.qpos.shape[1])], axis=1)
        smooth.qpos[:, 3:7] /= np.linalg.norm(smooth.qpos[:, 3:7], axis=1, keepdims=True)
    return smooth


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, derived from a 60 Hz natural frequency on the
        # reflected armature (critically damped). Stiff servos keep the whole-body
        # shape; the model-based feedforward below removes gravity/inertia sag.
        natural_frequency = 2.0 * np.pi * 60.0
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * ARMATURE * natural_frequency
        self.lookahead = self.frame_dt  # servo targets lead the simulation by one frame [s]
        self.diff_dt = 1.0 / 30.0  # finite-difference step for desired velocity/acceleration [s]
        self.smooth_sigma = 0.1  # Gaussian time smoothing of root/leg/waist reference [s]
        # Balance feedback: pelvis target correction per root pose error
        # (x, y, z [m/m]; roll, pitch, yaw [rad/rad]) and per error rate [s].
        # Only the horizontal position is fed back; tilt feedback destabilizes.
        self.balance_kp = np.array([0.75, 0.75, 0.0, 0.0, 0.0, 0.0])
        self.balance_kd = np.array([0.075, 0.075, 0.0, 0.0, 0.0, 0.0])
        self.balance_limit = np.array([0.05, 0.05, 0.05, 0.2, 0.2, 0.2])
        self._smooth_source = None
        self._prev_err = None
        self._err_rate = np.zeros(6)
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.controller = WholeBodyController(self.solver.mj_model)
        # Stance-foot anchors: the initial reference foot poses, flattened onto the floor.
        self.foot_anchors = self.controller.flat_foot_poses(self._shifted(q0))
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        target = self.compute_targets()
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def smoothed_reference(self, t):
        """Reference joint_q from the time-smoothed clip (rebuilt if the clip changes)."""
        key = (id(self.motion), self.motion.fps, self.smooth_sigma)
        if self._smooth_source != key:
            self._smooth_motion = smoothed_clip(self.motion, self.smooth_sigma)
            self._smooth_source = key
        return self._shifted(self._smooth_motion.sample(t))

    def desired(self, t, root_offset=None):
        """Desired joint_q at time t: reference, smoothed where balance-relevant, with
        the pelvis target corrected by root_offset (dp [m], drot [rad]) and the legs
        solved so both feet stay flat on their floor anchors."""
        q = self.reference(t)
        # Root, legs and waist (heavy, balance-relevant) follow the smoothed clip; the
        # arms keep the raw reference.
        q[:22] = self.smoothed_reference(t)[:22]
        if root_offset is not None:
            dp, drot = root_offset
            q[:3] += dp
            angle = float(np.linalg.norm(drot))
            if angle > 1e-9:
                dq = wp.quat_from_axis_angle(wp.vec3(*(drot / angle)), angle)
                q[3:7] = np.array(wp.normalize(dq * wp.quat(*q[3:7])))
        return self.controller.solve_legs(q, self.foot_anchors)

    def balance_offset(self):
        """Pelvis target correction opposing the measured root position (x, y) and tilt
        error: moves the body (and so its center of mass) back over the feet."""
        q = self.state_0.joint_q.numpy()[:7]
        q_des = self.desired(self.sim_time)
        rot_err = quat_log(wp.quat(*q[3:7]) * wp.quat_inverse(wp.quat(*q_des[3:7])))
        err = np.concatenate([q[:3] - q_des[:3], rot_err])
        if self._prev_err is None or self.sim_time == 0.0:
            self._prev_err = err.copy()
            self._err_rate = np.zeros(6)
        rate = (err - self._prev_err) / self.frame_dt
        self._err_rate += 0.5 * (rate - self._err_rate)  # low-pass filtered error rate
        self._prev_err = err
        u = np.clip(-(self.balance_kp * err + self.balance_kd * self._err_rate), -self.balance_limit, self.balance_limit)
        return u[:3], u[3:]

    def compute_targets(self):
        """Servo targets: desired pose plus feedforward torque expressed as target offset."""
        t = self.sim_time + self.lookahead
        h = self.diff_dt
        offset = self.balance_offset()
        q_des = self.desired(t, offset)
        q_prev, q_next = self.desired(t - h, offset), self.desired(t + h, offset)
        v0 = self.controller.velocity(q_prev, q_des, h)
        v1 = self.controller.velocity(q_des, q_next, h)
        qvel = 0.5 * (v0 + v1)
        qacc = (v1 - v0) / h
        tau = self.controller.joint_torques(q_des, qvel, qacc)
        # Position servo: kp (target - q) - kd qd. Offsetting the target by
        # (tau + kd qd_des) / kp adds the feedforward torque and cancels the damping
        # lag; the actuator force range still clamps the total torque.
        target = q_des.copy()
        target[7:] += (tau + self.kd * qvel[6:]) / self.kp
        return target

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
