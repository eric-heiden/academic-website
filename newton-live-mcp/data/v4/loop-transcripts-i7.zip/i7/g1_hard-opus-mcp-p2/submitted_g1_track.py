# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Controller: at start-up the clip is turned into a dynamically feasible plan
(see :class:`MotionPlanner`): the reference is lightly smoothed, the legs are
re-solved by IK so both feet stay flat on the floor, the pelvis is shifted
horizontally (linear-inverted-pendulum dynamics filter) so the zero-moment
point stays inside the feet, and inverse dynamics with the ground wrench split
between the feet gives feedforward joint torques. Every frame the servo target
is the planned pose plus feedforward torque / stiffness.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import copy

import mujoco
import numpy as np
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


def newton_to_mj(q):
    """Newton joint_q (root quat xyzw) -> MuJoCo qpos (root quat wxyz)."""
    return np.concatenate([q[:3], q[6:7], q[3:6], q[7:]])


def mj_to_newton(q):
    return np.concatenate([q[:3], q[4:7], q[3:4], q[7:]])


def gaussian_smooth(x, sigma):
    """Gaussian filter along axis 0 with edge padding."""
    if sigma <= 0:
        return x.copy()
    r = int(np.ceil(4 * sigma))
    w = np.exp(-0.5 * (np.arange(-r, r + 1) / sigma) ** 2)
    w /= w.sum()
    xp = np.concatenate([np.repeat(x[:1], r, 0), x, np.repeat(x[-1:], r, 0)])
    return sum(w[i] * xp[i : i + len(x)] for i in range(2 * r + 1))


class LegIK:
    """Regularized Gauss-Newton IK on the MuJoCo model: leg joints, pelvis height and pelvis
    roll/pitch such that both feet lie flat on the floor at given xy/yaw. The solution stays
    close to the reference joint angles; pelvis height and tilt are cheap (root orientation
    is free), which avoids large knee changes when a reference leg is locked straight."""

    def __init__(self, mjm, foot_height=0.035):
        self.m = mjm
        self.d = mujoco.MjData(mjm)
        names = [mjm.body(i).name for i in range(mjm.nbody)]
        self.feet = [next(i for i, n in enumerate(names) if n.endswith(f"{s}_ankle_roll_link")) for s in ("left", "right")]
        self.h = foot_height  # ankle-roll frame height when the sole spheres touch the floor
        self.cols = np.concatenate([[2, 3, 4], np.arange(6, 18)])  # pelvis z, roll, pitch + 12 leg dofs
        self.cost = np.array([1e-7, 1e-5, 1e-5] + [1e-4] * 12)
        self.lower, self.upper = mjm.jnt_range[1:13, 0], mjm.jnt_range[1:13, 1]
        self.jacp = np.zeros((3, mjm.nv))
        self.jacr = np.zeros((3, mjm.nv))

    def foot_targets(self, qpos):
        d = self.d
        d.qpos[:] = qpos
        mujoco.mj_kinematics(self.m, d)
        out = []
        for b in self.feet:
            R = d.xmat[b].reshape(3, 3)
            out.append((d.xpos[b][0], d.xpos[b][1], np.arctan2(R[1, 0], R[0, 0])))
        return out

    def solve(self, qpos, feet, iters=12):
        m, d = self.m, self.d
        targets = []
        for x, y, yaw in feet:
            c, s = np.cos(yaw), np.sin(yaw)
            targets.append((np.array([x, y, self.h]), np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])))
        d.qpos[:] = qpos
        offset = np.zeros(len(self.cols))  # accumulated deviation from the reference
        v = np.zeros(m.nv)
        for _ in range(iters):
            mujoco.mj_kinematics(m, d)
            mujoco.mj_comPos(m, d)
            Js, es = [], []
            for (p_t, R_t), b in zip(targets, self.feet):
                Re = R_t @ d.xmat[b].reshape(3, 3).T
                rot = 0.5 * np.array([Re[2, 1] - Re[1, 2], Re[0, 2] - Re[2, 0], Re[1, 0] - Re[0, 1]])
                es.append(np.concatenate([p_t - d.xpos[b], rot]))
                mujoco.mj_jacBody(m, d, self.jacp, self.jacr, b)
                Js.append(np.vstack([self.jacp[:, self.cols], self.jacr[:, self.cols]]))
            J, e = np.vstack(Js), np.concatenate(es)
            dx = np.linalg.solve(J.T @ J + np.diag(self.cost), J.T @ e - self.cost * offset)
            offset += dx
            v[:] = 0.0
            v[self.cols] = dx
            mujoco.mj_integratePos(m, d.qpos, v, 1.0)
            d.qpos[7:19] = np.clip(d.qpos[7:19], self.lower, self.upper)
        return d.qpos.copy()


class MotionPlanner:
    """Turns the kinematic reference into a planned pose and feedforward torque per frame.

    1. Sample the reference at the control rate and smooth it lightly (removes the velocity
       kinks of the 30 fps linear interpolation).
    2. Leg IK: both feet flat on the floor at the reference foot xy/yaw (the clips roll onto
       the toes, which the soft sphere contacts cannot balance on); pelvis height/tilt absorb it.
    3. Dynamics filter: inverse dynamics (no contacts) gives the ground wrench and its
       zero-moment point; where the ZMP leaves the feet, a horizontal pelvis correction from
       the linear inverted pendulum model (dc - h/g dc'' = dzmp) pulls it back inside.
    4. Inverse dynamics of the filtered plan with the ground wrench split between the feet
       (weighted by ZMP position) gives feedforward joint torques (gravity + dynamics).
    """

    def __init__(self, mjm, reference, duration, dt, sigma=2.0, com_height=0.70, passes=2, tail=1.0):
        self.m = copy.deepcopy(mjm)
        self.m.opt.disableflags = int(self.m.opt.disableflags) | int(mujoco.mjtDisableBit.mjDSBL_CONTACT)
        self.d = mujoco.MjData(self.m)
        self.ik = LegIK(self.m)
        self.dt = dt
        n = int(np.ceil((duration + tail) / dt)) + 2
        self.n = n
        q0 = gaussian_smooth(np.array([newton_to_mj(reference(k * dt)) for k in range(n)]), sigma)
        q0[:, 3:7] /= np.linalg.norm(q0[:, 3:7], axis=1, keepdims=True)
        self.q0 = q0
        self.feet = [self.ik.foot_targets(q) for q in q0]
        # ZMP bounds [m]: axis-aligned box over both feet (sole spheres of radius 5 mm at x -0.05 /
        # +0.12 and y +-0.03 in the ankle frame) shrunk by a ~2.5 cm (x) / 1.5 cm (y) safety margin.
        fx = np.array([[f[0][0], f[1][0]] for f in self.feet])
        fy = np.array([[f[0][1], f[1][1]] for f in self.feet])
        self.lo = np.stack([fx.min(1) - 0.03, fy.min(1) - 0.02], 1)
        self.hi = np.stack([fx.max(1) + 0.10, fy.max(1) + 0.02], 1)
        # LIPM filter matrix (with small regularization on offset and its rate)
        D2 = (np.eye(n, k=1) - 2 * np.eye(n) + np.eye(n, k=-1)) / dt**2
        D1 = (np.eye(n, k=1) - np.eye(n)) / dt
        lam = 1e-3
        self.lipm = np.vstack([np.eye(n) - com_height / 9.81 * D2, np.sqrt(lam) * np.eye(n), 0.02 * np.sqrt(lam) * D1])

        shift = np.zeros((n, 2))
        q = self._legs(shift)
        for _ in range(passes):
            zmp, _ = self._inverse(q)
            dz = np.clip(zmp, self.lo, self.hi) - zmp
            rhs = np.concatenate([dz, np.zeros((2 * n, 2))])
            shift += np.linalg.lstsq(self.lipm, rhs, rcond=None)[0] / 0.85  # CoM moves ~0.85x the pelvis
            q = self._legs(shift)
        self.zmp, self.tau = self._inverse(q)
        self.shift = shift
        self.q = np.array([mj_to_newton(qk) for qk in q])

    def _legs(self, shift):
        q = np.empty_like(self.q0)
        for k in range(self.n):
            qc = self.q0[k].copy()
            qc[:2] += shift[k]
            q[k] = self.ik.solve(qc, self.feet[k])
        return q

    def _inverse(self, q):
        m, d, dt, n = self.m, self.d, self.dt, self.n
        v = np.zeros((n, m.nv))
        for k in range(n - 1):
            mujoco.mj_differentiatePos(m, v[k], dt, q[k], q[k + 1])
        v[-1] = v[-2]
        v[1:] = 0.5 * (v[1:] + v[:-1])
        acc = np.gradient(v, dt, axis=0)
        zmp, tau = np.zeros((n, 2)), np.zeros((n, m.nv - 6))
        jp, jr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
        for k in range(n):
            d.qpos[:], d.qvel[:], d.qacc[:] = q[k], v[k], acc[k]
            mujoco.mj_inverse(m, d)
            f = d.qfrc_inverse.copy()
            force, torque, p = f[:3], d.xmat[1].reshape(3, 3) @ f[3:6], d.xpos[1]
            zmp[k] = [p[0] - (torque[1] + p[2] * force[0]) / force[2], p[1] + (torque[0] - p[2] * force[1]) / force[2]]
            # Split the ground wrench between the feet: weighted minimum norm, weight by ZMP position.
            pl, pr = d.xpos[self.ik.feet[0], :2], d.xpos[self.ik.feet[1], :2]
            u = pl - pr
            a = np.clip(np.dot(zmp[k] - pr, u) / np.dot(u, u), 0.02, 0.98)
            Js = []
            for b in self.ik.feet:
                mujoco.mj_jacBody(m, d, jp, jr, b)
                Js.append(np.vstack([jp, jr]))
            Jb = np.hstack([Js[0][:, :6].T, Js[1][:, :6].T])
            Winv = np.diag([a] * 6 + [1.0 - a] * 6)
            w = Winv @ Jb.T @ np.linalg.solve(Jb @ Winv @ Jb.T, f[:6])
            tau[k] = (f - Js[0].T @ w[:6] - Js[1].T @ w[6:])[6:]
        return zmp, tau


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, derived from a 42 Hz natural frequency (critically damped); high5
        # balances for roughly 30-60 Hz (softer sags forward, stiffer spins the feet).
        natural_frequency = 2.0 * np.pi * 42.0
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * ARMATURE * natural_frequency
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        # Dynamically feasible plan (poses and feedforward torques) at the control rate.
        self.plan = MotionPlanner(self.solver.mj_model, self.reference, self.motion.duration, self.frame_dt)
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        # Position targets for the servos: the planned pose one frame ahead, offset by
        # feedforward torque / stiffness so the servo also supplies the inverse-dynamics torque.
        k = min(int(round(self.sim_time / self.frame_dt)) + 1, self.plan.n - 1)
        target = self.plan.q[k].copy()
        target[7:] += self.plan.tau[k] / self.kp
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
