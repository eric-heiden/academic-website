# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Controller (all through the servo targets, nothing acts on the floating base):

1. Plan: a zero-phase Gaussian-smoothed copy of the clip (the whole clip is known up
   front), stronger on the root/legs/waist than on the light arms, to cut the
   acceleration peaks that make the feet spin or tip.
2. Retarget: per frame, a leg IK keeps both feet flat at their initial floor poses
   and puts the pelvis at the reference pose (height free, since the Kimodo feet
   float and tilt); if the whole-body CoM leaves the shrunken support polygon the
   pelvis target is shifted to bring it back.
3. Feedforward: floating-base inverse dynamics of the retargeted trajectory, with
   the base wrench carried by minimum-norm foot wrenches, folded into the servo
   targets as ``tau / kp`` so the actuator torque limits still apply.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import copy

import mujoco
import numpy as np
import warp as wp
from scipy.ndimage import gaussian_filter1d
from scipy.spatial import ConvexHull

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)

# ---------------- Controller parameters ----------------
SERVO_FREQUENCY = 55.0  # servo natural frequency on the reflected inertia [Hz]
SERVO_DAMPING_RATIO = 2.0
SMOOTH_BODY = 3.0  # Gaussian sigma for root, legs and waist [clip frames]
SMOOTH_ARMS = 0.75  # Gaussian sigma for the arms [clip frames]
PELVIS_TILT_REG = 1e-5  # IK cost of pelvis tilt relative to leg joint deviation
COM_MARGIN = 0.065  # CoM keep-out distance from the support polygon edge [m]
# Foot contact spheres (r = 5 mm) in the ankle-roll frame: x in [-0.05, 0.12], z = -0.03.
FOOT_HEIGHT = 0.035  # ankle-roll origin height with the foot flat on the floor [m]
FOOT_CORNERS = [(x, y) for x in (-0.055, 0.125) for y in (-0.03, 0.03)]


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)
        # Controller plan: the clip smoothed without phase lag (Gaussian in time).
        self.plan = MotionClip(args.motion)
        raw = self.plan.qpos
        self.plan.qpos = gaussian_filter1d(raw, SMOOTH_BODY, axis=0, mode="nearest")
        self.plan.qpos[:, 22:] = gaussian_filter1d(raw[:, 22:], SMOOTH_ARMS, axis=0, mode="nearest")
        self.plan.qpos[:, 3:7] /= np.linalg.norm(self.plan.qpos[:, 3:7], axis=1, keepdims=True)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, derived from a natural frequency on the reflected inertia.
        natural_frequency = 2.0 * np.pi * SERVO_FREQUENCY
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * SERVO_DAMPING_RATIO * ARMATURE * natural_frequency
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)

        # Kinematic model (CPU MuJoCo copy) used to retarget the legs every frame.
        self.ik_model = copy.copy(self.solver.mj_model)
        self.ik_data = mujoco.MjData(self.ik_model)
        mj_names = [self.ik_model.body(i).name for i in range(self.ik_model.nbody)]
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        self.feet = []
        for side, first_dof in (("left", 6), ("right", 12)):
            name = f"{side}_ankle_roll_link"
            mj_body = next(i for i, n in enumerate(mj_names) if n.endswith(name))
            self.feet.append((mj_body, labels.index(name), np.arange(first_dof, first_dof + 6)))
        # Contact-free copy for inverse dynamics (the feet supply the base wrench explicitly).
        self.id_model = copy.copy(self.solver.mj_model)
        self.id_model.opt.disableflags |= mujoco.mjtDisableBit.mjDSBL_CONTACT
        self.id_data = mujoco.MjData(self.id_model)
        # IK unknowns: pelvis height and orientation (free-joint dofs 2-5) and the 12 leg
        # joints, each regularized toward the reference (pelvis pose is cheap to change).
        self.ik_dofs = np.arange(2, 18)
        self.ik_reg = np.array([1e-6] + [PELVIS_TILT_REG] * 3 + [1e-4] * 12)
        self.ik_lower, self.ik_upper = self.ik_model.jnt_range[1:13].T
        # Feet stay flat at their initial floor position and heading.
        body_q = self.state_0.body_q.numpy()
        self.foot_targets = []
        for _, body, _ in self.feet:
            R = np.asarray(wp.quat_to_matrix(wp.quat(*body_q[body, 3:7]))).reshape(3, 3)
            p = body_q[body, :3].copy()
            p[2] = FOOT_HEIGHT
            self.foot_targets.append((p, self._yaw_rotation(R)))
        self.support_n, self.support_b = self.support_halfplanes(self.foot_targets, COM_MARGIN)
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    @staticmethod
    def _to_mj(q):
        return np.concatenate([q[:3], q[6:7], q[3:6], q[7:]])

    @staticmethod
    def _yaw_rotation(R):
        yaw = np.arctan2(R[1, 0], R[0, 0])
        c, s = np.cos(yaw), np.sin(yaw)
        return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])

    def leg_ik(self, q_ref, foot_targets, iterations=3):
        """Leg joint angles (plus small pelvis height/tilt changes) that put the feet at
        foot_targets while staying close to the reference pose."""
        m, d = self.ik_model, self.ik_data
        goal = self._to_mj(q_ref)
        d.qpos[:] = goal
        jacp, jacr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
        diff, step = np.zeros(m.nv), np.zeros(m.nv)
        for _ in range(iterations):
            mujoco.mj_kinematics(m, d)
            mujoco.mj_comPos(m, d)
            J, err = [], []
            for (body, _, _), (p_t, R_t) in zip(self.feet, foot_targets):
                quat = np.zeros(4)
                err_R = np.zeros(3)
                mujoco.mju_mat2Quat(quat, (R_t @ d.xmat[body].reshape(3, 3).T).flatten())
                mujoco.mju_quat2Vel(err_R, quat, 1.0)
                err.append(np.concatenate([p_t - d.xpos[body], err_R]))
                mujoco.mj_jacBody(m, d, jacp, jacr, body)
                J.append(np.vstack([jacp[:, self.ik_dofs], jacr[:, self.ik_dofs]]))
            J, err = np.vstack(J), np.concatenate(err)
            mujoco.mj_differentiatePos(m, diff, 1.0, goal, d.qpos)
            reg = self.ik_reg * diff[self.ik_dofs]
            step[:] = 0.0
            step[self.ik_dofs] = np.linalg.solve(J.T @ J + np.diag(self.ik_reg), J.T @ err - reg)
            mujoco.mj_integratePos(m, d.qpos, step, 1.0)
            d.qpos[7:19] = np.clip(d.qpos[7:19], self.ik_lower, self.ik_upper)
        mujoco.mj_kinematics(m, d)
        mujoco.mj_comPos(m, d)
        q = q_ref.copy()
        q[2] = d.qpos[2]
        q[3:7] = quat_wxyz_to_xyzw(d.qpos[3:7])
        q[7:19] = d.qpos[7:19]
        return q

    def feedforward(self, q_seq, h):
        """Joint torques realizing the middle configuration of q_seq (spacing h [s]) with
        the base wrench supplied by the two feet (minimum-norm foot wrenches)."""
        m, d = self.id_model, self.id_data
        q0, q1, q2 = (self._to_mj(q) for q in q_seq)
        v0, v1 = np.zeros(m.nv), np.zeros(m.nv)
        mujoco.mj_differentiatePos(m, v0, h, q0, q1)
        mujoco.mj_differentiatePos(m, v1, h, q1, q2)
        d.qpos[:] = q1
        d.qvel[:] = 0.5 * (v0 + v1)
        d.qacc[:] = (v1 - v0) / h
        mujoco.mj_inverse(m, d)
        jacp, jacr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
        Jc = []
        for body, _, _ in self.feet:
            mujoco.mj_jacBody(m, d, jacp, jacr, body)
            Jc.append(np.vstack([jacp, jacr]))
        Jc = np.vstack(Jc)
        A = Jc[:, :6].T
        w = A.T @ np.linalg.solve(A @ A.T, d.qfrc_inverse[:6])
        return d.qfrc_inverse[6:] - Jc[:, 6:].T @ w

    def support_halfplanes(self, foot_targets, margin):
        """Half-planes (n, b) with n.p <= b describing the foot support polygon shrunk by margin."""
        pts = np.array([(p + R @ np.array([x, y, 0.0]))[:2] for p, R in foot_targets for x, y in FOOT_CORNERS])
        hull = ConvexHull(pts)
        return hull.equations[:, :2], -hull.equations[:, 2] - margin

    def retarget(self, t):
        """Servo pose at time t: smoothed reference, legs solved for flat feet, CoM kept inside the support."""
        q = self.leg_ik(self.plan_reference(t), self.foot_targets)
        for _ in range(2):
            # Project the CoM (subtree of the pelvis) onto the shrunken support polygon.
            com = self.ik_data.subtree_com[1][:2].copy()
            p = com.copy()
            for _ in range(4):
                violation = self.support_n @ p - self.support_b
                k = np.argmax(violation)
                if violation[k] <= 0.0:
                    break
                p -= violation[k] * self.support_n[k]
            if np.linalg.norm(p - com) < 1e-4:
                break
            q[:2] += p - com
            q = self.leg_ik(q, self.foot_targets)
        return q

    def plan_reference(self, t):
        """Smoothed reference joint_q used for the servo targets."""
        return self._shifted(self.plan.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        # Position targets one frame ahead: retargeted plan pose plus the inverse-dynamics
        # feedforward torque expressed as a target offset (servo torque = kp * offset).
        t, h = self.sim_time + self.frame_dt, self.frame_dt
        target, before, after = self.retarget(t), self.retarget(t - h), self.retarget(t + h)
        target[7:] += self.feedforward([before, target, after], h) / self.kp
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
