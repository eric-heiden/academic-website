# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks a MuJoCo-qpos CSV clip
(root xyz, root quaternion wxyz, 29 joints at 30 fps). Actuators are MuJoCo
position servos with torque limits from the robot's MJCF; the controller sets
their gains and targets every frame:

- the commanded motion is the reference, smoothed with a zero-lag Gaussian;
- the pelvis is shifted horizontally when needed to keep the center of mass a
  margin inside the support polygon of the feet;
- the legs come from inverse kinematics that puts the pelvis at the commanded
  root pose with both feet flat where they stand (the kinematic clips let the
  "planted" feet pivot and tilt, which plain joint tracking turns into a fall);
- stiff servos get an inverse-dynamics feedforward (gravity and motion, contact
  wrenches solved from the floating-base equations) as a target offset, so the
  actuator torque limits still apply, plus a small integral term.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, derived from a stiff natural frequency of the reflected inertia.
        natural_frequency = 2.0 * np.pi * 40.0
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * ARMATURE * natural_frequency
        # Integral gain [1/s] on the joint errors that removes residual steady-state sag (the
        # inverse-dynamics feedforward below carries gravity; larger gains excite rocking).
        self.ki = 0.5
        self.integral_limit = 0.1
        # Nominal ankle-roll-link height [m] of a flat foot resting on the floor.
        self.foot_height = 0.037
        # Inverse-dynamics feedforward: scale of reference accelerations, finite-difference
        # window [s], and relative cost of foot contact torques versus forces.
        self.accel_scale = 1.0
        self.diff_window = 0.05
        self.torque_weight = 10.0
        # Zero-lag Gaussian smoothing [s] of the commanded motion; limits the accelerations
        # (notably the fast root yaw of high5) that the feet cannot transmit without slipping.
        self.smooth_sigma = 0.1
        # Smoothing [s] of the arm joints, which barely affect balance.
        self.arm_sigma = 0.02
        # Balance: keep the commanded center of mass this far [m] inside the support polygon of
        # the feet by shifting the commanded pelvis horizontally.
        self.support_margin = 0.05
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        # Kinematic copy of the robot for leg inverse kinematics (MuJoCo qpos layout).
        self.ik_model = self.solver.mj_model
        self.ik_data = mujoco.MjData(self.ik_model)
        self.id_data = mujoco.MjData(self.ik_model)
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        self.foot_bodies = [labels.index("left_ankle_roll_link"), labels.index("right_ankle_roll_link")]
        self.integral = np.zeros(29)
        self.last_target = None
        self.foot_poses = None
        self.support = None
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def _foot_targets(self, body_q):
        """Flat foot poses (position, rotation) on the floor at the feet's horizontal position and heading."""
        targets = []
        for body in self.foot_bodies:
            pose = body_q[body]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            yaw = np.arctan2(rotation[1, 0], rotation[0, 0])
            c, s = np.cos(yaw), np.sin(yaw)
            flat = np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])
            targets.append((np.array([pose[0], pose[1], self.foot_height]), flat))
        return targets

    def _leg_ik(self, ref, foot_targets, iterations=4, damping=1e-3):
        """Leg joint angles that place the pelvis at the reference root pose with the feet at foot_targets.

        Returns the leg angles and the pelvis height used: the reference pelvis is lowered by the
        mean height of the reference feet above a flat stance (e.g. when the clip rises onto its toes).
        """
        m, d = self.ik_model, self.ik_data
        d.qpos[:3] = ref[:3]
        d.qpos[3:7] = ref[[6, 3, 4, 5]]
        d.qpos[7:] = ref[7:]
        mujoco.mj_kinematics(m, d)
        d.qpos[2] -= np.mean([d.xpos[body + 1][2] for body in self.foot_bodies]) - self.foot_height
        jacp, jacr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
        for _ in range(iterations):
            mujoco.mj_kinematics(m, d)
            mujoco.mj_comPos(m, d)
            for leg, (body, (p_des, r_des)) in enumerate(zip(self.foot_bodies, foot_targets)):
                mj_body = body + 1
                p = d.xpos[mj_body]
                r = d.xmat[mj_body].reshape(3, 3)
                err = np.concatenate([p_des - p, 0.5 * np.cross(r, r_des, axis=0).sum(axis=1)])
                mujoco.mj_jacBody(m, d, jacp, jacr, mj_body)
                dofs = slice(6 + 6 * leg, 12 + 6 * leg)
                jac = np.vstack([jacp[:, dofs], jacr[:, dofs]])
                dq = np.linalg.solve(jac.T @ jac + damping * np.eye(6), jac.T @ err)
                d.qpos[7 + 6 * leg : 13 + 6 * leg] += dq
        return d.qpos[7:19].copy(), d.qpos[2]

    def _gaussian_reference(self, t, sigma):
        """Gaussian-weighted average of the reference joint_q around time t [s]."""
        if sigma <= 0.0:
            return self.reference(t)
        u = np.linspace(-2.0, 2.0, 9)
        weights = np.exp(-0.5 * u**2)
        weights /= weights.sum()
        samples = np.array([self.reference(t + sigma * ui) for ui in u])
        quats = samples[:, 3:7]
        quats *= np.sign(quats @ quats[len(u) // 2])[:, None]
        q = weights @ samples
        q[3:7] /= np.linalg.norm(q[3:7])
        return q

    def smoothed_reference(self, t):
        """Reference with the root, legs and waist smoothed by smooth_sigma and the arms by arm_sigma."""
        q = self._gaussian_reference(t, self.smooth_sigma)
        q[22:] = self._gaussian_reference(t, self.arm_sigma)[22:]
        return q

    @staticmethod
    def _support_polygon(foot_poses):
        """Inward unit normals n and offsets b (inside: n . p >= b) of the feet's convex hull."""
        points = []
        for position, rotation in foot_poses:
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    points.append((position + rotation @ np.array([x, y, 0.0]))[:2])
        points = sorted(map(tuple, points))

        def half(chain):
            hull = []
            for pt in chain:
                while len(hull) >= 2:
                    (ax, ay), (bx, by) = np.subtract(hull[-1], hull[-2]), np.subtract(pt, hull[-2])
                    if ax * by - ay * bx > 0:
                        break
                    hull.pop()
                hull.append(pt)
            return hull[:-1]

        hull = np.array(half(points) + half(points[::-1]))  # counter-clockwise
        edges = np.roll(hull, -1, axis=0) - hull
        normals = np.stack([-edges[:, 1], edges[:, 0]], axis=1)
        normals /= np.linalg.norm(normals, axis=1, keepdims=True)
        return normals, np.einsum("ij,ij->i", normals, hull)

    def _balanced(self, com):
        """Horizontal point nearest to com that lies support_margin inside the support polygon."""
        normals, offsets = self.support
        p = com.copy()
        for _ in range(3):
            for n, b in zip(normals, offsets):
                p += max(0.0, b + self.support_margin - n @ p) * n
        return p

    def _mj_qpos(self, t):
        """Commanded qpos (MuJoCo layout) at time t: smoothed reference, pelvis shifted to keep the
        center of mass inside the support polygon, legs from inverse kinematics."""
        ref = self.smoothed_reference(t)
        m, d = self.ik_model, self.ik_data
        for _ in range(2):
            legs, height = self._leg_ik(ref, self.foot_poses)
            qpos = np.concatenate([[ref[0], ref[1], height], ref[[6, 3, 4, 5]], legs, ref[19:]])
            d.qpos[:] = qpos
            mujoco.mj_kinematics(m, d)
            mujoco.mj_comPos(m, d)
            com = d.subtree_com[1][:2]
            shift = self._balanced(com) - com
            if not shift.any():
                break
            ref[:2] += shift
        return qpos

    def _feedforward(self, t):
        """Joint torques [N m] of the reference motion with both feet carrying the floating base."""
        m, d = self.ik_model, self.id_data
        h = self.diff_window
        q_prev, q_now, q_next = self._mj_qpos(t - h), self._mj_qpos(t), self._mj_qpos(t + h)
        v_prev, v_next = np.zeros(m.nv), np.zeros(m.nv)
        mujoco.mj_differentiatePos(m, v_prev, h, q_prev, q_now)
        mujoco.mj_differentiatePos(m, v_next, h, q_now, q_next)
        d.qpos[:] = q_now
        d.qvel[:] = 0.5 * (v_prev + v_next)
        d.qacc[:] = self.accel_scale * (v_next - v_prev) / h
        mujoco.mj_kinematics(m, d)
        mujoco.mj_comPos(m, d)
        mujoco.mj_comVel(m, d)
        bias = np.zeros(m.nv)
        mujoco.mj_rne(m, d, 1, bias)
        # Contact wrenches (force, torque at the ankle-roll origin) of both feet: weighted least norm
        # subject to the floating-base rows of the equations of motion.
        jacs = []
        for body in self.foot_bodies:
            jacp, jacr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
            mujoco.mj_jacBody(m, d, jacp, jacr, body + 1)
            jacs.append(np.vstack([jacp, jacr]))
        jac = np.vstack(jacs)  # 12 x nv
        weight = np.tile(np.r_[np.ones(3), self.torque_weight * np.ones(3)], 2)
        a = jac[:, :6].T / weight  # base rows, variables scaled by 1/weight
        wrench = (a.T @ np.linalg.solve(a @ a.T, bias[:6])) / weight
        return bias[6:] - jac[:, 6:].T @ wrench

    def step(self):
        # ---------------- Controller (tunable) ----------------
        # Servo targets one frame ahead: the balanced, smoothed command with inverse-kinematics
        # legs, offset by the inverse-dynamics feedforward torque and the integral term.
        if self.sim_time == 0.0:
            self.integral[:] = 0.0
            self.last_target = None
            self.foot_poses = None
        q = self.state_0.joint_q.numpy()
        body_q = self.state_0.body_q.numpy()
        if self.foot_poses is None:
            # Anchor the feet where they stand; the clips keep both feet planted.
            self.foot_poses = self._foot_targets(body_q)
            self.support = self._support_polygon(self.foot_poses)
        qpos = self._mj_qpos(self.sim_time + self.frame_dt)
        target = np.concatenate([qpos[:3], qpos[[4, 5, 6, 3]], qpos[7:]])
        feedforward = self._feedforward(self.sim_time + self.frame_dt) / self.kp
        if self.last_target is not None:
            self.integral += self.ki * (self.last_target[7:] - q[7:]) * self.frame_dt
            np.clip(self.integral, -self.integral_limit, self.integral_limit, out=self.integral)
        self.last_target = target.copy()
        target[7:] += self.integral + feedforward
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
