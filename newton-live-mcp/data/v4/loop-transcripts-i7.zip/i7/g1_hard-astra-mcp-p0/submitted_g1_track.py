# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference with whole-body inverse dynamics.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A 250 Hz quadratic program tracks the floating root and joints,
balances contact forces between the feet, and converts joint torques to servo
targets. Physics still runs at 500 Hz, with 50 Hz example frames.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import scipy.sparse as sp
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class WholeBodyController:
    """Inverse dynamics for standing gestures, using both feet for support.

    The optimization variables are generalized accelerations and the three
    force components at each foot collision sphere. The six unactuated rows
    of M*a + bias - J.T*f are constrained to zero; the remaining rows are
    bounded by the existing actuator torque limits. Contact forces are only
    optimization variables: all commands go through the 29 position servos.
    """

    def __init__(self, example):
        self.m = example.solver.mj_model
        self.d = mujoco.MjData(self.m)
        self.nv = self.m.nv
        self.mass = np.empty((self.nv, self.nv))
        self.feet = [
            i
            for i in range(self.m.nbody)
            if self.m.body(i).name.endswith(("left_ankle_roll_link", "right_ankle_roll_link"))
        ]
        self.geoms = [i for i in range(self.m.ngeom) if self.m.geom_bodyid[i] in self.feet]
        self.limits = example.model.joint_effort_limit.numpy()[6:].astype(float)
        # Acceleration feedback gains, separate from the inner servo gains.
        self.kp = np.r_[np.full(6, 160.0), np.full(29, 1600.0)]
        self.kd = 2 * np.sqrt(self.kp)
        self.weights = np.r_[np.full(3, 100.0), np.full(3, 30.0), np.ones(29)]
        self.last = None
        self.last_time = -np.inf
        self.solve_failures = 0

    @staticmethod
    def mjq(q):
        """Newton xyzw root quaternion to MuJoCo wxyz coordinates."""
        return np.r_[q[:3], q[6], q[3:6], q[7:]]

    def compute(self, example, t):
        mj, m, d = mujoco, self.m, self.d
        if t <= self.last_time:
            # A live reset must not retain the previous rollout's warm start.
            self.last = None
            self.solve_failures = 0
        self.last_time = t
        q = example.state_0.joint_q.numpy().astype(float)
        v = example.state_0.joint_qd.numpy().astype(float)
        d.qpos[:] = self.mjq(q)
        rot = np.empty(9)
        mj.mju_quat2Mat(rot, d.qpos[3:7])
        rot = rot.reshape(3, 3)
        # Newton reports root COM/world velocities; MuJoCo uses the body's
        # origin for translation and the body frame for angular velocity.
        d.qvel[:] = v
        d.qvel[:3] -= np.cross(v[3:6], rot @ m.body_ipos[1])
        d.qvel[3:6] = rot.T @ v[3:6]
        mj.mj_forward(m, d)
        mj.mj_fullM(m, d, self.mass)
        h = d.qfrc_bias - d.qfrc_passive

        # Differentiate the public reference sampler, so timing changes are
        # reflected in velocity/acceleration feedforward without clip logic.
        qr = self.mjq(example.reference(t))
        eps = 0.02
        qm = self.mjq(example.reference(t - eps))
        qp = self.mjq(example.reference(t + eps))
        vr = np.empty(self.nv)
        vm = np.empty(self.nv)
        vp = np.empty(self.nv)
        err = np.empty(self.nv)
        mj.mj_differentiatePos(m, vr, 2 * eps, qm, qp)
        mj.mj_differentiatePos(m, vm, eps, qm, qr)
        mj.mj_differentiatePos(m, vp, eps, qr, qp)
        mj.mj_differentiatePos(m, err, 1.0, d.qpos, qr)
        ar = (vp - vm) / eps
        desired = ar + self.kp * err + self.kd * (vr - d.qvel)

        # Soft foot acceleration tasks damp slip and bring the soles to the
        # floor. Soft tasks accommodate small inconsistencies in mocap feet.
        nc = len(self.geoms)
        J = np.zeros((3 * nc, self.nv))
        jd = np.zeros_like(J)
        ca = np.zeros(3 * nc)
        for k, g in enumerate(self.geoms):
            p = d.geom_xpos[g].copy()
            p[2] -= m.geom_size[g, 0]
            sl = slice(3 * k, 3 * k + 3)
            mj.mj_jac(m, d, J[sl], None, p, int(m.geom_bodyid[g]))
            mj.mj_jacDot(m, d, jd[sl], None, p, int(m.geom_bodyid[g]))
            ca[sl] = -40 * (J[sl] @ d.qvel) - jd[sl] @ d.qvel
            ca[3 * k + 2] -= 400 * p[2]

        nv = self.nv
        nx = nv + 3 * nc
        H = np.zeros((nx, nx))
        b = np.zeros(nx)
        H[:nv, :nv] = np.diag(self.weights) + 100 * J.T @ J
        b[:nv] = -self.weights * desired - 100 * J.T @ ca
        H[nv:, nv:] = np.eye(3 * nc) * 0.0001
        D = np.c_[self.mass, -J.T]
        # Light regularization selects a smooth force/torque distribution.
        H += 0.00001 * D[6:].T @ D[6:]
        b += 0.00001 * D[6:].T @ h[6:]
        A = [D[:6], D[6:]]
        lo = [-h[:6], -self.limits - h[6:]]
        hi = [-h[:6], self.limits - h[6:]]
        # Unilateral normal forces and a conservative inscribed friction
        # pyramid (the physical model's friction remains unchanged).
        cone = np.zeros((5 * nc, nx))
        for k in range(nc):
            f = nv + 3 * k
            cone[5 * k, f + 2] = 1
            cone[5 * k + 1, f : f + 3] = [1, 0, -0.7]
            cone[5 * k + 2, f : f + 3] = [-1, 0, -0.7]
            cone[5 * k + 3, f : f + 3] = [0, 1, -0.7]
            cone[5 * k + 4, f : f + 3] = [0, -1, -0.7]
        A.append(cone)
        lo.append(np.tile([0, -np.inf, -np.inf, -np.inf, -np.inf], nc))
        hi.append(np.tile([400, 0, 0, 0, 0], nc))
        opt = osqp.OSQP()
        opt.setup(
            P=sp.csc_matrix(np.triu(H)),
            q=b,
            A=sp.csc_matrix(np.vstack(A)),
            l=np.concatenate(lo),
            u=np.concatenate(hi),
            verbose=False,
            eps_abs=1e-4,
            eps_rel=1e-4,
            max_iter=1500,
            polishing=False,
        )
        if self.last is not None:
            opt.warm_start(x=self.last)
        result = opt.solve(raise_error=False)
        if result.x is not None and result.info.status_val in (1, 2):
            self.last = result.x
            tau = (D @ result.x + h)[6:]
        else:
            self.solve_failures += 1
            tau = example.kp * (qr[7:] - q[7:]) + example.kd * (vr[6:] - v[6:])
        tau = np.clip(tau, -self.limits, self.limits)
        target = q.copy()
        # Invert tau = kp*(target-q) - kd*v. Midpoint prediction compensates
        # for holding the position target over two physical substeps.
        target[7:] += (tau + example.kd * v[6:]) / example.kp + example.sim_dt * v[6:]
        return target


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # Inner position servos, in N m/rad and N m s/rad. Their targets
        # include the whole-body controller's feedforward/feedback torques.
        self.kp = np.array(
            [200.0, 250.0, 150.0, 250.0, 100.0, 100.0] * 2
            + [150.0, 100.0, 100.0]
            + ([60.0] * 5 + [20.0] * 2) * 2
        )
        self.kd = np.array(
            [6.0, 8.0, 5.0, 8.0, 4.0, 4.0] * 2
            + [5.0, 4.0, 4.0]
            + ([3.0] * 5 + [1.0] * 2) * 2
        )

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self.wbc = WholeBodyController(self)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        # Two steps return to the same state buffer, making this graph
        # reusable between successive CPU controller updates.
        for _ in range(2):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # Five controller updates, ten unchanged 2 ms physics substeps.
        for update in range(self.sim_substeps // 2):
            target = self.wbc.compute(self, self.sim_time + update * 2 * self.sim_dt)
            self.control.joint_target_q.assign(target)
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
