# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo motion with whole-body inverse dynamics.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A 250 Hz controller tracks root pose and joint angles, allocating
ground reaction forces subject to unactuated-base dynamics, friction, and joint
torque limits. Physics still runs at 500 Hz, with 50 Hz display frames.

Requires the installed ``mujoco``, ``scipy``, and ``osqp`` packages.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import warp as wp
from scipy import sparse

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class WholeBodyController:
    """Solve for generalized acceleration and eight sole contact forces.

    The objective combines reference acceleration plus pose/velocity feedback,
    soft stance-foot stabilization, and a small contact-force regularizer.
    The first six dynamics rows require exactly zero floating-base actuation;
    the remaining rows constrain the resulting joint torques to the MJCF limits.
    Contact forces are predictions used to compute actuator commands, never
    external forces applied to the simulator.
    """

    def __init__(self, example):
        self.example = example
        self.m = example.solver.mj_model
        # A separate data object evaluates dynamics without touching simulation
        # state, contacts, warm starts, or applied forces.
        self.d = mujoco.MjData(self.m)
        m = self.m
        self.feet = [i for i in range(m.nbody) if m.body(i).name.endswith("ankle_roll_link")]
        self.geoms = [
            i for i in range(m.ngeom)
            if m.geom_bodyid[i] in self.feet and m.geom_type[i] == mujoco.mjtGeom.mjGEOM_SPHERE
        ]
        self.nv = m.nv
        self.nf = 3 * len(self.geoms)
        self.mass = np.empty((m.nv, m.nv))
        self.jac = np.zeros((self.nf, m.nv))
        self.jdot = np.zeros((self.nf, m.nv))
        self.weights = np.r_[np.full(3, 30.0), np.full(3, 15.0), np.ones(29)]
        self.weights[6:18] = 4.0
        # Acceleration-level feedback gains (distinct from the inner servos).
        self.kp = np.r_[np.full(3, 180.0), np.full(3, 250.0), np.full(29, 500.0)]
        self.kd = 2 * np.sqrt(self.kp)
        self.qp = None
        self.torque = np.zeros(29)
        self.status_counts = {}

    def reference(self, t):
        """Use the public sampler, including its timing, in MuJoCo layout."""
        q = self.example.reference(t)
        return q[np.r_[0:3, 6, 3:6, 7:36]]

    def update(self, t):
        e, m, d = self.example, self.m, self.d
        d.qpos[:] = e.solver.mjw_data.qpos.numpy()[0]
        d.qvel[:] = e.solver.mjw_data.qvel.numpy()[0]
        mujoco.mj_forward(m, d)
        mujoco.mj_fullM(m, d, self.mass)
        # Centered differences provide feedforward without modifying the CSV
        # interpolation. differentiatePos handles quaternion pose errors.
        h = 0.01
        qm, qr, qp = (self.reference(t + offset) for offset in (-h, 0.0, h))
        vm, vp, error = (np.empty(m.nv) for _ in range(3))
        mujoco.mj_differentiatePos(m, vm, h, qm, qr)
        mujoco.mj_differentiatePos(m, vp, h, qr, qp)
        mujoco.mj_differentiatePos(m, error, 1.0, d.qpos, qr)
        velocity = (vm + vp) / 2
        accel = (vp - vm) / h + self.kp * error + self.kd * (velocity - d.qvel)
        J, Jdot = self.jac, self.jdot
        points = []
        for i, geom in enumerate(self.geoms):
            point = d.geom_xpos[geom].copy()
            point[2] -= m.geom_size[geom, 0]
            points.append(point)
            rows = slice(3 * i, 3 * i + 3)
            mujoco.mj_jac(m, d, J[rows], None, point, m.geom_bodyid[geom])
            mujoco.mj_jacDot(m, d, Jdot[rows], None, point, m.geom_bodyid[geom])
        points = np.array(points)
        # Soft contact tasks tolerate retargeting inconsistencies in the clip:
        # damp sole motion and bring the sphere contact points to floor height.
        foot_accel = -20.0 * (J @ d.qvel) - Jdot @ d.qvel
        foot_accel[2::3] -= 400.0 * points[:, 2]
        n = self.nv + self.nf
        P = np.zeros((n, n))
        P[:self.nv, :self.nv] = np.diag(self.weights) + 100.0 * J.T @ J
        P[self.nv:, self.nv:] = np.eye(self.nf) * 1.0e-4
        cost = np.r_[-self.weights * accel - 100.0 * J.T @ foot_accel, np.zeros(self.nf)]
        # M a + bias - J^T f = [0, joint_torque].
        dynamics = np.c_[self.mass, -J.T]
        bias = d.qfrc_bias - d.qfrc_passive
        # Friction pyramids and nonnegative normal forces at the sole corners.
        friction = np.zeros((5 * len(points), n))
        for i in range(len(points)):
            col = self.nv + 3 * i
            friction[5*i:5*i+5, col:col+3] = [
                [1, 0, -0.6], [-1, 0, -0.6], [0, 1, -0.6], [0, -1, -0.6], [0, 0, 1]
            ]
        A = np.r_[dynamics, friction]
        lo = np.r_[
            -bias[:6], m.actuator_forcerange[:, 0] - bias[6:], np.tile([-np.inf] * 4 + [0.0], len(points))
        ]
        hi = np.r_[
            -bias[:6], m.actuator_forcerange[:, 1] - bias[6:], np.tile([0.0] * 4 + [500.0], len(points))
        ]
        # Keep a fixed sparsity pattern so OSQP can reuse its allocations.
        if self.qp is None:
            self.prow, self.pcol = np.triu_indices(n)
            self.arow, self.acol = np.indices(A.shape).reshape(2, -1)
            ps = sparse.csc_matrix((P[self.prow, self.pcol], (self.prow, self.pcol)), shape=P.shape)
            aa = sparse.csc_matrix((A[self.arow, self.acol], (self.arow, self.acol)), shape=A.shape)
            self.porder = np.lexsort((self.prow, self.pcol))
            self.aorder = np.lexsort((self.arow, self.acol))
            self.qp = osqp.OSQP()
            self.qp.setup(
                P=ps, q=cost, A=aa, l=lo, u=hi, verbose=False,
                eps_abs=1.0e-4, eps_rel=1.0e-4, max_iter=1000, polishing=False,
            )
        else:
            self.qp.update(
                Px=P[self.prow, self.pcol][self.porder], q=cost,
                Ax=A[self.arow, self.acol][self.aorder], l=lo, u=hi,
            )
        result = self.qp.solve(raise_error=False)
        self.status_counts[result.info.status] = self.status_counts.get(result.info.status, 0) + 1
        if result.info.status_val in (1, 2):
            self.torque = np.clip(
                (dynamics @ result.x + bias)[6:], m.actuator_forcerange[:, 0], m.actuator_forcerange[:, 1]
            )
        # Retain the last bounded command if a solve fails. Encode torque through
        # the original force-limited POSITION actuators: tau = kp*(target-q)-kd*v.
        # The free joint has no actuator; only the 29 joint targets exert torque.
        target = e.reference(t)
        target[7:] = d.qpos[7:] + (self.torque + e.kd * d.qvel[6:]) / e.kp
        e.control.joint_target_q.assign(target)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # The outer controller supplies position/velocity feedback and inverse
        # dynamics. Low inner stiffness avoids holding-target lag between its
        # 4 ms updates; the native actuators continue to enforce torque limits.
        self.kp = np.ones(29)
        self.kd = np.zeros(29)

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self.controller = WholeBodyController(self)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self._physics_pair()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def _physics_pair(self):
        """Two unchanged 2 ms physics steps, returning to the same state buffer."""
        for _ in range(2):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def simulate(self):
        # Host-side feedback must stay outside the captured physics graph.
        for i in range(self.sim_substeps // 2):
            self.controller.update(self.sim_time + 2 * i * self.sim_dt)
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self._physics_pair()

    def step(self):
        self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
