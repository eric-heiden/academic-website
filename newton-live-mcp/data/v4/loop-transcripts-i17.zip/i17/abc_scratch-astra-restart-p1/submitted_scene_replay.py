# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, adds the three passive fruit bodies and the wooden tray, and ``Example``
drives every world with the logged commands as joint position targets, open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.04,  # latency from a logged command to the joint targets [s]
    "dt": 0.001,  # physics step [s]
}


# Fitted values are embedded here; photos and calibration logs are not needed at runtime.
# Fruit entries: label, initial centre [m], inertia semi-axes [m], yaw [rad], mass [kg], RGB.
FRUITS = (
    ("pear", (0.650, 0.335, 0.775), (0.040, 0.026, 0.025), -1.03, 0.060, (0.88, 0.68, 0.04)),
    ("orange", (0.503, -0.055, 0.779), (0.0285, 0.0285, 0.029), 0.0, 0.075, (0.92, 0.24, 0.025)),
    ("dark_fruit", (0.651, -0.188, 0.782), (0.033, 0.033, 0.032), 0.0, 0.080, (0.15, 0.055, 0.025)),
)
TRAY_CENTRE = (0.735, 0.102)
PEAR_ROLL = 0.001

# Joint gains, reflected motor inertia, dry friction, and per-link gravity compensation.
# A shared arm fit uses the 64 logs, with the episode used to refine tracking.
ARM_KP = (78.568344, 77.003353, 79.522549, 10.512457, 9.7147, 5.410525)
ARM_KD = (3.516776, 4.203478, 3.981548, 1.207747, 1.246257, 0.605856)
ARM_GC = (0.995, 0.951991, 0.666637, 0.875902, 0.864828, 0.727313)
ARM_FRICTION = (0.199689, 0.404258, 0.338354, 0.216403, 0.094789, 0.07497)
ARM_ARMATURE = (0.040684, 0.01835, 0.026179, 0.000779, 0.000687, 0.000861)


def add_objects(builder):
    fruit_cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=1.0, mu_torsional=0.001,
                                               mu_rolling=0.00015, gap=0.002)
    contact = {"mujoco:solref": wp.vec2(0.008, 1.0), "mujoco:solref_mode": 1,
               "mujoco:condim": 6}
    for name, pos, radii, yaw, mass, color in FRUITS:
        fruit_cfg.mu_rolling = {"pear": PEAR_ROLL, "orange": 0.00015, "dark_fruit": 0.002}[name]
        rx, ry, rz = radii
        inertia = np.diag([mass*(ry*ry+rz*rz)/5, mass*(rx*rx+rz*rz)/5,
                           mass*(rx*rx+ry*ry)/5])
        body = builder.add_body(xform=wp.transform(pos, wp.quat_from_axis_angle(wp.vec3(0,0,1),yaw)),
                                mass=mass, inertia=wp.mat33(inertia),
                                com=wp.vec3(0,0,0),
                                lock_inertia=True, label=name)
        if name == "pear":
            builder.add_shape_ellipsoid(body,rx=0.028,ry=0.026,rz=0.025,cfg=fruit_cfg,
                                       color=color,label="pear_bulb",custom_attributes=contact)
            builder.add_shape_ellipsoid(body,xform=wp.transform((0.027,0,0.002),wp.quat_identity()),
                                       rx=0.024,ry=0.014,rz=0.016,cfg=fruit_cfg,
                                       color=color,label="pear_neck",custom_attributes=contact)
        else:
            builder.add_shape_ellipsoid(body, rx=rx, ry=ry, rz=rz, cfg=fruit_cfg,
                                       color=color, label=name+"_skin", custom_attributes=contact)


    # A shallow wooden sector, with nineteen floor sections and nineteen rim segments.
    cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=0.8, mu_torsional=0.008,
                                         mu_rolling=0.00015, gap=0.002)
    pivot = np.array([0.930, 0.145])
    radius = 0.244
    angles = np.linspace(math.radians(171), math.radians(228), 18)
    outline = np.vstack([pivot, pivot + radius*np.column_stack([np.cos(angles),np.sin(angles)])])
    n = len(outline)
    centre_xy = np.array(TRAY_CENTRE)
    floor_z = 0.755 + 0.6*np.sum((outline-centre_xy)**2,axis=1)
    # Triangular sections retain the shallow concavity of the wooden interior.
    for i in range(n):
        j=(i+1)%n
        xy=np.vstack([centre_xy,outline[i],outline[j]])
        vertices=np.vstack([np.column_stack([xy,np.full(3,0.750)]),
                            np.column_stack([xy,[0.755,floor_z[i],floor_z[j]]])])
        faces=np.array([0,2,1,3,4,5,0,1,4,0,4,3,1,2,5,1,5,4,2,0,3,2,3,5],dtype=np.int32)
        mesh=newton.Mesh(vertices.astype(np.float32),faces)
        builder.add_shape_mesh(-1,mesh=mesh,cfg=cfg,label=f"tray_floor_{i}",
                               color=(0.65,0.40,0.17),custom_attributes=contact)

    for i in range(n):
        a,b=outline[i],outline[(i+1)%n]
        centre=(a+b)/2
        theta=math.atan2(b[1]-a[1],b[0]-a[0])
        builder.add_shape_box(-1,xform=wp.transform((centre[0],centre[1],float(0.754+0.6*np.sum((centre-centre_xy)**2))),
                              wp.quat_from_axis_angle(wp.vec3(0,0,1),theta)),
                              hx=float(np.linalg.norm(b-a)/2+0.001),hy=0.003,hz=0.008,
                              cfg=cfg,label=f"tray_rim_{i}",color=(0.72,0.47,0.22),custom_attributes=contact)


def build_model(num_worlds: int = 1) -> newton.Model:
    """Calibrated station and passive objects in identical independent worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    for j, label in enumerate(station.joint_label):
        name = label.rsplit("/", 1)[-1]
        d = station.joint_qd_start[j]
        if any(name == f"{side}_joint{k+1}" for side in SIDES for k in range(6)):
            k = int(name[-1]) - 1
            station.joint_target_ke[d] = ARM_KP[k]
            station.joint_target_kd[d] = ARM_KD[k]
            station.joint_effort_limit[d] = 28.0 if k < 3 else 10.0
            station.joint_friction[d] = ARM_FRICTION[k]
            station.joint_armature[d] = ARM_ARMATURE[k]
        elif name in ("left_left_finger","right_left_finger"):
            station.joint_target_ke[d] = 1200.0
            station.joint_target_kd[d] = 14.0
            station.joint_effort_limit[d] = 20.0
    for i, b in enumerate(station.shape_body):
        if b >= 0 and station.body_label[b].rsplit("/",1)[-1].startswith(SIDES):
            station.shape_material_mu_torsional[i] = 0.001
            station.shape_material_mu_rolling[i] = 0.00015
    add_objects(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    # Keep the imported actuator metadata and the Newton effort limits consistent.
    force_range = model.mujoco.actuator_forcerange.numpy()
    limited = model.mujoco.actuator_forcelimited.numpy()
    has_range = model.mujoco.actuator_has_forcerange.numpy()
    for i in range(len(force_range)):
        if i % 7 == 6:
            force_range[i] = (-20.0, 20.0)
            limited[i] = 1
            has_range[i] = True
    model.mujoco.actuator_forcerange.assign(force_range)
    model.mujoco.actuator_forcelimited.assign(limited)
    model.mujoco.actuator_has_forcerange.assign(has_range)
    gravity_comp = model.mujoco.gravcomp.numpy()
    for b, label in enumerate(model.body_label):
        name = label.rsplit("/", 1)[-1]
        if name.startswith(SIDES):
            for k in range(1, 7):
                if name.endswith(f"link_{k}"):
                    gravity_comp[b] = ARM_GC[k-1]
            if any(part in name for part in ("finger", "lf_", "rf_", "camera")):
                gravity_comp[b] = ARM_GC[5]
    model.mujoco.gravcomp.assign(gravity_comp)
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    # Elliptic friction remains well behaved in the low-friction control.
    # The contact capacity also includes broad-phase candidates from the tray sections.
    return newton.solvers.SolverMuJoCo(
        model,
        use_mujoco_contacts=True,
        cone="elliptic",
        iterations=80,
        ls_iterations=30,
        njmax=400,
        nconmax=4096,
    )


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """MuJoCo computes the contacts, including the finite friction cone."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
