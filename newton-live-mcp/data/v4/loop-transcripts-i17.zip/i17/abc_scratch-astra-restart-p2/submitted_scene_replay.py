# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, and ``Example`` drives every world with the logged commands as joint position
targets, open loop. The fitted scene adds three passive ellipsoidal fruit proxies
and a shallow wooden sector with a sloping floor and beveled rim. The fit is stored
below; building the scene does not require the photos or calibration recordings.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.04,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}


# Fitted from the calibration logs and the recorded joint response.
ARM_KP = (64.09, 59.20, 70.50, 9.925, 11.866, 19.506)
ARM_KD = (2.533, 2.479, 2.730, 1.143, 1.530, 2.582)
ARM_FRICTION = (0.497, 1.449, 1.642, 0.223, 0.099, 0.191)
ARM_ARMATURE = (0.00362, 0.00011, 0.00012, 0.00010, 0.00010, 0.00010)
ARM_GRAVCOMP = (0.964, 0.999, 0.575, 0.988, 1.0, 0.210)
GRIPPER_KP = 1200.0  # N/m
GRIPPER_FORCE = 10.0  # N, shared load through the original finger equality

# Name, position [m], semi-axes [m], mass [kg], yaw [rad], and display color.
# Sizes and poses use the calibrated top/wrist views and measured jaw openings.
# Masses and contact materials are effective rigid-body fits for the replicas.
FRUITS = (
    ("pear", (0.648, 0.334, 0.778), (0.041, 0.027, 0.027), 0.12, -0.55, (0.90, 0.70, 0.04)),
    ("orange", (0.503, -0.051, 0.780), (0.030, 0.030, 0.029), 0.12, 0.0, (0.95, 0.25, 0.025)),
    ("dark_fruit", (0.649, -0.189, 0.784), (0.035, 0.034, 0.033), 0.15, 0.0, (0.13, 0.045, 0.018)),
)


def add_objects(builder: newton.ModelBuilder):
    """Three free passive bodies and 23 static collision shapes for the tray."""
    fruit_cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=0.35, mu_torsional=0.002, mu_rolling=0.0005, margin=0.0, gap=0.002)
    for name, position, radii, mass, yaw, color in FRUITS:
        rx, ry, rz = radii
        inertia = np.diag(np.array((ry*ry + rz*rz, rx*rx + rz*rz, rx*rx + ry*ry)) * mass / 5.0)
        body = builder.add_body(xform=wp.transform(position, wp.quat_from_axis_angle(wp.vec3(0, 0, 1), yaw)),
                                mass=mass, inertia=inertia, lock_inertia=True, label=name)
        builder.add_shape_ellipsoid(body, rx=rx, ry=ry, rz=rz, cfg=fruit_cfg, color=color, label=name + "_skin", custom_attributes={"mujoco:condim": 6})

    # The shallow wooden sector: a convex floor and short walls around its perimeter.
    origin = np.array((0.919, 0.145))
    angles = np.linspace(math.radians(169), math.radians(233), 21)
    outline = np.vstack((origin, origin + 0.232 * np.column_stack((np.cos(angles), np.sin(angles)))))
    n = len(outline)
    vertices = np.vstack((np.column_stack((outline, np.full(n, 0.750))),
                          np.column_stack((outline, 0.758 + 0.09 * (outline[:,0] - 0.70)))))
    triangles = []
    for i in range(1, n-1):
        triangles.extend((0, i+1, i, n, n+i, n+i+1))
    for i in range(n):
        j = (i+1) % n
        triangles.extend((i, j, n+j, i, n+j, n+i))
    wood = newton.ModelBuilder.ShapeConfig(density=0.0, mu=0.35, mu_torsional=0.002, mu_rolling=0.0005, margin=0.0, gap=0.002)
    mesh = newton.Mesh(vertices=np.asarray(vertices, dtype=np.float32), indices=np.asarray(triangles, dtype=np.int32))
    builder.add_shape_mesh(-1, mesh=mesh, cfg=wood, color=(0.58, 0.35, 0.13), label="tray_floor")
    # Rounded bowl lip approximated by inward-sloping convex segments.
    for i in range(len(angles)-1):
        a, b = angles[i:i+2]
        xy = np.array([origin + r*np.array((math.cos(t), math.sin(t)))
                       for r,t in ((0.205,a),(0.235,a),(0.235,b),(0.205,b))])
        top = np.array((0.758 + .09*(xy[0,0]-.70), .787, .787,
                        0.758 + .09*(xy[3,0]-.70)))
        verts = np.vstack((np.column_stack((xy,np.full(4,.750))),np.column_stack((xy,top))))
        faces = (0,2,1, 0,3,2, 4,5,6, 4,6,7, 0,1,5, 0,5,4,
                 1,2,6, 1,6,5, 2,3,7, 2,7,6, 3,0,4, 3,4,7)
        lip = newton.Mesh(vertices=verts.astype(np.float32), indices=np.array(faces,dtype=np.int32))
        builder.add_shape_mesh(-1, mesh=lip, cfg=wood, color=(0.66,0.43,0.20), label=f"tray_arc_{i}")
    for i, end in enumerate((outline[1],outline[-1])):
        delta = end - origin
        normal = np.array((-delta[1],delta[0])) / np.linalg.norm(delta)
        if i == 1:
            normal = -normal
        xy = np.array((origin,end,end + normal*.024,origin + normal*.024))
        top = np.array((.787,.787, .758+.09*(xy[2,0]-.70), .758+.09*(xy[3,0]-.70)))
        verts = np.vstack((np.column_stack((xy,np.full(4,.750))),np.column_stack((xy,top))))
        faces = (0,2,1, 0,3,2, 4,5,6, 4,6,7, 0,1,5, 0,5,4,
                 1,2,6, 1,6,5, 2,3,7, 2,7,6, 3,0,4, 3,4,7)
        wall = newton.Mesh(vertices=verts.astype(np.float32), indices=np.array(faces,dtype=np.int32))
        builder.add_shape_mesh(-1, mesh=wall, cfg=wood, color=(.66,.43,.20), label=f"tray_side_{i}")


def build_model(num_worlds: int = 1) -> newton.Model:
    """Calibrated station and passive objects in identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_objects(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    ke, kd = model.joint_target_ke.numpy(), model.joint_target_kd.numpy()
    friction, armature = model.joint_friction.numpy(), model.joint_armature.numpy()
    limits = model.joint_effort_limit.numpy()
    dof_start = model.joint_qd_start.numpy()
    for j, label in enumerate(model.joint_label):
        name = label.rsplit("/", 1)[-1]
        dof = int(dof_start[j])
        if name.startswith(SIDES) and "_joint" in name and name[-1:].isdigit():
            k = int(name[-1]) - 1
            ke[dof], kd[dof] = ARM_KP[k], ARM_KD[k]
            friction[dof], armature[dof] = ARM_FRICTION[k], ARM_ARMATURE[k]
            limits[dof] = 28.0 if k < 3 else 10.0
        elif name in ("left_left_finger", "right_left_finger"):
            ke[dof], kd[dof], limits[dof] = GRIPPER_KP, 14.0, GRIPPER_FORCE
    model.joint_target_ke.assign(ke)
    model.joint_target_kd.assign(kd)
    model.joint_friction.assign(friction)
    model.joint_armature.assign(armature)
    model.joint_effort_limit.assign(limits)
    gravcomp = model.mujoco.gravcomp.numpy()
    for i, label in enumerate(model.body_label):
        name = label.rsplit("/", 1)[-1]
        if name.startswith(SIDES):
            gravcomp[i] = 1.0
            if name[-7:-1] == "_link_" and name[-1:].isdigit():
                gravcomp[i] = ARM_GRAVCOMP[int(name[-1])-1]
    model.mujoco.gravcomp.assign(gravcomp)
    force = model.mujoco.actuator_forcerange.numpy()
    limited = model.mujoco.actuator_forcelimited.numpy()
    has_range = model.mujoco.actuator_has_forcerange.numpy()
    for i, label in enumerate(model.mujoco.actuator_label):
        if label.endswith("gripper"):
            force[i] = (-GRIPPER_FORCE, GRIPPER_FORCE)
            limited[i] = True
            has_range[i] = True
    model.mujoco.actuator_forcerange.assign(force)
    model.mujoco.actuator_forcelimited.assign(limited)
    model.mujoco.actuator_has_forcerange.assign(has_range)
    # Materials stay on the model so rebuilding the solver preserves them.
    mu = model.shape_material_mu.numpy()
    torsion = model.shape_material_mu_torsional.numpy()
    rolling = model.shape_material_mu_rolling.numpy()
    for i, label in enumerate(model.shape_label):
        if "left_arm/" in label or "right_arm/" in label:
            mu[i], torsion[i], rolling[i] = 1.2, 0.008, 0.002
    model.shape_material_mu.assign(mu)
    model.shape_material_mu_torsional.assign(torsion)
    model.shape_material_mu_rolling.assign(rolling)
    model.mujoco.solref.assign(np.tile(np.array((0.006, 1.0), dtype=np.float32), (model.shape_count, 1)))
    model.mujoco.solref_mode.assign(np.ones(model.shape_count, dtype=np.int32))
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    # Elliptic cones remain stable in the low-friction control. Capacity includes
    # broad-phase candidates as well as the much smaller set of active contacts.
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=True, cone="elliptic", iterations=40,
                                      ls_iterations=10, njmax=512, nconmax=4096, impratio=2.0)


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """MuJoCo performs contact generation for the analytic fruit surfaces."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
