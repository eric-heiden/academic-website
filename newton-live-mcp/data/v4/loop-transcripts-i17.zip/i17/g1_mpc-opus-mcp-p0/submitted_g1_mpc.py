# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 humanoid tracking a reference motion (starter for a controller).

The robot is the floating-base Unitree G1 with 29 actuated joints, standing on
the floor of its MJCF and simulated by SolverMuJoCo with 2 ms steps. A
controller runs at 100 Hz: every 10 ms it reads the robot's state and returns
one :class:`Command` for the next control period. Each joint actuator then
applies, at every 2 ms physics step,

    tau = clip(kp * (q - q_joint) + kd * (qd - qd_joint) + tau_ff, -limit, limit)

with the MJCF torque limit of its joint. The plant (``build_model``,
``make_solver``, :class:`Robot`) is fixed; the controller is the part to develop.

Reference motions are MuJoCo-qpos CSV clips at 30 fps: root position [m], root
quaternion (w, x, y, z), and the 29 joint angles [rad] in MJCF order. The robot
starts at rest at the clip's first frame with its feet 2 mm above the floor.

The :class:`Controller` is a sampling-based model predictive controller (MPPI):
every control period it rolls out 512 perturbed joint-target plans for 0.8 s
from the measured state on its own batch of G1 worlds
(:class:`newton.utils.BatchRollout`, SolverMuJoCo with 5 ms steps), scores how
well each tracks the reference (root pose and velocity, joints, soles, falls),
and moves its plan toward the best ones. The servos track the reference joint
angles plus the plan's offsets and the reference joint velocities.

Run: ``python g1_mpc.py --motion walk.csv --viewer null`` (the whole clip; ``--num-frames N``
runs N control periods) prints the tracking report.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
import warp as wp

import newton
import newton.examples

SIM_DT = 0.002  # physics step [s]
CONTROL_DT = 0.01  # control period [s] (100 Hz)
SUBSTEPS = round(CONTROL_DT / SIM_DT)
JOINT_COUNT = 29

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)

# Accepted actuator gains: kp [N m/rad] and kd [N m s/rad] per joint.
KP_RANGE = (1.0, 10000.0)
KD_RANGE = (0.0, 500.0)

# The robot has fallen when the root drops below this height [m], its up axis tilts more than 45 degrees
# (cosine below 0.7), or anything but the feet touches the floor.
FALL_HEIGHT_M = 0.55
FALL_UP_COS = 0.7
FEET = ("left_ankle_roll_link", "right_ankle_roll_link")
WRISTS = ("left_wrist_yaw_link", "right_wrist_yaw_link")
# Foot contact spheres (centres in the ankle roll link frame [m]) and their radius [m].
SOLE_POINTS = np.array([[-0.05, -0.025, -0.03], [-0.05, 0.025, -0.03], [0.12, -0.03, -0.03], [0.12, 0.03, -0.03]])
SOLE_RADIUS = 0.005
SOLE_CENTER = np.array([0.035, 0.0, -0.035])
LIFT_REFERENCE_M = 0.03  # lift recall: reference sole clearance above this [m] ...
LIFT_ROBOT_M = 0.02  # ... counts when the robot's sole clearance is above this [m]
JITTER_HZ = 6.0  # jitter: joint-error RMS above this frequency [Hz]


def asset_path() -> str:
    return str(newton.utils.download_asset("unitree_g1") / "mjcf/g1_29dof_rev_1_0.xml")


def build_model(joint_q: np.ndarray | None = None) -> newton.Model:
    """The G1 on the MJCF floor with torque-limited joint actuators, optionally posed at ``joint_q``."""
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    builder.add_mjcf(asset_path(), collapse_fixed_joints=True)
    # Robot self-collision is excluded; the feet and body still collide with the floor.
    robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
    for i, shape in enumerate(robot_shapes):
        for other in robot_shapes[i + 1 :]:
            builder.add_shape_collision_filter_pair(shape, other)
    builder.joint_armature[6:] = ARMATURE.tolist()
    # MuJoCo position servos whose gains and targets Robot.apply sets from each Command.
    builder.joint_target_ke[6:] = [100.0] * JOINT_COUNT
    builder.joint_target_kd[6:] = [2.0] * JOINT_COUNT
    builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * JOINT_COUNT
    builder.custom_attributes["mujoco:ctrl_source"].values = [
        int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
    ] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcerange"].values = [
        (-limit, limit) for limit in builder.joint_effort_limit[6:]
    ]
    if joint_q is not None:
        builder.joint_q[:] = np.asarray(joint_q, dtype=float).tolist()
    return builder.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverMuJoCo:
    return newton.solvers.SolverMuJoCo(
        model, njmax=192, nconmax=64, use_mujoco_contacts=True, integrator="implicitfast", iterations=50
    )


def quat_wxyz_to_xyzw(q: np.ndarray) -> np.ndarray:
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def body_index(model: newton.Model, name: str) -> int:
    return [label.rsplit("/", 1)[-1] for label in model.body_label].index(name)


class MotionClip:
    """A reference clip, linearly interpolated in time (root quaternion by normalized lerp).

    With a model, the clip is shifted vertically so that the lowest foot contact point of its first frame
    is 2 mm above the floor (the robot starts there).
    """

    def __init__(self, path, model: newton.Model | None = None, fps: float = 30.0):
        self.qpos = np.loadtxt(path, delimiter=",", ndmin=2)
        if self.qpos.shape[1] != 7 + JOINT_COUNT or len(self.qpos) < 2:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps
        self.z_offset = 0.0
        if model is not None:
            self.z_offset = floor_offset(model, self.sample(0.0))

    def sample(self, t: float) -> np.ndarray:
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time ``t`` [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        q[2] += self.z_offset
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


def floor_offset(model: newton.Model, joint_q: np.ndarray) -> float:
    """Vertical shift [m] that puts the lowest foot contact point of ``joint_q`` 2 mm above the floor."""
    state = model.state()
    newton.eval_fk(model, wp.array(joint_q, dtype=float, device=model.device), model.joint_qd, state)
    body_q = state.body_q.numpy().astype(np.float64)
    lowest = np.inf
    for name in FEET:
        pose = body_q[body_index(model, name)]
        points = pose[:3] + SOLE_POINTS @ _rotation(pose[3:7]).T
        lowest = min(lowest, float(points[:, 2].min()) - SOLE_RADIUS)
    return float(0.002 - lowest)


@dataclass
class Command:
    """Actuator command for one control period: per-joint arrays of 29 values in MJCF joint order (scalars
    broadcast). Each actuator applies ``clip(kp (q - q_joint) + kd (qd - qd_joint) + tau, -limit, limit)``
    at every physics step of the period."""

    q: np.ndarray
    """Position targets [rad]."""
    kp: np.ndarray | float
    """Stiffness [N m/rad], within KP_RANGE."""
    kd: np.ndarray | float
    """Damping [N m s/rad], within KD_RANGE."""
    qd: np.ndarray | float = 0.0
    """Velocity targets [rad/s]."""
    tau: np.ndarray | float = 0.0
    """Feedforward torques [N m]."""


def command_arrays(command) -> dict[str, np.ndarray]:
    """The command's fields as float64 arrays of 29 values; raises ValueError for invalid commands."""
    out = {}
    for name in ("q", "kp", "kd", "qd", "tau"):
        value = getattr(command, name, 0.0)
        value = np.broadcast_to(np.asarray(0.0 if value is None else value, dtype=np.float64), (JOINT_COUNT,))
        if not np.all(np.isfinite(value)):
            raise ValueError(f"Command.{name} is not finite")
        out[name] = value.copy()
    for name, (low, high) in (("kp", KP_RANGE), ("kd", KD_RANGE)):
        if np.any(out[name] < low) or np.any(out[name] > high):
            raise ValueError(f"Command.{name} must be within [{low:g}, {high:g}]")
    return out


class Robot:
    """The simulated G1 (the plant): model, solver, state, and the actuator command interface."""

    def __init__(self, start_q: np.ndarray):
        self.model = build_model(start_q)
        self.solver = make_solver(self.model)
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.effort_limit = self.model.joint_effort_limit.numpy()[6:].copy()
        # MuJoCo actuator -> actuated joint (0..28), for writing servo gains without a full model update.
        self._actuator_joint = self.solver.mjc_actuator_to_newton_idx.numpy() - 6
        self._gains = None
        self._target = self.model.joint_q.numpy().copy()
        self.graph = None
        self.capture()

    def capture(self):
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def simulate(self):
        """One control period of physics steps."""
        for i in range(SUBSTEPS):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, SIM_DT)
            if SUBSTEPS % 2 == 1 and i == SUBSTEPS - 1:
                self.state_0.assign(self.state_1)
            else:
                self.state_0, self.state_1 = self.state_1, self.state_0

    def apply(self, command) -> None:
        """Set the actuators from a :class:`Command` (the servo target absorbs qd and tau, which is exact)."""
        c = command_arrays(command)
        gains = np.concatenate([c["kp"], c["kd"]])
        if self._gains is None or not np.array_equal(gains, self._gains):
            ke, kd = self.model.joint_target_ke.numpy(), self.model.joint_target_kd.numpy()
            ke[6:], kd[6:] = c["kp"], c["kd"]
            self.model.joint_target_ke.assign(ke)
            self.model.joint_target_kd.assign(kd)
            # Same effect as solver.notify_model_changed(JOINT_DOF_PROPERTIES) on the servos, which is much slower.
            gain, bias = self.solver.mjw_model.actuator_gainprm, self.solver.mjw_model.actuator_biasprm
            gain_np, bias_np = gain.numpy(), bias.numpy()
            gain_np[:, :, 0] = c["kp"][self._actuator_joint]
            bias_np[:, :, 1] = -c["kp"][self._actuator_joint]
            bias_np[:, :, 2] = -c["kd"][self._actuator_joint]
            gain.assign(gain_np)
            bias.assign(bias_np)
            self._gains = gains
        self._target[7:] = c["q"] + (c["kd"] * c["qd"] + c["tau"]) / c["kp"]
        self.control.joint_target_q.assign(self._target)

    def advance(self):
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()


def _quat_angle(a: np.ndarray, b: np.ndarray) -> float:
    """Angle [rad] between two unit quaternions (xyzw)."""
    return float(2.0 * np.arccos(np.clip(abs(np.dot(a, b)), 0.0, 1.0)))


def _rotation(quat_xyzw: np.ndarray) -> np.ndarray:
    x, y, z, w = quat_xyzw / np.linalg.norm(quat_xyzw)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def foot_points(body_q: np.ndarray, foot: int) -> tuple[np.ndarray, float]:
    """Sole centre [m] and sole clearance above the floor [m] of a foot body."""
    rotation = _rotation(body_q[foot, 3:7])
    clearance = float(np.min((body_q[foot, :3] + SOLE_POINTS @ rotation.T)[:, 2]) - SOLE_RADIUS)
    return body_q[foot, :3] + rotation @ SOLE_CENTER, clearance


def jitter(errors: np.ndarray, dt: float, cutoff: float = JITTER_HZ, trim: float = 0.1) -> float:
    """RMS [rad] of the joint errors' content above ``cutoff`` [Hz] (zero-phase, ``trim`` [s] cut at both ends)."""
    k = round(trim / dt)
    errors = errors[k : len(errors) - k]
    if len(errors) < 16:
        return float("nan")
    errors = errors - errors.mean(axis=0)
    spectrum = np.fft.rfft(errors, axis=0)
    spectrum[np.fft.rfftfreq(len(errors), dt) <= cutoff] = 0.0
    return float(np.sqrt(np.mean(np.fft.irfft(spectrum, n=len(errors), axis=0) ** 2)))


class TrackingReport:
    """Tracking errors against a reference clip, sampled after every control period."""

    def __init__(self, robot: Robot, motion: MotionClip):
        self.robot, self.motion = robot, motion
        model = robot.model
        self.scratch = model.state()
        self.joint_q = wp.zeros(model.joint_coord_count, dtype=float, device=model.device)
        self.feet = [body_index(model, name) for name in FEET]
        self.wrists = [body_index(model, name) for name in WRISTS]
        mj = robot.solver.mj_model
        foot_ids = {i for i in range(mj.nbody) if mj.body(i).name.endswith(FEET)}
        # MuJoCo geoms that may touch the floor: those of the feet.
        self.foot_geom = np.array([int(mj.geom_bodyid[g]) in foot_ids for g in range(mj.ngeom)])
        self.robot_geom = np.array([int(mj.geom_bodyid[g]) != 0 for g in range(mj.ngeom)])
        self.rows = []
        self.fall_time = None
        self.fall_reason = None

    def non_foot_contact(self) -> bool:
        """Whether a robot geom other than the feet touches the floor."""
        data = self.robot.solver.mjw_data
        count = min(int(data.nacon.numpy()[0]), data.contact.geom.shape[0])
        if count == 0:
            return False
        geoms = data.contact.geom.numpy()[:count]
        touching = data.contact.dist.numpy()[:count] <= 0.0
        robot = self.robot_geom[geoms]
        other = robot & ~self.foot_geom[geoms]
        return bool(np.any(touching & other.any(axis=1)))

    def update(self, t: float, state: newton.State) -> bool:
        """Record the errors of ``state`` at time ``t`` [s]; returns whether the robot is still on its feet.

        Recording stops at a fall. Samples at or after ``t`` are dropped first (the clock was rewound)."""
        while self.rows and self.rows[-1]["t"] >= t - 1e-9:
            self.rows.pop()
        if self.fall_time is not None and self.fall_time >= t - 1e-9:
            self.fall_time = self.fall_reason = None
        if self.fall_time is not None:
            return False
        q = state.joint_q.numpy().astype(np.float64)
        body_q = state.body_q.numpy().astype(np.float64)
        ref = self.motion.sample(t)
        self.joint_q.assign(ref)
        newton.eval_fk(self.robot.model, self.joint_q, self.robot.model.joint_qd, self.scratch)
        ref_body_q = self.scratch.body_q.numpy().astype(np.float64)
        finite = bool(np.all(np.isfinite(q)) and np.all(np.isfinite(body_q)))
        quat = q[3:7] / np.linalg.norm(q[3:7]) if finite else ref[3:7]
        soles = [foot_points(body_q, f) for f in self.feet]
        ref_soles = [foot_points(ref_body_q, f) for f in self.feet]
        row = {
            "t": t,
            "finite": finite,
            "root_err": float(np.linalg.norm(q[:3] - ref[:3])),
            "root_rot_err": _quat_angle(quat, ref[3:7]),
            "joint_err": q[7:] - ref[7:],
            "wrist_err2": float(np.mean(np.sum((body_q[self.wrists, :3] - ref_body_q[self.wrists, :3]) ** 2, axis=1))),
            "sole_err2": float(np.mean([np.sum((a[0] - b[0]) ** 2) for a, b in zip(soles, ref_soles, strict=True)])),
            "lift": [(b[1] > LIFT_REFERENCE_M, a[1] > LIFT_ROBOT_M) for a, b in zip(soles, ref_soles, strict=True)],
        }
        self.rows.append(row)
        reason = None
        if not finite:
            reason = "state not finite"
        elif q[2] < FALL_HEIGHT_M:
            reason = f"root height {q[2]:.2f} m"
        elif _rotation(quat)[2, 2] < FALL_UP_COS:
            reason = "root tilted over"
        elif self.non_foot_contact():
            reason = "non-foot floor contact"
        if reason is not None:
            self.fall_time, self.fall_reason = t, reason
        return reason is None

    def summary(self) -> dict:
        """Metrics over the recorded samples, up to a fall (errors are infinite if the state stopped being finite)."""
        rows = self.rows
        finite = bool(rows) and all(r["finite"] for r in rows)
        inf = float("inf")

        def rms(values):
            return float(np.sqrt(np.mean(np.square(values)))) if finite else inf

        lifts = [robot for r in rows for ref, robot in r["lift"] if ref]
        errors = np.array([r["joint_err"] for r in rows]) if finite else None
        return {
            "upright": self.fall_time is None and finite,
            "fall_time_s": self.fall_time,
            "fall_reason": self.fall_reason,
            "survival": 1.0 if self.fall_time is None else self.fall_time / self.motion.duration,
            "root_rmse_m": rms([r["root_err"] for r in rows]),
            "root_rot_rmse_deg": float(np.degrees(rms([r["root_rot_err"] for r in rows]))),
            "joint_rmse_rad": rms(errors) if finite else inf,
            "wrist_rmse_m": float(np.sqrt(np.mean([r["wrist_err2"] for r in rows]))) if finite else inf,
            "sole_rmse_m": float(np.sqrt(np.mean([r["sole_err2"] for r in rows]))) if finite else inf,
            "lift_recall": float(np.mean(lifts)) if lifts else None,
            "jitter_mrad": 1000.0 * jitter(errors, CONTROL_DT) if finite else inf,
            "root_err_max_m": max(r["root_err"] for r in rows) if finite else inf,
            "samples": len(rows),
        }


# Sampling-based MPC (MPPI over joint-target offsets), rolled out on the controller's own batch of G1 worlds.
MPC_SAMPLES = 512  # rollouts per control period (world 0 replays the nominal plan)
MPC_HORIZON = 80  # control periods per rollout
MPC_KNOTS = 6  # knots of the piecewise-linear offset plan, spread over the horizon
MPC_ELITE = 32  # best rollouts averaged into the next nominal plan
MPC_SUBSTEPS = 2  # physics steps per control period in the planner (coarser than the plant's)
MPC_TEMPERATURE = 0.3  # softmax temperature of the elite, relative to their cost spread
MPC_MAX_OFFSET = 0.6  # bound of the joint-target offsets [rad]
GAIN_HZ = 20.0  # servo natural frequency (on the armature) [Hz]
GAIN_DAMPING = 1.0  # servo damping ratio
LEG_SIGMA, WAIST_SIGMA, ARM_SIGMA = 0.05, 0.03, 0.01  # sampling noise of the offsets [rad]
W_ROOT_XY, W_ROOT_Z, W_ROOT_ROT = 800.0, 600.0, 150.0  # cost weights: root position [1/m^2], rotation [1/rad^2]
W_LEG, W_ARM, W_FOOT = 2.0, 0.5, 300.0  # joints [1/rad^2], soles [1/m^2]
W_ROOT_VEL, W_ROOT_ANGVEL, W_OFFSET = 20.0, 2.0, 0.5
W_TERMINAL = 4.0  # extra weight of the last horizon step
FALL_PENALTY = 1.0e4
# Wall-time guard: if compute() (plus an allowance for the plant's physics) would exceed this over the clip, the
# horizon shrinks (to at least MPC_MIN_HORIZON) so that the rest of the clip fits.
ROLLOUT_BUDGET_S = 140.0
PHYSICS_ALLOWANCE_S = 0.006  # per control period
MPC_MIN_HORIZON = 40


class Controller:
    """Sampling MPC: every control period, roll out MPC_SAMPLES perturbations of the nominal plan from the
    measured state for MPC_HORIZON control periods on a batch of copies of the robot, score their tracking of the
    reference (root pose, joints, soles, velocities, falls), and move the plan toward the best rollouts (MPPI).

    The plan is a piecewise-linear offset on the reference joint angles; the servos also track the reference
    joint velocities. ``model`` is a copy of the plant's model posed at the start; ``motion`` is the clip.
    """

    def __init__(self, model: newton.Model, motion: MotionClip):
        self.motion = motion
        self.rng = np.random.default_rng(0)
        omega = 2.0 * np.pi * GAIN_HZ
        self.kp = ARMATURE * omega**2
        self.kd = 2.0 * GAIN_DAMPING * ARMATURE * omega
        self.sigma = np.array([LEG_SIGMA] * 12 + [WAIST_SIGMA] * 3 + [ARM_SIGMA] * 14)
        self.joint_weight = np.array([W_LEG] * 15 + [W_ARM] * 14)
        self._reference_table(model)

        start_q = motion.sample(0.0)
        self.rollout = newton.utils.BatchRollout(
            lambda: build_model(start_q),
            MPC_SAMPLES,
            solver=make_solver,
            dt=CONTROL_DT / MPC_SUBSTEPS,
            substeps=MPC_SUBSTEPS,
        )
        solver = self.rollout.solver
        actuator_joint = solver.mjc_actuator_to_newton_idx.numpy() - 6
        gain, bias = solver.mjw_model.actuator_gainprm, solver.mjw_model.actuator_biasprm
        gain_np, bias_np = gain.numpy(), bias.numpy()
        gain_np[:, :, 0] = self.kp[actuator_joint]
        bias_np[:, :, 1] = -self.kp[actuator_joint]
        bias_np[:, :, 2] = -self.kd[actuator_joint]
        gain.assign(gain_np)
        bias.assign(bias_np)
        self.start = self.rollout.model.state()
        self.coords = model.joint_coord_count
        self.dofs = model.joint_dof_count
        self.record = {
            "q": "joint_q",
            "qd": "joint_qd",
            "lf": ("body_q", "*/" + FEET[0]),
            "rf": ("body_q", "*/" + FEET[1]),
        }
        self.nominal = np.zeros((MPC_KNOTS, JOINT_COUNT))
        self._set_horizon(MPC_HORIZON)
        # Warm up (kernel loading and graph capture) from the start pose.
        self.plan(0.0, start_q, np.zeros(self.dofs))
        self.nominal[:] = 0.0
        self.compute_seconds = 0.0
        self.calls = 0

    def _set_horizon(self, horizon: int):
        """Use ``horizon`` control periods per rollout, resampling the nominal plan onto the new knots."""
        knot_frames = np.linspace(0.0, horizon - 1, MPC_KNOTS)
        if getattr(self, "knot_frames", None) is not None:
            old = self.knot_frames
            self.nominal = np.stack([np.interp(knot_frames, old, self.nominal[:, j]) for j in range(JOINT_COUNT)], 1)
        self.horizon = horizon
        self.knot_frames = knot_frames
        frames = np.arange(horizon)
        eye = np.eye(MPC_KNOTS)
        # Linear interpolation of the knots at each frame [H, KNOTS], and of the knots one period later.
        self.interp = np.stack([np.interp(frames, knot_frames, eye[i]) for i in range(MPC_KNOTS)], 1)
        self.shift = np.stack([np.interp(knot_frames + 1.0, knot_frames, eye[i]) for i in range(MPC_KNOTS)], 1)
        self.schedule = np.zeros((horizon, MPC_SAMPLES, self.coords), dtype=np.float32)

    def _check_budget(self, t: float):
        """Shrink the horizon when the measured time per control period would overrun the rollout budget."""
        if self.calls < 20 or self.calls % 10 or self.horizon <= MPC_MIN_HORIZON:
            return
        spent = self.compute_seconds + PHYSICS_ALLOWANCE_S * self.calls
        per_call = spent / self.calls
        remaining = max(self.motion.duration - t, 0.0) / CONTROL_DT + 1.0
        left = ROLLOUT_BUDGET_S - spent
        if per_call * remaining > left:
            scale = max(left, 0.0) / (per_call * remaining)
            horizon = max(MPC_MIN_HORIZON, int(self.horizon * scale * 0.9))
            if horizon < self.horizon:
                self._set_horizon(horizon)

    def _reference_table(self, model: newton.Model):
        """Reference root pose, joint angles, velocities, and sole centres at every control period."""
        count = int(np.ceil(self.motion.duration / CONTROL_DT)) + MPC_HORIZON + 3
        times = np.arange(count) * CONTROL_DT
        self.ref_q = np.array([self.motion.sample(t) for t in times])
        h = 0.5 * CONTROL_DT
        ahead = np.array([self.motion.sample(t + h) for t in times])
        behind = np.array([self.motion.sample(max(t - h, 0.0)) for t in times])
        span = np.array([min(t + h, self.motion.duration) - min(max(t - h, 0.0), self.motion.duration) for t in times])
        span = np.maximum(span, 1e-9)[:, None]
        self.ref_qd = (ahead[:, 7:] - behind[:, 7:]) / span
        self.ref_v = (ahead[:, :3] - behind[:, :3]) / span
        self.ref_w = _rotation_vector(_quat_mul(ahead[:, 3:7], _quat_conj(behind[:, 3:7]))) / span
        state = model.state()
        feet = [body_index(model, name) for name in FEET]
        joint_q = wp.zeros(model.joint_coord_count, dtype=float, device=model.device)
        soles = []
        for q in self.ref_q:
            joint_q.assign(q)
            newton.eval_fk(model, joint_q, model.joint_qd, state)
            body_q = state.body_q.numpy().astype(np.float64)
            soles.append([foot_points(body_q, f)[0] for f in feet])
        self.ref_sole = np.array(soles)  # [T, 2, 3]

    def _index(self, t: float) -> int:
        return min(int(round(t / CONTROL_DT)), len(self.ref_q) - MPC_HORIZON - 2)

    def plan(self, t: float, joint_q: np.ndarray, joint_qd: np.ndarray) -> np.ndarray:
        """One MPPI iteration from the measured state; returns the offsets of the first control period."""
        k = self._index(t)
        n, horizon = MPC_SAMPLES, self.horizon
        noise = self.rng.standard_normal((n, MPC_KNOTS, JOINT_COUNT)) * self.sigma
        noise[0] = 0.0
        knots = np.clip(self.nominal[None] + noise, -MPC_MAX_OFFSET, MPC_MAX_OFFSET)
        offsets = np.einsum("hk,nkj->hnj", self.interp, knots)  # [H, N, 29]
        ref_next = self.ref_q[k + 1 : k + 1 + horizon, 7:]
        ref_qd = self.ref_qd[k + 1 : k + 1 + horizon]
        target = ref_next[:, None, :] + offsets + (self.kd * ref_qd / self.kp)[:, None, :]
        self.schedule[:, :, 7:] = target

        self.start.joint_q.assign(np.tile(joint_q.astype(np.float32), n))
        self.start.joint_qd.assign(np.tile(joint_qd.astype(np.float32), n))
        newton.eval_fk(self.rollout.model, self.start.joint_q, self.start.joint_qd, self.start)
        self.rollout.reset(self.start)
        rec = self.rollout.run(horizon, control={"joint_target_q": self.schedule}, record=self.record)
        q = rec["q"][1:].reshape(horizon, n, self.coords).astype(np.float64)
        qd = rec["qd"][1:].reshape(horizon, n, self.dofs).astype(np.float64)
        ref = self.ref_q[k + 1 : k + 1 + horizon]
        cost = self._cost(q, qd, rec, ref, k)
        cost += W_OFFSET * np.sum(knots**2, axis=(1, 2))
        cost[~np.isfinite(cost)] = 1e12

        order = np.argsort(cost)
        elite = order[:MPC_ELITE]
        spread = max(cost[elite[-1]] - cost[elite[0]], 1e-9)
        w = np.exp(-(cost[elite] - cost[elite[0]]) / (MPC_TEMPERATURE * spread))
        w /= w.sum()
        self.nominal = np.einsum("n,nkj->kj", w, knots[elite])
        self.last_cost = (cost[0], cost[elite[0]])
        return self.nominal[0].copy()

    def _cost(self, q, qd, rec, ref, k) -> np.ndarray:
        h = len(ref)
        step_w = np.ones(h)
        step_w[-1] += W_TERMINAL
        step_w = step_w[:, None]
        root = q[:, :, :3] - ref[:, None, :3]
        cost = W_ROOT_XY * np.sum(root[..., :2] ** 2, -1) + W_ROOT_Z * root[..., 2] ** 2
        quat = q[:, :, 3:7] / np.linalg.norm(q[:, :, 3:7], axis=-1, keepdims=True)
        dot = np.abs(np.sum(quat * ref[:, None, 3:7], -1))
        angle = 2.0 * np.arccos(np.clip(dot, 0.0, 1.0))
        cost += W_ROOT_ROT * angle**2
        cost += np.sum(self.joint_weight * (q[:, :, 7:] - ref[:, None, 7:]) ** 2, -1)
        x, y, z, w = quat[..., 0], quat[..., 1], quat[..., 2], quat[..., 3]
        up_z = 1.0 - 2.0 * (x * x + y * y)
        fallen = (q[:, :, 2] < FALL_HEIGHT_M + 0.05) | (up_z < FALL_UP_COS + 0.1)
        cost += FALL_PENALTY * fallen
        ref_v = self.ref_v[k + 1 : k + 1 + h]
        cost += W_ROOT_VEL * np.sum((qd[:, :, :3] - ref_v[:, None]) ** 2, -1)
        ref_w = self.ref_w[k + 1 : k + 1 + h]
        cost += W_ROOT_ANGVEL * np.sum((qd[:, :, 3:6] - ref_w[:, None]) ** 2, -1)
        ref_sole = self.ref_sole[k + 1 : k + 1 + h]
        for i, name in enumerate(("lf", "rf")):
            body = rec[name][1:].reshape(h, -1, 7).astype(np.float64)
            rotation = _rotation_batch(body[..., 3:7])
            sole = body[..., :3] + rotation @ SOLE_CENTER
            cost += W_FOOT * np.sum((sole - ref_sole[:, None, i]) ** 2, -1)
        return np.sum(step_w * cost, axis=0)

    def compute(self, t: float, joint_q: np.ndarray, joint_qd: np.ndarray) -> Command:
        """Command for the control period starting at ``t`` [s], given the state then: joint_q (root position [m],
        root quaternion xyzw, 29 joint angles [rad]) and joint_qd (root COM linear [m/s] and angular [rad/s]
        velocity in the world frame, 29 joint velocities [rad/s])."""
        started = time.perf_counter()
        self._check_budget(t)
        offset = self.plan(t, joint_q, joint_qd)
        k = self._index(t)
        command = Command(q=self.ref_q[k + 1, 7:] + offset, kp=self.kp, kd=self.kd, qd=self.ref_qd[k + 1])
        # Shift the plan by one control period for the next call.
        self.nominal = self.shift @ self.nominal
        self.calls += 1
        self.compute_seconds += time.perf_counter() - started
        return command


def _quat_conj(q: np.ndarray) -> np.ndarray:
    return np.concatenate([-q[..., :3], q[..., 3:]], axis=-1)


def _quat_mul(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Hamilton products of quaternions (xyzw)."""
    av, aw, bv, bw = a[..., :3], a[..., 3:], b[..., :3], b[..., 3:]
    return np.concatenate([aw * bv + bw * av + np.cross(av, bv), aw * bw - np.sum(av * bv, -1, keepdims=True)], -1)


def _rotation_vector(q: np.ndarray) -> np.ndarray:
    """Rotation vectors [rad] of quaternions (xyzw)."""
    q = np.where(q[..., 3:] < 0.0, -q, q)
    sin = np.linalg.norm(q[..., :3], axis=-1, keepdims=True)
    angle = 2.0 * np.arctan2(sin, q[..., 3:])
    return q[..., :3] * np.where(sin > 1e-9, angle / np.maximum(sin, 1e-12), 2.0)


def _rotation_batch(quat_xyzw: np.ndarray) -> np.ndarray:
    """Rotation matrices [..., 3, 3] of unit quaternions (xyzw) [..., 4]."""
    q = quat_xyzw / np.linalg.norm(quat_xyzw, axis=-1, keepdims=True)
    x, y, z, w = q[..., 0], q[..., 1], q[..., 2], q[..., 3]
    return np.stack(
        [
            np.stack([1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)], -1),
            np.stack([2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)], -1),
            np.stack([2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)], -1),
        ],
        -2,
    )


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.frame_dt = CONTROL_DT
        self.sim_dt = SIM_DT
        self.sim_time = 0.0
        # The robot starts at rest at the clip's first frame; the controller plans on its own copy of the model.
        self.motion = MotionClip(args.motion, build_model())
        start = self.motion.sample(0.0)
        self.robot = Robot(start)
        planning_model = build_model(start)
        self.controller = Controller(planning_model, MotionClip(args.motion, planning_model))
        self.report = TrackingReport(self.robot, self.motion)
        self.compute_seconds = 0.0
        self.viewer.set_model(self.model)

    # The live host and viewers look for these on the example.
    @property
    def model(self):
        return self.robot.model

    @property
    def solver(self):
        return self.robot.solver

    @property
    def state_0(self):
        return self.robot.state_0

    @property
    def state_1(self):
        return self.robot.state_1

    @property
    def control(self):
        return self.robot.control

    def capture(self):
        self.robot.capture()

    def step(self):
        # Read the state first: the copy waits for the last physics step, which is not the controller's time.
        joint_q = self.state_0.joint_q.numpy().astype(np.float64)
        joint_qd = self.state_0.joint_qd.numpy().astype(np.float64)
        started = time.perf_counter()
        command = self.controller.compute(self.sim_time, joint_q, joint_qd)
        self.compute_seconds += time.perf_counter() - started
        self.robot.apply(command)
        self.robot.advance()
        self.sim_time += self.frame_dt
        self.report.update(self.sim_time, self.state_0)

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def print_report(self):
        summary = self.report.summary()
        print(f"tracked {self.sim_time:.2f} of {self.motion.duration:.2f} s")
        for key, value in summary.items():
            print(f"  {key}: {value:.4f}" if isinstance(value, float) else f"  {key}: {value}")
        print(f"  controller_seconds: {self.compute_seconds:.2f}")

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, default="walk.csv", help="Reference clip (MuJoCo qpos CSV, 30 fps)")
        parser.set_defaults(num_frames=None)
        return parser


if __name__ == "__main__":
    parser = Example.create_parser()
    known, _ = parser.parse_known_args()
    if known.num_frames is None:
        parser.set_defaults(num_frames=round(MotionClip(known.motion).duration / CONTROL_DT))
    viewer, args = newton.examples.init(parser)
    example = Example(viewer, args)
    started = time.perf_counter()
    newton.examples.run(example, args)
    example.print_report()
    print(f"  wall_seconds: {time.perf_counter() - started:.2f}")
