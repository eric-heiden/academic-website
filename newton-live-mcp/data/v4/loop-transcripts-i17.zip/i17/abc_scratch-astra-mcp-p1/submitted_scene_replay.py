# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, and ``Example`` drives every world with the logged commands as joint position
targets, open loop.

The reconstruction adds three passive fruit bodies (85, 95, and 110 g) and a
static wooden tray. The tray has a shallow dished floor represented by 20 convex
panels and 20 rim segments. Camera and arm-log fits are stored below as constants;
building the scene does not require the photos or calibration logs.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.02,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}


# Fitted from the station logs; common physical servos on both arms.
ARM = {
    "kp": [54.866, 44.083, 53.643, 9.111, 9.543, 11.083],
    "kd": [3.146, 2.811, 3.749, 1.259, 1.426, 1.715],
    "armature": [.02324, .00182, .00180, .000105, .000117, .000113],
    "friction": [.4491, .7679, .7673, .1792, .0806, .1059],
    "gravcomp": [.0023, .9420, .8430, .9309, .8798, .4503],
}
FRUITS = [
    # name, position, yaw, enclosing semi-axes, mass, colour
    ("pear", (.643, .337, .7755), -1.06, (.041, .027, .0255), .085, (.83, .65, .035)),
    ("orange", (.496, -.044, .7805), 0., (.0305, .0305, .0305), .095, (.93, .23, .015)),
    ("dark_fruit", (.651, -.190, .782), 0., (.033, .033, .032), .11, (.13, .045, .025)),
]


def add_objects(builder):
    """Compact convex fruit models and a shallow wooden sector tray."""
    fruit_cfg = newton.ModelBuilder.ShapeConfig(density=0, mu=1.0,
        mu_torsional=.003, mu_rolling=.0005, margin=0., gap=.002)
    attr = {"mujoco:condim": 6, "mujoco:solref": (.008, 1.), "mujoco:solref_mode": 1}
    for name, pos, yaw, radii, mass, color in FRUITS:
        a,b,c = radii
        inertia = np.diag([mass*(b*b+c*c)/5, mass*(a*a+c*c)/5, mass*(a*a+b*b)/5])
        body = builder.add_body(xform=wp.transform(pos, wp.quat_from_axis_angle(wp.vec3(0,0,1), yaw)),
            mass=mass, inertia=wp.mat33(inertia), com=wp.vec3(-.008,0,0) if name=="pear" else wp.vec3(0,0,0),
            lock_inertia=True, label=name)
        if name == "pear":
            builder.add_shape_ellipsoid(body, xform=wp.transform((-.01,0,0), wp.quat_identity()),
                rx=.029, ry=.027, rz=.0255, cfg=fruit_cfg, color=color, custom_attributes=attr)
            builder.add_shape_ellipsoid(body, xform=wp.transform((.023,0,0), wp.quat_identity()),
                rx=.019, ry=.017, rz=.019, cfg=fruit_cfg, color=color, custom_attributes=attr)
        else:
            builder.add_shape_ellipsoid(body, rx=a, ry=b, rz=c, cfg=fruit_cfg, color=color, custom_attributes=attr)

    # World coordinates of the tip, arc radius and two radial edges, fitted to
    # the calibrated top-camera silhouette. Floor and rim are separate solids.
    tip = np.array([.916, .145])
    radius = .238
    angles = np.linspace(math.radians(170), math.radians(230), 19)
    outline = np.vstack([tip, tip + radius*np.stack([np.cos(angles), np.sin(angles)],axis=1)])
    basin = np.array([.725, .115])
    floor_height = .754
    edge_height = .768
    n=len(outline)
    tray_cfg = newton.ModelBuilder.ShapeConfig(density=0,mu=.65,mu_torsional=.002,mu_rolling=.0004,gap=.002)
    edge_z = np.array([.778 if i==0 else edge_height for i in range(n)])
    for i in range(n):
        j=(i+1)%n
        p,q=outline[i],outline[j]
        verts=np.array([[basin[0],basin[1],.7505],[p[0],p[1],.7505],[q[0],q[1],.7505],
            [basin[0],basin[1],floor_height],[p[0],p[1],edge_z[i]],[q[0],q[1],edge_z[j]]],dtype=np.float32)
        faces=np.array([0,2,1,3,4,5,0,1,4,0,4,3,1,2,5,1,5,4,2,0,3,2,3,5],dtype=np.int32)
        builder.add_shape_mesh(-1,mesh=newton.Mesh(verts,faces),cfg=tray_cfg,
            color=(.56,.34,.14),label=f"tray_floor_{i}",custom_attributes=attr)
        mid=(p+q)*.5;delta=q-p
        top=max(edge_z[i],edge_z[j])+.006
        builder.add_shape_box(-1,xform=wp.transform((mid[0],mid[1],(.751+top)*.5),
            wp.quat_from_axis_angle(wp.vec3(0,0,1),math.atan2(delta[1],delta[0]))),
            hx=float(np.linalg.norm(delta)*.5+.0015),hy=.0035,hz=float((top-.751)*.5),
            cfg=tray_cfg,color=(.66,.43,.21),label=f"tray_rim_{i}",custom_attributes=attr)


def build_model(num_worlds: int = 1) -> newton.Model:
    """The reconstructed station in identical, independent worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    for j,label in enumerate(station.joint_label):
        name=label.rsplit("/",1)[-1]
        d=station.joint_qd_start[j]
        if any(name == f"{side}_joint{k+1}" for side in SIDES for k in range(6)):
            k=int(name[-1])-1
            station.joint_target_ke[d]=ARM["kp"][k]
            station.joint_target_kd[d]=ARM["kd"][k]
            station.joint_armature[d]=ARM["armature"][k]
            station.joint_friction[d]=ARM["friction"][k]
            station.joint_effort_limit[d]=28. if k<3 else 10.
        elif name.endswith("left_finger"):
            station.joint_target_ke[d]=1200.
            station.joint_effort_limit[d]=12.
    add_objects(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    gravity_compensation = model.mujoco.gravcomp.numpy()
    for i, label in enumerate(model.body_label):
        name = label.rsplit("/", 1)[-1]
        for side in SIDES:
            for k in range(6):
                if name == f"{side}_link_{k+1}":
                    gravity_compensation[i] = ARM["gravcomp"][k]
    model.mujoco.gravcomp.assign(gravity_compensation)

    # Specify the squeeze limit on both the joint and its imported servo.
    force_range = model.mujoco.actuator_forcerange.numpy()
    force_limited = model.mujoco.actuator_forcelimited.numpy()
    has_force_range = model.mujoco.actuator_has_forcerange.numpy()
    for i, label in enumerate(model.mujoco.actuator_label):
        if label.rsplit("/", 1)[-1] in ("left_gripper", "right_gripper"):
            force_range[i] = (-12.0, 12.0)
            force_limited[i] = 1
            has_force_range[i] = True
    model.mujoco.actuator_forcerange.assign(force_range)
    model.mujoco.actuator_forcelimited.assign(force_limited)
    model.mujoco.actuator_has_forcerange.assign(has_force_range)
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=True,
        cone="elliptic", iterations=50, ls_iterations=20, nconmax=4096, njmax=1200,
        impratio=1., tolerance=1e-8)


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Use the solver's native convex contacts."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
