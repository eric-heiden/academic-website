# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure), adds the scene recreated from
the photos and logs (a pear, an orange, and a dark round fruit on the table, and the
wedge-shaped wooden tray they are put into), and tunes the arm and gripper drives to the
logs, in ``num_worlds`` identical worlds. ``Example`` drives every world with the logged
commands as joint position targets, open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.033,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}

TABLE_Z = 0.75  # table top [m]

# Fruits fitted to the photos and logs: start position on the table (x, y) [m], heading of the long axis
# about z [rad], shape, collision size [m], and mass [kg]. Widths follow the gripper opening while it held
# each fruit; positions follow the top camera and where the gripper closed.
FRUITS = {
    "pear": {"xy": (0.6490, 0.3340), "yaw": -0.49, "radius": 0.0255, "half_height": 0.013, "mass": 0.11},
    "orange": {"xy": (0.5007, -0.0526), "yaw": 0.0, "radius": 0.029, "half_height": 0.0, "mass": 0.12},
    "dark_fruit": {"xy": (0.6473, -0.1883), "yaw": 0.0, "radius": 0.032, "half_height": 0.0, "mass": 0.13},
}
FRUIT_COLORS = {"pear": (0.85, 0.75, 0.05), "orange": (0.95, 0.35, 0.02), "dark_fruit": (0.22, 0.09, 0.07)}
FRUIT_MATERIAL = {"mu": 1.2, "mu_torsional": 0.01, "mu_rolling": 0.001, "restitution": 0.0}

# Wedge-shaped wooden tray (static), a circular sector fitted to its silhouette in photos/01_top.jpg:
# apex (x, y) [m], direction of its axis [rad], radius [m], half opening angle [rad]. Its floor is shaped so
# that the released fruits settle where the real ones did (photos 04, 09-11): flat between VALLEY_R from the
# apex, rising gently toward the apex and the arc, and on the -y half toward the tray axis.
TRAY = {
    "apex": (0.942, 0.148),
    "heading": math.radians(-162.3),
    "radius": 0.263,
    "half_angle": math.radians(30.1),
    "floor_top": TABLE_Z + 0.006,  # top of the tray floor [m]
    "rim_top": TABLE_Z + 0.022,  # top of the rim [m]
    "rim_thickness": 0.006,
    "mu": 0.9,
}
TRAY_COLOR = (0.80, 0.58, 0.36)
VALLEY_R = (0.175, 0.205)  # flat part of the floor, as distances from the apex [m]
VALLEY_SLOPE = 0.10  # floor slope toward the flat part
SIDE_SLOPE = 0.08  # cross slope of the floor's -y half toward the tray axis

# Arm and gripper drive (per joint 1-6: stiffness [N m/rad], damping [N m s/rad]) and gripper squeeze.
# Gains are a least-squares fit of the measured motor torques to the command error and joint velocity.
ARM_KE = (80.0, 80.0, 80.0, 12.0, 7.5, 6.5)
ARM_KD = (4.3, 4.3, 4.3, 1.6, 1.0, 0.7)
ARM_GRAVCOMP = 0.6  # gravity compensation of links 2-6 (the real arms sag under gravity)
ARM_EFFORT = (28.0, 28.0, 28.0, 10.0, 10.0, 10.0)
GRIPPER_KE = 1000.0  # [N/m]
GRIPPER_FORCE = 5.5  # squeeze force limit [N]: ample with the pads' friction, not enough to lift by squeezing alone
CONTACT_GAP = 0.01  # contact detection gap of every shape [m]


def _yaw(angle: float) -> wp.quat:
    return wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), float(angle))


def add_fruits(builder: newton.ModelBuilder) -> None:
    """The three fruits: free bodies resting on the table."""
    for name, fruit in FRUITS.items():
        r, h, m = fruit["radius"], fruit["half_height"], fruit["mass"]
        x, y = fruit["xy"]
        # principal inertia between a solid and a thin-shell ellipsoid of the extents (semi-axes a, r, r)
        a = r + h
        ixx = 0.25 * m * (r * r + r * r)
        iyy = 0.25 * m * (a * a + r * r)
        body = builder.add_body(
            xform=wp.transform(wp.vec3(x, y, TABLE_Z + r + 0.0005), _yaw(fruit["yaw"])),
            mass=m,
            inertia=wp.mat33(ixx, 0.0, 0.0, 0.0, iyy, 0.0, 0.0, 0.0, iyy),
            lock_inertia=True,
            label=name,
        )
        cfg = newton.ModelBuilder.ShapeConfig(density=0.0, **FRUIT_MATERIAL)
        if h > 0.0:
            # capsule along the body x axis (its length lies on the table)
            rot = wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), 0.5 * math.pi)
            builder.add_shape_capsule(
                body, xform=wp.transform(wp.vec3(), rot), radius=r, half_height=h, cfg=cfg, color=FRUIT_COLORS[name]
            )
        else:
            builder.add_shape_sphere(body, radius=r, cfg=cfg, color=FRUIT_COLORS[name])


def add_tray(builder: newton.ModelBuilder) -> None:
    """The wedge tray: static floor strips and a low rim along its sector outline."""
    ax, ay = TRAY["apex"]
    th, R, half = TRAY["heading"], TRAY["radius"], TRAY["half_angle"]
    u = np.array([math.cos(th), math.sin(th)])
    v = np.array([-u[1], u[0]])
    apex = np.array([ax, ay])
    cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=TRAY["mu"], mu_torsional=0.01, mu_rolling=0.003)
    floor_z, rim_z, t = TRAY["floor_top"], TRAY["rim_top"], TRAY["rim_thickness"]
    # floor: strips across the axis, from near the (rounded) apex to the arc. It is flat between VALLEY_R
    # from the apex, where the real fruits came to rest, and rises gently toward the apex and the arc.
    thick = 0.008
    r_in, r_out = VALLEY_R
    edges = np.concatenate([np.linspace(0.06, r_in, 4)[:-1], np.linspace(r_in, r_out, 3)[:-1], np.linspace(r_out, R, 3)])
    for i, (d0, d1) in enumerate(zip(edges[:-1], edges[1:])):
        w = max(min(d * math.tan(half), math.sqrt(max(R * R - d * d, 0.0))) for d in np.linspace(d0, d1, 9))
        dm = 0.5 * (d0 + d1)
        slope = -VALLEY_SLOPE if d1 <= r_in + 1e-9 else VALLEY_SLOPE if d0 >= r_out - 1e-9 else 0.0
        top = floor_z + VALLEY_SLOPE * max(r_in - dm, dm - r_out, 0.0)
        pitch = -math.atan(slope)
        # two halves across the axis; the half on the -y side also slopes down toward the axis
        for side, cross in ((-1.0, 0.0), (1.0, SIDE_SLOPE)):
            roll = math.atan(cross) * side
            c = apex + u * dm + v * side * 0.5 * w
            z = top + cross * 0.5 * w - 0.5 * thick
            rot = _yaw(th) * wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), pitch)
            rot = rot * wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), roll)
            builder.add_shape_box(
                -1,
                xform=wp.transform(wp.vec3(c[0], c[1], z), rot),
                hx=0.5 * (d1 - d0) / math.cos(pitch) + 0.001,
                hy=0.5 * w / math.cos(roll) + 0.001,
                hz=0.5 * thick,
                cfg=cfg,
                color=TRAY_COLOR,
                label=f"tray_floor_{i}_{int(side > 0)}",
            )
    hz = 0.5 * (rim_z - TABLE_Z)
    # straight sides
    for sign in (-1.0, 1.0):
        ang = th + sign * half
        e = np.array([math.cos(ang), math.sin(ang)])
        n = np.array([-e[1], e[0]]) * sign  # outward normal
        d0, d1 = 0.06 / math.cos(half), R
        c = apex + e * 0.5 * (d0 + d1) + n * 0.5 * t
        builder.add_shape_box(
            -1,
            xform=wp.transform(wp.vec3(c[0], c[1], TABLE_Z + hz), _yaw(ang)),
            hx=0.5 * (d1 - d0),
            hy=0.5 * t,
            hz=hz,
            cfg=cfg,
            color=TRAY_COLOR,
            label=f"tray_side_{int(sign > 0)}",
        )
    # arc
    segments = 6
    for k in range(segments):
        ang = th - half + (k + 0.5) * 2.0 * half / segments
        e = np.array([math.cos(ang), math.sin(ang)])
        c = apex + e * (R + 0.5 * t)
        chord = 2.0 * (R + t) * math.sin(half / segments) + 0.004
        builder.add_shape_box(
            -1,
            xform=wp.transform(wp.vec3(c[0], c[1], TABLE_Z + hz), _yaw(ang)),
            hx=0.5 * t,
            hy=0.5 * chord,
            hz=hz,
            cfg=cfg,
            color=TRAY_COLOR,
            label=f"tray_arc_{k}",
        )


def tune_station(model: newton.Model) -> None:
    """Arm and gripper drives fitted to the arm logs and the episode."""
    names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
    q_start = model.joint_qd_start.numpy()
    ke, kd = model.joint_target_ke.numpy(), model.joint_target_kd.numpy()
    effort = model.joint_effort_limit.numpy()
    for j, name in enumerate(names):
        dof = q_start[j]
        for side in SIDES:
            for k in range(6):
                if name == f"{side}_joint{k + 1}":
                    ke[dof], kd[dof], effort[dof] = ARM_KE[k], ARM_KD[k], ARM_EFFORT[k]
            if name == f"{side}_left_finger":
                ke[dof] = GRIPPER_KE
    model.joint_target_ke.assign(ke)
    model.joint_target_kd.assign(kd)
    model.joint_effort_limit.assign(effort)
    mj = model.mujoco
    labels = list(mj.actuator_label) if not hasattr(mj.actuator_label, "numpy") else list(mj.actuator_label.numpy())
    forcerange = mj.actuator_forcerange.numpy()
    limited = mj.actuator_forcelimited.numpy()
    has_range = mj.actuator_has_forcerange.numpy()
    for a, label in enumerate(labels):
        name = str(label).rsplit("/", 1)[-1]
        for side in SIDES:
            if name == f"{side}_gripper":
                forcerange[a] = (-GRIPPER_FORCE, GRIPPER_FORCE)
                limited[a], has_range[a] = 1, 1
            for k in range(6):
                if name == f"{side}_joint{k + 1}":
                    forcerange[a] = (-ARM_EFFORT[k], ARM_EFFORT[k])
    mj.actuator_forcerange.assign(forcerange)
    mj.actuator_forcelimited.assign(limited)
    mj.actuator_has_forcerange.assign(has_range)
    # rolling and torsional friction need full contact dimensionality on the added shapes
    condim = mj.condim.numpy()
    body = model.shape_body.numpy()
    fruit_bodies = {i for i, label in enumerate(model.body_label) if label.rsplit("/", 1)[-1] in FRUITS}
    for s in range(model.shape_count):
        if body[s] in fruit_bodies or body[s] == -1 and "tray" in model.shape_label[s]:
            condim[s] = 6
    mj.condim.assign(condim)
    gravcomp = mj.gravcomp.numpy()
    for b, label in enumerate(model.body_label):
        name = label.rsplit("/", 1)[-1]
        if any(name == f"{side}_link_{k}" for side in SIDES for k in range(2, 7)):
            gravcomp[b] = ARM_GRAVCOMP
    mj.gravcomp.assign(gravcomp)
    # a tight contact gap keeps the broadphase small (the MJCF default of 0.1 m overflows it)
    model.shape_gap.fill_(CONTACT_GAP)


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station with the fruits and the tray in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_fruits(station)
    add_tray(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    tune_station(model)
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(
        model,
        use_mujoco_contacts=True,
        cone="elliptic",
        iterations=50,
        ls_iterations=25,
        nconmax=200,
        njmax=600,
    )


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
