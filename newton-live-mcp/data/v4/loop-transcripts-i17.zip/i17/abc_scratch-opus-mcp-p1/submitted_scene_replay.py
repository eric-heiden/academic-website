# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, and ``Example`` drives every world with the logged commands as joint position
targets, open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Scene (fitted to photos/, camera.json, and the episode): three fruits as free bodies on the table
(a pear of two spheres lying on its side, an orange, and a dark round fruit; start poses from the top
camera and the arm kinematics at each grasp, sizes from the gripper openings at the grasps) and the
wedge-shaped wooden tray as static boxes: a circular sector fit to the tray's silhouette, with a thin
floor, low walls, rim bands that rise toward the outline and a ramp in the rounded tip (a shallow dish,
slightly tilted, so released fruits roll together toward the -x side as the real ones did). The arms
use stiffer servos with partial gravity compensation (the real arms sag below their commands), a
0.1 s command latency, and the grippers a stiffer finger servo with a 15 N squeeze limit.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.1,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}

TABLE_Z = 0.75  # table top [m]

# Fruits, from the top camera at the start (photos/01_top.jpg) and the grasps (wrist photos, gripper
# openings, and the arm kinematics at each grasp). Each fruit: start xy [m], yaw [rad], mass [kg], and
# collision spheres (body-frame xyz and radius [m]); the body origin is the centre of mass.
FRUITS = {
    "pear": {
        "xy": (0.6490, 0.3330),
        "yaw": -1.06,  # the body x axis points from the bulb toward the stem
        "mass": 0.045,
        "spheres": (((-0.012, 0.0, 0.003), 0.026), ((0.021, 0.0, -0.004), 0.019)),
    },
    "orange": {"xy": (0.5025, -0.0560), "yaw": 0.0, "mass": 0.045, "spheres": (((0.0, 0.0, 0.0), 0.029),)},
    "dark_fruit": {"xy": (0.6470, -0.1880), "yaw": 0.0, "mass": 0.055, "spheres": (((0.0, 0.0, 0.0), 0.032),)},
}
FRUIT_MATERIAL = {"mu": 0.6, "mu_torsional": 0.001, "mu_rolling": 0.002, "restitution": 0.0}
INERTIA_SCALE = 1.25  # of a solid ellipsoid with the fruit's extents

# Wedge-shaped wooden tray (static): circular sector fit to its silhouette in photos/11_top.jpg.
TRAY = {
    "apex": (0.7773, -0.0575),
    "radius": 0.2435,
    "heading": 1.6494,  # direction from the apex to the middle of the arc [rad]
    "half_angle": 0.7023,  # [rad]
    "floor": 0.005,  # floor thickness [m]
    "wall_height": 0.025,  # above the table [m]
    "wall": 0.01,  # wall thickness [m]
    "inset": 0.006,  # walls inside the outline [m]
    "wall_start": 0.08,  # straight walls start this far from the apex [m]
    "tip_length": 0.09,  # the rounded tip: a ramp from the apex down to the floor over this distance [m] ...
    "tip_height": 0.025,  # ... rising this high above the floor at the apex [m]
    "rim_width": 0.06,  # the floor rises toward the outline over this band (a shallow dish) [m]
    "rim_slope": 0.2,  # [rad]
    "rim_width_left": 0.08,  # rim band along the straight edge on the -x side (heading + half_angle) [m]
    "tilt": 0.035,  # the tray sits tilted by this angle [rad] ...
    "tilt_dir": 2.8,  # ... downhill toward this world direction (mostly -x) [rad]
    "slices": 12,
    "arc_segments": 8,
    "mu": 0.4,
}

# Robot and contact settings (fitted to the episode's measured joints and gripper behaviour).
ROBOT = {
    "arm_kp_scale": 3.0,  # of the MJCF position gains (joints 1-6)
    "arm_kd_scale": 2.0,
    "arm_gravcomp": 0.5,
    "grip_kp": 1500.0,  # finger slide position gain [N/m]
    "grip_force": 15.0,  # squeeze force limit [N]
}
CONTACT = {
    "solref": (0.004, 1.0),  # time constant [s] and damping ratio of fruit, tray, pad, and table contacts
    "condim": 6,  # fruits: sliding, torsional, and rolling friction
}


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_tray(station)
    for name, fruit in FRUITS.items():
        add_fruit(station, name, fruit)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    tune_model(model)
    return model


def tune_model(model: newton.Model):
    """Arm and gripper drives and contact parameters, set on the model before the solver compiles it."""
    joints = [label.rsplit("/", 1)[-1] for label in model.joint_label]
    bodies = [label.rsplit("/", 1)[-1] for label in model.body_label]
    shapes = [label.rsplit("/", 1)[-1] for label in model.shape_label]
    dof = model.joint_qd_start.numpy()
    ke, kd = model.joint_target_ke.numpy(), model.joint_target_kd.numpy()
    effort = model.joint_effort_limit.numpy()
    for j, name in enumerate(joints):
        side, _, rest = name.partition("_")
        if side not in SIDES:
            continue
        if rest.startswith("joint"):
            ke[dof[j]] *= ROBOT["arm_kp_scale"]
            kd[dof[j]] *= ROBOT["arm_kd_scale"]
            effort[dof[j]] = 28.0 if int(rest[5:]) <= 3 else 10.0
        elif rest == "left_finger":
            ke[dof[j]] = ROBOT["grip_kp"]
            effort[dof[j]] = ROBOT["grip_force"]
    model.joint_target_ke.assign(ke)
    model.joint_target_kd.assign(kd)
    model.joint_effort_limit.assign(effort)
    mj = model.mujoco
    forcerange, forcelimited = mj.actuator_forcerange.numpy(), mj.actuator_forcelimited.numpy()
    has_forcerange = mj.actuator_has_forcerange.numpy()
    for a in range(len(forcerange)):
        if forcerange[a, 1] <= forcerange[a, 0]:  # the finger servos (unlimited in the MJCF)
            forcerange[a] = (-ROBOT["grip_force"], ROBOT["grip_force"])
            forcelimited[a] = has_forcerange[a] = 1
    mj.actuator_forcerange.assign(forcerange)
    mj.actuator_forcelimited.assign(forcelimited)
    mj.actuator_has_forcerange.assign(has_forcerange)
    gravcomp = mj.gravcomp.numpy()
    for b, name in enumerate(bodies):
        if any(name == f"{side}_link_{k}" for side in SIDES for k in range(2, 7)):
            gravcomp[b] = ROBOT["arm_gravcomp"]
    mj.gravcomp.assign(gravcomp)
    solref, mode, condim = mj.solref.numpy(), mj.solref_mode.numpy(), mj.condim.numpy()
    fruit_prefix = tuple(FRUITS)
    for i, name in enumerate(shapes):
        fruit = name.startswith(fruit_prefix)
        if fruit or name.startswith("tray") or name == "table_plane" or "f_down" in name:
            solref[i] = CONTACT["solref"]
            mode[i] = 1  # raw solref
        if fruit:
            condim[i] = CONTACT["condim"]
    mj.solref.assign(solref)
    mj.solref_mode.assign(mode)
    mj.condim.assign(condim)


def add_fruit(builder: newton.ModelBuilder, name: str, fruit: dict):
    """One fruit: a free body of spheres resting on the table, its centre of mass at the body origin."""
    spheres = fruit["spheres"]
    lo = np.min([np.asarray(p) - r for p, r in spheres], axis=0)
    hi = np.max([np.asarray(p) + r for p, r in spheres], axis=0)
    half = 0.5 * (hi - lo)
    m = fruit["mass"]
    inertia = INERTIA_SCALE * m / 5.0 * np.diag([half[1] ** 2 + half[2] ** 2, half[0] ** 2 + half[2] ** 2, half[0] ** 2 + half[1] ** 2])
    x, y = fruit["xy"]
    xform = wp.transform(wp.vec3(x, y, TABLE_Z - lo[2]), wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), fruit["yaw"]))
    body = builder.add_body(xform=xform, mass=m, inertia=wp.mat33(*inertia.ravel()), label=name, lock_inertia=True)
    cfg = newton.ModelBuilder.ShapeConfig(density=0.0, **FRUIT_MATERIAL)
    for k, (p, r) in enumerate(spheres):
        builder.add_shape_sphere(body, xform=wp.transform(wp.vec3(*p), wp.quat_identity()), radius=r, cfg=cfg, label=f"{name}_{k}")


def add_tray(builder: newton.ModelBuilder):
    """The tray as static boxes: floor slices, rim panels, a tip ramp, and low walls along the sector."""
    tr = TRAY
    ax, ay = tr["apex"]
    radius, heading, half, inset = tr["radius"], tr["heading"], tr["half_angle"], tr["inset"]
    cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=tr["mu"], mu_torsional=0.001, mu_rolling=0.001)
    up = wp.vec3(0.0, 0.0, 1.0)
    # The whole tray tilts about a horizontal axis through the middle of its floor.
    pivot = wp.vec3(ax + 0.6 * radius * math.cos(heading), ay + 0.6 * radius * math.sin(heading), TABLE_Z)
    d = tr["tilt_dir"]
    tilt = wp.quat_from_axis_angle(wp.vec3(-math.sin(d), math.cos(d), 0.0), tr["tilt"])

    def add_box(xform, hx, hy, hz, label):
        p = wp.transform_get_translation(xform)
        q = wp.transform_get_rotation(xform)
        xform = wp.transform(pivot + wp.quat_rotate(tilt, p - pivot), tilt * q)
        builder.add_shape_box(-1, xform=xform, hx=hx, hy=hy, hz=hz, cfg=cfg, label=label)

    def box(cx, cy, cz, yaw, hx, hy, hz, label):
        add_box(wp.transform(wp.vec3(cx, cy, cz), wp.quat_from_axis_angle(up, yaw)), hx, hy, hz, label)

    floor_z = TABLE_Z + 0.5 * tr["floor"]
    top = TABLE_Z + tr["floor"]
    n = tr["slices"]
    r_in = radius - inset
    r0 = 0.05  # the tip ramp covers the narrow tip
    for k in range(n):
        a = heading - half + (k + 0.5) * 2.0 * half / n
        width = 2.0 * r_in * math.sin(half / n)
        rc = 0.5 * (r0 + r_in)
        box(ax + rc * math.cos(a), ay + rc * math.sin(a), floor_z, a, 0.5 * (r_in - r0), 0.5 * width, 0.5 * tr["floor"], f"tray_floor_{k}")

    # Rim panels: plates whose top rises from the floor at rim_width inside the wall to the wall.
    w, slope, th = tr["rim_width"], tr["rim_slope"], 0.5 * tr["floor"]

    def panel(ex, ey, nx, ny, length, label, w=w):
        """Panel along the wall point (ex, ey) [m] with inward normal (nx, ny), the given length, and width w."""
        yaw = math.atan2(ny, nx) - 0.5 * math.pi  # local y inward
        q = wp.quat_from_axis_angle(up, yaw) * wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), -slope)
        normal = wp.quat_rotate(q, wp.vec3(0.0, 0.0, 1.0))
        d = 0.5 * w
        c = wp.vec3(ex + d * nx, ey + d * ny, top + d * math.tan(slope)) - normal * th
        add_box(wp.transform(c, q), 0.5 * length, 0.5 * w / math.cos(slope), th, label)

    # Tip ramp: a plate along the heading whose top falls from tip_height near the apex to the floor.
    r_a, r_b = 0.015, tr["tip_length"]
    ramp = math.atan2(tr["tip_height"], r_b - r_a)
    rm = 0.5 * (r_a + r_b)
    width = 2.0 * rm * math.tan(half) - 2.0 * inset
    q = wp.quat_from_axis_angle(up, heading) * wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), ramp)
    normal = wp.quat_rotate(q, wp.vec3(0.0, 0.0, 1.0))
    c = wp.vec3(ax + rm * math.cos(heading), ay + rm * math.sin(heading), top + 0.5 * tr["tip_height"]) - normal * th
    add_box(wp.transform(c, q), 0.5 * (r_b - r_a) / math.cos(ramp), 0.5 * width, th, "tray_tip")

    r_wall = radius - inset
    for sign in (-1.0, 1.0):
        a = heading + sign * half
        nx, ny = math.cos(a - sign * 0.5 * math.pi), math.sin(a - sign * 0.5 * math.pi)
        ws = tr["rim_width_left"] if sign > 0 else w
        s0 = ws / math.tan(2.0 * half)  # keeps the panel's inner corner inside the other wall
        s_mid = 0.5 * (s0 + r_wall)
        mx, my = ax + s_mid * math.cos(a) + inset * nx, ay + s_mid * math.sin(a) + inset * ny
        panel(mx, my, nx, ny, r_wall - s0, f"tray_rim_side_{int(sign > 0)}", ws)
    for k in range(tr["arc_segments"]):
        a = heading - half + (k + 0.5) * 2.0 * half / tr["arc_segments"]
        length = 2.0 * r_wall * math.sin(half / tr["arc_segments"]) + 0.004
        panel(ax + r_wall * math.cos(a), ay + r_wall * math.sin(a), -math.cos(a), -math.sin(a), length, f"tray_rim_arc_{k}")
    wall_z, wall_hz, wt = TABLE_Z + 0.5 * tr["wall_height"], 0.5 * tr["wall_height"], tr["wall"]
    for sign in (-1.0, 1.0):
        a = heading + sign * half
        nx, ny = math.cos(a - sign * 0.5 * math.pi), math.sin(a - sign * 0.5 * math.pi)  # inward normal
        off = inset + 0.5 * wt
        s0 = tr["wall_start"]  # the rounded tip has only the rim panels
        cx = ax + 0.5 * (s0 + r_in) * math.cos(a) + off * nx
        cy = ay + 0.5 * (s0 + r_in) * math.sin(a) + off * ny
        box(cx, cy, wall_z, a, 0.5 * (r_in - s0), 0.5 * wt, wall_hz, f"tray_side_{int(sign > 0)}")
    m = tr["arc_segments"]
    r_mid = radius - inset - 0.5 * wt
    for k in range(m):
        a = heading - half + (k + 0.5) * 2.0 * half / m
        length = 2.0 * r_mid * math.sin(half / m) + 0.004
        box(ax + r_mid * math.cos(a), ay + r_mid * math.sin(a), wall_z, a, 0.5 * wt, 0.5 * length, wall_hz, f"tray_arc_{k}")


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=False, cone="elliptic", impratio=1.0)


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return newton.CollisionPipeline(model)


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
