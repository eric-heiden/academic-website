# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, and ``Example`` drives every world with the logged commands as joint position
targets, open loop.

The offline fit is stored below: three passive fruit bodies, a static wooden tray,
and the arm response parameters. Building the scene does not require the photos or
the calibration logs.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.035,  # latency from a logged command to the joint targets [s]
    "dt": 0.001,  # physics step [s]
}


# Geometry comes from the calibrated top and wrist views; masses and contact
# parameters are effective rigid-body fits. Dimensions below are radii in meters.
FRUITS = (
    dict(
        name="pear", position=(0.649, 0.336, 0.778),
        radii=(0.043, 0.027, 0.028), mass=0.035,
        yaw=-1.0, color=(0.83, 0.67, 0.035),
    ),
    dict(
        name="orange", position=(0.501, -0.053, 0.777),
        radii=(0.030, 0.030, 0.027), mass=0.120,
        yaw=0.0, color=(0.95, 0.23, 0.018),
    ),
    dict(
        name="dark_fruit", position=(0.646, -0.187, 0.783),
        radii=(0.036, 0.034, 0.033), mass=0.095,
        yaw=0.0, color=(0.11, 0.035, 0.017),
    ),
)
# Floor inclination fitted to the motion after release.
TRAY_SLOPE = 0.10
TRAY_CROSS_SLOPE = -0.01

# Shared YAM servo fit, in joint order. The last gravity-compensation value
# applies to the fingers and wrist camera assembly.
ARM_KP = (65.878449, 61.888, 74.199546, 10.208067, 6.964761, 4.89201)
ARM_KD = (2.85876, 2.765879, 3.192832, 1.189535, 0.930209, 0.685669)
ARM_ARMATURE = (0.049526, 0.000363, 0.022454, 0.0001, 0.0001, 0.000559)
ARM_FRICTION = (0.527586, 1.58146, 1.738867, 0.231838, 0.058875, 0.046127)
ARM_GRAVCOMP = (0.995, 0.985804, 0.507852, 0.995127, 0.812269, 0.65534, 0.73306)


def add_objects(builder):
    material = newton.ModelBuilder.ShapeConfig(
        density=0.0, mu=0.80, mu_torsional=0.003,
        mu_rolling=0.0015, margin=0.0, gap=0.003,
    )
    for fruit in FRUITS:
        material.mu_rolling = {"pear": 0.0006, "orange": 0.0015, "dark_fruit": 0.004}[fruit["name"]]
        r = np.asarray(fruit["radii"])
        inertia = fruit["mass"] / 5.0 * (np.sum(r * r) - r * r)
        body = builder.add_body(
            xform=wp.transform(
                fruit["position"], wp.quat_from_axis_angle(wp.vec3(0, 0, 1), fruit["yaw"])
            ),
            mass=fruit["mass"], inertia=wp.mat33(np.diag(inertia)),
            lock_inertia=True, label=fruit["name"],
        )
        if fruit["name"] == "pear":
            # A single convex surface joins the bulb and tapered neck.
            vertices, triangles = [], []
            for offset, radii in [
                ((-0.010, 0.0, 0.0), (0.029, 0.027, 0.028)),
                ((0.023, 0.0, 0.002), (0.025, 0.017, 0.020)),
            ]:
                first = len(vertices)
                for i in range(13):
                    theta = math.pi * i / 12
                    for j in range(16):
                        phi = 2 * math.pi * j / 16
                        vertices.append((
                            offset[0] + radii[0] * math.cos(theta),
                            offset[1] + radii[1] * math.sin(theta) * math.cos(phi),
                            offset[2] + radii[2] * math.sin(theta) * math.sin(phi),
                        ))
                for i in range(12):
                    for j in range(16):
                        a, b = first + i * 16 + j, first + i * 16 + (j + 1) % 16
                        triangles.extend([a, a + 16, b, b, a + 16, b + 16])
            builder.add_shape_convex_hull(
                body, mesh=newton.Mesh(vertices=vertices, indices=triangles),
                cfg=material, color=fruit["color"], label="pear_surface",
            )
        else:
            builder.add_shape_ellipsoid(body, rx=r[0], ry=r[1], rz=r[2], cfg=material, color=fruit["color"])

    # Shallow wooden circular-sector tray: one convex floor and a segmented rim.
    apex = np.array([0.920, 0.140])
    angles = np.linspace(math.radians(169), math.radians(232), 19)
    outline = np.vstack([apex, apex + 0.222 * np.c_[np.cos(angles), np.sin(angles)]])
    vertices = np.vstack([
        np.c_[outline, np.full(len(outline), 0.750)],
        np.c_[outline, 0.751 + TRAY_SLOPE * (outline[:, 0] - 0.695)
              + TRAY_CROSS_SLOPE * (outline[:, 1] - 0.14)],
    ])
    n = len(outline)
    faces = []
    for i in range(1, n - 1):
        faces.extend([0, i + 1, i, n, n + i, n + i + 1])
    for i in range(n):
        j = (i + 1) % n
        faces.extend([i, j, n + j, i, n + j, n + i])
    wood = newton.ModelBuilder.ShapeConfig(
        density=0.0, mu=0.80, mu_torsional=0.003,
        mu_rolling=0.0001, gap=0.003,
    )
    builder.add_shape_convex_hull(
        -1, mesh=newton.Mesh(vertices=vertices, indices=faces),
        cfg=wood, color=(0.60, 0.36, 0.15), label="tray_floor",
    )
    for i in range(n):
        a, b = outline[i], outline[(i + 1) % n]
        direction = b - a
        centre = (a + b) * 0.5
        length = float(np.linalg.norm(direction))
        pitch = -math.atan((TRAY_SLOPE * direction[0] + TRAY_CROSS_SLOPE * direction[1]) / length)
        rim_z = 0.751 + TRAY_SLOPE * (centre[0] - 0.695) + TRAY_CROSS_SLOPE * (centre[1] - 0.14) + 0.005
        builder.add_shape_box(
            -1, xform=wp.transform(
                (centre[0], centre[1], rim_z),
                wp.quat_rpy(0.0, pitch, math.atan2(direction[1], direction[0])),
            ),
            hx=length / (2.0 * math.cos(pitch)) + 0.001, hy=0.003, hz=0.007,
            cfg=wood, color=(0.66, 0.41, 0.19), label=f"tray_rim_{i}",
        )


def build_model(num_worlds: int = 1) -> newton.Model:
    """Calibrated station and three passive fruits in identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_objects(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    ke, kd = model.joint_target_ke.numpy(), model.joint_target_kd.numpy()
    effort = model.joint_effort_limit.numpy()
    armature = model.joint_armature.numpy()
    friction = model.joint_friction.numpy()
    dof = model.joint_qd_start.numpy()
    for i, label in enumerate(model.joint_label):
        name = label.rsplit("/", 1)[-1]
        for side in SIDES:
            if name.startswith(side+"_joint"):
                k = int(name[-1])-1
                ke[dof[i]], kd[dof[i]] = ARM_KP[k], ARM_KD[k]
                effort[dof[i]] = 28. if k < 3 else 10.
                armature[dof[i]] = ARM_ARMATURE[k]
                friction[dof[i]] = ARM_FRICTION[k]
            elif name == side+"_left_finger":
                ke[dof[i]], kd[dof[i]], effort[dof[i]] = 800., 14., 10.
    model.joint_target_ke.assign(ke)
    model.joint_target_kd.assign(kd)
    model.joint_effort_limit.assign(effort)
    model.joint_armature.assign(armature)
    model.joint_friction.assign(friction)
    gravcomp = model.mujoco.gravcomp.numpy()
    for i, label in enumerate(model.body_label):
        name = label.rsplit("/", 1)[-1]
        for side in SIDES:
            if name in [f"{side}_link_{k+1}" for k in range(6)]:
                gravcomp[i] = ARM_GRAVCOMP[int(name[-1])-1]
            elif name.startswith(side+"_") and name.endswith(("finger", "lf_rot", "rf_rot", "lf_down", "rf_down", "camera_frame", "camera_d405")):
                gravcomp[i] = ARM_GRAVCOMP[6]
    model.mujoco.gravcomp.assign(gravcomp)
    # All contact settings remain in the model, including raw positive solref.
    sr = model.mujoco.solref.numpy()
    sr[:] = (0.008, 1.5)
    model.mujoco.solref.assign(sr)
    model.mujoco.solref_mode.fill_(1)
    model.mujoco.cone.fill_(1)
    condim = model.mujoco.condim.numpy()
    shape_body = model.shape_body.numpy()
    mu = model.shape_material_mu.numpy()
    torsional = model.shape_material_mu_torsional.numpy()
    rolling = model.shape_material_mu_rolling.numpy()
    for i, b in enumerate(shape_body):
        if b >= 0 and ("left_arm" in model.body_label[b] or "right_arm" in model.body_label[b]):
            mu[i], torsional[i] = 1.3, 0.005
            rolling[i] = 0.0003 if condim[i] >= 6 else 0.0001
    model.shape_material_mu.assign(mu)
    model.shape_material_mu_torsional.assign(torsional)
    model.shape_material_mu_rolling.assign(rolling)
    for i, label in enumerate(model.shape_label):
        b = shape_body[i]
        if "tray_" in label or (b >= 0 and model.body_label[b].rsplit("/", 1)[-1] in ("pear", "orange", "dark_fruit")):
            condim[i] = 6
    model.mujoco.condim.assign(condim)
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(
        model, use_mujoco_contacts=True, cone="elliptic",
        iterations=40, ls_iterations=30, nconmax=6000, njmax=2400,
    )


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """MuJoCo performs collision detection for this scene."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
