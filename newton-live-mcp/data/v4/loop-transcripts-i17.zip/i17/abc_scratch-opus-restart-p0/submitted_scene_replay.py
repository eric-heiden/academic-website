# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) with the episode's scene, three
fake fruits (a pear, an orange, and a dark round fruit) and the wedge-shaped wooden tray
they are put into, in ``num_worlds`` identical worlds, and ``Example`` drives every world
with the logged commands as joint position targets, open loop. The arm servos, the
gripper, the command delay, and the scene are fitted to the logs and the photos
(``PARAMS``, ``ARM``, ``GRIPPER``, ``FRUITS``, ``TRAY``).

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.04,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}

# Arm servos fitted to the episode's measured joints: gain scale on the MJCF kp (kv scales with its
# square root), effort limits [N m], and gravity compensation of link 2 and of links 3-6.
ARM = {"kp_scale": 1.5, "effort": (28.0, 28.0, 28.0, 10.0, 10.0, 10.0), "gravcomp_link2": 0.9, "gravcomp_distal": 0.8}
# Gripper: finger slide position gain [N/m] and squeeze force limit [N] (the MJCF's damping stays).
GRIPPER = {"kp": 1000.0, "force": 20.0}

# Fruits: centre (x, y) on the table [m], yaw of the first semi-axis [rad], semi-axes [m], mass [kg], and
# optionally their own rolling friction [m]. Each one starts where the replayed gripper closes on it, within
# 2 cm of where the top camera saw it (photos/01_top.jpg: pear (0.645, 0.343), orange (0.496, -0.042), dark
# fruit (0.632, -0.175)). Their widths across the fingers match the measured gripper openings while held
# (0.53, 0.60, 0.72) and their sizes in the photos (pear about 72 x 59 mm, orange 64 mm, dark fruit 77 mm);
# the pear lies across the fingers, as the left wrist camera shows it (photos/03_left_wrist.jpg).
FRUITS = (
    {"name": "pear", "xy": (0.6495, 0.3375), "yaw": -0.485, "semi": (0.036, 0.0295, 0.0295), "mass": 0.06},
    {"name": "orange", "xy": (0.4948, -0.0496), "yaw": 0.0, "semi": (0.032, 0.032, 0.030), "mass": 0.07},
    {"name": "dark_fruit", "xy": (0.6450, -0.1850), "yaw": 0.0, "semi": (0.0385, 0.0385, 0.0385), "mass": 0.08, "mu_rolling": 0.005},
)
# Soft fake fruit: no bounce, some rolling resistance (condim 6 turns on torsional and rolling friction).
FRUIT_MATERIAL = {"mu": 1.0, "mu_torsional": 0.01, "mu_rolling": 0.003, "restitution": 0.0, "condim": 6}

# Wedge tray: a circular sector fitted to its silhouette in the top camera (apex (0.936, 0.148), radius 0.251 m,
# edges at 167.4 and 230.2 degrees in photos/01_top.jpg; it ends about 1.4 cm toward -x and 3 degrees turned in
# photos/11_top.jpg). The model spans both poses, with its edges a little outside the fit so that the fruits,
# released near the edges, land on the floor. Its floor is flat where the pear and the dark fruit were released
# and settled, and rises toward the apex, where the orange was released before it rolled about 9 cm toward
# the arc (photos/04, 09, 10, 11_top.jpg). It collides with the fruits only.
TRAY = {
    "apex": (0.932, 0.150),  # sector apex on the table [m]
    "radius": 0.253,  # [m]
    "start": math.radians(164.5),  # direction of the first straight edge [rad]
    "angle": math.radians(69.0),  # opening angle [rad]
    "floor": 0.008,  # floor thickness at the arc's lowest point [m]
    "slope": math.radians(8.0),  # slope of the floor's ramp toward the apex [rad]
    "ramp": (0.80, 0.10),  # a point on the line where the ramp starts [m]
    "ramp_dir": math.radians(15.0),  # uphill direction of the ramp [rad]
    "rim": 0.035,  # rim height above the table [m]
    "bulge": 0.015,  # outward offset of the first edge's rim near the apex [m]
    "bulge_end": 0.15,  # distance from the apex where that offset ends [m]
    "wall": 0.006,  # rim thickness [m]
    "mu": 0.6,
}
TABLE_Z = 0.75


def _yaw(angle: float) -> wp.quat:
    return wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), angle)


def _tune_station(station: newton.ModelBuilder):
    """Arm servos, gravity compensation, and gripper from ARM and GRIPPER."""
    names = [label.rsplit("/", 1)[-1] for label in station.joint_label]
    for j, name in enumerate(names):
        dof = station.joint_qd_start[j]
        for side in SIDES:
            for k in range(6):
                if name == f"{side}_joint{k + 1}":
                    station.joint_target_ke[dof] *= ARM["kp_scale"]
                    station.joint_target_kd[dof] *= math.sqrt(ARM["kp_scale"])
                    station.joint_effort_limit[dof] = ARM["effort"][k]
            if name == f"{side}_left_finger":
                station.joint_target_ke[dof] = GRIPPER["kp"]
                station.joint_effort_limit[dof] = GRIPPER["force"]
    gravcomp = station.custom_attributes["mujoco:gravcomp"].values
    for b, label in enumerate(station.body_label):
        name = label.rsplit("/", 1)[-1]
        if name.endswith("link_2"):
            gravcomp[b] = ARM["gravcomp_link2"]
        elif any(name.endswith(f"link_{k}") for k in (3, 4, 5, 6)):
            gravcomp[b] = ARM["gravcomp_distal"]


def _add_fruits(builder: newton.ModelBuilder):
    for i, fruit in enumerate(FRUITS):
        a, b, c = fruit["semi"]
        cfg = newton.ModelBuilder.ShapeConfig(
            density=fruit["mass"] / (4.0 / 3.0 * math.pi * a * b * c),
            mu=FRUIT_MATERIAL["mu"],
            mu_torsional=FRUIT_MATERIAL["mu_torsional"],
            mu_rolling=fruit.get("mu_rolling", FRUIT_MATERIAL["mu_rolling"]),
            restitution=FRUIT_MATERIAL["restitution"],
            gap=0.01,
            collision_group=-1 - i,  # own negative group: collides with everything, including the other fruits
        )
        x, y = fruit["xy"]
        body = builder.add_body(xform=wp.transform(wp.vec3(x, y, TABLE_Z + c), _yaw(fruit["yaw"])), label=fruit["name"])
        builder.add_shape_ellipsoid(
            body, rx=a, ry=b, rz=c, cfg=cfg, label=f"{fruit['name']}_shape",
            custom_attributes={"mujoco:condim": FRUIT_MATERIAL["condim"]},
        )


def _add_tray(builder: newton.ModelBuilder):
    """Static tray shapes; they collide with the fruits only (not with the robot)."""
    cfg = newton.ModelBuilder.ShapeConfig(mu=TRAY["mu"], gap=0.01, collision_group=2, density=0.0)
    ax, ay = TRAY["apex"]
    R, a0, th, wall = TRAY["radius"], TRAY["start"], TRAY["angle"], TRAY["wall"]
    floor_hz, rim_hz = 0.5 * TRAY["floor"], 0.5 * TRAY["rim"]
    # floor: strips across the ramp direction; flat (``floor`` thick) up to the line through ``ramp`` across that
    # direction, from there rising toward the apex with the given slope (the real orange, released near the apex,
    # rolled toward the arc before it settled)
    slope = math.tan(TRAY["slope"])
    phi = TRAY["ramp_dir"]
    e_s = np.array([math.cos(phi), math.sin(phi)])  # uphill
    e_t = np.array([-e_s[1], e_s[0]])
    pts = np.array([ax, ay]) + np.array(
        [[r * math.cos(a), r * math.sin(a)] for r in np.linspace(0.0, R, 120) for a in np.linspace(a0, a0 + th, 120)]
    )
    s_pts, t_pts = pts @ e_s, pts @ e_t
    s_ramp = float(np.dot(TRAY["ramp"], e_s))
    edges = np.concatenate([np.linspace(s_pts.min() + 0.01, s_ramp, 7), np.linspace(s_ramp, s_pts.max() - 0.01, 6)[1:]])
    for s0, s1 in zip(edges[:-1], edges[1:]):
        # the strip spans the narrower end of its band, so that it stays inside the sector
        ends = [t_pts[np.abs(s_pts - s) < 0.004] for s in (s0, s1)]
        t0, t1 = max(e.min() for e in ends), min(e.max() for e in ends)
        sm = 0.5 * (s0 + s1)
        c = e_s * sm + e_t * 0.5 * (t0 + t1)
        k = slope if sm > s_ramp else 0.0
        normal = wp.normalize(wp.vec3(-k * e_s[0], -k * e_s[1], 1.0))
        top = TRAY["floor"] + k * (sm - s_ramp)
        centre = wp.vec3(c[0], c[1], TABLE_Z + top) - normal * floor_hz
        rot = wp.quat_between_vectors(wp.vec3(0.0, 0.0, 1.0), normal) * _yaw(phi)
        builder.add_shape_box(
            -1, xform=wp.transform(centre, rot),
            hx=0.5 * (s1 - s0) * math.sqrt(1.0 + k * k), hy=0.5 * (t1 - t0), hz=floor_hz, cfg=cfg,
            label=f"tray_floor_{len(builder.shape_type)}",
        )
    # straight rims along both radii; the apex half of the first one sits ``bulge`` farther out
    r_in = 0.03  # no rim in the apex corner
    for ang, side, pieces in ((a0, 1.0, ((r_in, TRAY["bulge_end"], TRAY["bulge"]), (TRAY["bulge_end"], R, 0.0))),
                              (a0 + th, -1.0, ((r_in, R, 0.0),))):
        d = np.array([math.cos(ang), math.sin(ang)])
        n = np.array([-d[1], d[0]]) * side  # inward normal
        for r0, r1, out in pieces:
            c = np.array([ax, ay]) + d * 0.5 * (r0 + r1) + n * (0.5 * wall - out)
            builder.add_shape_box(
                -1, xform=wp.transform(wp.vec3(c[0], c[1], TABLE_Z + rim_hz), _yaw(ang)),
                hx=0.5 * (r1 - r0), hy=0.5 * wall, hz=rim_hz, cfg=cfg, label=f"tray_rim_{len(builder.shape_type)}",
            )
    # arc rim in segments
    segments = 6
    for i in range(segments):
        ang = a0 + (i + 0.5) * th / segments
        d = np.array([math.cos(ang), math.sin(ang)])
        c = np.array([ax, ay]) + d * (R - 0.5 * wall)
        half_len = (R - 0.5 * wall) * math.tan(0.5 * th / segments) + 0.5 * wall
        builder.add_shape_box(
            -1, xform=wp.transform(wp.vec3(c[0], c[1], TABLE_Z + rim_hz), _yaw(ang)),
            hx=0.5 * wall, hy=half_len, hz=rim_hz, cfg=cfg, label=f"tray_arc_{len(builder.shape_type)}",
        )


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station with the fruits and the tray in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    _tune_station(station)
    _add_tray(station)
    _add_fruits(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    return builder.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=False, cone="elliptic", impratio=1.0)


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return newton.CollisionPipeline(model)


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
