# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) in ``num_worlds`` identical
worlds, and ``Example`` drives every world with the logged commands as joint position
targets, open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.0,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}


# Scene fitted to the recording (world coordinates, meters). Fruit start positions come from the top camera
# (photos/01_top.jpg) and the forward kinematics of the measured joints at each grasp; sizes from the
# measured gripper openings at the grasps and the top-camera silhouettes.
FRUIT_MATERIAL = {"mu": 1.0, "mu_torsional": 0.01, "mu_rolling": 0.0025, "restitution": 0.0, "gap": 0.02}
FRUITS = {
    # pear lying on its side: a bulb and a neck sphere along its axis (bulb -> stem)
    # (a box core 1.5 mm inside the bulb's surface keeps the lumpy real pear from rolling about its axis)
    "pear": {"mass": 0.045, "pos": (0.648, 0.336), "axis": (0.518, -0.856), "spheres": ((0.0, 0.027), (0.031, 0.0185)),
             "core": 0.0015, "material": {"mu": 0.2, "mu_rolling": 0.005, "mu_torsional": 0.02}},
    "orange": {"mass": 0.05, "pos": (0.500, -0.053), "spheres": ((0.0, 0.0295),)},
    "dark_fruit": {"mass": 0.055, "pos": (0.648, -0.186), "spheres": ((0.0, 0.0345),)},
}
# Wedge tray: a circular sector (apex, radius, directions of its two straight sides) fitted to its silhouette
# in the top camera; a thin floor plate and a low rim.
# The floor is a shallow trough, lowest along x = ``valley_x`` and rising by ``slopes`` toward the apex and
# toward the arc: the real fruits came to rest in a row across the tray at x = 0.72 to 0.77 m, the orange after
# rolling out of the narrow apex corner where it was released and pushing the pear ahead of it.
TRAY = {"apex": (0.926, 0.150), "radius": 0.252, "sides": (math.radians(-191.5), math.radians(-126.0)),
        "floor": 0.006, "valley_x": 0.745, "slopes": (0.26, 0.2), "ramp_top": 0.039, "ramp_end_x": 0.89,
        "rim_height": 0.039, "rim_width": 0.008, "arc_segments": 8, "mu": 0.2}
TABLE_Z = 0.75
GRIPPER_FORCE = 40.0  # squeeze force limit of the gripper servos [N] (above what the 400 N/m servo reaches)


def _quat_z(angle: float) -> wp.quat:
    return wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), float(angle))


def add_fruits(builder: newton.ModelBuilder):
    attrs = {"mujoco:condim": 6}
    for name, spec in FRUITS.items():
        cfg = newton.ModelBuilder.ShapeConfig(density=0.0, **{**FRUIT_MATERIAL, **spec.get("material", {})})
        spheres = spec["spheres"]
        r0 = spheres[0][1]
        if len(spheres) == 1:
            rot = wp.quat_identity()
            half = (r0, r0, r0)
        else:
            # tilt the axis so both spheres touch the table
            (o0, r0), (o1, r1) = spheres
            tilt = math.asin((r0 - r1) / (o1 - o0))
            yaw = math.atan2(spec["axis"][1], spec["axis"][0])
            rot = _quat_z(yaw) * wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), tilt)
            length = (o1 - o0) + r0 + r1
            half = (0.5 * length, r0, r0)
        # body origin at the centre of the collision geometry (centre of mass)
        lo = min(o - r for (o, r) in spheres)
        hi = max(o + r for (o, r) in spheres)
        centre = 0.5 * (lo + hi)
        a, b, c = half
        m = spec["mass"]
        k = 0.25  # between a solid (0.2) and a thin-shell (1/3) ellipsoid
        inertia = wp.mat33(k * m * (b * b + c * c), 0.0, 0.0, 0.0, k * m * (a * a + c * c), 0.0, 0.0, 0.0, k * m * (a * a + b * b))
        p0 = wp.quat_rotate(rot, wp.vec3(spheres[0][0] - centre, 0.0, 0.0))
        pos = wp.vec3(spec["pos"][0] - p0[0], spec["pos"][1] - p0[1], TABLE_Z + r0 + 0.0005 - p0[2])
        body = builder.add_body(xform=wp.transform(pos, rot), mass=m, inertia=inertia, lock_inertia=True, label=name)
        for (o, r) in spheres:
            builder.add_shape_sphere(body, xform=wp.transform(wp.vec3(o - centre, 0.0, 0.0), wp.quat_identity()),
                                     radius=r, cfg=cfg, custom_attributes=attrs)
        if "core" in spec:
            # level with the table in the resting pose
            core = r0 - spec["core"]
            level = wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), -tilt)
            builder.add_shape_box(body, xform=wp.transform(wp.vec3(spheres[0][0] - centre, 0.0, 0.0), level),
                                  hx=0.5 * r0, hy=core, hz=core, cfg=cfg, custom_attributes=attrs)


def add_tray(builder: newton.ModelBuilder):
    cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=TRAY["mu"], mu_torsional=0.01, mu_rolling=0.0025, gap=0.02)
    attrs = {"mujoco:condim": 6}
    ax, ay = TRAY["apex"]
    R, (a0, a1) = TRAY["radius"], TRAY["sides"]
    th, al = 0.5 * (a0 + a1), 0.5 * (a1 - a0)
    w, h, f = TRAY["rim_width"], TRAY["rim_height"], TRAY["floor"]

    def prism(pts, top, label):
        """Convex prism from the table up to ``top(x, y)`` over a convex polygon (counter-clockwise)."""
        m = len(pts)
        verts = [(x - ax, y - ay, 0.0) for (x, y) in pts] + [(x - ax, y - ay, top(x, y)) for (x, y) in pts]
        tris = []
        for i in range(1, m - 1):
            tris += [0, i + 1, i, m, m + i, m + i + 1]
        for i in range(m):
            j = (i + 1) % m
            tris += [i, j, m + j, i, m + j, m + i]
        hull = newton.Mesh(np.asarray(verts, dtype=np.float32), np.asarray(tris, dtype=np.int32), compute_inertia=False)
        builder.add_shape_convex_hull(-1, xform=wp.transform(wp.vec3(ax, ay, TABLE_Z), wp.quat_identity()),
                                      mesh=hull, cfg=cfg, custom_attributes=attrs, label=label)

    def clip(poly, sign, x_cut):
        """The part of a convex polygon with sign * (x - x_cut) >= 0."""
        out = []
        for i, p in enumerate(poly):
            q = poly[(i + 1) % len(poly)]
            dp, dq = sign * (p[0] - x_cut), sign * (q[0] - x_cut)
            if dp >= 0.0:
                out.append(p)
            if dp * dq < 0.0:
                u = dp / (dp - dq)
                out.append((p[0] + u * (q[0] - p[0]), p[1] + u * (q[1] - p[1])))
        return out

    # floor plate over the sector polygon (without the apex tip)
    cut = 0.03
    pts = [(ax + cut * math.cos(th + al), ay + cut * math.sin(th + al)), (ax + cut * math.cos(th - al), ay + cut * math.sin(th - al))]
    pts += [(ax + R * math.cos(th + t), ay + R * math.sin(th + t)) for t in np.linspace(-al, al, 12)]
    prism(pts, lambda x, y: f, "tray_floor")
    # trough walls: ramps up from the valley toward the apex corner and toward the arc
    xv, (s_apex, s_arc) = TRAY["valley_x"], TRAY["slopes"]
    top = TRAY["ramp_top"]  # the ramp levels off at this height in the apex corner
    xk = xv + (top - f) / s_apex
    prism(clip(clip(pts, 1.0, xv), -1.0, xk), lambda x, y: f + s_apex * (x - xv), "tray_ramp_apex")
    prism(clip(clip(pts, 1.0, xk), -1.0, TRAY["ramp_end_x"]), lambda x, y: top, "tray_ramp_top")
    prism(clip(pts, -1.0, xv), lambda x, y: f + s_arc * (xv - x), "tray_ramp_arc")
    zc = TABLE_Z + 0.5 * h
    # straight sides
    for sgn in (-1.0, 1.0):
        d = th + sgn * al
        nx, ny = -sgn * math.sin(d), sgn * math.cos(d)  # outward normal
        L = R - 0.02
        cx = ax + 0.5 * (R + 0.02) * math.cos(d) - 0.5 * w * nx
        cy = ay + 0.5 * (R + 0.02) * math.sin(d) - 0.5 * w * ny
        builder.add_shape_box(-1, xform=wp.transform(wp.vec3(cx, cy, zc), _quat_z(d)), hx=0.5 * L, hy=0.5 * w, hz=0.5 * h,
                              cfg=cfg, custom_attributes=attrs)
    # arc
    k = TRAY["arc_segments"]
    seg = 2 * al / k
    for i in range(k):
        t = th - al + (i + 0.5) * seg
        rc = R - 0.5 * w
        hx = rc * math.tan(0.5 * seg) + 0.5 * w
        builder.add_shape_box(-1, xform=wp.transform(wp.vec3(ax + rc * math.cos(t), ay + rc * math.sin(t), zc), _quat_z(t)),
                              hx=0.5 * w, hy=hx, hz=0.5 * h, cfg=cfg, custom_attributes=attrs)


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station with the fruits and the tray in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_tray(station)
    add_fruits(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    # explicit squeeze force limit on the gripper actuators (the MJCF leaves it unlimited)
    grippers = [i for i, label in enumerate(model.mujoco.actuator_label) if label.endswith("_gripper")]
    for name, value in (("actuator_forcerange", (-GRIPPER_FORCE, GRIPPER_FORCE)), ("actuator_has_forcerange", 1),
                        ("actuator_forcelimited", 1)):
        array = getattr(model.mujoco, name)
        values = array.numpy()
        values[grippers] = value
        array.assign(values)
    names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
    qd_start, effort = model.joint_qd_start.numpy(), model.joint_effort_limit.numpy()
    for j, name in enumerate(names):
        if name.endswith("_left_finger") or name.endswith("_right_finger"):
            effort[qd_start[j]] = GRIPPER_FORCE
    model.joint_effort_limit.assign(effort)
    return model


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=False, cone="elliptic")


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return newton.CollisionPipeline(model)


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
