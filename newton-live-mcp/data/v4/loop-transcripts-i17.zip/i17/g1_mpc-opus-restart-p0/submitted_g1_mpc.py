# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 humanoid tracking a reference motion (starter for a controller).

The robot is the floating-base Unitree G1 with 29 actuated joints, standing on
the floor of its MJCF and simulated by SolverMuJoCo with 2 ms steps. A
controller runs at 100 Hz: every 10 ms it reads the robot's state and returns
one :class:`Command` for the next control period. Each joint actuator then
applies, at every 2 ms physics step,

    tau = clip(kp * (q - q_joint) + kd * (qd - qd_joint) + tau_ff, -limit, limit)

with the MJCF torque limit of its joint. The plant (``build_model``,
``make_solver``, :class:`Robot`) is fixed; the controller is the part to develop.

Reference motions are MuJoCo-qpos CSV clips at 30 fps: root position [m], root
quaternion (w, x, y, z), and the 29 joint angles [rad] in MJCF order. The robot
starts at rest at the clip's first frame with its feet 2 mm above the floor.

The :class:`Controller` is sampling-based model predictive control (MPPI): every
control period it branches a GPU batch of copies of the robot from the measured
state, rolls out perturbed joint-target plans, and keeps the cost-weighted mean.

Run: ``python g1_mpc.py --motion walk.csv --viewer null`` (the whole clip; ``--num-frames N``
runs N control periods) prints the tracking report.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
import warp as wp

import newton
import newton.examples

SIM_DT = 0.002  # physics step [s]
CONTROL_DT = 0.01  # control period [s] (100 Hz)
SUBSTEPS = round(CONTROL_DT / SIM_DT)
JOINT_COUNT = 29

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)

# Accepted actuator gains: kp [N m/rad] and kd [N m s/rad] per joint.
KP_RANGE = (1.0, 10000.0)
KD_RANGE = (0.0, 500.0)

# The robot has fallen when the root drops below this height [m], its up axis tilts more than 45 degrees
# (cosine below 0.7), or anything but the feet touches the floor.
FALL_HEIGHT_M = 0.55
FALL_UP_COS = 0.7
FEET = ("left_ankle_roll_link", "right_ankle_roll_link")
WRISTS = ("left_wrist_yaw_link", "right_wrist_yaw_link")
# Foot contact spheres (centres in the ankle roll link frame [m]) and their radius [m].
SOLE_POINTS = np.array([[-0.05, -0.025, -0.03], [-0.05, 0.025, -0.03], [0.12, -0.03, -0.03], [0.12, 0.03, -0.03]])
SOLE_RADIUS = 0.005
SOLE_CENTER = np.array([0.035, 0.0, -0.035])
LIFT_REFERENCE_M = 0.03  # lift recall: reference sole clearance above this [m] ...
LIFT_ROBOT_M = 0.02  # ... counts when the robot's sole clearance is above this [m]
JITTER_HZ = 6.0  # jitter: joint-error RMS above this frequency [Hz]


def asset_path() -> str:
    return str(newton.utils.download_asset("unitree_g1") / "mjcf/g1_29dof_rev_1_0.xml")


def build_model(joint_q: np.ndarray | None = None) -> newton.Model:
    """The G1 on the MJCF floor with torque-limited joint actuators, optionally posed at ``joint_q``."""
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    builder.add_mjcf(asset_path(), collapse_fixed_joints=True)
    # Robot self-collision is excluded; the feet and body still collide with the floor.
    robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
    for i, shape in enumerate(robot_shapes):
        for other in robot_shapes[i + 1 :]:
            builder.add_shape_collision_filter_pair(shape, other)
    builder.joint_armature[6:] = ARMATURE.tolist()
    # MuJoCo position servos whose gains and targets Robot.apply sets from each Command.
    builder.joint_target_ke[6:] = [100.0] * JOINT_COUNT
    builder.joint_target_kd[6:] = [2.0] * JOINT_COUNT
    builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * JOINT_COUNT
    builder.custom_attributes["mujoco:ctrl_source"].values = [
        int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
    ] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * JOINT_COUNT
    builder.custom_attributes["mujoco:actuator_forcerange"].values = [
        (-limit, limit) for limit in builder.joint_effort_limit[6:]
    ]
    if joint_q is not None:
        builder.joint_q[:] = np.asarray(joint_q, dtype=float).tolist()
    return builder.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverMuJoCo:
    return newton.solvers.SolverMuJoCo(
        model, njmax=192, nconmax=64, use_mujoco_contacts=True, integrator="implicitfast", iterations=50
    )


def quat_wxyz_to_xyzw(q: np.ndarray) -> np.ndarray:
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def body_index(model: newton.Model, name: str) -> int:
    return [label.rsplit("/", 1)[-1] for label in model.body_label].index(name)


class MotionClip:
    """A reference clip, linearly interpolated in time (root quaternion by normalized lerp).

    With a model, the clip is shifted vertically so that the lowest foot contact point of its first frame
    is 2 mm above the floor (the robot starts there).
    """

    def __init__(self, path, model: newton.Model | None = None, fps: float = 30.0):
        self.qpos = np.loadtxt(path, delimiter=",", ndmin=2)
        if self.qpos.shape[1] != 7 + JOINT_COUNT or len(self.qpos) < 2:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps
        self.z_offset = 0.0
        if model is not None:
            self.z_offset = floor_offset(model, self.sample(0.0))

    def sample(self, t: float) -> np.ndarray:
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time ``t`` [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        q[2] += self.z_offset
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


def floor_offset(model: newton.Model, joint_q: np.ndarray) -> float:
    """Vertical shift [m] that puts the lowest foot contact point of ``joint_q`` 2 mm above the floor."""
    state = model.state()
    newton.eval_fk(model, wp.array(joint_q, dtype=float, device=model.device), model.joint_qd, state)
    body_q = state.body_q.numpy().astype(np.float64)
    lowest = np.inf
    for name in FEET:
        pose = body_q[body_index(model, name)]
        points = pose[:3] + SOLE_POINTS @ _rotation(pose[3:7]).T
        lowest = min(lowest, float(points[:, 2].min()) - SOLE_RADIUS)
    return float(0.002 - lowest)


@dataclass
class Command:
    """Actuator command for one control period: per-joint arrays of 29 values in MJCF joint order (scalars
    broadcast). Each actuator applies ``clip(kp (q - q_joint) + kd (qd - qd_joint) + tau, -limit, limit)``
    at every physics step of the period."""

    q: np.ndarray
    """Position targets [rad]."""
    kp: np.ndarray | float
    """Stiffness [N m/rad], within KP_RANGE."""
    kd: np.ndarray | float
    """Damping [N m s/rad], within KD_RANGE."""
    qd: np.ndarray | float = 0.0
    """Velocity targets [rad/s]."""
    tau: np.ndarray | float = 0.0
    """Feedforward torques [N m]."""


def command_arrays(command) -> dict[str, np.ndarray]:
    """The command's fields as float64 arrays of 29 values; raises ValueError for invalid commands."""
    out = {}
    for name in ("q", "kp", "kd", "qd", "tau"):
        value = getattr(command, name, 0.0)
        value = np.broadcast_to(np.asarray(0.0 if value is None else value, dtype=np.float64), (JOINT_COUNT,))
        if not np.all(np.isfinite(value)):
            raise ValueError(f"Command.{name} is not finite")
        out[name] = value.copy()
    for name, (low, high) in (("kp", KP_RANGE), ("kd", KD_RANGE)):
        if np.any(out[name] < low) or np.any(out[name] > high):
            raise ValueError(f"Command.{name} must be within [{low:g}, {high:g}]")
    return out


class Robot:
    """The simulated G1 (the plant): model, solver, state, and the actuator command interface."""

    def __init__(self, start_q: np.ndarray):
        self.model = build_model(start_q)
        self.solver = make_solver(self.model)
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.effort_limit = self.model.joint_effort_limit.numpy()[6:].copy()
        # MuJoCo actuator -> actuated joint (0..28), for writing servo gains without a full model update.
        self._actuator_joint = self.solver.mjc_actuator_to_newton_idx.numpy() - 6
        self._gains = None
        self._target = self.model.joint_q.numpy().copy()
        self.graph = None
        self.capture()

    def capture(self):
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def simulate(self):
        """One control period of physics steps."""
        for i in range(SUBSTEPS):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, SIM_DT)
            if SUBSTEPS % 2 == 1 and i == SUBSTEPS - 1:
                self.state_0.assign(self.state_1)
            else:
                self.state_0, self.state_1 = self.state_1, self.state_0

    def apply(self, command) -> None:
        """Set the actuators from a :class:`Command` (the servo target absorbs qd and tau, which is exact)."""
        c = command_arrays(command)
        gains = np.concatenate([c["kp"], c["kd"]])
        if self._gains is None or not np.array_equal(gains, self._gains):
            ke, kd = self.model.joint_target_ke.numpy(), self.model.joint_target_kd.numpy()
            ke[6:], kd[6:] = c["kp"], c["kd"]
            self.model.joint_target_ke.assign(ke)
            self.model.joint_target_kd.assign(kd)
            # Same effect as solver.notify_model_changed(JOINT_DOF_PROPERTIES) on the servos, which is much slower.
            gain, bias = self.solver.mjw_model.actuator_gainprm, self.solver.mjw_model.actuator_biasprm
            gain_np, bias_np = gain.numpy(), bias.numpy()
            gain_np[:, :, 0] = c["kp"][self._actuator_joint]
            bias_np[:, :, 1] = -c["kp"][self._actuator_joint]
            bias_np[:, :, 2] = -c["kd"][self._actuator_joint]
            gain.assign(gain_np)
            bias.assign(bias_np)
            self._gains = gains
        self._target[7:] = c["q"] + (c["kd"] * c["qd"] + c["tau"]) / c["kp"]
        self.control.joint_target_q.assign(self._target)

    def advance(self):
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()


def _quat_angle(a: np.ndarray, b: np.ndarray) -> float:
    """Angle [rad] between two unit quaternions (xyzw)."""
    return float(2.0 * np.arccos(np.clip(abs(np.dot(a, b)), 0.0, 1.0)))


def _rotation(quat_xyzw: np.ndarray) -> np.ndarray:
    x, y, z, w = quat_xyzw / np.linalg.norm(quat_xyzw)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def foot_points(body_q: np.ndarray, foot: int) -> tuple[np.ndarray, float]:
    """Sole centre [m] and sole clearance above the floor [m] of a foot body."""
    rotation = _rotation(body_q[foot, 3:7])
    clearance = float(np.min((body_q[foot, :3] + SOLE_POINTS @ rotation.T)[:, 2]) - SOLE_RADIUS)
    return body_q[foot, :3] + rotation @ SOLE_CENTER, clearance


def jitter(errors: np.ndarray, dt: float, cutoff: float = JITTER_HZ, trim: float = 0.1) -> float:
    """RMS [rad] of the joint errors' content above ``cutoff`` [Hz] (zero-phase, ``trim`` [s] cut at both ends)."""
    k = round(trim / dt)
    errors = errors[k : len(errors) - k]
    if len(errors) < 16:
        return float("nan")
    errors = errors - errors.mean(axis=0)
    spectrum = np.fft.rfft(errors, axis=0)
    spectrum[np.fft.rfftfreq(len(errors), dt) <= cutoff] = 0.0
    return float(np.sqrt(np.mean(np.fft.irfft(spectrum, n=len(errors), axis=0) ** 2)))


class TrackingReport:
    """Tracking errors against a reference clip, sampled after every control period."""

    def __init__(self, robot: Robot, motion: MotionClip):
        self.robot, self.motion = robot, motion
        model = robot.model
        self.scratch = model.state()
        self.joint_q = wp.zeros(model.joint_coord_count, dtype=float, device=model.device)
        self.feet = [body_index(model, name) for name in FEET]
        self.wrists = [body_index(model, name) for name in WRISTS]
        mj = robot.solver.mj_model
        foot_ids = {i for i in range(mj.nbody) if mj.body(i).name.endswith(FEET)}
        # MuJoCo geoms that may touch the floor: those of the feet.
        self.foot_geom = np.array([int(mj.geom_bodyid[g]) in foot_ids for g in range(mj.ngeom)])
        self.robot_geom = np.array([int(mj.geom_bodyid[g]) != 0 for g in range(mj.ngeom)])
        self.rows = []
        self.fall_time = None
        self.fall_reason = None

    def non_foot_contact(self) -> bool:
        """Whether a robot geom other than the feet touches the floor."""
        data = self.robot.solver.mjw_data
        count = min(int(data.nacon.numpy()[0]), data.contact.geom.shape[0])
        if count == 0:
            return False
        geoms = data.contact.geom.numpy()[:count]
        touching = data.contact.dist.numpy()[:count] <= 0.0
        robot = self.robot_geom[geoms]
        other = robot & ~self.foot_geom[geoms]
        return bool(np.any(touching & other.any(axis=1)))

    def update(self, t: float, state: newton.State) -> bool:
        """Record the errors of ``state`` at time ``t`` [s]; returns whether the robot is still on its feet.

        Recording stops at a fall. Samples at or after ``t`` are dropped first (the clock was rewound)."""
        while self.rows and self.rows[-1]["t"] >= t - 1e-9:
            self.rows.pop()
        if self.fall_time is not None and self.fall_time >= t - 1e-9:
            self.fall_time = self.fall_reason = None
        if self.fall_time is not None:
            return False
        q = state.joint_q.numpy().astype(np.float64)
        body_q = state.body_q.numpy().astype(np.float64)
        ref = self.motion.sample(t)
        self.joint_q.assign(ref)
        newton.eval_fk(self.robot.model, self.joint_q, self.robot.model.joint_qd, self.scratch)
        ref_body_q = self.scratch.body_q.numpy().astype(np.float64)
        finite = bool(np.all(np.isfinite(q)) and np.all(np.isfinite(body_q)))
        quat = q[3:7] / np.linalg.norm(q[3:7]) if finite else ref[3:7]
        soles = [foot_points(body_q, f) for f in self.feet]
        ref_soles = [foot_points(ref_body_q, f) for f in self.feet]
        row = {
            "t": t,
            "finite": finite,
            "root_err": float(np.linalg.norm(q[:3] - ref[:3])),
            "root_rot_err": _quat_angle(quat, ref[3:7]),
            "joint_err": q[7:] - ref[7:],
            "wrist_err2": float(np.mean(np.sum((body_q[self.wrists, :3] - ref_body_q[self.wrists, :3]) ** 2, axis=1))),
            "sole_err2": float(np.mean([np.sum((a[0] - b[0]) ** 2) for a, b in zip(soles, ref_soles, strict=True)])),
            "lift": [(b[1] > LIFT_REFERENCE_M, a[1] > LIFT_ROBOT_M) for a, b in zip(soles, ref_soles, strict=True)],
        }
        self.rows.append(row)
        reason = None
        if not finite:
            reason = "state not finite"
        elif q[2] < FALL_HEIGHT_M:
            reason = f"root height {q[2]:.2f} m"
        elif _rotation(quat)[2, 2] < FALL_UP_COS:
            reason = "root tilted over"
        elif self.non_foot_contact():
            reason = "non-foot floor contact"
        if reason is not None:
            self.fall_time, self.fall_reason = t, reason
        return reason is None

    def summary(self) -> dict:
        """Metrics over the recorded samples, up to a fall (errors are infinite if the state stopped being finite)."""
        rows = self.rows
        finite = bool(rows) and all(r["finite"] for r in rows)
        inf = float("inf")

        def rms(values):
            return float(np.sqrt(np.mean(np.square(values)))) if finite else inf

        lifts = [robot for r in rows for ref, robot in r["lift"] if ref]
        errors = np.array([r["joint_err"] for r in rows]) if finite else None
        return {
            "upright": self.fall_time is None and finite,
            "fall_time_s": self.fall_time,
            "fall_reason": self.fall_reason,
            "survival": 1.0 if self.fall_time is None else self.fall_time / self.motion.duration,
            "root_rmse_m": rms([r["root_err"] for r in rows]),
            "root_rot_rmse_deg": float(np.degrees(rms([r["root_rot_err"] for r in rows]))),
            "joint_rmse_rad": rms(errors) if finite else inf,
            "wrist_rmse_m": float(np.sqrt(np.mean([r["wrist_err2"] for r in rows]))) if finite else inf,
            "sole_rmse_m": float(np.sqrt(np.mean([r["sole_err2"] for r in rows]))) if finite else inf,
            "lift_recall": float(np.mean(lifts)) if lifts else None,
            "jitter_mrad": 1000.0 * jitter(errors, CONTROL_DT) if finite else inf,
            "root_err_max_m": max(r["root_err"] for r in rows) if finite else inf,
            "samples": len(rows),
        }


def _quat_rotate(quat_xyzw: np.ndarray, v: np.ndarray) -> np.ndarray:
    """Rotate the vector ``v`` by unit quaternions (xyzw) of shape [..., 4]."""
    xyz, w = quat_xyzw[..., :3], quat_xyzw[..., 3:4]
    t = 2.0 * np.cross(xyz, v)
    return v + w * t + np.cross(xyz, t)


def _smooth(x: np.ndarray, sigma: float) -> np.ndarray:
    """Gaussian smoothing along axis 0 (``sigma`` in samples, edges padded)."""
    radius = int(np.ceil(3 * sigma))
    kernel = np.exp(-0.5 * (np.arange(-radius, radius + 1) / sigma) ** 2)
    kernel /= kernel.sum()
    padded = np.concatenate([np.repeat(x[:1], radius, axis=0), x, np.repeat(x[-1:], radius, axis=0)])
    return np.apply_along_axis(lambda c: np.convolve(c, kernel, mode="valid"), 0, padded)


def _reference_torques(mj_model, ref_q: np.ndarray, clearance: np.ndarray) -> np.ndarray:
    """Joint torques [frames, 29] that realize the reference (Newton joint_q rows on the control grid) by inverse
    dynamics, with the floating base's wrench carried by the feet near the floor (least-norm foot wrenches)."""
    import mujoco

    qpos = np.concatenate([ref_q[:, :3], ref_q[:, 6:7], ref_q[:, 3:6], ref_q[:, 7:]], axis=1)
    frames, nv = len(qpos), mj_model.nv
    qvel = np.zeros((frames, nv))
    for f in range(frames - 1):
        mujoco.mj_differentiatePos(mj_model, qvel[f], CONTROL_DT, qpos[f], qpos[f + 1])
    qvel[-1] = qvel[-2]
    qvel = np.concatenate([qvel[:1], 0.5 * (qvel[1:] + qvel[:-1])])  # central differences
    qvel = _smooth(qvel, 3.0)
    qacc = _smooth(np.gradient(qvel, CONTROL_DT, axis=0), 2.0)
    feet = [mujoco.mj_name2id(mj_model, mujoco.mjtObj.mjOBJ_BODY, name) for name in FEET]
    support = np.clip((0.03 - clearance) / 0.02, 0.0, 1.0)  # [frames, 2]
    data = mujoco.MjData(mj_model)
    flags = mj_model.opt.disableflags
    mj_model.opt.disableflags = flags | int(mujoco.mjtDisableBit.mjDSBL_CONTACT)
    jacp, jacr = np.zeros((3, nv)), np.zeros((3, nv))
    tau = np.zeros((frames, nv - 6))
    try:
        for f in range(frames):
            data.qpos[:], data.qvel[:], data.qacc[:] = qpos[f], qvel[f], qacc[f]
            mujoco.mj_inverse(mj_model, data)
            generalized = data.qfrc_inverse.copy()
            jacobians = []
            for body, weight in zip(feet, support[f], strict=True):
                if weight > 0.0:
                    mujoco.mj_jacBody(mj_model, data, jacp, jacr, body)
                    jacobians.append(weight * np.vstack([jacp, jacr]))
            if jacobians:
                jac = np.vstack(jacobians)  # [6k, nv]
                root = jac[:, :6].T  # [6, 6k]
                wrench = root.T @ np.linalg.solve(root @ root.T + 1e-6 * np.eye(6), generalized[:6])
                generalized -= jac.T @ wrench
            tau[f] = generalized[6:]
    finally:
        mj_model.opt.disableflags = flags
    return tau


class Controller:
    """Sampling-based model predictive control (MPPI) on a GPU batch of copies of the robot.

    The decision variables are offsets of the joint position targets from a nominal schedule (the reference angles
    with the reference velocity and the reference's inverse-dynamics torques folded into the target), a
    piecewise-linear spline with knots every ``KNOT_FRAMES`` control periods over a ``HORIZON`` of control periods.
    Every control period the batch branches from the measured state, each world rolls out the warm-started plan plus
    Gaussian noise with the plant's actuator law (fixed gains; 5 ms planning steps), and the plan moves to the
    cost-weighted mean of the samples. The cost tracks the reference root pose and velocity, joints, and soles,
    penalizes falling, and keeps the offsets small. The iterations per period follow a wall-time budget for the
    clip, with more of them where the predicted cost is high.

    ``model`` is a copy of the plant's model posed at the start (``build_model(motion.sample(0.0))``), the
    controller's to use for planning; the simulated robot is a separate model the controller never sees.
    ``motion`` is the reference clip (a :class:`MotionClip` with the floor shift applied).
    """

    SAMPLES = 256
    HORIZON = 50  # control periods per rollout
    KNOT_FRAMES = 10  # control periods between spline knots
    PLAN_SUBSTEPS = 2  # physics steps per control period in the planning rollouts (5 ms, coarser than the plant)
    SERVO_HZ = 20.0  # servo natural frequency with the reflected inertia
    MAX_ITERATIONS = 6  # MPPI iterations per control period at most
    START_ITERATIONS = 30  # iterations for the first plan, from the known start state
    ONLINE_SECONDS = 150.0  # wall time [s] from the first compute() to the clip's end (idle machine)
    TEMPERATURE = 0.1  # MPPI temperature, a fraction of the median sample's excess cost
    NOISE = 1.0  # scale of the sampling noise [rad]
    TAIL_RELAX = 0.5  # how far a new tail knot relaxes toward the nominal targets
    OFFSET_WEIGHT = 1.0  # cost weight of the target offsets
    FEEDFORWARD = 1.0  # scale of the reference's inverse-dynamics torques in the nominal targets
    ADAPT = 1  # spread the iterations by the predicted cost
    IDLE_ITERATION_SECONDS = 0.085  # one MPPI iteration on the idle machine [s]

    def __init__(self, model: newton.Model, motion: MotionClip):
        self.motion = motion
        self.model = model
        natural_frequency = 2.0 * np.pi * self.SERVO_HZ
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 4.0 * ARMATURE * natural_frequency
        start_q = model.joint_q.numpy().astype(np.float64)

        def build():
            m = build_model(start_q)
            ke, kd = m.joint_target_ke.numpy(), m.joint_target_kd.numpy()
            ke[6:], kd[6:] = self.kp, self.kd
            m.joint_target_ke.assign(ke)
            m.joint_target_kd.assign(kd)
            return m

        self.rollout = newton.utils.BatchRollout(
            build,
            self.SAMPLES,
            solver=make_solver,
            dt=CONTROL_DT / self.PLAN_SUBSTEPS,
            substeps=self.PLAN_SUBSTEPS,
            device=model.device,
        )
        labels = list(self.rollout.model.body_label[: model.body_count])
        self.foot_labels = [labels[body_index(model, name)] for name in FEET]
        self.feet = [body_index(model, name) for name in FEET]

        # Reference on the control grid (past the clip's end it holds the last frame).
        frames = round(motion.duration / CONTROL_DT) + self.HORIZON + 3
        self.ref_q = np.array([motion.sample(f * CONTROL_DT) for f in range(frames)])
        ref_qd = np.gradient(self.ref_q[:, 7:], CONTROL_DT, axis=0)
        self.ref_root_v = np.gradient(self.ref_q[:, :3], CONTROL_DT, axis=0)
        # Reference soles and their clearance (which feet carry the robot).
        state = model.state()
        joint_q = wp.zeros(model.joint_coord_count, dtype=float, device=model.device)
        soles, clearance = [], []
        for q in self.ref_q:
            joint_q.assign(q)
            newton.eval_fk(model, joint_q, model.joint_qd, state)
            body_q = state.body_q.numpy().astype(np.float64)
            points = [foot_points(body_q, f) for f in self.feet]
            soles.append([p[0] for p in points])
            clearance.append([p[1] for p in points])
        self.ref_soles = np.array(soles)  # [frames, 2, 3]
        # Nominal targets: reference angles one period ahead, with the reference velocity and the inverse-dynamics
        # torques absorbed into the target (the actuator law is linear in q, qd, and tau).
        tau = self.FEEDFORWARD * _reference_torques(self.rollout.solver.mj_model, self.ref_q, np.array(clearance))
        limit = model.joint_effort_limit.numpy()[6:]
        tau = np.clip(tau, -limit, limit)
        lead = np.concatenate([self.ref_q[1:, 7:], self.ref_q[-1:, 7:]])
        lead_qd = np.concatenate([ref_qd[1:], ref_qd[-1:]])
        lead_tau = np.concatenate([tau[1:], tau[-1:]])
        self.nominal = lead + (self.kd * lead_qd + lead_tau) / self.kp

        knots = self.HORIZON // self.KNOT_FRAMES + 1
        self.knot_frames = np.arange(knots) * self.KNOT_FRAMES
        # Frame i of a rollout applies the spline at i (linear interpolation matrix [HORIZON, knots]).
        self.interp = np.zeros((self.HORIZON, knots))
        for i in range(self.HORIZON):
            k = min(i // self.KNOT_FRAMES, knots - 2)
            a = (i - k * self.KNOT_FRAMES) / self.KNOT_FRAMES
            self.interp[i, k], self.interp[i, k + 1] = 1.0 - a, a
        self.plan = np.zeros((knots, JOINT_COUNT))
        sigma = self.NOISE * np.array([0.08] * 12 + [0.06] * 3 + [0.05] * 14)
        self.sigma = np.tile(sigma, (knots, 1))
        self.rng = np.random.default_rng(0)
        self.state = model.state()
        self.joint_q = wp.zeros(model.joint_coord_count, dtype=float, device=model.device)
        self.joint_qd = wp.zeros(model.joint_dof_count, dtype=float, device=model.device)
        self.schedule = np.zeros((self.HORIZON, self.SAMPLES, model.joint_coord_count), dtype=np.float32)
        self.last_frame = 0
        # Warm up: load the kernels and capture the rollout graph, then time an iteration.
        start_qd = model.joint_qd.numpy().astype(np.float64)
        self._optimize(0, start_q, start_qd, iterations=1)
        self.plan[:] = 0.0
        seconds = []
        for _ in range(3):
            began = time.perf_counter()
            self._optimize(0, start_q, start_qd, iterations=1)
            seconds.append(time.perf_counter() - began)
        self.iteration_seconds = min(seconds)
        # A busy machine gets proportionally more time (within limits).
        self.slowdown = float(np.clip(self.iteration_seconds / self.IDLE_ITERATION_SECONDS, 1.0, 1.15))
        self.frames = round(motion.duration / CONTROL_DT)
        # The robot starts at rest at the clip's first frame: optimize the first plan from there.
        self._optimize(0, start_q, start_qd, self.START_ITERATIONS)
        self.mean_cost = max(self.last_cost, 1e-3)
        self.last_frame = 0
        self.online_start = None
        self.compute_seconds = 0.0
        self.calls = 0

    def _iterations(self, seconds: float) -> int:
        """MPPI iterations that fit in ``seconds`` (stochastic rounding keeps the average)."""
        x = max(0.0, seconds) / self.iteration_seconds
        return int(min(self.MAX_ITERATIONS, np.floor(x + self.rng.random())))

    def _timed_optimize(self, frame, joint_q, joint_qd, iterations):
        if iterations <= 0:
            return
        began = time.perf_counter()
        self._optimize(frame, joint_q, joint_qd, iterations)
        measured = (time.perf_counter() - began) / iterations
        self.iteration_seconds = 0.9 * self.iteration_seconds + 0.1 * measured

    def _shift(self, frames: int) -> None:
        if frames <= 0:
            return
        old = self.knot_frames
        new = old + frames
        self.plan = np.stack([np.interp(new, old, self.plan[:, j]) for j in range(JOINT_COUNT)], axis=1)
        # Past the old plan's end, the offsets relax toward the nominal (the tail is weakly observed).
        beyond = np.clip((new - old[-1]) / self.KNOT_FRAMES, 0.0, 1.0)
        self.plan *= (1.0 - self.TAIL_RELAX * beyond)[:, None]

    def _costs(self, frame: int, q: np.ndarray, qd: np.ndarray, body_q: np.ndarray, offsets: np.ndarray):
        h = self.HORIZON
        ref = self.ref_q[frame + 1 : frame + 1 + h]  # [h, 36]
        q, qd, body_q = q[1:], qd[1:], body_q[1:]  # [h, N, ...]
        pos_err = np.sum((q[:, :, :3] - ref[:, None, :3]) ** 2, axis=-1)
        quat = q[:, :, 3:7] / np.linalg.norm(q[:, :, 3:7], axis=-1, keepdims=True)
        dot = np.abs(np.sum(quat * ref[:, None, 3:7], axis=-1))
        rot_err = (2.0 * np.arccos(np.clip(dot, 0.0, 1.0))) ** 2
        joint_err = np.mean((q[:, :, 7:] - ref[:, None, 7:]) ** 2, axis=-1)
        soles = body_q[..., :3] + _quat_rotate(body_q[..., 3:7], SOLE_CENTER)  # [h, N, 2, 3]
        sole_err = np.mean(np.sum((soles - self.ref_soles[frame + 1 : frame + 1 + h, None]) ** 2, axis=-1), axis=-1)
        vel_err = np.sum((qd[:, :, :3] - self.ref_root_v[frame + 1 : frame + 1 + h, None]) ** 2, axis=-1)
        up = 1.0 - 2.0 * (quat[..., 0] ** 2 + quat[..., 1] ** 2)
        fallen = (q[:, :, 2] < FALL_HEIGHT_M + 0.05) | (up < 0.8)
        cost = (
            pos_err / 0.03**2
            + rot_err / 0.1**2
            + joint_err / 0.1**2
            + sole_err / 0.03**2
            + 0.1 * vel_err / 0.2**2
            + 1000.0 * fallen
        )
        cost = np.sum(cost, axis=0) / h
        cost += self.OFFSET_WEIGHT * np.mean(offsets**2, axis=(1, 2)) / 0.2**2
        return cost

    def _optimize(self, frame: int, joint_q: np.ndarray, joint_qd: np.ndarray, iterations: int = 1) -> None:
        n, h = self.SAMPLES, self.HORIZON
        for _ in range(iterations):
            self.joint_q.assign(joint_q)
            self.joint_qd.assign(joint_qd)
            newton.eval_fk(self.model, self.joint_q, self.joint_qd, self.state)
            self.state.joint_q.assign(self.joint_q)
            self.state.joint_qd.assign(self.joint_qd)
            self.rollout.reset(self.state, model=self.model)
            noise = self.rng.standard_normal((n, *self.plan.shape)) * self.sigma
            noise[0] = 0.0
            offsets = self.plan[None] + noise  # [N, knots, 29]
            targets = self.nominal[frame : frame + h, None, :] + np.einsum("ik,nkj->inj", self.interp, offsets)
            self.schedule[:, :, 7:] = targets
            records = self.rollout.run(
                h,
                control={"joint_target_q": self.schedule},
                record={"q": "joint_q", "qd": "joint_qd", "feet": ("body_q", self.foot_labels)},
            )
            cost = self._costs(frame, records["q"], records["qd"], records["feet"].astype(np.float64), offsets)
            best = cost.min()
            temperature = max(1e-6, self.TEMPERATURE * (np.median(cost) - best))
            weights = np.exp(-(cost - best) / temperature)
            weights /= weights.sum()
            self.plan = self.plan + np.einsum("n,nkj->kj", weights, noise)
            self.last_cost = best

    def compute(self, t: float, joint_q: np.ndarray, joint_qd: np.ndarray) -> Command:
        """Command for the control period starting at ``t`` [s], given the state then: joint_q (root position [m],
        root quaternion xyzw, 29 joint angles [rad]) and joint_qd (root COM linear [m/s] and angular [rad/s]
        velocity in the world frame, 29 joint velocities [rad/s])."""
        now = time.perf_counter()
        if self.online_start is None:
            self.online_start = now
        frame = min(max(round(t / CONTROL_DT), 0), len(self.nominal) - self.HORIZON - 1)
        self._shift(frame - self.last_frame)
        self.last_frame = frame
        # Spread the remaining time over the remaining periods (wall time between calls is physics and reporting).
        elapsed = now - self.online_start
        overhead = (elapsed - self.compute_seconds) / self.calls if self.calls else 0.02
        remaining = max(1, self.frames - frame)
        per_frame = (self.ONLINE_SECONDS * self.slowdown - elapsed) / remaining - overhead - 0.005
        if self.ADAPT:
            # Hard stretches (predicted cost above its running mean) get more iterations, easy ones fewer.
            per_frame *= float(np.clip(self.last_cost / self.mean_cost, 0.5, 2.0))
        self._timed_optimize(frame, joint_q, joint_qd, max(1, self._iterations(per_frame)))
        self.mean_cost = 0.99 * self.mean_cost + 0.01 * self.last_cost
        self.calls += 1
        self.compute_seconds += time.perf_counter() - now
        return Command(q=self.nominal[frame] + self.plan[0], kp=self.kp, kd=self.kd)


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.frame_dt = CONTROL_DT
        self.sim_dt = SIM_DT
        self.sim_time = 0.0
        # The robot starts at rest at the clip's first frame; the controller plans on its own copy of the model.
        self.motion = MotionClip(args.motion, build_model())
        start = self.motion.sample(0.0)
        self.robot = Robot(start)
        planning_model = build_model(start)
        self.controller = Controller(planning_model, MotionClip(args.motion, planning_model))
        self.report = TrackingReport(self.robot, self.motion)
        self.compute_seconds = 0.0
        self.viewer.set_model(self.model)

    # The live host and viewers look for these on the example.
    @property
    def model(self):
        return self.robot.model

    @property
    def solver(self):
        return self.robot.solver

    @property
    def state_0(self):
        return self.robot.state_0

    @property
    def state_1(self):
        return self.robot.state_1

    @property
    def control(self):
        return self.robot.control

    def capture(self):
        self.robot.capture()

    def step(self):
        # Read the state first: the copy waits for the last physics step, which is not the controller's time.
        joint_q = self.state_0.joint_q.numpy().astype(np.float64)
        joint_qd = self.state_0.joint_qd.numpy().astype(np.float64)
        started = time.perf_counter()
        command = self.controller.compute(self.sim_time, joint_q, joint_qd)
        self.compute_seconds += time.perf_counter() - started
        self.robot.apply(command)
        self.robot.advance()
        self.sim_time += self.frame_dt
        self.report.update(self.sim_time, self.state_0)

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def print_report(self):
        summary = self.report.summary()
        print(f"tracked {self.sim_time:.2f} of {self.motion.duration:.2f} s")
        for key, value in summary.items():
            print(f"  {key}: {value:.4f}" if isinstance(value, float) else f"  {key}: {value}")
        print(f"  controller_seconds: {self.compute_seconds:.2f}")

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, default="walk.csv", help="Reference clip (MuJoCo qpos CSV, 30 fps)")
        parser.set_defaults(num_frames=None)
        return parser


if __name__ == "__main__":
    parser = Example.create_parser()
    known, _ = parser.parse_known_args()
    if known.num_frames is None:
        parser.set_defaults(num_frames=round(MotionClip(known.motion).duration / CONTROL_DT))
    viewer, args = newton.examples.init(parser)
    example = Example(viewer, args)
    started = time.perf_counter()
    newton.examples.run(example, args)
    example.print_report()
    print(f"  wall_seconds: {time.perf_counter() - started:.2f}")
