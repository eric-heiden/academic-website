# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure) with the scene recreated from the
photos and logs (the pear, the orange, and the dark fruit as free bodies, and the static
wedge tray) in ``num_worlds`` identical worlds, and ``Example`` drives every world with
the logged commands as joint position targets, open loop. The arm servos, the command
delay, and the gripper squeeze are fitted to the measured joints and gripper openings.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.09,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}


# Fruits fitted to the top camera (start), the wrist cameras, and the gripper openings while
# holding them. Spheres in each body's frame: (offset along body x [m], radius [m]).
FRUITS = {
    "pear": {
        "spheres": ((0.0, 0.026), (0.028, 0.018)),  # body and neck; the neck points along +x
        "pos": (0.646, 0.337),  # body sphere centre on the table [m]
        "axis": (0.573, -0.820),  # body -> neck direction on the table
        "mass": 0.12,
    },
    "orange": {"spheres": ((0.0, 0.028),), "pos": (0.500, -0.052), "axis": (1.0, 0.0), "mass": 0.12},
    "dark_fruit": {"spheres": ((0.0, 0.0295),), "pos": (0.645, -0.185), "axis": (1.0, 0.0), "mass": 0.13},
}
FRUIT_MATERIAL = {"mu": 0.5, "mu_torsional": 0.01, "mu_rolling": 0.002, "restitution": 0.05}
INERTIA_SCALE = 1.1  # x a solid ellipsoid of the fruit's extents

# Wedge tray (a circular sector fitted to its silhouette in the top camera at the end), static.
TRAY = {
    "apex": (0.9493, 0.1618),  # sector apex on the table [m]
    "heading": math.radians(-157.4),  # apex -> arc direction
    "radius": 0.2817,
    "half_angle": math.radians(30.2),
    "floor": 0.007,  # floor thickness [m]
    "ramp_end": 0.19,  # the floor rises from here towards the apex [m from the apex]
    "ramp_angle": math.radians(5.0),
    "edge_ramp": (0.10, 0.24, 0.06, math.radians(12.0)),  # along the -y rim: from, to [m from the apex], width [m], slope
    "rim": 0.025,  # rim height above the table [m]
    "wall": 0.008,  # rim thickness [m]
    "mu": 0.4,
}
TABLE_Z = 0.75
FRUIT_GROUPS = (-1, -2, -3)  # negative groups: fruits collide with everything and each other
TRAY_GROUP = 2  # the tray collides with the fruits only (the robot and the table are group 1)


def _quat_z(angle: float) -> wp.quat:
    return wp.quat_from_axis_angle(wp.vec3(0.0, 0.0, 1.0), float(angle))


def add_fruits(builder: newton.ModelBuilder) -> None:
    for (name, fruit), group in zip(FRUITS.items(), FRUIT_GROUPS):
        spheres = fruit["spheres"]
        lo = min(x - r for x, r in spheres)
        hi = max(x + r for x, r in spheres)
        half = max(r for _, r in spheres)
        # tilt the axis so every sphere rests on the table
        r0 = spheres[0][1]
        tilt = 0.0
        if len(spheres) > 1:
            x1, r1 = spheres[1]
            tilt = math.asin((r0 - r1) / x1)
        yaw = math.atan2(fruit["axis"][1], fruit["axis"][0])
        rot = wp.mul(_quat_z(yaw), wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), tilt))
        pos = wp.vec3(fruit["pos"][0], fruit["pos"][1], TABLE_Z + r0 + 0.0005)
        a, b = 0.5 * (hi - lo), half
        m = fruit["mass"]
        inertia = INERTIA_SCALE * m / 5.0 * np.diag([2.0 * b * b, a * a + b * b, a * a + b * b])
        body = builder.add_body(
            xform=wp.transform(pos, rot),
            com=wp.vec3(0.5 * (hi + lo), 0.0, 0.0),
            mass=m,
            inertia=wp.mat33(*inertia.flatten().tolist()),
            label=name,
            lock_inertia=True,
        )
        cfg = newton.ModelBuilder.ShapeConfig(density=0.0, collision_group=group, **FRUIT_MATERIAL)
        for x, r in spheres:
            builder.add_shape_sphere(body, xform=wp.transform(wp.vec3(x, 0.0, 0.0), wp.quat_identity()), radius=r, cfg=cfg)


def tray_boxes() -> list[tuple[tuple[float, float, float], tuple[float, ...], tuple[float, float, float]]]:
    """Tray collision boxes: (centre [m], rotation (x, y, z, w), half extents [m]) in the world."""
    t = TRAY
    R, al, w = t["radius"], t["half_angle"], t["wall"]
    ax, ay = t["apex"]
    h = t["heading"]
    boxes = []

    def place(u, v, z, yaw, hx, hy, hz, tilt=0.0, roll=0.0):
        """A box whose top face is centred ``hz`` above (u, v, z) in the tray frame."""
        c, s = math.cos(h), math.sin(h)
        rot = wp.mul(_quat_z(h + yaw), wp.quat_from_axis_angle(wp.vec3(0.0, 1.0, 0.0), tilt))
        rot = wp.mul(rot, wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), roll))
        n = np.array(wp.quat_rotate(rot, wp.vec3(0.0, 0.0, 1.0)))
        top = np.array([ax + c * u - s * v, ay + s * u + c * v, z + hz])
        centre = top - hz * n
        boxes.append((tuple(map(float, centre)), tuple(map(float, rot)), (float(hx), float(hy), float(hz))))

    # floor strips across the heading; towards the apex the floor rises (the narrow corner
    # sends fruits dropped there towards the middle, as the real orange did)
    top = TABLE_Z + t["floor"]
    s_ramp, slope = t["ramp_end"], math.tan(t["ramp_angle"])
    edges = np.concatenate([np.linspace(0.03, s_ramp, 6), np.linspace(s_ramp, R - 0.004, 4)[1:]])
    for s0, s1 in zip(edges[:-1], edges[1:]):
        half_w = min(s0 * math.tan(al), math.sqrt(max(R * R - s1 * s1, 0.0))) - 0.002
        if half_w <= 0.005:
            continue
        sm = 0.5 * (s0 + s1)
        tilt = t["ramp_angle"] if s1 <= s_ramp + 1e-9 else 0.0
        z_top = top + max(s_ramp - sm, 0.0) * slope
        hz = 0.5 * (z_top - TABLE_Z) + 0.004
        place(sm, 0.0, z_top - hz, 0.0, 0.5 * (s1 - s0) / math.cos(tilt), half_w, hz, tilt)
    # flared floor along the -y straight rim: fruits dropped next to it roll inwards
    s0, s1, width, angle = t["edge_ramp"]
    if width > 0.0:
        rise = 0.5 * width * math.tan(angle)
        hz = 0.5 * (top + rise - TABLE_Z) + 0.004
        d = 0.5 * (s0 + s1)
        u, v = d * math.cos(al), d * math.sin(al)
        # centre line half a ramp width inside the rim line
        u, v = u + 0.5 * width * math.sin(al), v - 0.5 * width * math.cos(al)
        place(u, v, top + rise - hz, al, 0.5 * (s1 - s0), 0.5 * width, hz, 0.0, angle)
    # straight rims, inset by half a wall
    zr = TABLE_Z + 0.5 * t["rim"]
    hr = 0.5 * t["rim"]
    s0, s1 = 0.04, R * math.cos(al) - 0.02
    for side in (-1.0, 1.0):
        d = 0.5 * (s0 + s1)
        u, v = d * math.cos(al), side * d * math.sin(al)
        n = 0.5 * w
        u, v = u - n * math.sin(al), v - side * n * math.cos(al)
        place(u, v, zr, side * al, 0.5 * (s1 - s0), 0.5 * w, hr)
    # arc rim, clear of the rounded corners
    k, span = 7, al - math.radians(4.0)
    rr = R - 0.5 * w - 0.003
    seg = rr * 2.0 * span / k
    for i in range(k):
        phi = -span + (i + 0.5) * 2.0 * span / k
        place(rr * math.cos(phi), rr * math.sin(phi), zr, phi, 0.5 * w, 0.5 * seg, hr)
    return boxes


def add_tray(builder: newton.ModelBuilder) -> None:
    cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=TRAY["mu"], restitution=0.05, collision_group=TRAY_GROUP)
    for centre, rot, half in tray_boxes():
        xform = wp.transform(wp.vec3(*centre), wp.quat(*rot))
        builder.add_shape_box(-1, xform=xform, hx=half[0], hy=half[1], hz=half[2], cfg=cfg, label="tray")


def build_model(num_worlds: int = 1) -> newton.Model:
    """The station with the fruits and the tray in ``num_worlds`` identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    add_tray(station)
    add_fruits(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    model = builder.finalize()
    configure(model)
    return model


# Gripper: position gain [N/m] and squeeze force limit [N] of the finger slide servo.
GRIPPER = {"kp": 1000.0, "kv": 14.0, "force": 10.0}
# Arm servos per joint 1-6 (both arms), fitted so the replayed hands follow the forward kinematics
# of the measured joints: position gain [N m/rad], velocity gain [N m s/rad], and the gravity
# compensation of links 1-6 (the fit prefers none: the real arms sag like stiff uncompensated servos).
ARM = {
    "kp": (313.6, 160.0, 313.6, 40.0, 40.0, 40.0),
    "kv": (5.0, 8.0, 12.8, 4.0, 2.0, 2.0),
    "gravcomp": 0.0,
}


def configure(model: newton.Model) -> None:
    """Fruit contact dimensions and the actuator settings, written to the model's MuJoCo attributes."""
    mj = model.mujoco
    body_names = [label.rsplit("/", 1)[-1] for label in model.body_label]
    fruit_bodies = {i for i, name in enumerate(body_names) if name in FRUITS}
    shape_body = model.shape_body.numpy()
    condim = mj.condim.numpy()
    condim[[i for i, b in enumerate(shape_body) if b in fruit_bodies]] = 6
    mj.condim.assign(condim)

    labels = [label.rsplit("/", 1)[-1] for label in mj.actuator_label]
    gain, bias = mj.actuator_gainprm.numpy(), mj.actuator_biasprm.numpy()
    frange, flimited = mj.actuator_forcerange.numpy(), mj.actuator_forcelimited.numpy()
    has_frange = mj.actuator_has_forcerange.numpy()
    act_world = mj.actuator_world.numpy()
    ke, kd = model.joint_target_ke.numpy(), model.joint_target_kd.numpy()
    qd_start, joint_world = model.joint_qd_start.numpy(), model.joint_world.numpy()
    joint_names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
    dof_of = {(int(joint_world[j]), name): int(qd_start[j]) for j, name in enumerate(joint_names)}
    for a, name in enumerate(labels):
        side, _, part = name.partition("_")
        if part == "gripper":
            kp, kv, force = GRIPPER["kp"], GRIPPER["kv"], GRIPPER["force"]
            frange[a] = (-force, force)
            flimited[a] = 1
            has_frange[a] = True
        else:
            k = int(part[-1]) - 1
            kp = gain[a, 0] if ARM["kp"] is None else ARM["kp"][k]
            kv = -bias[a, 2] if ARM["kv"] is None else ARM["kv"][k]
        gain[a, 0], bias[a, 1], bias[a, 2] = kp, -kp, -kv
        joint = f"{side}_left_finger" if part == "gripper" else name
        dof = dof_of[(int(act_world[a]), joint)]
        ke[dof], kd[dof] = kp, kv
    mj.actuator_gainprm.assign(gain)
    mj.actuator_biasprm.assign(bias)
    mj.actuator_forcerange.assign(frange)
    mj.actuator_forcelimited.assign(flimited)
    mj.actuator_has_forcerange.assign(has_frange)
    model.joint_target_ke.assign(ke)
    model.joint_target_kd.assign(kd)

    gravcomp = mj.gravcomp.numpy()
    links = {f"{side}_link_{k}" for side in SIDES for k in range(1, 7)}
    gravcomp[[i for i, name in enumerate(body_names) if name in links]] = ARM["gravcomp"]
    mj.gravcomp.assign(gravcomp)


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=False, cone="elliptic")


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """Collision pipeline the replay calls before every solver step (``None`` if the solver finds contacts)."""
    return newton.CollisionPipeline(model)


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
