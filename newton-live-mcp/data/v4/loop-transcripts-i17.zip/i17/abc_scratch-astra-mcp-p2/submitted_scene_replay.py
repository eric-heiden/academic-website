# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure), adds the three fruit
bodies and the wooden tray, and makes ``num_worlds`` identical copies. ``Example``
drives every world with the logged commands as joint position targets, open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.02,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}


# Fitted from the arm logs and the measured motion in episode.npz.
ARM_KP = (61.45, 56.64, 72.67, 10.57, 8.63, 9.02)
ARM_KD = (4.07, 5.30, 6.64, 1.56, 1.13, 1.41)
ARM_GRAVCOMP = (0.69, 1.0, 0.614, 0.912, 1.0, 0.306)

# The local long axis of the pear points toward its neck.
FRUITS = (
    dict(name="pear", position=(0.646, 0.335, 0.774), radii=(0.039, 0.026, 0.024),
         yaw=-0.65, mass=0.09, color=(0.88, 0.67, 0.025)),
    dict(name="orange", position=(0.500, -0.049, 0.780), radii=(0.030, 0.030, 0.030),
         yaw=0.0, mass=0.11, color=(0.90, 0.20, 0.015)),
    dict(name="dark_fruit", position=(0.642, -0.185, 0.780), radii=(0.033, 0.032, 0.030),
         yaw=0.0, mass=0.12, color=(0.12, 0.042, 0.022)),
)


def add_objects(builder):
    fruit_cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=1.0,
        mu_torsional=0.005, mu_rolling=0.001, margin=0.0, gap=0.002)
    contact = {"mujoco:condim": 6, "mujoco:solref_mode": 1, "mujoco:solref": (0.008, 1.0),
               "mujoco:geom_solimp": (0.95, 0.99, 0.001, 0.5, 2.0)}
    # Explicit inertia avoids overlapping collision lobes counting mass twice.
    for fruit in FRUITS:
        a, b, c = fruit["radii"]
        mass = fruit["mass"]
        inertia = np.diag([b*b+c*c, a*a+c*c, a*a+b*b]) * mass / 5.0
        body = builder.add_body(label=fruit["name"], mass=mass,
            inertia=wp.mat33(inertia), lock_inertia=True,
            xform=wp.transform(fruit["position"], wp.quat_from_axis_angle(wp.vec3(0,0,1), fruit["yaw"])))
        if fruit["name"] == "pear":
            builder.add_shape_ellipsoid(body, rx=0.028, ry=b, rz=c,
                xform=wp.transform(wp.vec3(-0.011,0,0), wp.quat_identity()),
                cfg=fruit_cfg, color=fruit["color"], custom_attributes=contact)
            builder.add_shape_ellipsoid(body, rx=0.024, ry=0.017, rz=0.017,
                xform=wp.transform(wp.vec3(0.015,0,0.003), wp.quat_identity()),
                cfg=fruit_cfg, color=fruit["color"], custom_attributes=contact)
        else:
            builder.add_shape_ellipsoid(body, rx=a, ry=b, rz=c,
                cfg=fruit_cfg, color=fruit["color"], custom_attributes=contact)

    # Wooden sector tray: a shallow dished floor and low walls following its outline.
    cfg = newton.ModelBuilder.ShapeConfig(density=0.0, mu=0.65,
        mu_torsional=0.004, mu_rolling=0.001, gap=0.002)
    origin = np.array([0.921, 0.145])
    angles = np.linspace(math.radians(171), math.radians(229), 19)
    arc = origin + 0.230 * np.column_stack([np.cos(angles), np.sin(angles)])
    polygon = np.vstack([origin, arc])
    def floor_height(x):
        return 0.761 + np.where(x >= 0.750, 0.10*(x-0.750), 0.08*(0.750-x))

    def prism(poly, low, high, label, color):
        n = len(poly)
        vertices = np.vstack([np.column_stack([poly,z]) for z in (low,high)])
        triangles = []
        for i in range(1,n-1):
            triangles.extend([(0,i+1,i), (n,n+i,n+i+1)])
        for i in range(n):
            j=(i+1)%n
            triangles.extend([(i,j,n+j),(i,n+j,n+i)])
        mesh = newton.Mesh(vertices=vertices.astype(np.float32), indices=np.array(triangles,dtype=np.int32).ravel())
        builder.add_shape_mesh(-1, mesh=mesh, cfg=cfg, color=color, label=label, custom_attributes=contact)

    # The shallow dish lets the round fruit roll toward the wide end and settle.
    for side in (-1,1):
        clipped=[]
        for p,q in zip(polygon,np.roll(polygon,-1,axis=0)):
            p_in=side*(p[0]-.750)>=0
            q_in=side*(q[0]-.750)>=0
            if p_in: clipped.append(p)
            if p_in != q_in:
                clipped.append(p+(q-p)*(.750-p[0])/(q[0]-p[0]))
        poly=np.array(clipped)
        height=floor_height(poly[:,0])
        prism(poly,height-.006,height,f"tray_floor_{side}",(0.59,0.37,0.16))
    for i,(p,q) in enumerate(zip(polygon,np.roll(polygon,-1,axis=0))):
        v=q-p;center=(p+q)/2
        rim_z = float(floor_height(center[0])) + .009 if 0 < i < len(polygon)-1 else 0.763 + .10*(float(center[0])-.72)
        builder.add_shape_box(-1, hx=float(np.linalg.norm(v))/2+0.001, hy=0.003, hz=0.005,
            xform=wp.transform(wp.vec3(float(center[0]),float(center[1]),rim_z),
                wp.quat_from_axis_angle(wp.vec3(0,0,1),math.atan2(v[1],v[0]))),
            cfg=cfg, color=(0.48,0.28,0.11), label=f"tray_rim_{i}", custom_attributes=contact)


def build_model(num_worlds: int = 1) -> newton.Model:
    """Build identical station, fruit, and tray copies."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(str(STATION))
    for j,label in enumerate(station.joint_label):
        name=label.rsplit("/",1)[-1]
        for side in SIDES:
            if name.startswith(side+"_joint") and name[-1:].isdigit():
                k=int(name[-1])-1
                d=station.joint_qd_start[j]
                station.joint_target_ke[d]=ARM_KP[k]
                station.joint_target_kd[d]=ARM_KD[k]
            if name == side+"_left_finger":
                d=station.joint_qd_start[j]
                station.joint_target_ke[d]=1000.0
                station.joint_effort_limit[d]=20.0
    grav=station.custom_attributes["mujoco:gravcomp"]
    for b,label in enumerate(station.body_label):
        name=label.rsplit("/",1)[-1]
        for side in SIDES:
            if name.startswith(side+"_link_") and name[-1:].isdigit():
                grav.values[b]=ARM_GRAVCOMP[int(name[-1])-1]
    # Servo force limits must also be authored on the imported actuator rows.
    for a in (6, 13):
        station.custom_attributes["mujoco:actuator_forcerange"].values[a]=(-20.0,20.0)
        station.custom_attributes["mujoco:actuator_has_forcerange"].values[a]=True
        station.custom_attributes["mujoco:actuator_forcelimited"].values[a]=1
    station.shape_gap[:] = [0.003] * len(station.shape_gap)
    add_objects(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    return builder.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(model, use_mujoco_contacts=True,
        cone="elliptic", iterations=30, ls_iterations=30,
        njmax=512, nconmax=160, impratio=2.0)


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """MuJoCo computes the contacts, including the ellipsoidal fruit surfaces."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
