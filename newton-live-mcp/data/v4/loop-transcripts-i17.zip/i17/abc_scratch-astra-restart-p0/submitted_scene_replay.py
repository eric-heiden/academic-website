# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Open-loop replay of a real bimanual robot episode at the ABC YAM station.

``episode.npz`` holds the measured joints and the logged joint and gripper commands of
a real episode recorded at a bimanual station with two 6-DoF YAM arms (FORMAT.md
describes the files). ``build_model`` builds the station from ``station/`` (the ABC
simulator's MJCF: arms, grippers, table, and enclosure), adds the fitted fruits
and shallow wooden tray, and replicates the scene in ``num_worlds`` identical
worlds, and ``Example`` drives every world with the logged commands as joint position
targets, open loop.

Command rule (verification replays submissions with the same rule): physics step
``k`` applies, at control time ``t[0] + k * dt``, the last command logged at or before
``t[0] + k * dt - command_delay`` (zero-order hold; the first command before that, the
last one after the episode ends). A gripper command ``g`` sets the left finger slide
target to ``clip(g, 0, 1) * 0.0475`` m and the right finger's to the negative value.
The arms start at the first measured joints and velocities, the fingers at the first
measured opening, and every other body where ``model.joint_q`` places it.

Run: ``python scene_replay.py --viewer null`` replays the whole episode
(``--seconds`` stops early, ``--num-worlds`` adds copies).
"""

from __future__ import annotations

import math
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np
import warp as wp

import newton
import newton.examples

HERE = Path(__file__).resolve().parent
STATION = HERE / "station" / "yam_bimanual_empty.xml"
EPISODE = HERE / "episode.npz"
SIDES = ("left", "right")
GRIPPER_TRAVEL = 0.0475  # finger slide [m] at gripper opening 1
FRAME_DT = 1.0 / 30.0  # example frame [s]

PARAMS = {
    "command_delay": 0.035,  # latency from a logged command to the joint targets [s]
    "dt": 0.002,  # physics step [s]
}


# Physical estimates in SI units, saved here so replay needs no fitting data.
# The arm fit used 40,606 samples from the 64 calibration logs. Fruit masses
# are effective payload estimates for the lightweight imitation fruits.
ARM_GRAVCOMP = 0.7
TRAY_SLOPE = 0.07
TRAY_CROSS_SLOPE = -0.04
RIM_BEVEL = -0.65
FRUIT_ROLLING = 0.0008
ARM_KP = (80.0, 80.0, 80.0, 10.0, 10.0, 6.0)
ARM_KD = (4.0, 4.2, 4.3, 1.4, 1.3, 0.6)
FRUITS = (
    dict(
        name="pear", position=(0.650, 0.338, 0.776),
        radii=(0.043, 0.027, 0.026), yaw=-1.15,
        mass=0.060, color=(0.92, 0.73, 0.04),
    ),
    dict(
        name="orange", position=(0.498, -0.060, 0.781),
        radii=(0.031, 0.030, 0.031), yaw=0.0,
        mass=0.075, color=(0.95, 0.25, 0.02),
    ),
    dict(
        name="dark_fruit", position=(0.662, -0.182, 0.782),
        radii=(0.033, 0.032, 0.032), yaw=0.0,
        mass=0.085, color=(0.12, 0.035, 0.018),
    ),
)


def station_xml():
    root = ET.parse(STATION).getroot()
    compiler = root.find("compiler")
    compiler.set("meshdir", str(STATION.parent / compiler.get("meshdir")))
    root.find("option").set("cone", "elliptic")
    for body in root.iter("body"):
        if body.get("gravcomp") is not None:
            body.set("gravcomp", str(ARM_GRAVCOMP))
    for actuator in root.find("actuator"):
        name = actuator.get("name", "")
        if "joint" in name:
            k = int(name[-1]) - 1
            actuator.set("kp", str(ARM_KP[k]))
            actuator.set("kv", str(ARM_KD[k]))
        else:
            actuator.set("kp", "1200")
            actuator.set("kv", "14")
            actuator.set("forcerange", "-30 30")
    return ET.tostring(root, encoding="unicode")


def add_pear_visual(station, body, color):
    """A tapered skin and stem; the smooth ellipsoid is the contact envelope."""
    profile = (
        (-0.043, 0.001), (-0.037, 0.014), (-0.026, 0.023),
        (-0.014, 0.025), (0.0, 0.021), (0.014, 0.015),
        (0.028, 0.011), (0.040, 0.006), (0.043, 0.001),
    )
    sides = 24
    vertices = []
    for x, radius in profile:
        for k in range(sides):
            angle = 2.0 * math.pi * k / sides
            vertices.append((x, radius * math.cos(angle), 0.96 * radius * math.sin(angle)))
    indices = []
    for row in range(len(profile) - 1):
        for k in range(sides):
            a = row * sides + k
            b = row * sides + (k + 1) % sides
            indices.extend((a, b, b + sides, a, b + sides, a + sides))
    skin = newton.ModelBuilder.ShapeConfig(
        density=0, has_shape_collision=False, has_particle_collision=False,
    )
    mesh = newton.Mesh(
        np.asarray(vertices, dtype=np.float32), np.asarray(indices, dtype=np.int32),
    )
    station.add_shape_mesh(body, mesh=mesh, cfg=skin, color=color, label="pear_visual")
    station.add_shape_capsule(
        body,
        xform=wp.transform(
            (0.047, 0, 0), wp.quat_from_axis_angle(wp.vec3(0, 1, 0), math.pi / 2),
        ),
        radius=0.0015, half_height=0.006, cfg=skin,
        color=(0.20, 0.10, 0.035), label="pear_stem",
    )


def add_scene(station):
    contact = {"mujoco:condim": 6, "mujoco:solref": (0.020, 1.0), "mujoco:solref_mode": 1}
    fruit_cfg = newton.ModelBuilder.ShapeConfig(
        density=0, mu=1.0, mu_torsional=0.006, mu_rolling=FRUIT_ROLLING, margin=0.0,
    )
    for spec in FRUITS:
        a, b, c = spec["radii"]
        mass = spec["mass"]
        inertia = np.diag([
            mass * (b*b + c*c) / 5,
            mass * (a*a + c*c) / 5,
            mass * (a*a + b*b) / 5,
        ])
        body = station.add_body(
            xform=wp.transform(
                spec["position"], wp.quat_from_axis_angle(wp.vec3(0, 0, 1), spec["yaw"]),
            ),
            mass=mass, inertia=wp.mat33(inertia), lock_inertia=True, label=spec["name"],
        )
        collision_cfg = fruit_cfg.copy()
        collision_cfg.is_visible = spec["name"] != "pear"
        station.add_shape_ellipsoid(
            body, rx=a, ry=b, rz=c, cfg=collision_cfg, color=spec["color"],
            label=spec["name"] + "_skin", custom_attributes=contact,
        )
        if spec["name"] == "pear":
            add_pear_visual(station, body, spec["color"])

    # The photo-fitted sector has a shallow sloping floor and an inward bevel.
    # One convex floor and twenty rim pieces stay below 30 mm above the table.
    center = np.array([0.914, 0.139])
    radius = 0.225
    angles = np.linspace(2.950, 4.025, 19)
    outline = np.vstack([
        center, center + radius * np.column_stack([np.cos(angles), np.sin(angles)]),
    ])
    vertices = np.array([
        [x, y, z if z < 0.755 else z + TRAY_SLOPE*(x - 0.730) + TRAY_CROSS_SLOPE*(y - 0.100)]
        for z in (0.750, 0.759) for x, y in outline
    ], dtype=np.float32)
    n = len(outline)
    triangles = []
    for k in range(1, n - 1):
        triangles.extend([0, k + 1, k, n, n + k, n + k + 1])
    for k in range(n):
        j = (k + 1) % n
        triangles.extend([k, j, n + j, k, n + j, n + k])
    wood = newton.ModelBuilder.ShapeConfig(
        density=0, mu=0.7, mu_torsional=0.003, mu_rolling=0.001, margin=0.0,
    )
    mesh = newton.Mesh(vertices, np.asarray(triangles, dtype=np.int32))
    station.add_shape_convex_hull(
        -1, mesh=mesh, cfg=wood, color=(0.58, 0.36, 0.16),
        label="tray_floor", custom_attributes=contact,
    )
    for k in range(n):
        p, q = outline[k], outline[(k + 1) % n]
        mid = (p + q) / 2
        delta = q - p
        yaw = math.atan2(delta[1], delta[0])
        rotation = (
            wp.quat_from_axis_angle(wp.vec3(0, 0, 1), yaw)
            * wp.quat_from_axis_angle(wp.vec3(1, 0, 0), RIM_BEVEL)
        )
        station.add_shape_box(
            -1, xform=wp.transform((mid[0], mid[1], 0.770), rotation),
            hx=float(np.linalg.norm(delta)) / 2 + 0.001, hy=0.012, hz=0.003,
            cfg=wood, color=(0.65, 0.43, 0.21), label=f"tray_rim_{k}",
            custom_attributes=contact,
        )


def build_model(num_worlds: int = 1) -> newton.Model:
    """The calibrated station, three free fruits, and tray, in identical worlds."""
    station = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(station)
    station.add_mjcf(station_xml())
    add_scene(station)
    builder = newton.ModelBuilder()
    newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
    for _ in range(num_worlds):
        builder.add_world(station)
    return builder.finalize()


def make_solver(model: newton.Model) -> newton.solvers.SolverBase:
    return newton.solvers.SolverMuJoCo(
        model, use_mujoco_contacts=True, cone="elliptic",
        iterations=30, ls_iterations=15, njmax=2048, nconmax=4096,
    )


def make_pipeline(model: newton.Model) -> newton.CollisionPipeline | None:
    """MuJoCo generates the contacts for the elliptic friction solver."""
    return None


def load_episode(path: str | Path = EPISODE) -> dict[str, np.ndarray]:
    with np.load(path) as data:
        return {key: np.asarray(data[key]) for key in data.files}


def command_targets(episode: dict, times: np.ndarray, delay: float) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    """Per side: arm joint targets [T, 6] [rad] and left finger slide targets [T] [m] at control times [s]."""
    out = {}
    for side in SIDES:
        t, tg = episode[f"{side}_cmd_t"], episode[f"{side}_grip_cmd_t"]
        rows = np.clip(np.searchsorted(t, times - delay, side="right") - 1, 0, len(t) - 1)
        grip_rows = np.clip(np.searchsorted(tg, times - delay, side="right") - 1, 0, len(tg) - 1)
        finger = np.clip(episode[f"{side}_grip_cmd"][grip_rows], 0.0, 1.0) * GRIPPER_TRAVEL
        out[side] = (episode[f"{side}_cmd"][rows, :6], finger)
    return out


@wp.kernel
def apply_targets(
    schedule: wp.array2d[wp.float32],
    step: wp.array[wp.int32],
    index: wp.array[wp.int32],
    target: wp.array[wp.float32],
):
    j = wp.tid()
    target[index[j]] = schedule[wp.min(step[0], schedule.shape[0] - 1), j]


@wp.kernel
def advance(step: wp.array[wp.int32]):
    step[0] = step[0] + 1


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.episode = load_episode()
        self.model = build_model(args.num_worlds)
        self.solver = make_solver(self.model)
        self.collision_pipeline = make_pipeline(self.model)
        self.contacts = self.collision_pipeline.contacts() if self.collision_pipeline is not None else None
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()

        self.sim_dt = PARAMS["dt"]
        self.substeps = max(1, round(FRAME_DT / self.sim_dt))
        self.frame_dt = self.substeps * self.sim_dt
        self.sim_time = 0.0
        t = self.episode["left_t"]
        self.duration = float(t[-1] - t[0])
        times = t[0] + np.arange(math.ceil(self.duration / self.sim_dt - 1e-6)) * self.sim_dt
        targets = command_targets(self.episode, times, PARAMS["command_delay"])

        # Station joints of every world by MJCF name; targets use coordinate or DOF indexing.
        model = self.model
        names = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        world = model.joint_world.numpy()
        q_start, qd_start = model.joint_q_start.numpy(), model.joint_qd_start.numpy()
        coords = self.control.joint_target_q.shape[0] == model.joint_coord_count
        self.q0, self.qd0 = model.joint_q.numpy().copy(), np.zeros(model.joint_dof_count, dtype=np.float32)
        columns, index = [], []
        for w in range(model.world_count):
            joint = {name: j for j, name in enumerate(names) if world[j] == w}
            for side in SIDES:
                arm, finger = targets[side]
                for k in range(6):
                    j = joint[f"{side}_joint{k + 1}"]
                    self.q0[q_start[j]] = self.episode[f"{side}_q"][0, k]
                    self.qd0[qd_start[j]] = self.episode[f"{side}_qd"][0, k]
                    columns.append(arm[:, k])
                    index.append(q_start[j] if coords else qd_start[j])
                opening = float(np.clip(self.episode[f"{side}_grip"][0], 0.0, 1.0)) * GRIPPER_TRAVEL
                for sign, name in ((1.0, "left_finger"), (-1.0, "right_finger")):
                    j = joint[f"{side}_{name}"]
                    self.q0[q_start[j]] = sign * opening
                    columns.append(sign * finger)
                    index.append(q_start[j] if coords else qd_start[j])
        self.schedule = wp.array(np.stack(columns, axis=-1).astype(np.float32), dtype=wp.float32)
        self.target_index = wp.array(np.asarray(index, dtype=np.int32), dtype=wp.int32)
        self.step_index = wp.zeros(1, dtype=wp.int32)  # an example array: MCP checkpoints rewind it
        self.reset()

        self.graph = None
        if wp.get_device().is_cuda:
            self.simulate()  # load kernels and let the solver allocate before the capture
            self.reset()
            self.capture()
        self.viewer.set_model(self.model)

    def reset(self):
        """Back to the first state sample: initial state and targets, command cursor 0."""
        self.state_0.joint_q.assign(self.q0)
        self.state_0.joint_qd.assign(self.qd0)
        newton.eval_fk(self.model, self.state_0.joint_q, self.state_0.joint_qd, self.state_0)
        self.state_1.assign(self.state_0)
        self.step_index.zero_()
        self.apply_targets()
        if hasattr(self.solver, "reset"):
            self.solver.reset(self.state_0, flags=newton.StateFlags.NONE)
        self.sim_time = 0.0

    def apply_targets(self):
        inputs = [self.schedule, self.step_index, self.target_index]
        wp.launch(apply_targets, self.schedule.shape[1], inputs, [self.control.joint_target_q])

    def simulate(self):
        """One physics step at the current command row."""
        self.apply_targets()
        if self.collision_pipeline is not None:
            self.collision_pipeline.collide(self.state_0, self.contacts)
        self.solver.step(self.state_0, self.state_1, self.control, self.contacts, self.sim_dt)
        self.state_0.assign(self.state_1)
        wp.launch(advance, 1, [self.step_index])

    def capture(self):
        """Record one physics step as a CUDA graph (again after replacing the solver or pipeline)."""
        with wp.ScopedCapture() as capture:
            self.simulate()
        self.graph = capture.graph

    def step(self):
        for _ in range(self.substeps):
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    def test_final(self):
        assert np.all(np.isfinite(self.state_0.body_q.numpy())), "the simulation diverged"

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--num-worlds", type=int, default=1, help="Identical copies of the scene, one world each")
        parser.add_argument("--seconds", type=float, default=None, help="Replay only this long [s]")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    example = Example(viewer, args)
    seconds = example.duration if args.seconds is None else min(args.seconds, example.duration)
    for _ in range(math.ceil(seconds / example.frame_dt - 1e-6)):
        if args.viewer != "null" and not viewer.is_running():
            break
        example.step()
        example.render()
    example.test_final()
    print(f"replayed {example.sim_time:.2f} s of {args.num_worlds} world(s)")
