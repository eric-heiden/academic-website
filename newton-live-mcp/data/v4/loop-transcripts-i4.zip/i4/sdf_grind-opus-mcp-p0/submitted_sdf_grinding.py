# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

###########################################################################
# Example SDF Grinding
#
# A cylindrical grinding wheel is driven kinematically across an ellipsoidal
# workpiece. The workpiece is a mesh shape whose collision geometry is a sparse
# texture SDF (``workpiece_sdf``, built by ``Mesh.build_sdf``); hydroelastic
# SDF-SDF collision reports the contact surface and normal load every frame,
# without a dynamics solver. After each collision query, the volume the wheel
# swept since the previous frame is subtracted (CSG difference) from the
# workpiece texture SDF in place. The rendered workpiece surface is extracted
# from the same SDF.
#
# Command: python sdf_grinding.py
#
###########################################################################

import math

import numpy as np
import warp as wp

import newton
import newton.examples

WORKPIECE_RADII = (0.45, 0.25, 0.12)
WORKPIECE_RESOLUTION = 256
GRINDER_RADIUS = 0.13
GRINDER_HALF_WIDTH = 0.04
GRIND_DEPTH = 0.035
GRIND_FRAMES = 270
HYDROELASTIC_STIFFNESS = 1.0e8


@wp.kernel(enable_backward=False)
def _compute_normal_load(
    contact_count: wp.array[wp.int32],
    contact_distance: wp.array[wp.float32],
    contact_stiffness: wp.array[wp.float32],
    normal_load: wp.array[wp.float32],
):
    contact = wp.tid()
    if contact < contact_count[0]:
        normal_load[contact] = wp.max(-contact_distance[contact] * contact_stiffness[contact], 0.0)
    else:
        normal_load[contact] = 0.0


@wp.func
def _swept_wheel_sdf(
    point: wp.vec3,
    tool_prev: wp.transform,
    tool_curr: wp.transform,
    radius: float,
    half_width: float,
) -> float:
    """Signed distance to the volume a cylinder sweeps between two poses.

    The wheel translates within its own radial plane (the cylinder axis is the
    local z-axis), so the swept volume is a 2D stadium (disk swept along the
    segment between both centers) extruded over the wheel width, whose
    signed distance is exact.
    """
    inv_curr = wp.transform_inverse(tool_curr)
    q = wp.transform_point(inv_curr, point)
    a = wp.transform_point(inv_curr, wp.transform_get_translation(tool_prev))

    seg = wp.vec2(a[0], a[1])
    pt = wp.vec2(q[0], q[1])
    seg_len_sq = wp.dot(seg, seg)
    t = float(0.0)
    if seg_len_sq > 1.0e-12:
        t = wp.clamp(wp.dot(pt, seg) / seg_len_sq, 0.0, 1.0)

    dr = wp.length(pt - seg * t) - radius
    dz = wp.abs(q[2] - a[2] * t) - half_width
    outside = wp.length(wp.vec2(wp.max(dr, 0.0), wp.max(dz, 0.0)))
    inside = wp.min(wp.max(dr, dz), 0.0)
    return outside + inside


@wp.kernel(enable_backward=False)
def _grind_subgrid_samples(
    cell_coords: wp.array[wp.vec3i],
    cell_slots: wp.array[wp.uint32],
    subgrid_size: int,
    sdf_box_lower: wp.vec3,
    voxel_size: wp.vec3,
    tool_prev: wp.transform,
    tool_curr: wp.transform,
    radius: float,
    half_width: float,
    subgrid_values: wp.array3d[wp.float32],
):
    """Subtract the swept wheel from every fine sample of the resident subgrids."""
    cell_idx, sample = wp.tid()
    cell = cell_coords[cell_idx]
    slot = cell_slots[cell_idx]

    n = subgrid_size + 1
    lx = sample % n
    ly = (sample // n) % n
    lz = sample // (n * n)

    fine = wp.vec3(
        float(cell[0] * subgrid_size + lx),
        float(cell[1] * subgrid_size + ly),
        float(cell[2] * subgrid_size + lz),
    )
    point = sdf_box_lower + wp.cw_mul(fine, voxel_size)
    removed = -_swept_wheel_sdf(point, tool_prev, tool_curr, radius, half_width)

    tx = int(slot & wp.uint32(0x3FF)) * n + lx
    ty = int((slot >> wp.uint32(10)) & wp.uint32(0x3FF)) * n + ly
    tz = int((slot >> wp.uint32(20)) & wp.uint32(0x3FF)) * n + lz
    # CSG difference: workpiece minus swept wheel = max(d_workpiece, -d_wheel).
    if removed > subgrid_values[tz, ty, tx]:
        subgrid_values[tz, ty, tx] = removed


@wp.kernel(enable_backward=False)
def _grind_coarse_samples(
    subgrid_size: int,
    sdf_box_lower: wp.vec3,
    voxel_size: wp.vec3,
    tool_prev: wp.transform,
    tool_curr: wp.transform,
    radius: float,
    half_width: float,
    coarse_values: wp.array3d[wp.float32],
):
    """Subtract the swept wheel from the coarse background samples."""
    z, y, x = wp.tid()
    fine = wp.vec3(float(x * subgrid_size), float(y * subgrid_size), float(z * subgrid_size))
    point = sdf_box_lower + wp.cw_mul(fine, voxel_size)
    removed = -_swept_wheel_sdf(point, tool_prev, tool_curr, radius, half_width)
    if removed > coarse_values[z, y, x]:
        coarse_values[z, y, x] = removed


class Example:
    def __init__(self, viewer, _args):
        self.viewer = viewer
        self.frame_dt = 1.0 / 60.0
        self.sim_time = 0.0
        self.frame = 0

        # A gently curved blank keeps fine SDF subgrids resident around the
        # entire machined surface, which makes this compact in-place demo
        # independent of Newton's linear-subgrid storage optimization.
        workpiece_mesh = newton.Mesh.create_ellipsoid(
            *WORKPIECE_RADII,
            num_latitudes=32,
            num_longitudes=64,
            compute_normals=False,
            compute_uvs=False,
            compute_inertia=False,
        )
        self.workpiece_sdf = workpiece_mesh.build_sdf(
            max_resolution=WORKPIECE_RESOLUTION,
            narrow_band_range=(-0.08, 0.08),
            margin=0.04,
            texture_format="float32",
            paired_samples=False,
        )

        shape_cfg = newton.ModelBuilder.ShapeConfig(
            margin=0.0,
            gap=0.005,
            kh=HYDROELASTIC_STIFFNESS,
            density=0.0,
            is_hydroelastic=True,
        )
        workpiece_cfg = shape_cfg.copy()
        workpiece_cfg.is_visible = False
        grinder_cfg = shape_cfg.copy()
        grinder_cfg.sdf_max_resolution = 64
        grinder_cfg.sdf_narrow_band_range = (-0.06, 0.06)
        grinder_cfg.sdf_padding = 0.01

        builder = newton.ModelBuilder()
        builder.sdf_texture_paired_samples = False
        self.workpiece_shape = builder.add_shape_mesh(
            body=-1,
            mesh=workpiece_mesh,
            cfg=workpiece_cfg,
            label="workpiece",
        )

        initial_pose = self._grinder_pose(0)
        self.grinder_body = builder.add_body(xform=initial_pose, label="grinder")
        self.grinder_shape = builder.add_shape_cylinder(
            body=self.grinder_body,
            radius=GRINDER_RADIUS,
            half_height=GRINDER_HALF_WIDTH,
            cfg=grinder_cfg,
            color=(0.18, 0.20, 0.23),
            opacity=0.4,
            label="grinding_wheel",
        )

        self.model = builder.finalize()
        self.state_0 = self.model.state()
        self.collision_pipeline = newton.CollisionPipeline(
            self.model,
            sdf_hydroelastic_config=newton.geometry.HydroelasticSDF.Config(
                output_contact_surface=True,
            ),
        )
        self.contacts = self.collision_pipeline.contacts()
        self.contact_surface = self.collision_pipeline.hydroelastic_sdf.get_contact_surface()
        self.contact_distance = wp.empty(
            self.contacts.rigid_contact_max,
            dtype=wp.float32,
            device=self.model.device,
        )
        self.normal_load = wp.empty_like(self.contact_distance)
        self.total_normal_load = 0.0

        self.body_q = self.state_0.body_q.numpy()
        self._set_grinder_pose(initial_pose)
        self._init_material_removal()
        self._tool_prev = self._tool_pose_in_workpiece(initial_pose)
        self._update_workpiece_surface()

        self.viewer.set_model(self.model)
        self.viewer.show_hydro_contact_surface = True
        self.viewer.set_camera(pos=wp.vec3(0.8, -0.85, 0.5), pitch=-18.0, yaw=132.0)

    @staticmethod
    def _grinder_pose(frame: int) -> wp.transform:
        x_start = -0.36
        x_end = 0.36
        x = x_start + min(frame / GRIND_FRAMES, 1.0) * (x_end - x_start)
        radial_fraction = min((x / WORKPIECE_RADII[0]) ** 2, 1.0)
        surface_z = WORKPIECE_RADII[2] * math.sqrt(1.0 - radial_fraction)
        z = surface_z + GRINDER_RADIUS - GRIND_DEPTH
        rotation = wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), -0.5 * math.pi)
        return wp.transform(wp.vec3(x, 0.0, z), rotation)

    def _set_grinder_pose(self, pose: wp.transform) -> None:
        self.body_q[self.grinder_body] = np.asarray(pose)
        self.state_0.body_q.assign(self.body_q)

    def _init_material_removal(self) -> None:
        """Mirror the workpiece texture SDF into editable Warp arrays.

        The collision pipeline samples the texture SDF attached to the workpiece
        shape in ``Model``. Material removal edits a float32 copy of its subgrid
        and coarse texels and uploads them back into those same textures, so the
        collision geometry, the hydroelastic contact surface and the rendered
        isosurface all see the machined workpiece.
        """
        sdf_data = self.workpiece_sdf.texture_data
        if sdf_data.paired_samples or self.workpiece_sdf._subgrid_texture.dtype != wp.float32:
            raise ValueError("Material removal requires an unpaired float32 texture SDF.")
        if sdf_data.subgrids_min_sdf_value != 0.0 or sdf_data.subgrids_sdf_value_range != 1.0:
            raise ValueError("Material removal requires unscaled subgrid SDF values.")

        # Textures read by the collision pipeline and by the isosurface extraction.
        sdf_idx = int(self.model._shape_sdf_index.numpy()[self.workpiece_shape])
        self._subgrid_textures = [self.model._texture_sdf_subgrid_textures[sdf_idx]]
        self._coarse_textures = [self.model._texture_sdf_coarse_textures[sdf_idx]]
        if self.workpiece_sdf._subgrid_texture is not self._subgrid_textures[0]:
            self._subgrid_textures.append(self.workpiece_sdf._subgrid_texture)
        if self.workpiece_sdf._coarse_texture is not self._coarse_textures[0]:
            self._coarse_textures.append(self.workpiece_sdf._coarse_texture)

        device = self.model.device
        subgrid_tex = self._subgrid_textures[0]
        coarse_tex = self._coarse_textures[0]
        self._subgrid_values = wp.empty(
            (subgrid_tex.depth, subgrid_tex.height, subgrid_tex.width), dtype=wp.float32, device=device
        )
        self._coarse_values = wp.empty(
            (coarse_tex.depth, coarse_tex.height, coarse_tex.width), dtype=wp.float32, device=device
        )
        subgrid_tex.copy_to(self._subgrid_values)
        coarse_tex.copy_to(self._coarse_values)

        # Coarse cells that own a fine subgrid (the rest fall back to coarse samples).
        start_slots = sdf_data.subgrid_start_slots.numpy()
        resident = np.argwhere(start_slots < 0xFFFFFFFE)
        self._grind_cells = wp.array(resident.astype(np.int32), dtype=wp.vec3i, device=device)
        self._grind_cell_slots = wp.array(
            start_slots[resident[:, 0], resident[:, 1], resident[:, 2]], dtype=wp.uint32, device=device
        )
        self._subgrid_size = int(sdf_data.subgrid_size)
        self._sdf_box_lower = wp.vec3(sdf_data.sdf_box_lower)
        self._voxel_size = wp.vec3(sdf_data.voxel_size)

        shape_xforms = self.model.shape_transform.numpy()
        self._workpiece_xform_inv = wp.transform_inverse(wp.transform(*shape_xforms[self.workpiece_shape]))
        self._grinder_shape_xform = wp.transform(*shape_xforms[self.grinder_shape])

    def _tool_pose_in_workpiece(self, body_pose: wp.transform) -> wp.transform:
        world_pose = wp.transform_multiply(body_pose, self._grinder_shape_xform)
        return wp.transform_multiply(self._workpiece_xform_inv, world_pose)

    def _remove_swept_material(self, grinder_pose: wp.transform) -> None:
        """Subtract the volume the wheel swept since the previous frame from the workpiece SDF."""
        tool_curr = self._tool_pose_in_workpiece(grinder_pose)
        n = self._subgrid_size + 1
        wp.launch(
            _grind_subgrid_samples,
            dim=(self._grind_cells.shape[0], n * n * n),
            inputs=[
                self._grind_cells,
                self._grind_cell_slots,
                self._subgrid_size,
                self._sdf_box_lower,
                self._voxel_size,
                self._tool_prev,
                tool_curr,
                GRINDER_RADIUS,
                GRINDER_HALF_WIDTH,
                self._subgrid_values,
            ],
            device=self.model.device,
        )
        wp.launch(
            _grind_coarse_samples,
            dim=self._coarse_values.shape,
            inputs=[
                self._subgrid_size,
                self._sdf_box_lower,
                self._voxel_size,
                self._tool_prev,
                tool_curr,
                GRINDER_RADIUS,
                GRINDER_HALF_WIDTH,
                self._coarse_values,
            ],
            device=self.model.device,
        )
        self._tool_prev = tool_curr
        self._upload_workpiece_sdf()

    def _upload_workpiece_sdf(self) -> None:
        for texture in self._subgrid_textures:
            texture.copy_from(self._subgrid_values)
        for texture in self._coarse_textures:
            texture.copy_from(self._coarse_values)

    def _update_workpiece_surface(self) -> None:
        surface = self.workpiece_sdf.extract_isomesh(device=self.model.device)
        if surface is None:
            raise RuntimeError("Grinding removed the complete workpiece.")
        self.workpiece_points = wp.array(surface.vertices, dtype=wp.vec3, device=self.model.device)
        self.workpiece_indices = wp.array(surface.indices.reshape(-1), dtype=wp.int32, device=self.model.device)

    def step(self):
        self.frame += 1
        grinder_pose = self._grinder_pose(self.frame)
        self._set_grinder_pose(grinder_pose)

        # Run hydroelastic SDF-SDF collision before editing the workpiece.
        self.collision_pipeline.collide(self.state_0, self.contacts)
        newton.eval_rigid_contact_kinematics(
            self.model,
            self.state_0,
            self.contacts,
            out_distance=self.contact_distance,
        )
        wp.launch(
            _compute_normal_load,
            dim=self.contacts.rigid_contact_max,
            inputs=[
                self.contacts.rigid_contact_count,
                self.contact_distance,
                self.contacts.rigid_contact_stiffness,
                self.normal_load,
            ],
            device=self.model.device,
        )
        self.total_normal_load = float(wp.utils.array_sum(self.normal_load))
        self._remove_swept_material(grinder_pose)
        self._update_workpiece_surface()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.log_mesh(
            "/workpiece_sdf",
            self.workpiece_points,
            self.workpiece_indices,
            color=(0.55, 0.62, 0.68),
            roughness=0.65,
            metallic=0.25,
            dynamic=True,
        )
        self.viewer.log_hydro_contact_surface(self.contact_surface)
        self.viewer.log_scalar("Hydroelastic normal load [N]", self.total_normal_load)
        self.viewer.end_frame()


if __name__ == "__main__":
    viewer, args = newton.examples.init()
    newton.examples.run(Example(viewer, args), args)
