# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

###########################################################################
# Example SDF Grinding
#
# A cylindrical grinding wheel is driven kinematically across an ellipsoidal
# workpiece. The workpiece is a mesh shape whose collision geometry is a sparse
# texture SDF (``workpiece_sdf``, built by ``Mesh.build_sdf``); hydroelastic
# SDF-SDF collision reports the contact surface and normal load every frame,
# without a dynamics solver. The rendered workpiece surface is extracted from
# the same SDF. Each frame subtracts the swept wheel from both levels of the
# texture SDF in place, then extracts the newly machined surface.
#
# Command: python sdf_grinding.py
#
###########################################################################

import math

import numpy as np
import warp as wp

import newton
import newton.examples

WORKPIECE_RADII = (0.45, 0.25, 0.12)
WORKPIECE_RESOLUTION = 256
GRINDER_RADIUS = 0.13
GRINDER_HALF_WIDTH = 0.04
GRIND_DEPTH = 0.035
GRIND_FRAMES = 270
HYDROELASTIC_STIFFNESS = 1.0e8


@wp.func
def _swept_grinder_distance(p: wp.vec3, start: wp.vec3, end: wp.vec3) -> float:
    # The wheel axis is Y throughout _grinder_pose. Its sweep along one
    # XZ line segment is a 2D capsule extruded between the wheel's end caps.
    # Including the whole segment also includes the initial pose at frame 0.
    segment = end - start
    t = wp.clamp(wp.dot(p - start, segment) / wp.max(wp.dot(segment, segment), 1.0e-20), 0.0, 1.0)
    center = start + t * segment
    radial = wp.length(wp.vec2(p[0] - center[0], p[2] - center[2])) - GRINDER_RADIUS
    axial = wp.abs(p[1]) - GRINDER_HALF_WIDTH
    return wp.length(wp.vec2(wp.max(radial, 0.0), wp.max(axial, 0.0))) + wp.min(wp.max(radial, axial), 0.0)


@wp.kernel(enable_backward=False)
def _carve_subgrids(
    slots: wp.array3d[wp.uint32],
    values: wp.array3d[wp.float32],
    lower: wp.vec3,
    voxel_size: wp.vec3,
    subgrid_size: int,
    start: wp.vec3,
    end: wp.vec3,
):
    bx, by, bz, sample = wp.tid()
    slot = slots[bx, by, bz]
    # EMPTY and LINEAR cells use the coarse texture. The blank's wide narrow
    # band keeps fine subgrids resident throughout this shallow cut.
    if slot < wp.uint32(0xFFFFFFFE):
        n = subgrid_size + 1
        lx = sample % n
        ly = (sample // n) % n
        lz = sample // (n * n)
        p = lower + wp.cw_mul(
            wp.vec3(float(bx * subgrid_size + lx), float(by * subgrid_size + ly), float(bz * subgrid_size + lz)),
            voxel_size,
        )
        # Slots pack atlas BLOCK coordinates, not texel coordinates. Textures
        # use Z,Y,X array order; the indirection array uses X,Y,Z order.
        tx = int(slot & wp.uint32(0x3FF)) * n + lx
        ty = int((slot >> wp.uint32(10)) & wp.uint32(0x3FF)) * n + ly
        tz = int((slot >> wp.uint32(20)) & wp.uint32(0x3FF)) * n + lz
        # SDF difference: solid is negative, so removing B from A is max(A,-B).
        # Update every duplicate border sample to keep adjacent blocks joined.
        values[tz, ty, tx] = wp.max(values[tz, ty, tx], -_swept_grinder_distance(p, start, end))


@wp.kernel(enable_backward=False)
def _carve_coarse(
    values: wp.array3d[wp.float32],
    lower: wp.vec3,
    spacing: wp.vec3,
    start: wp.vec3,
    end: wp.vec3,
):
    z, y, x = wp.tid()
    p = lower + wp.cw_mul(wp.vec3(float(x), float(y), float(z)), spacing)
    values[z, y, x] = wp.max(values[z, y, x], -_swept_grinder_distance(p, start, end))


@wp.kernel(enable_backward=False)
def _compute_normal_load(
    contact_count: wp.array[wp.int32],
    contact_distance: wp.array[wp.float32],
    contact_stiffness: wp.array[wp.float32],
    normal_load: wp.array[wp.float32],
):
    contact = wp.tid()
    if contact < contact_count[0]:
        normal_load[contact] = wp.max(-contact_distance[contact] * contact_stiffness[contact], 0.0)
    else:
        normal_load[contact] = 0.0


class Example:
    def __init__(self, viewer, _args):
        self.viewer = viewer
        self.frame_dt = 1.0 / 60.0
        self.sim_time = 0.0
        self.frame = 0

        # A gently curved blank keeps fine SDF subgrids resident around the
        # entire machined surface, which makes this compact in-place demo
        # independent of Newton's linear-subgrid storage optimization.
        workpiece_mesh = newton.Mesh.create_ellipsoid(
            *WORKPIECE_RADII,
            num_latitudes=32,
            num_longitudes=64,
            compute_normals=False,
            compute_uvs=False,
            compute_inertia=False,
        )
        self.workpiece_sdf = workpiece_mesh.build_sdf(
            max_resolution=WORKPIECE_RESOLUTION,
            narrow_band_range=(-0.08, 0.08),
            margin=0.04,
            texture_format="float32",
            paired_samples=False,
        )

        shape_cfg = newton.ModelBuilder.ShapeConfig(
            margin=0.0,
            gap=0.005,
            kh=HYDROELASTIC_STIFFNESS,
            density=0.0,
            is_hydroelastic=True,
        )
        workpiece_cfg = shape_cfg.copy()
        workpiece_cfg.is_visible = False
        grinder_cfg = shape_cfg.copy()
        grinder_cfg.sdf_max_resolution = 64
        grinder_cfg.sdf_narrow_band_range = (-0.06, 0.06)
        grinder_cfg.sdf_padding = 0.01

        builder = newton.ModelBuilder()
        builder.sdf_texture_paired_samples = False
        builder.add_shape_mesh(
            body=-1,
            mesh=workpiece_mesh,
            cfg=workpiece_cfg,
            label="workpiece",
        )

        initial_pose = self._grinder_pose(0)
        self.grinder_body = builder.add_body(xform=initial_pose, label="grinder")
        builder.add_shape_cylinder(
            body=self.grinder_body,
            radius=GRINDER_RADIUS,
            half_height=GRINDER_HALF_WIDTH,
            cfg=grinder_cfg,
            color=(0.18, 0.20, 0.23),
            opacity=0.4,
            label="grinding_wheel",
        )

        self.model = builder.finalize()
        self.state_0 = self.model.state()
        self.collision_pipeline = newton.CollisionPipeline(
            self.model,
            sdf_hydroelastic_config=newton.geometry.HydroelasticSDF.Config(
                output_contact_surface=True,
            ),
        )
        self.contacts = self.collision_pipeline.contacts()
        self.contact_surface = self.collision_pipeline.hydroelastic_sdf.get_contact_surface()
        self.contact_distance = wp.empty(
            self.contacts.rigid_contact_max,
            dtype=wp.float32,
            device=self.model.device,
        )
        self.normal_load = wp.empty_like(self.contact_distance)
        self.total_normal_load = 0.0

        self.body_q = self.state_0.body_q.numpy()
        self._set_grinder_pose(initial_pose)
        self._initialize_material_removal()
        self._update_workpiece_surface()

        self.viewer.set_model(self.model)
        self.viewer.show_hydro_contact_surface = True
        self.viewer.set_camera(pos=wp.vec3(0.8, -0.85, 0.5), pitch=-18.0, yaw=132.0)

    @staticmethod
    def _grinder_pose(frame: int) -> wp.transform:
        x_start = -0.36
        x_end = 0.36
        x = x_start + min(frame / GRIND_FRAMES, 1.0) * (x_end - x_start)
        radial_fraction = min((x / WORKPIECE_RADII[0]) ** 2, 1.0)
        surface_z = WORKPIECE_RADII[2] * math.sqrt(1.0 - radial_fraction)
        z = surface_z + GRINDER_RADIUS - GRIND_DEPTH
        rotation = wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), -0.5 * math.pi)
        return wp.transform(wp.vec3(x, 0.0, z), rotation)

    def _set_grinder_pose(self, pose: wp.transform) -> None:
        self.body_q[self.grinder_body] = np.asarray(pose)
        self.state_0.body_q.assign(self.body_q)

    def _initialize_material_removal(self) -> None:
        # Writable staging arrays retain the accumulated CSG difference. Keep
        # the original texture objects: the mesh SDF, model's SDF table, and
        # hydroelastic descriptors all refer to these same texture handles.
        sdf = self.workpiece_sdf
        self._fine_values = wp.empty(
            (sdf._subgrid_texture.depth, sdf._subgrid_texture.height, sdf._subgrid_texture.width),
            dtype=wp.float32,
            device=self.model.device,
        )
        self._coarse_values = wp.empty(
            (sdf._coarse_texture.depth, sdf._coarse_texture.height, sdf._coarse_texture.width),
            dtype=wp.float32,
            device=self.model.device,
        )
        sdf._subgrid_texture.copy_to(self._fine_values)
        sdf._coarse_texture.copy_to(self._coarse_values)

    def _remove_material(self, previous_pose: wp.transform, pose: wp.transform) -> None:
        sdf = self.workpiece_sdf
        data = sdf.texture_data
        start = wp.transform_get_translation(previous_pose)
        end = wp.transform_get_translation(pose)
        wp.launch(
            _carve_subgrids,
            dim=(*data.subgrid_start_slots.shape, (data.subgrid_size + 1) ** 3),
            inputs=[
                data.subgrid_start_slots,
                self._fine_values,
                data.sdf_box_lower,
                data.voxel_size,
                data.subgrid_size,
                start,
                end,
            ],
            device=self.model.device,
        )
        wp.launch(
            _carve_coarse,
            dim=self._coarse_values.shape,
            inputs=[
                self._coarse_values,
                data.sdf_box_lower,
                data.voxel_size * float(data.subgrid_size),
                start,
                end,
            ],
            device=self.model.device,
        )
        # Publish both levels before collision or isosurface sampling. Copying
        # into the existing textures updates collision without rebuilding the
        # pipeline or leaving cached descriptors pointing at an old texture.
        sdf._subgrid_texture.copy_from(self._fine_values)
        sdf._coarse_texture.copy_from(self._coarse_values)

    def _update_workpiece_surface(self) -> None:
        surface = self.workpiece_sdf.extract_isomesh(device=self.model.device)
        if surface is None:
            raise RuntimeError("Grinding removed the complete workpiece.")
        self.workpiece_points = wp.array(surface.vertices, dtype=wp.vec3, device=self.model.device)
        self.workpiece_indices = wp.array(surface.indices.reshape(-1), dtype=wp.int32, device=self.model.device)

    def step(self):
        self.frame += 1
        grinder_pose = self._grinder_pose(self.frame)
        self._set_grinder_pose(grinder_pose)

        # Run hydroelastic SDF-SDF collision before editing the workpiece.
        self.collision_pipeline.collide(self.state_0, self.contacts)
        newton.eval_rigid_contact_kinematics(
            self.model,
            self.state_0,
            self.contacts,
            out_distance=self.contact_distance,
        )
        wp.launch(
            _compute_normal_load,
            dim=self.contacts.rigid_contact_max,
            inputs=[
                self.contacts.rigid_contact_count,
                self.contact_distance,
                self.contacts.rigid_contact_stiffness,
                self.normal_load,
            ],
            device=self.model.device,
        )
        self.total_normal_load = float(wp.utils.array_sum(self.normal_load))
        if self.frame <= GRIND_FRAMES:
            self._remove_material(self._grinder_pose(self.frame - 1), grinder_pose)
            self._update_workpiece_surface()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.log_mesh(
            "/workpiece_sdf",
            self.workpiece_points,
            self.workpiece_indices,
            color=(0.55, 0.62, 0.68),
            roughness=0.65,
            metallic=0.25,
            dynamic=True,
        )
        self.viewer.log_hydro_contact_surface(self.contact_surface)
        self.viewer.log_scalar("Hydroelastic normal load [N]", self.total_normal_load)
        self.viewer.end_frame()


if __name__ == "__main__":
    viewer, args = newton.examples.init()
    newton.examples.run(Example(viewer, args), args)
