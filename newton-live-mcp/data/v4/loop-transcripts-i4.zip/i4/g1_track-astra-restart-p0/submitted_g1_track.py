# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 tracking a Kimodo motion with floating-base balance feedback.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A double-support inverse-dynamics controller balances the root
through the legs; velocity and inverse-dynamics feedforward track the motion.
The controller uses MuJoCo, NumPy, SciPy and OSQP.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import warp as wp
from scipy import sparse

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class BalanceController:
    """Double-support inverse dynamics, delivered only through joint servos.

    A small QP tracks the floating-base pose and joint accelerations while
    satisfying unactuated dynamics, foot support, friction and torque bounds.
    Its contact forces are predictions used to calculate motor commands; they
    are never applied to the simulator. MuJoCo supplies the actual contacts.
    """

    def __init__(self, example):
        self.example = example
        self.model = example.solver.mj_model
        # Separate scratch data: inverse dynamics never writes simulation state.
        self.data = mujoco.MjData(self.model)
        self.nv = self.model.nv
        self.feet = [
            i
            for side in ("left", "right")
            for i in range(self.model.nbody)
            if self.model.body(i).name.endswith(f"{side}_ankle_roll_link")
        ]
        self.anchors = None
        self.mass = np.empty((self.nv, self.nv))
        self.limits = self.model.actuator_forcerange[:, 1].copy()
        self.acceleration_kp = np.r_[np.full(6, 100.0), np.full(29, 180.0)]
        self.acceleration_kd = 2.0 * np.sqrt(self.acceleration_kp)
        self.weights = np.r_[np.full(3, 200.0), np.full(3, 100.0), np.ones(29)]
        # Arms, waist and hip yaw retain stiff trajectory tracking. The other
        # ten leg joints implement the support/balance torques from the QP.
        self.tracking_joints = np.r_[2, 8, np.arange(12, 29)]
        self.qp = None
        self.solve_failures = 0

    @staticmethod
    def _mujoco_qpos(q):
        return np.r_[q[:3], q[6], q[3:6], q[7:]]

    def _contact_tasks(self):
        """Sole stabilization and world-space Jacobians at the eight corners."""
        m, d, nv = self.model, self.data, self.nv
        contact_jacobians, contact_accelerations, force_jacobians = [], [], []
        anchors = []
        for k, body in enumerate(self.feet):
            rotation = d.xmat[body].reshape(3, 3)
            center = d.xpos[body] + rotation @ np.array([0.035, 0.0, -0.035])
            jp, jr, jdp, jdr = (np.zeros((3, nv)) for _ in range(4))
            mujoco.mj_jac(m, d, jp, jr, center, body)
            mujoco.mj_jacDot(m, d, jdp, jdr, center, body)
            jacobian = np.vstack((jp, jr))
            jacobian_dot = np.vstack((jdp, jdr))

            anchors.append(center.copy())
            anchor = center.copy() if self.anchors is None else self.anchors[k].copy()
            anchor[2] = 0.0
            # Level each sole while retaining its current heading. Hip-yaw
            # tracking can turn the feet as requested by the reference.
            yaw = np.arctan2(rotation[1, 0], rotation[0, 0])
            c, s = np.cos(yaw), np.sin(yaw)
            level_rotation = np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])
            orientation_error = 0.5 * sum(
                np.cross(rotation[:, i], level_rotation[:, i]) for i in range(3)
            )
            acceleration = (
                100.0 * np.r_[anchor - center, orientation_error]
                - 20.0 * (jacobian @ d.qvel)
                - jacobian_dot @ d.qvel
            )
            contact_jacobians.append(jacobian)
            contact_accelerations.append(acceleration)
            # The same sole dimensions are used by Example._floor_offset.
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    point = d.xpos[body] + rotation @ np.array([x, y, -0.035])
                    jac = np.zeros((3, nv))
                    mujoco.mj_jac(m, d, jac, None, point, body)
                    force_jacobians.append(jac)
        if self.anchors is None:
            self.anchors = anchors
        return (
            np.vstack(contact_jacobians),
            np.concatenate(contact_accelerations),
            np.vstack(force_jacobians),
        )

    def update(self, t):
        e, m, d, nv = self.example, self.model, self.data, self.nv
        # Read native generalized velocities (MuJoCo uses body-local root
        # angular velocity; Newton's floating-joint velocity convention differs).
        if e.solver.use_mujoco_cpu:
            d.qpos[:] = e.solver.mj_data.qpos
            d.qvel[:] = e.solver.mj_data.qvel
        else:
            d.qpos[:] = e.solver.mjw_data.qpos.numpy()[0]
            d.qvel[:] = e.solver.mjw_data.qvel.numpy()[0]
        mujoco.mj_forward(m, d)
        mujoco.mj_fullM(m, d, self.mass)
        mass = self.mass
        bias = d.qfrc_bias - d.qfrc_passive

        # Differentiate the public reference sampler, including its quaternion
        # and endpoint handling. This also follows changes in playback speed.
        derivative_dt = 0.5 * e.frame_dt
        qref = self._mujoco_qpos(e.reference(t))
        qminus = self._mujoco_qpos(e.reference(max(t - derivative_dt, 0.0)))
        qplus = self._mujoco_qpos(e.reference(t + derivative_dt))
        velocity, vminus, vplus, error = (np.zeros(nv) for _ in range(4))
        mujoco.mj_differentiatePos(m, velocity, 2.0 * derivative_dt, qminus, qplus)
        mujoco.mj_differentiatePos(m, vminus, derivative_dt, qminus, qref)
        mujoco.mj_differentiatePos(m, vplus, derivative_dt, qref, qplus)
        acceleration = (vplus - vminus) / derivative_dt
        mujoco.mj_differentiatePos(m, error, 1.0, d.qpos, qref)
        desired_acceleration = (
            acceleration
            + self.acceleration_kp * error
            + self.acceleration_kd * (velocity - d.qvel)
        )

        contact_jac, contact_acc, force_jac = self._contact_tasks()
        nf = force_jac.shape[0]
        # Decision variables are [generalized acceleration, corner forces].
        # Eliminate actuator torque with tau = (M*a + bias - J.T*f)[6:].
        equality = np.vstack(
            (
                np.c_[mass[:6], -force_jac[:, :6].T],
                np.c_[contact_jac, np.zeros((contact_jac.shape[0], nf))],
            )
        )
        equality_rhs = np.r_[-bias[:6], contact_acc]
        torque_map = np.c_[mass[6:], -force_jac[:, 6:].T]

        # Nonnegative normal forces and a linearized friction pyramid also
        # constrain the center of pressure to the rectangular foot support.
        friction = np.zeros((nf // 3 * 5, nv + nf))
        for k in range(nf // 3):
            friction[k * 5 : k * 5 + 5, nv + k * 3 : nv + k * 3 + 3] = [
                [0.0, 0.0, 1.0],
                [1.0, 0.0, -0.6],
                [-1.0, 0.0, -0.6],
                [0.0, 1.0, -0.6],
                [0.0, -1.0, -0.6],
            ]
        force_lower = np.tile([0.0, -np.inf, -np.inf, -np.inf, -np.inf], nf // 3)
        force_upper = np.tile([400.0, 0.0, 0.0, 0.0, 0.0], nf // 3)
        constraints = np.vstack((equality, torque_map, friction))
        lower = np.r_[equality_rhs, -self.limits - bias[6:], force_lower]
        upper = np.r_[equality_rhs, self.limits - bias[6:], force_upper]
        cost = np.r_[-self.weights * desired_acceleration, np.zeros(nf)]
        # Keep explicit zeros so the sparse update pattern is configuration
        # independent; reuse OSQP's workspace and previous solution each frame.
        rows, cols = np.indices(constraints.shape)
        constraint_matrix = sparse.csc_matrix(
            (constraints.ravel(), (rows.ravel(), cols.ravel())), shape=constraints.shape
        )
        if self.qp is None:
            self.qp = osqp.OSQP()
            self.qp.setup(
                P=sparse.diags(np.r_[self.weights, np.full(nf, 1.0e-4)], format="csc"),
                q=cost,
                A=constraint_matrix,
                l=lower,
                u=upper,
                verbose=False,
                eps_abs=1.0e-4,
                eps_rel=1.0e-4,
                max_iter=1500,
                polishing=False,
            )
        else:
            self.qp.update(q=cost, Ax=constraint_matrix.data, l=lower, u=upper)
        solution = self.qp.solve()
        if (
            solution.info.status_val in (1, 2)
            and solution.x is not None
            and np.all(np.isfinite(solution.x))
        ):
            torque = torque_map @ solution.x + bias[6:]
        else:
            # A bounded joint PD command is preferable to an invalid QP iterate.
            self.solve_failures += 1
            torque = e.kp * error[6:] + e.kd * (velocity[6:] - d.qvel[6:])
        torque = np.clip(torque, -self.limits, self.limits)

        # Convert the support torque to an equivalent position-servo target.
        # The half-frame term compensates the zero-order hold between updates;
        # the simulator retains implicit servo damping at every 2 ms substep.
        target = e.reference(t)
        target[7:] = (
            d.qpos[7:]
            + (torque + e.kd * d.qvel[6:]) / e.kp
            + d.qvel[6:] * e.frame_dt * 0.5
        )
        # Direct trajectory servos reject small unmodelled contact/friction
        # disturbances without the low-inertia joints accumulating pose error.
        ahead = e.reference(t + 0.5 * e.frame_dt)
        joints = self.tracking_joints
        dofs = 6 + joints
        target[7 + joints] = (
            ahead[7 + joints]
            + e.kd[joints] / e.kp[joints] * velocity[dofs]
            + (mass[dofs] @ acceleration + bias[dofs]) / e.kp[joints]
        )
        e.control.joint_target_q.assign(target)


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint. Implicit damping acts at the physics substep rate.
        self.kp = np.array(
            [400.0, 400.0, 300.0, 500.0, 200.0, 200.0] * 2 + [300.0] * 3 + [150.0] * 14
        )
        self.kd = np.array([12.0, 12.0, 8.0, 12.0, 6.0, 6.0] * 2 + [10.0] * 3 + [5.0] * 14)
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self.balance = BalanceController(self)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        self.balance.update(self.sim_time)
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
