You are working on a Newton physics simulation task.

Workspace: /home/horde/artifacts/newton-live-mcp-v4/loop/i4/g1_track-opus-restart-p0
Newton source tree (read-only reference, including docs and examples): /home/horde/apps/newton-live-mcp

g1_track.py simulates a floating-base Unitree G1 humanoid (SolverMuJoCo, 50 Hz frames, 2 ms substeps) that should follow a Kimodo reference motion (wave.csv: root pose and 29 joint angles at 30 fps) using position servos with torque limits. Problem: with the current controller the robot falls.

Goal: set up the controller so the robot follows the reference motion without falling. Verification runs the script in a fresh process on wave.csv and on an unseen faster playback of the same clip: the root must stay upright (height above 0.6 m), root position RMSE at most 4 cm, and joint-angle RMSE at most 0.05 rad. It also reports a harder stretch clip (high5.csv) that is not required.
Constraints (checked): do not change the robot model (bodies, masses, armature, torque limits), the timestep, or the motion input and playback, and apply no forces or torques to the floating base. The controller (gains, targets, feedforward, feedback, anything in the step logic) may change. Keep the file runnable as a Newton example (`python g1_track.py --motion wave.csv --viewer null`).

Deliverable: the edited g1_track.py in the workspace, then a brief report. You have 30 minutes; working efficiently matters. Do not modify files outside the workspace, do not look for other trials or hidden verification data, and do not use subagents.

Workflow: this is a script-based setup. Run the simulation with
  uv run --no-sync --project /home/horde/apps/newton-live-mcp python g1_track.py --viewer null --num-frames <N> --motion wave.csv
or write your own scripts that import the Example class; each run starts a fresh simulator process. There is no display; to look at the scene, render images yourself (for example with newton.sensors.SensorTiledCamera) and open them with your image-viewing tool.
