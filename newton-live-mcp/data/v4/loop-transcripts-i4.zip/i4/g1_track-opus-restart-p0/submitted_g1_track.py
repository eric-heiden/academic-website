# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import numpy as np
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def quat_to_matrix(q):
    """Rotation matrix of an xyzw quaternion."""
    x, y, z, w = q / np.linalg.norm(q)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def rotation_log(r):
    """Rotation vector of a rotation matrix (small to moderate angles)."""
    angle = np.arccos(np.clip(0.5 * (np.trace(r) - 1.0), -1.0, 1.0))
    axis = np.array([r[2, 1] - r[1, 2], r[0, 2] - r[2, 0], r[1, 0] - r[0, 1]])
    return 0.5 * axis * (angle / np.sin(angle) if angle > 1e-6 else 1.0)


def relative_pose(parent, child):
    """Pose (position, rotation matrix) of body ``child`` in the frame of ``parent`` (body_q rows)."""
    rp = quat_to_matrix(parent[3:7])
    return rp.T @ (child[:3] - parent[:3]), rp.T @ quat_to_matrix(child[3:7])


# Controller parameters: servo natural frequency [Hz] on the reflected inertia, damping factor
# (kd = zeta2 * armature * omega), target lead [frames], velocity feedforward weight, pelvis-pose
# feedback weight through the legs, and damped-least-squares damping of the leg IK.
CFG = {"freq": 60.0, "zeta2": 4.0, "lead": 1.0, "vff": 0.0, "alpha": 0.4, "damping": 0.1}


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, derived from a 60 Hz natural frequency on the reflected inertia
        # (10 Hz is far too soft to carry the robot's weight without an RL policy).
        natural_frequency = 2.0 * np.pi * CFG["freq"]
        self.kp = ARMATURE * natural_frequency**2
        self.kd = CFG["zeta2"] * ARMATURE * natural_frequency
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self._init_leg_ik(q0)
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _init_leg_ik(self, q0):
        """Constant leg Jacobians (foot pose in the pelvis frame w.r.t. the 6 leg joints) at the start pose."""
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        self.pelvis = labels.index("pelvis")
        self.feet = [labels.index("left_ankle_roll_link"), labels.index("right_ankle_roll_link")]
        self.leg_coords = [np.arange(7, 13), np.arange(13, 19)]
        state = self.model.state()

        def foot_poses(q):
            self.model.joint_q.assign(q)
            newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
            body_q = state.body_q.numpy()
            return [relative_pose(body_q[self.pelvis], body_q[foot]) for foot in self.feet]

        base = foot_poses(q0)
        eps = 1e-4
        self.leg_jacobian_inv = []
        for leg, coords in enumerate(self.leg_coords):
            jac = np.zeros((6, 6))
            for k, c in enumerate(coords):
                q = q0.copy()
                q[c] += eps
                p, r = foot_poses(q)[leg]
                jac[:3, k] = (p - base[leg][0]) / eps
                jac[3:, k] = base[leg][1] @ rotation_log(base[leg][1].T @ r) / eps
            # Damped least squares: the nearly straight knee makes the vertical direction singular.
            self.leg_jacobian_inv.append(jac.T @ np.linalg.inv(jac @ jac.T + CFG["damping"] ** 2 * np.eye(6)))
        self.model.joint_q.assign(q0)

    def _leg_correction(self, ref):
        """Leg joint offsets that move the pelvis onto the reference pose with the feet where they are."""
        body_q = self.state_0.body_q.numpy()
        pelvis = body_q[self.pelvis]
        pelvis_ref = np.concatenate([ref[:3], ref[3:7]])
        dq = np.zeros(29)
        for leg, coords in enumerate(self.leg_coords):
            p_des, r_des = relative_pose(pelvis_ref, body_q[self.feet[leg]])
            p_cur, r_cur = relative_pose(pelvis, body_q[self.feet[leg]])
            err = np.concatenate([p_des - p_cur, r_cur @ rotation_log(r_cur.T @ r_des)])
            dq[coords - 7] = self.leg_jacobian_inv[leg] @ err
        return dq

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        # Position targets for the servos: the reference joint angles one frame ahead, plus a
        # leg correction that moves the pelvis onto the reference pose with the feet where they
        # actually stand (the reference clip has some foot skating).
        t = self.sim_time + CFG["lead"] * self.frame_dt
        target = self.reference(t)
        h = 0.5 * self.frame_dt
        qd_ref = (self.reference(t + h)[7:] - self.reference(t - h)[7:]) / (2 * h)
        target[7:] += CFG["vff"] * self.kd / self.kp * qd_ref
        if CFG["alpha"] > 0.0:
            target[7:] += CFG["alpha"] * self._leg_correction(self.reference(self.sim_time))
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
