You are working on a Newton physics simulation task.

Workspace: /home/horde/artifacts/newton-live-mcp-v4/loop/i4/sdf_grind-opus-restart-p0
Newton source tree (read-only reference, including docs and examples): /home/horde/apps/newton-live-mcp

sdf_grinding.py is a Newton scene for machining: a cylindrical grinding wheel is driven kinematically across an ellipsoidal workpiece (a static mesh shape whose collision geometry is a sparse texture SDF built by Mesh.build_sdf), and hydroelastic SDF-SDF collision reports the contact surface and normal load every frame without a dynamics solver. Problem: the wheel passes through the workpiece without removing any material, so the rendered and colliding workpiece never changes.

Goal: add material removal, a capability Newton does not provide out of the box. As the wheel moves, the material it sweeps through must disappear from the workpiece's collision geometry (the SDF attached to the workpiece mesh shape), and the rendered surface must follow. Verification runs the script's Example for the full pass (GRIND_FRAMES + 10 frames) in a fresh process and then checks the workpiece SDF: the removed volume must match the volume swept by the wheel within 15%; points inside the groove must be clear and points 2 cm below it must remain solid (at least 90% each); and with the wheel placed back into the finished groove, the hydroelastic normal load must be at most 25% of the load on an unground workpiece.
Constraints (checked): keep the workpiece shape, wheel size, tool path (_grinder_pose), GRIND_DEPTH, GRIND_FRAMES, hydroelastic stiffness, and the collision pipeline setup; the removal must act on the geometry the collision pipeline uses. Performance matters less than correctness, but a full pass should stay under a few minutes. Keep the file runnable (`python sdf_grinding.py --viewer null`).

Deliverable: the edited sdf_grinding.py in the workspace, then a brief report. You have 45 minutes; working efficiently matters. Do not modify files outside the workspace, do not look for other trials or hidden verification data, and do not use subagents.

Workflow: this is a script-based setup. Run the simulation with
  uv run --no-sync --project /home/horde/apps/newton-live-mcp python sdf_grinding.py --viewer null --num-frames <N>
or write your own scripts that import the Example class; each run starts a fresh simulator process. There is no display; to look at the scene, render images yourself (for example with newton.sensors.SensorTiledCamera) and open them with your image-viewing tool.
