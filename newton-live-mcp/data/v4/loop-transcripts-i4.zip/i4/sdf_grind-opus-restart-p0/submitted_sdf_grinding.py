# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

###########################################################################
# Example SDF Grinding
#
# A cylindrical grinding wheel is driven kinematically across an ellipsoidal
# workpiece. The workpiece is a mesh shape whose collision geometry is a sparse
# texture SDF (``workpiece_sdf``, built by ``Mesh.build_sdf``); hydroelastic
# SDF-SDF collision reports the contact surface and normal load every frame,
# without a dynamics solver. After each collision query the volume swept by the
# wheel since the previous frame is carved out of the workpiece SDF in place
# (CSG subtraction ``d = max(d, -d_wheel)`` on the sparse subgrid and coarse
# textures that the collision pipeline samples). The rendered workpiece
# surface is extracted from the same SDF, so it follows the groove.
#
# Command: python sdf_grinding.py
#
###########################################################################

import math

import numpy as np
import warp as wp

import newton
import newton.examples

WORKPIECE_RADII = (0.45, 0.25, 0.12)
WORKPIECE_RESOLUTION = 256
GRINDER_RADIUS = 0.13
GRINDER_HALF_WIDTH = 0.04
GRIND_DEPTH = 0.035
GRIND_FRAMES = 270
HYDROELASTIC_STIFFNESS = 1.0e8


@wp.kernel(enable_backward=False)
def _compute_normal_load(
    contact_count: wp.array[wp.int32],
    contact_distance: wp.array[wp.float32],
    contact_stiffness: wp.array[wp.float32],
    normal_load: wp.array[wp.float32],
):
    contact = wp.tid()
    if contact < contact_count[0]:
        normal_load[contact] = wp.max(-contact_distance[contact] * contact_stiffness[contact], 0.0)
    else:
        normal_load[contact] = 0.0


@wp.func
def _swept_wheel_sdf(q: wp.vec3, sweep: wp.vec3, radius: float, half_width: float) -> float:
    """Signed distance [m] to a wheel (cylinder along local +Z) swept along ``sweep``.

    ``q`` and ``sweep`` are expressed in the wheel frame at the start of the
    sweep. The wheel moves in its radial plane, so the swept solid is the
    extrusion of a 2D stadium (disk swept along a segment) along the axis.
    """
    sweep_sq = sweep[0] * sweep[0] + sweep[1] * sweep[1]
    t = float(0.0)
    if sweep_sq > 0.0:
        t = wp.clamp((q[0] * sweep[0] + q[1] * sweep[1]) / sweep_sq, 0.0, 1.0)
    rel = q - t * sweep
    dr = wp.length(wp.vec2(rel[0], rel[1])) - radius
    dz = wp.abs(rel[2]) - half_width
    outside = wp.length(wp.vec2(wp.max(dr, 0.0), wp.max(dz, 0.0)))
    return outside + wp.min(wp.max(dr, dz), 0.0)


@wp.func
def _carve_sample(
    values: wp.array3d[wp.float32],
    x: int,
    y: int,
    z: int,
    fine_coords: wp.vec3,
    box_lower: wp.vec3,
    voxel_size: wp.vec3,
    workpiece_to_wheel: wp.transform,
    sweep: wp.vec3,
    radius: float,
    half_width: float,
    value_min: float,
    inv_value_range: float,
):
    local_pos = box_lower + wp.cw_mul(fine_coords, voxel_size)
    wheel_pos = wp.transform_point(workpiece_to_wheel, local_pos)
    carved = -_swept_wheel_sdf(wheel_pos, sweep, radius, half_width)
    # Textures store (d - min) / range; the mapping is monotonic, so CSG
    # subtraction commutes with it. Texture arrays are indexed [z, y, x].
    values[z, y, x] = wp.max(values[z, y, x], (carved - value_min) * inv_value_range)


@wp.kernel(enable_backward=False)
def _carve_subgrids(
    subgrid_cells: wp.array[wp.vec3i],
    subgrid_blocks: wp.array[wp.vec3i],
    subgrid_size: int,
    box_lower: wp.vec3,
    voxel_size: wp.vec3,
    workpiece_to_wheel: wp.transform,
    sweep: wp.vec3,
    radius: float,
    half_width: float,
    value_min: float,
    inv_value_range: float,
    subgrid_values: wp.array3d[wp.float32],
):
    cell_idx, i, j, k = wp.tid()
    cell = subgrid_cells[cell_idx]
    block = subgrid_blocks[cell_idx]
    samples = subgrid_size + 1
    fine_coords = wp.vec3(
        float(cell[0] * subgrid_size + i),
        float(cell[1] * subgrid_size + j),
        float(cell[2] * subgrid_size + k),
    )
    _carve_sample(
        subgrid_values,
        block[0] * samples + i,
        block[1] * samples + j,
        block[2] * samples + k,
        fine_coords,
        box_lower,
        voxel_size,
        workpiece_to_wheel,
        sweep,
        radius,
        half_width,
        value_min,
        inv_value_range,
    )


@wp.kernel(enable_backward=False)
def _carve_coarse(
    subgrid_size: int,
    box_lower: wp.vec3,
    voxel_size: wp.vec3,
    workpiece_to_wheel: wp.transform,
    sweep: wp.vec3,
    radius: float,
    half_width: float,
    coarse_values: wp.array3d[wp.float32],
):
    i, j, k = wp.tid()
    fine_coords = wp.vec3(float(i * subgrid_size), float(j * subgrid_size), float(k * subgrid_size))
    _carve_sample(
        coarse_values,
        i,
        j,
        k,
        fine_coords,
        box_lower,
        voxel_size,
        workpiece_to_wheel,
        sweep,
        radius,
        half_width,
        0.0,
        1.0,
    )


class Example:
    def __init__(self, viewer, _args):
        self.viewer = viewer
        self.frame_dt = 1.0 / 60.0
        self.sim_time = 0.0
        self.frame = 0

        # A gently curved blank keeps fine SDF subgrids resident around the
        # entire machined surface, which makes this compact in-place demo
        # independent of Newton's linear-subgrid storage optimization.
        workpiece_mesh = newton.Mesh.create_ellipsoid(
            *WORKPIECE_RADII,
            num_latitudes=32,
            num_longitudes=64,
            compute_normals=False,
            compute_uvs=False,
            compute_inertia=False,
        )
        self.workpiece_sdf = workpiece_mesh.build_sdf(
            max_resolution=WORKPIECE_RESOLUTION,
            narrow_band_range=(-0.08, 0.08),
            margin=0.04,
            texture_format="float32",
            paired_samples=False,
        )

        shape_cfg = newton.ModelBuilder.ShapeConfig(
            margin=0.0,
            gap=0.005,
            kh=HYDROELASTIC_STIFFNESS,
            density=0.0,
            is_hydroelastic=True,
        )
        workpiece_cfg = shape_cfg.copy()
        workpiece_cfg.is_visible = False
        grinder_cfg = shape_cfg.copy()
        grinder_cfg.sdf_max_resolution = 64
        grinder_cfg.sdf_narrow_band_range = (-0.06, 0.06)
        grinder_cfg.sdf_padding = 0.01

        builder = newton.ModelBuilder()
        builder.sdf_texture_paired_samples = False
        self.workpiece_shape = builder.add_shape_mesh(
            body=-1,
            mesh=workpiece_mesh,
            cfg=workpiece_cfg,
            label="workpiece",
        )

        initial_pose = self._grinder_pose(0)
        self.grinder_body = builder.add_body(xform=initial_pose, label="grinder")
        self.grinder_shape = builder.add_shape_cylinder(
            body=self.grinder_body,
            radius=GRINDER_RADIUS,
            half_height=GRINDER_HALF_WIDTH,
            cfg=grinder_cfg,
            color=(0.18, 0.20, 0.23),
            opacity=0.4,
            label="grinding_wheel",
        )

        self.model = builder.finalize()
        self.state_0 = self.model.state()
        self.collision_pipeline = newton.CollisionPipeline(
            self.model,
            sdf_hydroelastic_config=newton.geometry.HydroelasticSDF.Config(
                output_contact_surface=True,
            ),
        )
        self.contacts = self.collision_pipeline.contacts()
        self.contact_surface = self.collision_pipeline.hydroelastic_sdf.get_contact_surface()
        self.contact_distance = wp.empty(
            self.contacts.rigid_contact_max,
            dtype=wp.float32,
            device=self.model.device,
        )
        self.normal_load = wp.empty_like(self.contact_distance)
        self.total_normal_load = 0.0

        self.body_q = self.state_0.body_q.numpy()
        self._set_grinder_pose(initial_pose)
        self._init_material_removal()
        self._update_workpiece_surface()

        self.viewer.set_model(self.model)
        self.viewer.show_hydro_contact_surface = True
        self.viewer.set_camera(pos=wp.vec3(0.8, -0.85, 0.5), pitch=-18.0, yaw=132.0)

    @staticmethod
    def _grinder_pose(frame: int) -> wp.transform:
        x_start = -0.36
        x_end = 0.36
        x = x_start + min(frame / GRIND_FRAMES, 1.0) * (x_end - x_start)
        radial_fraction = min((x / WORKPIECE_RADII[0]) ** 2, 1.0)
        surface_z = WORKPIECE_RADII[2] * math.sqrt(1.0 - radial_fraction)
        z = surface_z + GRINDER_RADIUS - GRIND_DEPTH
        rotation = wp.quat_from_axis_angle(wp.vec3(1.0, 0.0, 0.0), -0.5 * math.pi)
        return wp.transform(wp.vec3(x, 0.0, z), rotation)

    def _set_grinder_pose(self, pose: wp.transform) -> None:
        self.body_q[self.grinder_body] = np.asarray(pose)
        self.state_0.body_q.assign(self.body_q)

    def _init_material_removal(self) -> None:
        """Mirror the workpiece SDF textures in editable device arrays.

        The model references the textures of ``workpiece_sdf`` directly, so
        rewriting their contents in place changes the geometry that the
        collision pipeline samples without rebuilding the model or pipeline.
        """
        sdf = self.workpiece_sdf.texture_data
        coarse_texture = self.workpiece_sdf._coarse_texture
        subgrid_texture = self.workpiece_sdf._subgrid_texture
        model_sdf_index = int(self.model._shape_sdf_index.numpy()[self.workpiece_shape])
        if (
            self.model._texture_sdf_coarse_textures[model_sdf_index] is not coarse_texture
            or self.model._texture_sdf_subgrid_textures[model_sdf_index] is not subgrid_texture
        ):
            raise RuntimeError("The workpiece shape does not use the textures of workpiece_sdf.")
        for texture in (coarse_texture, subgrid_texture):
            if texture.dtype != wp.float32 or texture.num_channels != 1:
                raise RuntimeError("Material removal requires float32, unpaired workpiece SDF textures.")

        device = self.model.device
        self.coarse_values = wp.empty(
            (coarse_texture.depth, coarse_texture.height, coarse_texture.width), dtype=wp.float32, device=device
        )
        self.subgrid_values = wp.empty(
            (subgrid_texture.depth, subgrid_texture.height, subgrid_texture.width), dtype=wp.float32, device=device
        )
        coarse_texture.copy_to(self.coarse_values)
        subgrid_texture.copy_to(self.subgrid_values)

        # Resident subgrids: coarse cell coordinates and their texel block in
        # the packed subgrid texture (10 bits per axis in the start slot).
        slots = sdf.subgrid_start_slots.numpy()
        cells = np.argwhere(slots < 0xFFFFFFFE)
        packed = slots[cells[:, 0], cells[:, 1], cells[:, 2]].astype(np.int64)
        blocks = np.stack((packed & 0x3FF, (packed >> 10) & 0x3FF, (packed >> 20) & 0x3FF), axis=1)
        self.subgrid_cells = wp.array(cells.astype(np.int32), dtype=wp.vec3i, device=device)
        self.subgrid_blocks = wp.array(blocks.astype(np.int32), dtype=wp.vec3i, device=device)

        self.workpiece_xform = wp.transform(*self.model.shape_transform.numpy()[self.workpiece_shape])
        self.wheel_shape_xform = wp.transform(*self.model.shape_transform.numpy()[self.grinder_shape])
        self.previous_wheel_pose = self._wheel_pose_in_workpiece()

    def _wheel_pose_in_workpiece(self) -> wp.transform:
        body_pose = wp.transform(*self.body_q[self.grinder_body])
        wheel_world = wp.transform_multiply(body_pose, self.wheel_shape_xform)
        return wp.transform_multiply(wp.transform_inverse(self.workpiece_xform), wheel_world)

    def _remove_swept_material(self) -> None:
        """Subtract the volume the wheel swept since the previous frame from the workpiece SDF."""
        sdf = self.workpiece_sdf.texture_data
        wheel_pose = self._wheel_pose_in_workpiece()
        workpiece_to_wheel = wp.transform_inverse(self.previous_wheel_pose)
        # Sweep of the wheel center in the wheel frame of the previous pose
        # (the kinematic path translates the wheel without rotating it).
        sweep = wp.transform_point(workpiece_to_wheel, wheel_pose.p)
        subgrid_size = int(sdf.subgrid_size)
        samples = subgrid_size + 1
        device = self.model.device

        if self.subgrid_cells.shape[0] > 0:
            wp.launch(
                _carve_subgrids,
                dim=(self.subgrid_cells.shape[0], samples, samples, samples),
                inputs=[
                    self.subgrid_cells,
                    self.subgrid_blocks,
                    subgrid_size,
                    sdf.sdf_box_lower,
                    sdf.voxel_size,
                    workpiece_to_wheel,
                    sweep,
                    GRINDER_RADIUS,
                    GRINDER_HALF_WIDTH,
                    float(sdf.subgrids_min_sdf_value),
                    1.0 / float(sdf.subgrids_sdf_value_range),
                    self.subgrid_values,
                ],
                device=device,
            )
            self.workpiece_sdf._subgrid_texture.copy_from(self.subgrid_values)

        depth, height, width = self.coarse_values.shape
        wp.launch(
            _carve_coarse,
            dim=(width, height, depth),
            inputs=[
                subgrid_size,
                sdf.sdf_box_lower,
                sdf.voxel_size,
                workpiece_to_wheel,
                sweep,
                GRINDER_RADIUS,
                GRINDER_HALF_WIDTH,
                self.coarse_values,
            ],
            device=device,
        )
        self.workpiece_sdf._coarse_texture.copy_from(self.coarse_values)
        self.previous_wheel_pose = wheel_pose

    def _update_workpiece_surface(self) -> None:
        surface = self.workpiece_sdf.extract_isomesh(device=self.model.device)
        if surface is None:
            raise RuntimeError("Grinding removed the complete workpiece.")
        self.workpiece_points = wp.array(surface.vertices, dtype=wp.vec3, device=self.model.device)
        self.workpiece_indices = wp.array(surface.indices.reshape(-1), dtype=wp.int32, device=self.model.device)

    def step(self):
        self.frame += 1
        grinder_pose = self._grinder_pose(self.frame)
        self._set_grinder_pose(grinder_pose)

        # Run hydroelastic SDF-SDF collision before editing the workpiece.
        self.collision_pipeline.collide(self.state_0, self.contacts)
        newton.eval_rigid_contact_kinematics(
            self.model,
            self.state_0,
            self.contacts,
            out_distance=self.contact_distance,
        )
        wp.launch(
            _compute_normal_load,
            dim=self.contacts.rigid_contact_max,
            inputs=[
                self.contacts.rigid_contact_count,
                self.contact_distance,
                self.contacts.rigid_contact_stiffness,
                self.normal_load,
            ],
            device=self.model.device,
        )
        self.total_normal_load = float(wp.utils.array_sum(self.normal_load))
        self._remove_swept_material()
        self._update_workpiece_surface()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.log_mesh(
            "/workpiece_sdf",
            self.workpiece_points,
            self.workpiece_indices,
            color=(0.55, 0.62, 0.68),
            roughness=0.65,
            metallic=0.25,
            dynamic=True,
        )
        self.viewer.log_hydro_contact_surface(self.contact_surface)
        self.viewer.log_scalar("Hydroelastic normal load [N]", self.total_normal_load)
        self.viewer.end_frame()


if __name__ == "__main__":
    viewer, args = newton.examples.init()
    newton.examples.run(Example(viewer, args), args)
