# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import copy

import mujoco
import numpy as np
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def quat_to_mat(q):
    """Rotation matrix of an xyzw quaternion."""
    x, y, z, w = q / np.linalg.norm(q)
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ]
    )


def axis_angle_mat(axis, angle):
    k = np.array([[0.0, -axis[2], axis[1]], [axis[2], 0.0, -axis[0]], [-axis[1], axis[0], 0.0]])
    return np.eye(3) + np.sin(angle) * k + (1.0 - np.cos(angle)) * (k @ k)


def pose_mat(p, q):
    T = np.eye(4)
    T[:3, :3] = quat_to_mat(q)
    T[:3, 3] = p
    return T


def rot_log(R):
    """Rotation vector of a rotation matrix."""
    c = np.clip(0.5 * (np.trace(R) - 1.0), -1.0, 1.0)
    angle = np.arccos(c)
    v = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    if angle < 1e-6:
        return 0.5 * v
    return angle / (2.0 * np.sin(angle)) * v


class LegKinematics:
    """Pelvis-to-ankle forward/inverse kinematics of the two 6-DoF legs (NumPy, from the model's joint frames)."""

    def __init__(self, model):
        labels = [label.rsplit("/", 1)[-1] for label in model.joint_label]
        X_p = model.joint_X_p.numpy()
        X_c = model.joint_X_c.numpy()
        axes = model.joint_axis.numpy()
        q_start = model.joint_q_start.numpy()
        qd_start = model.joint_qd_start.numpy()
        names = ["hip_pitch", "hip_roll", "hip_yaw", "knee", "ankle_pitch", "ankle_roll"]
        self.legs = []
        for side in ("left", "right"):
            chain = []
            for name in names:
                j = labels.index(f"{side}_{name}_joint")
                Tp = pose_mat(X_p[j, :3], X_p[j, 3:7])
                Tc_inv = np.linalg.inv(pose_mat(X_c[j, :3], X_c[j, 3:7]))
                chain.append((Tp, axes[qd_start[j]], Tc_inv))
            coords = [int(q_start[labels.index(f"{side}_{name}_joint")]) for name in names]
            self.legs.append((chain, np.array(coords)))
        dofs = [np.array(coords) - 1 for _chain, coords in self.legs]
        lower, upper = model.joint_limit_lower.numpy(), model.joint_limit_upper.numpy()
        # Keep IK solutions inside the joint limits and the knee away from its straight singularity.
        self.lower = [lower[d] + 0.02 for d in dofs]
        self.upper = [upper[d] - 0.02 for d in dofs]
        for lo in self.lower:
            lo[3] = max(lo[3], 0.05)

    def fk(self, leg, q):
        T = np.eye(4)
        R = np.eye(4)
        for (Tp, axis, Tc_inv), angle in zip(self.legs[leg][0], q):
            R[:3, :3] = axis_angle_mat(axis, angle)
            T = T @ Tp @ R @ Tc_inv
        return T

    def level_ankle(self, leg, R_pelvis, q, fraction=1.0, iterations=3):
        """Ankle pitch/roll that remove `fraction` of the foot's tilt from horizontal (hips/knee kept)."""
        q = q.copy()
        target = None
        eps = 1e-6
        for _ in range(iterations):
            z = R_pelvis @ self.fk(leg, q)[:3, 2]
            if target is None:
                # Tilted foot normal -> partially leveled normal.
                target = (1.0 - fraction) * z + fraction * np.array([0.0, 0.0, 1.0])
                target /= np.linalg.norm(target)
            err = (target - z)[:2]
            J = np.zeros((2, 2))
            for k in range(2):
                dq = q.copy()
                dq[4 + k] += eps
                J[:, k] = ((R_pelvis @ self.fk(leg, dq)[:3, 2]) - z)[:2] / eps
            q[4:] += np.linalg.solve(J + 1e-9 * np.eye(2), err)
        q = np.clip(q, self.lower[leg], self.upper[leg])
        return q

    def ik(self, leg, T_des, q, iterations=4, damping=1e-4, max_step=0.1):
        """Leg angles placing the ankle at T_des (pelvis frame), damped least squares from q."""
        q = q.copy()
        eps = 1e-6
        for _ in range(iterations):
            T = self.fk(leg, q)
            err = np.concatenate([T_des[:3, 3] - T[:3, 3], rot_log(T_des[:3, :3] @ T[:3, :3].T)])
            if np.linalg.norm(err) < 1e-7:
                break
            J = np.zeros((6, 6))
            for k in range(6):
                dq = q.copy()
                dq[k] += eps
                Tk = self.fk(leg, dq)
                J[:3, k] = (Tk[:3, 3] - T[:3, 3]) / eps
                J[3:, k] = rot_log(Tk[:3, :3] @ T[:3, :3].T) / eps
            dq = np.linalg.solve(J.T @ J + damping * np.eye(6), J.T @ err)
            q += dq * min(1.0, max_step / (np.abs(dq).max() + 1e-12))
            q = np.clip(q, self.lower[leg], self.upper[leg])
        return q


class InverseDynamics:
    """Quasi-static inverse dynamics of the reference pose with the ground reaction split over both soles.

    Solves M qacc + bias = tau + Jc^T f on a CPU copy of the solver's MuJoCo model: the six floating-base
    rows fix the foot wrenches f (weighted least norm, preferring forces over sole moments), the joint rows
    then give the actuator torques tau.
    """

    def __init__(self, mj_model, foot_bodies, sole_point, moment_arm=0.05):
        self.m = copy.deepcopy(mj_model)
        self.m.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_CONTACT)
        self.d = mujoco.MjData(self.m)
        self.feet = [b + 1 for b in foot_bodies]  # MuJoCo body 0 is the world
        self.sole_point = np.asarray(sole_point)
        self.w_inv = np.tile(np.r_[np.ones(3), np.full(3, moment_arm**2)], len(foot_bodies))
        self.jacp = np.zeros((3, self.m.nv))
        self.jacr = np.zeros((3, self.m.nv))

    def _set_pose(self, q):
        d = self.d
        d.qpos[:3] = q[:3]
        d.qpos[3:7] = [q[6], q[3], q[4], q[5]]
        d.qpos[7:] = q[7:]

    def com(self, q):
        """Whole-body center of mass [m] at joint_q q."""
        self._set_pose(q)
        mujoco.mj_kinematics(self.m, self.d)
        mujoco.mj_comPos(self.m, self.d)
        return self.d.subtree_com[1].copy()

    def torques(self, q, qd=None, qdd=None):
        m, d = self.m, self.d
        self._set_pose(q)
        d.qvel[:] = 0.0 if qd is None else qd
        d.qacc[:] = 0.0 if qdd is None else qdd
        mujoco.mj_inverse(m, d)
        tau = d.qfrc_inverse.copy()
        rows = []
        for b in self.feet:
            point = d.xpos[b] + d.xmat[b].reshape(3, 3) @ self.sole_point
            mujoco.mj_jac(m, d, self.jacp, self.jacr, point, b)
            rows += [self.jacp.copy(), self.jacr.copy()]
        Jc = np.vstack(rows)
        A = Jc[:, :6].T
        AW = A * self.w_inv
        f = AW.T @ np.linalg.solve(AW @ A.T, tau[:6])
        return tau[6:] - Jc[:, 6:].T @ f


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, here derived from a 40 Hz natural frequency of the
        # reflected actuator inertia. Stiff legs/ankles keep the standing robot from
        # sagging into a lean (inverted pendulum needs > m g h ankle stiffness).
        # Legs and waist get heavy damping (10x critical w.r.t. the armature) so the whole-body
        # sway mode over the ankles is damped.
        natural_frequency = 2.0 * np.pi * 40.0
        damping_ratio = np.ones(29)
        damping_ratio[:15] = 10.0
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * damping_ratio * ARMATURE * natural_frequency
        # Whole-body balance layer on top of the reference (see targets()):
        # - leg joints from IK so the pelvis reaches the commanded pose over the reference feet,
        # - the commanded pelvis gets horizontal PI feedback on the measured root position error,
        # - the commanded CoM is kept within [-com_behind_max, com_ahead_max] of the measured
        #   feet's mean sole center (the reference rises onto the toes while turning),
        # - the ankles level the feet (the reference feet are tilted by a few degrees),
        # - quasi-static inverse-dynamics torques are fed forward through the servo targets.
        self.root_kp = 0.3  # proportional root position feedback [-]
        self.root_ki = 1.0  # integral root position feedback [1/s]
        self.com_ahead_max = 0.04  # [m]
        self.com_behind_max = 0.04  # [m]
        self.level_feet = 1.0  # fraction of the reference foot tilt removed by the ankle joints
        self.smooth_window = 0.0  # half width [s] of the triangular smoothing of the reference targets
        self.use_feedforward = True
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.legs = LegKinematics(self.model)
        self.sole_depth = self._sole_depth()
        self.root_error_integral = np.zeros(3)
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        self.foot_bodies = [labels.index("left_ankle_roll_link"), labels.index("right_ankle_roll_link")]
        self.dynamics = InverseDynamics(
            self.solver.mj_model,
            self.foot_bodies,
            [0.035, 0.0, -self.sole_depth],
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _sole_depth(self):
        """Depth [m] of the foot collision spheres' bottom below the ankle-roll link origin."""
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        foot = labels.index("left_ankle_roll_link")
        shape_body = self.model.shape_body.numpy()
        shape_type = self.model.shape_type.numpy()
        xform = self.model.shape_transform.numpy()
        scale = self.model.shape_scale.numpy()
        depth = 0.0
        for s in np.flatnonzero(shape_body == foot):
            if shape_type[s] == int(newton.GeoType.SPHERE):
                depth = max(depth, -(xform[s, 2] - scale[s, 0]))
        return depth if depth > 0.0 else 0.035

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def smoothed_reference(self, t):
        """Reference joint_q averaged over a triangular window of +-smooth_window [s]: removes the
        velocity kinks of the 30 fps linear interpolation that stiff servos would turn into torque spikes."""
        if self.smooth_window <= 0.0:
            return self.reference(t)
        offsets = np.linspace(-1.0, 1.0, 9)
        weights = 1.0 - np.abs(offsets) + 1e-3
        weights /= weights.sum()
        q = sum(w * self.reference(t + o * self.smooth_window) for w, o in zip(weights, offsets))
        q[3:7] /= np.linalg.norm(q[3:7])
        return q

    def targets(self, t, root_now, feet_now=None):
        """Servo targets at time t [s]: reference joints, with leg joints from IK so that the pelvis
        reaches the (feedback-corrected, CoM-limited) reference root pose over the reference feet."""
        ref = self.smoothed_reference(t)
        target = ref.copy()
        T_pelvis = pose_mat(ref[:3], ref[3:7])
        T_cmd = T_pelvis.copy()
        feet = []
        for leg, (_chain, coords) in enumerate(self.legs.legs):
            feet.append(T_pelvis @ self.legs.fk(leg, ref[coords]))
        if root_now is not None:
            # Horizontal root position feedback (PI) toward the reference pelvis position.
            error = self.reference(self.sim_time)[:3] - root_now[:3]
            error[2] = 0.0
            self.root_error_integral += error * self.frame_dt
            correction = self.root_kp * error + self.root_ki * self.root_error_integral
            T_cmd[:3, 3] += np.clip(correction, -0.05, 0.05)
        if self.com_ahead_max is not None:
            # Keep the commanded CoM over the real support: at most com_ahead_max ahead of (and
            # com_behind_max behind) the mean sole center of the measured feet, along their heading.
            support = feet
            if feet_now is not None:
                support = [pose_mat(f[:3], f[3:7]) for f in feet_now]
            soles = [T[:3, 3] + T[:3, :3] @ self.dynamics.sole_point for T in support]
            heading = support[0][:3, 0] + support[1][:3, 0]
            heading[2] = 0.0
            heading /= np.linalg.norm(heading)
            com = self.dynamics.com(ref) + T_cmd[:3, 3] - T_pelvis[:3, 3]
            lead = heading @ (com - 0.5 * (soles[0] + soles[1]))
            excess = max(0.0, lead - self.com_ahead_max) + min(0.0, lead + self.com_behind_max)
            if excess != 0.0:
                T_cmd[:3, 3] -= excess * heading
                if root_now is not None:
                    self.root_error_integral -= error * self.frame_dt  # anti-windup
        # Solve both legs; if a (nearly straight) leg cannot reach its foot, lower the pelvis and re-solve.
        for _ in range(2):
            T_cmd_inv = np.linalg.inv(T_cmd)
            shortfall = 0.0
            for leg, (_chain, coords) in enumerate(self.legs.legs):
                q_leg = self.legs.ik(leg, T_cmd_inv @ feet[leg], ref[coords])
                target[coords] = q_leg
                reached = T_cmd @ self.legs.fk(leg, q_leg)
                shortfall = max(shortfall, reached[2, 3] - feet[leg][2, 3])
            if shortfall < 1e-3:
                break
            T_cmd[2, 3] -= shortfall + 1e-3
        if self.level_feet > 0.0:
            for leg, (_chain, coords) in enumerate(self.legs.legs):
                target[coords] = self.legs.level_ankle(leg, T_cmd[:3, :3], target[coords], self.level_feet)
        if self.use_feedforward:
            # Feedforward torque as a servo target offset: kp (q* + tau/kp - q) = kp (q* - q) + tau.
            q_id = target.copy()
            q_id[:3] = T_cmd[:3, 3]
            target[7:] += self.dynamics.torques(q_id) / self.kp
        return target

    def step(self):
        # ---------------- Controller (tunable) ----------------
        if self.sim_time <= 0.0:
            self.root_error_integral[:] = 0.0
        root_now = self.state_0.joint_q.numpy()[:7]
        body_q = self.state_0.body_q.numpy()
        target = self.targets(self.sim_time + self.frame_dt, root_now, body_q[self.foot_bodies])
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
