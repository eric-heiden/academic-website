# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Controller: stiff servos track the reference waist/arm angles directly. The leg
targets come from IK that keeps both feet flat at their planted poses while the
pelvis follows the reference root pose. The pelvis command is shifted to keep the
CoM inside an inset support polygon and corrected by PID feedback on the measured
CoM. A static gravity feedforward (both feet sharing the load) is added as a
target offset tau / kp, so it stays within the actuator torque limits.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import warp as wp

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class LegIK:
    """Kinematics helper on a MuJoCo CPU copy of the G1 MJCF (controller-side only, not simulated).

    Provides FK/CoM, damped least-squares leg IK (feet poses for a given pelvis pose) and
    static gravity torques with both feet supporting the robot.
    """

    def __init__(self, mjcf_path):
        self.mj = mujoco
        self.m = mujoco.MjModel.from_xml_path(mjcf_path)
        self.d = mujoco.MjData(self.m)
        self.feet = [self.m.body(f"{side}_ankle_roll_link").id for side in ("left", "right")]
        self.jacp = np.zeros((3, self.m.nv))
        self.jacr = np.zeros((3, self.m.nv))

    def fk(self, qpos):
        self.d.qpos[:] = qpos
        self.mj.mj_kinematics(self.m, self.d)
        self.mj.mj_comPos(self.m, self.d)

    def gravity_torques(self, qpos, moment_weight=0.1):
        """Joint torques holding qpos statically with both feet supporting the robot (min-norm contact wrenches)."""
        self.d.qpos[:] = qpos
        self.d.qvel[:] = 0.0
        self.mj.mj_forward(self.m, self.d)
        bias = self.d.qfrc_bias.copy()
        JT = []
        for body in self.feet:
            self.mj.mj_jacBody(self.m, self.d, self.jacp, self.jacr, body)
            JT.append(np.vstack([self.jacp, self.jacr / moment_weight]).T)  # nv x 6
        JT = np.hstack(JT)  # nv x 12
        f = np.linalg.lstsq(JT[:6], bias[:6], rcond=None)[0]
        return bias[6:] - (JT @ f)[6:]

    def solve(self, qpos, goals, iters=6, damping=1e-3):
        """qpos: MuJoCo qpos (pelvis pose fixed); goals: [(pos, rotmat)] per foot. Returns updated qpos."""
        qpos = qpos.copy()
        for _ in range(iters):
            self.fk(qpos)
            for leg, (body, (gp, gR)) in enumerate(zip(self.feet, goals)):
                R = self.d.xmat[body].reshape(3, 3)
                e_rot = 0.5 * (np.cross(R[:, 0], gR[:, 0]) + np.cross(R[:, 1], gR[:, 1]) + np.cross(R[:, 2], gR[:, 2]))
                err = np.concatenate([gp - self.d.xpos[body], e_rot])
                self.mj.mj_jacBody(self.m, self.d, self.jacp, self.jacr, body)
                dofs = slice(6 + 6 * leg, 12 + 6 * leg)
                J = np.vstack([self.jacp[:, dofs], self.jacr[:, dofs]])
                dq = np.linalg.solve(J.T @ J + damping * np.eye(6), J.T @ err)
                dq = np.clip(dq, -0.2, 0.2)
                qpos[7 + 6 * leg : 13 + 6 * leg] += dq
        return qpos


def quat_xyzw_to_wxyz(q):
    return np.concatenate([q[..., 3:4], q[..., :3]], axis=-1)


def yaw_rotation(R):
    yaw = np.arctan2(R[1, 0], R[0, 0])
    c, s = np.cos(yaw), np.sin(yaw)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        self.ik = LegIK(str(asset / "mjcf/g1_29dof_rev_1_0.xml"))
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Stiff joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint from a 60 Hz natural frequency (damping ratio 2) on the
        # reflected inertia. Balance comes from the leg IK / CoM feedback in step().
        natural_frequency = 2.0 * np.pi * 60.0
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 4.0 * ARMATURE * natural_frequency
        self.foot_height = 0.038  # commanded ankle-frame height of the flat, planted feet [m]
        self.com_margin = 0.05  # keep the commanded CoM this far inside the support polygon [m]
        self.com_kp = 0.8  # measured CoM position feedback on the pelvis command [-]
        self.com_kd = 0.1  # measured CoM velocity feedback [s]
        self.com_ki = 1.0  # integral CoM feedback [1/s]
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self._init_controller()
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def _init_controller(self):
        """Planted foot goals (flat, at the initial foot poses) and their support polygon."""
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        body_q = self.state_0.body_q.numpy()
        self.foot_goals = []
        corners = []
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            R = yaw_rotation(np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3))
            p = np.array([pose[0], pose[1], self.foot_height])
            self.foot_goals.append((p, R))
            # Foot contact spheres of the MJCF (ankle_roll_link frame).
            for c in ((-0.05, 0.025), (-0.05, -0.025), (0.12, 0.03), (0.12, -0.03)):
                corners.append(tuple((p + R @ np.array([c[0], c[1], 0.0]))[:2]))
        # Counter-clockwise convex hull (monotone chain) -> half-planes n.x <= d.
        def chain(points):
            h = []
            for pt in points:
                while len(h) >= 2 and np.cross(np.append(np.subtract(h[-1], h[-2]), 0), np.append(np.subtract(pt, h[-2]), 0))[2] <= 0:
                    h.pop()
                h.append(pt)
            return h[:-1]
        pts = sorted(corners)
        hull = chain(pts) + chain(pts[::-1])
        self.support = []
        for a, b in zip(hull, hull[1:] + hull[:1]):
            e = np.subtract(b, a)
            n = np.array([e[1], -e[0]]) / np.linalg.norm(e)
            self.support.append((n, n @ np.asarray(a)))
        self.com_prev = None
        self.com_des_prev = None
        self.com_int = np.zeros(2)

    def _project_support(self, x, margin):
        """Project a horizontal point into the support polygon inset by margin (cyclic half-plane projection)."""
        x = x.copy()
        for _ in range(20):
            for n, d in self.support:
                v = n @ x - (d - margin)
                if v > 0:
                    x -= v * n
        return x

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        # 1. Reference pose one frame ahead (upper body joints are tracked directly).
        target = self.reference(self.sim_time + self.frame_dt)
        qpos = np.concatenate([target[:3], quat_xyzw_to_wxyz(target[3:7]), target[7:]])
        # 2. Pelvis height: keep the reference pelvis-over-ankle height above the flat planted feet.
        self.ik.fk(qpos)
        ankle_z = np.mean([self.ik.d.xpos[b][2] for b in self.ik.feet])
        qpos[2] -= ankle_z - self.foot_height
        qpos = self.ik.solve(qpos, self.foot_goals)
        # 3. Shift the pelvis so the commanded CoM stays inside the inset support polygon.
        self.ik.fk(qpos)
        com_cmd = self.ik.d.subtree_com[0][:2].copy()
        com_des = self._project_support(com_cmd, self.com_margin)
        # 4. PID feedback on the measured CoM (from the simulated state) moves the pelvis command.
        q = self.state_0.joint_q.numpy()
        self.ik.fk(np.concatenate([q[:3], quat_xyzw_to_wxyz(q[3:7]), q[7:]]))
        com_meas = self.ik.d.subtree_com[0][:2].copy()
        if self.com_prev is None:
            self.com_prev, self.com_des_prev = com_meas.copy(), com_des.copy()
        v_meas = (com_meas - self.com_prev) / self.frame_dt
        v_des = (com_des - self.com_des_prev) / self.frame_dt
        self.com_prev, self.com_des_prev = com_meas, com_des
        self.com_int = np.clip(self.com_int + (com_des - com_meas) * self.frame_dt, -0.05, 0.05)
        feedback = self.com_kp * (com_des - com_meas) + self.com_kd * (v_des - v_meas) + self.com_ki * self.com_int
        qpos[:2] += com_des - com_cmd + feedback
        # 5. Leg IK: flat feet at their planted poses under the commanded pelvis pose.
        qpos = self.ik.solve(qpos, self.foot_goals)
        target[7:19] = qpos[7:19]
        # 6. Gravity feedforward (feet share the load), realized as a servo target offset tau / kp.
        target[7:] += self.ik.gravity_torques(qpos) / self.kp
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
