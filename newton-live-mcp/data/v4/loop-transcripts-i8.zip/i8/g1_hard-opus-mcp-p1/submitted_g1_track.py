# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Controller: the clip is turned into a balanced whole-body plan once at start-up
(``BalancePlanner``), then tracked by the servos with velocity and inverse-dynamics
torque feedforward folded into the position targets:

1. The sampled reference is lightly smoothed in time (the 30 fps clip is linearly
   interpolated, so its velocity jumps at every key frame).
2. Leg IK keeps both feet flat and fixed where they start. The reference rises on
   its toes and pivots its feet while turning, which the real contacts cannot
   follow; pelvis height is left free to absorb this.
3. The pelvis is shifted horizontally where needed so the whole-body COM keeps a
   margin to the edges of the support polygon (mostly the toes in high5.csv).
4. MuJoCo inverse dynamics of the plan (contacts off) gives the generalized forces;
   the floating-base wrench is split into two foot wrenches and the remaining joint
   torques are applied as feedforward (target offset tau / kp, still clamped by
   the actuator force range).

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import copy

import mujoco
import numpy as np
import warp as wp
from scipy.ndimage import gaussian_filter1d, maximum_filter1d, minimum_filter1d
from scipy.spatial.transform import Rotation

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)

# joint_q indices of the 12 leg joints (left then right; 6 each).
LEG_Q = np.arange(7, 19)
# Foot sole: contact spheres at x in {-0.05, 0.12}, y = +-0.03, z = -0.03 (radius 5 mm)
# in the ankle-roll frame; flat feet put the ankle this high above the floor [m].
SOLE_X = (-0.05, 0.12)
SOLE_Y = (-0.03, 0.03)
ANKLE_HEIGHT = 0.0335


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class BalancePlanner:
    """Offline whole-body plan: flat planted feet, COM kept inside the feet, inverse-dynamics torques."""

    def __init__(self, model_cpu, mj_model, frame_dt):
        self.model = model_cpu
        self.frame_dt = frame_dt
        self.state = model_cpu.state()
        self.q_buf = wp.zeros(model_cpu.joint_coord_count, dtype=float, device="cpu")
        self.qd_zero = wp.zeros(model_cpu.joint_dof_count, dtype=float, device="cpu")
        labels = [label.rsplit("/", 1)[-1] for label in model_cpu.body_label]
        self.feet = [labels.index("left_ankle_roll_link"), labels.index("right_ankle_roll_link")]
        self.leg_q = [LEG_Q[:6], LEG_Q[6:]]
        self.mass = model_cpu.body_mass.numpy()
        self.body_com = model_cpu.body_com.numpy()
        self.leg_lower = model_cpu.joint_limit_lower.numpy()[LEG_Q - 1]
        self.leg_upper = model_cpu.joint_limit_upper.numpy()[LEG_Q - 1]
        # Inverse dynamics runs without contacts; the ground wrench is distributed explicitly.
        self.mj_model = copy.deepcopy(mj_model)
        self.mj_model.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_CONTACT)
        self.mj_data = mujoco.MjData(self.mj_model)
        names = [mujoco.mj_id2name(self.mj_model, mujoco.mjtObj.mjOBJ_BODY, i) for i in range(self.mj_model.nbody)]
        self.mj_feet = [next(i for i, n in enumerate(names) if n.endswith(f"{side}_ankle_roll_link")) for side in ("left", "right")]

    # ---- kinematics helpers -------------------------------------------------
    def fk(self, q):
        self.q_buf.assign(q)
        newton.eval_fk(self.model, self.q_buf, self.qd_zero, self.state)
        return self.state.body_q.numpy().copy()

    def com(self, body_q):
        rot = Rotation.from_quat(body_q[:, 3:7]).as_matrix()
        p = body_q[:, :3] + np.einsum("bij,bj->bi", rot, self.body_com)
        return (self.mass[:, None] * p).sum(0) / self.mass.sum()

    def foot_error(self, body_q, k, target):
        pos, rot = target
        b = self.feet[k]
        return np.concatenate([pos - body_q[b, :3], (rot * Rotation.from_quat(body_q[b, 3:7]).inv()).as_rotvec()])

    def planted_feet(self, q0):
        """Flat foot poses at the initial reference foot positions and headings."""
        body_q = self.fk(q0)
        targets = []
        for b in self.feet:
            yaw = Rotation.from_quat(body_q[b, 3:7]).as_euler("ZYX")[0]
            pos = body_q[b, :3].astype(float).copy()
            pos[2] = ANKLE_HEIGHT
            targets.append((pos, Rotation.from_rotvec([0.0, 0.0, yaw])))
        return targets

    def support_box(self, feet):
        pts = np.array([p + r.apply([x, y, -0.03]) for p, r in feet for x in SOLE_X for y in SOLE_Y])
        return pts[:, :2].min(0), pts[:, :2].max(0)

    def solve_legs(self, q, q_ref, feet, iters, h=1e-4, w_z=0.3, w_joint=0.05, damping=1e-4):
        """Gauss-Newton on 12 leg joints + pelvis height: feet on targets, stay near the reference."""
        q = q.copy()
        var = np.concatenate([LEG_Q, [2]])

        def residual(qq):
            body_q = self.fk(qq)
            err = [self.foot_error(body_q, k, feet[k]) for k in range(2)]
            return np.concatenate([*err, [w_z * (qq[2] - q_ref[2])], w_joint * (qq[LEG_Q] - q_ref[LEG_Q])])

        for _ in range(iters):
            r = residual(q)
            jac = np.zeros((len(r), len(var)))
            for j, v in enumerate(var):
                qq = q.copy()
                qq[v] += h
                jac[:, j] = (residual(qq) - r) / h
            q[var] -= np.linalg.solve(jac.T @ jac + damping * np.eye(len(var)), jac.T @ r)
            q[LEG_Q] = np.clip(q[LEG_Q], self.leg_lower, self.leg_upper)
        return q

    # ---- plan ----------------------------------------------------------------
    def plan(
        self,
        reference,
        duration,
        smoothing=0.03,
        toe_margin=0.05,
        heel_margin=0.04,
        side_margin=0.035,
        shift_gain=1.25,
        shift_sigma=0.12,
        shift_hold=0.25,
        passes=2,
    ):
        """Balanced joint_q plan, joint velocities and feedforward joint torques on the frame grid."""
        dt = self.frame_dt
        n = int(np.ceil(duration / dt)) + 3
        ref = np.array([reference(k * dt) for k in range(n)])
        ref = gaussian_filter1d(ref, smoothing / dt, axis=0, mode="nearest")
        ref[:, 3:7] /= np.linalg.norm(ref[:, 3:7], axis=1, keepdims=True)

        feet = self.planted_feet(ref[0])
        lo, hi = self.support_box(feet)
        com_lo = np.array([lo[0] + heel_margin, lo[1] + side_margin])
        com_hi = np.array([hi[0] - toe_margin, hi[1] - side_margin])
        window = int(shift_hold / dt) * 2 + 1

        shift = np.zeros((n, 2))
        plan = ref.copy()
        for it in range(passes):
            com = np.zeros((n, 3))
            prev = None
            for k in range(n):
                q_ref = ref[k].copy()
                q_ref[:2] += shift[k]
                q = q_ref.copy()
                if prev is not None:
                    q[LEG_Q] = prev[LEG_Q]
                    q[2] = prev[2] + ref[k, 2] - ref[k - 1, 2]
                q = self.solve_legs(q, q_ref, feet, iters=3 if prev is not None else 8)
                plan[k] = prev = q
                com[k] = self.com(self.fk(q))
            if it < passes - 1:
                # Horizontal COM correction, held around each violation and smoothed in time.
                need = np.clip(com[:, :2], com_lo, com_hi) - com[:, :2]
                upper = maximum_filter1d(need, window, axis=0)
                lower = minimum_filter1d(need, window, axis=0)
                need = np.where(upper > -lower, upper, lower)
                shift += shift_gain * gaussian_filter1d(need, shift_sigma / dt, axis=0, mode="nearest")

        qd, tau = self.inverse_dynamics(plan)
        return plan, qd, tau

    def inverse_dynamics(self, plan, w_tangent=5.0, w_normal=1.0, w_moment=20.0):
        """Joint torques for the plan with the base wrench carried by the two feet."""
        m, d, dt = self.mj_model, self.mj_data, self.frame_dt
        n = len(plan)
        qpos = np.concatenate([plan[:, :3], plan[:, 6:7], plan[:, 3:6], plan[:, 7:]], axis=1)
        qvel = np.zeros((n, m.nv))
        for k in range(n):
            a, b = max(k - 1, 0), min(k + 1, n - 1)
            mujoco.mj_differentiatePos(m, qvel[k], dt * (b - a), qpos[a], qpos[b])
        qacc = np.gradient(qvel, dt, axis=0)
        weights = 1.0 / np.array([w_tangent, w_tangent, w_normal, w_moment, w_moment, w_moment] * 2)
        jacp, jacr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
        tau = np.zeros((n, m.nv - 6))
        for k in range(n):
            d.qpos[:], d.qvel[:], d.qacc[:] = qpos[k], qvel[k], qacc[k]
            mujoco.mj_inverse(m, d)
            jac, centers = [], []
            for bid in self.mj_feet:
                center = d.xpos[bid] + d.xmat[bid].reshape(3, 3) @ np.array([0.035, 0.0, -0.035])
                mujoco.mj_jac(m, d, jacp, jacr, center, bid)
                jac.append(np.vstack([jacp, jacr]))
                centers.append(center)
            jac = np.vstack(jac)
            base = jac[:, :6].T
            wrench = d.qfrc_inverse[:6]
            # Preferred split: vertical load shared by the COM position between the feet.
            axis = centers[1][:2] - centers[0][:2]
            s = np.clip(np.dot(d.subtree_com[1][:2] - centers[0][:2], axis) / np.dot(axis, axis), 0.0, 1.0)
            f = np.zeros(12)
            f[2], f[8] = (1.0 - s) * wrench[2], s * wrench[2]
            f += weights * (base.T @ np.linalg.solve((base * weights) @ base.T, wrench - base @ f))
            tau[k] = d.qfrc_inverse[6:] - (jac.T @ f)[6:]
        return qvel[:, 6:], tau


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad] per
        # actuated joint from per-group natural frequencies (legs, waist, arms), critically
        # damped. Stiff legs keep the robot from sagging onto its toes.
        frequency = np.array([50.0] * 12 + [40.0] * 3 + [30.0] * 14)
        natural_frequency = 2.0 * np.pi * frequency
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * ARMATURE * natural_frequency
        self.torque_feedforward_limit = 0.8  # fraction of the actuator torque limit
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]
        effort_limit = np.array(builder.joint_effort_limit[6:])

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        planner_model = builder.finalize(device="cpu")
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)

        # ---------------- Controller plan ----------------
        planner = BalancePlanner(planner_model, self.solver.mj_model, self.frame_dt)
        self.plan_q, self.plan_qd, plan_tau = planner.plan(self.reference, self.motion.duration + 0.5)
        limit = self.torque_feedforward_limit * effort_limit
        self.plan_tau = np.clip(plan_tau, -limit, limit)
        # --------------------------------------------------

        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def _plan_at(self, values, t):
        """Linear interpolation of a per-frame plan array at time t [s] (held at the ends)."""
        x = t / self.frame_dt
        i = int(np.clip(np.floor(x), 0, len(values) - 2))
        a = float(np.clip(x - i, 0.0, 1.0))
        return (1.0 - a) * values[i] + a * values[i + 1]

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        # Servo targets: the balanced plan one frame ahead, with velocity feedforward
        # (kd * qd_ref) and inverse-dynamics torque feedforward folded into the target,
        # since the servo force is kp * (target - q) - kd * qd.
        t_next = self.sim_time + self.frame_dt
        target = self._plan_at(self.plan_q, t_next)
        qd_ref = self._plan_at(self.plan_qd, t_next)
        tau_ff = self._plan_at(self.plan_tau, self.sim_time + 0.5 * self.frame_dt)
        target[7:] += (self.kd * qd_ref + tau_ff) / self.kp
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
