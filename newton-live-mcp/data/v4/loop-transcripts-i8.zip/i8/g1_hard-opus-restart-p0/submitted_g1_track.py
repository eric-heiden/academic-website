# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Controller: stiff joint servos track a temporally smoothed copy of the clip. The leg targets
come from a regularized leg IK that keeps both soles flat at their initial ground placement
under the (balance-shifted) reference pelvis; the pelvis target is shifted against the
capture-point error of the measured center of mass (admittance-style balance).

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import copy

import mujoco
import numpy as np
import warp as wp
from scipy.ndimage import gaussian_filter1d

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Stiff joint-space PD servos (kp [N m/rad], kd [N m s/rad]) per actuated joint.
        leg = [1500.0, 1500.0, 800.0, 2000.0, 1000.0, 500.0]
        arm = [150.0, 150.0, 100.0, 100.0, 50.0, 20.0, 20.0]
        self.kp = np.array(leg * 2 + [400.0, 300.0, 300.0] + arm * 2)
        self.kd = self.kp / np.array([15.0] * 12 + [20.0] * 3 + [25.0] * 14)
        # Balance: pelvis target shift per capture-point error [m/m], and its limit [m].
        self.k_pelvis = 2.5
        self.max_shift = 0.2
        self.omega = np.sqrt(9.81 / 0.69)  # inverted-pendulum frequency [1/s]
        # [s] temporal smoothing of the controller's copy of the clip: root, legs, waist, arms
        self.smooth_sigma = (0.1, 0.1, 0.1, 0.05)
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)

        # Kinematic helper (CPU MuJoCo copy of the same model) for the leg IK.
        self.mjm = self.solver.mj_model
        self.mjd = mujoco.MjData(self.mjm)
        mj_names = [self.mjm.body(i).name for i in range(self.mjm.nbody)]
        nt_names = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        self.feet_mj = [next(i for i, n in enumerate(mj_names) if n.endswith(f"{s}_ankle_roll_link")) for s in ("left", "right")]
        self.feet_nt = [nt_names.index(f"{s}_ankle_roll_link") for s in ("left", "right")]
        self.leg_dofs = [np.arange(6, 12), np.arange(12, 18)]  # MuJoCo dof addresses of each leg
        self.sole_height = 0.035  # foot frame height above ground when the sole spheres touch
        self.foot_anchor = None  # (x, y, yaw) of each foot at the start, used as IK goals
        self.com_prev = None
        self.com_ref_prev = None
        # Controller plan: a temporally smoothed copy of the clip, which removes the acceleration
        # spikes of the 30 fps linear interpolation that no contact wrench could realize.
        self.plan = copy.copy(self.motion)
        groups = (slice(0, 7), slice(7, 19), slice(19, 22), slice(22, 36))
        self.plan.qpos = self.motion.qpos.copy()
        for cols, sigma in zip(groups, self.smooth_sigma):
            self.plan.qpos[:, cols] = gaussian_filter1d(self.motion.qpos[:, cols], sigma * self.motion.fps, axis=0, mode="nearest")
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def planned(self, t):
        """Smoothed controller plan (joint_q layout, floor shift applied) at time t [s]."""
        return self._shifted(self.plan.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def leg_ik(self, ref, feet, iterations=3):
        """Leg joint angles (and pelvis height) that put the reference pelvis over flat feet.

        Regularized least squares: the feet should be flat on the ground at the (x, y, yaw)
        in ``feet``, while the legs stay close to the reference angles.
        """
        qpos = np.concatenate([ref[:3], ref[6:7], ref[3:6], ref[7:]])
        q0 = qpos.copy()
        goals = []
        for x, y, yaw in feet:
            c, s = np.cos(yaw), np.sin(yaw)
            goals.append((np.array([x, y, self.sole_height]), np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])))
        dofs = np.concatenate([[2], self.leg_dofs[0], self.leg_dofs[1]])  # pelvis z + both legs
        qidx = np.where(dofs < 6, dofs, dofs + 1)
        w_task = np.array([1.0 / 0.001] * 3 + [1.0 / 0.002] * 3)
        w_reg = np.array([1.0 / 0.01] + [1.0 / 0.05] * 12)
        jacp, jacr = np.zeros((3, self.mjm.nv)), np.zeros((3, self.mjm.nv))
        for _ in range(iterations):
            self.mjd.qpos[:] = qpos
            mujoco.mj_kinematics(self.mjm, self.mjd)
            mujoco.mj_comPos(self.mjm, self.mjd)
            rows, errs = [], []
            for body, (p_goal, r_goal) in zip(self.feet_mj, goals):
                r = self.mjd.xmat[body].reshape(3, 3)
                dr = r_goal @ r.T
                angle_axis = 0.5 * np.array([dr[2, 1] - dr[1, 2], dr[0, 2] - dr[2, 0], dr[1, 0] - dr[0, 1]])
                errs.append(w_task * np.concatenate([p_goal - self.mjd.xpos[body], angle_axis]))
                mujoco.mj_jacBody(self.mjm, self.mjd, jacp, jacr, body)
                rows.append(w_task[:, None] * np.vstack([jacp[:, dofs], jacr[:, dofs]]))
            jac, err = np.vstack(rows), np.concatenate(errs)
            reg = w_reg**2
            dq = np.linalg.solve(jac.T @ jac + np.diag(reg), jac.T @ err - reg * (qpos[qidx] - q0[qidx]))
            qpos[qidx] += dq
        out = ref.copy()
        out[2] = qpos[2]
        out[7:] = qpos[7:]
        return out

    def com(self, q):
        """Whole-body center of mass [m] of joint_q q (Newton layout)."""
        self.mjd.qpos[:] = np.concatenate([q[:3], q[6:7], q[3:6], q[7:]])
        mujoco.mj_kinematics(self.mjm, self.mjd)
        mujoco.mj_comPos(self.mjm, self.mjd)
        return self.mjd.subtree_com[1].copy()

    def step(self):
        # ---------------- Controller (tunable) ----------------
        q = self.state_0.joint_q.numpy().astype(np.float64)
        if self.foot_anchor is None:
            body_q = self.state_0.body_q.numpy()
            feet = []
            for k in self.feet_nt:
                rot = np.asarray(wp.quat_to_matrix(wp.quat(*body_q[k, 3:7]))).reshape(3, 3)
                feet.append([body_q[k, 0], body_q[k, 1], np.arctan2(rot[1, 0], rot[0, 0])])
            self.foot_anchor = np.array(feet)
        t1 = self.sim_time + self.frame_dt
        ref = self.planned(t1)
        qd_ref = (self.planned(t1 + 0.01)[7:] - self.planned(t1 - 0.01)[7:]) / 0.02
        # Balance estimate: capture-point error of the measured vs. planned center of mass.
        com, com_ref = self.com(q), self.com(self.planned(self.sim_time))
        if self.com_prev is None:
            self.com_prev, self.com_ref_prev = com, com_ref
        vel = (com - self.com_prev) / self.frame_dt
        vel_ref = (com_ref - self.com_ref_prev) / self.frame_dt
        self.com_prev, self.com_ref_prev = com, com_ref
        err = (com + vel / self.omega - com_ref - vel_ref / self.omega)[:2]
        # Admittance: move the pelvis target against the capture-point error.
        shift = -self.k_pelvis * err
        norm = np.linalg.norm(shift)
        if norm > self.max_shift:
            shift *= self.max_shift / norm
        ref[:2] += shift
        # Leg targets keep the feet flat at their initial placement under the shifted pelvis;
        # damping acts on the velocity error via the planned joint velocity.
        target = self.leg_ik(ref, self.foot_anchor)
        target[7:] += self.kd / self.kp * qd_ref
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
