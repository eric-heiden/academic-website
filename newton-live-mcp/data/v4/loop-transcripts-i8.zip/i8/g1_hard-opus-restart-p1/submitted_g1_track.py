# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Controller: stiff joint servos plus feedforward precomputed once per clip. The
servo joint targets are the reference corrected to be physically trackable
(root shifted to keep a CoM margin inside the feet, legs re-solved by IK for
flat planted feet, light smoothing); whole-body inverse dynamics with the base
wrench split between the feet gives joint feedforward torques, which enter
together with a velocity term as an offset of the position targets.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import warp as wp
from scipy.ndimage import gaussian_filter1d

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    # ---------------- Controller parameters (tunable) ----------------
    LEG_HZ = 35.0  # servo natural frequency of hip and knee joints [Hz]
    ANKLE_HZ = 45.0  # ankle pitch/roll [Hz]
    UPPER_HZ = 35.0  # waist and arms [Hz]
    DAMPING_RATIO = 1.0
    REF_SMOOTH = 1.5  # Gaussian smoothing of the servo joint targets [clip samples]
    COM_MARGIN_TOE = 0.035  # keep the reference CoM this far behind the toe edge [m]
    COM_MARGIN_HEEL = 0.03  # ... and this far in front of the heel edge [m]
    COM_SHIFT_SMOOTH = 3.0  # smoothing of the CoM-guard root shift [clip samples]
    MOMENT_WEIGHT = 0.01  # inverse cost of foot moments vs. forces in the contact wrench split

    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad] per actuated
        # joint from a per-group natural frequency on the reflected inertia (critically damped).
        # step() adds whole-body inverse-dynamics and velocity feedforward through the targets.
        frequency_hz = np.array(([self.LEG_HZ] * 4 + [self.ANKLE_HZ] * 2) * 2 + [self.UPPER_HZ] * 17)
        natural_frequency = 2.0 * np.pi * frequency_hz
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * self.DAMPING_RATIO * ARMATURE * natural_frequency
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        self._init_controller()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    # ---------------- Controller (tunable) ----------------------
    def _init_controller(self):
        """Precompute the servo joint targets, their velocities and inverse-dynamics joint torques.

        The Kimodo clip is kinematic only: its feet are slightly tilted and floating, and during the
        high five the CoM rests close to the toes while the arm swing pushes the ZMP past them, so
        exact joint tracking tips the robot over. The servo targets are therefore corrected once
        per clip: the root is shifted to keep a CoM margin inside the support polygon, the legs are
        re-solved so both feet stay flat and planted, and the joint targets are lightly smoothed.
        """
        mjm = self.solver.mj_model
        self.mj_model = mjm
        self.mj_data = mujoco.MjData(mjm)
        names = [mjm.body(i).name for i in range(mjm.nbody)]
        self.foot_bodies = [
            next(i for i, n in enumerate(names) if n.endswith(f"{side}_ankle_roll_link")) for side in ("left", "right")
        ]
        self.pelvis_body = next(i for i, n in enumerate(names) if n.endswith("pelvis"))
        qpos = self.motion.qpos.copy()
        qpos[:, 2] += self.floor_offset
        qpos = self._flat_feet(qpos)
        if self.REF_SMOOTH > 0.0:
            qpos[:, 7:] = gaussian_filter1d(qpos[:, 7:], self.REF_SMOOTH, axis=0, mode="nearest")
        self.servo_q = qpos[:, 7:].copy()
        n, dt = len(qpos), 1.0 / self.motion.fps
        nv = mjm.nv
        # Velocities at the samples (central differences in the tangent space of the free joint).
        vel = np.zeros((n, nv))
        for k in range(n):
            a, b = max(k - 1, 0), min(k + 1, n - 1)
            if b > a:
                mujoco.mj_differentiatePos(mjm, vel[k], (b - a) * dt, qpos[a], qpos[b])
        acc = np.gradient(vel, dt, axis=0) if n > 2 else np.zeros_like(vel)
        # Light smoothing of the kinematic derivatives (reference is sampled at 30 fps).
        kernel = np.array([1.0, 2.0, 3.0, 2.0, 1.0]) / 9.0
        def smooth(x):
            pad = np.pad(x, ((2, 2), (0, 0)), mode="edge")
            return sum(kernel[i] * pad[i : i + len(x)] for i in range(5))
        vel_s, acc_s = smooth(vel), smooth(acc)
        self.servo_qd = vel_s[:, 6:]
        self.servo_tau = np.array([self._inverse_dynamics(qpos[k], vel_s[k], acc_s[k]) for k in range(n)])

    def _flat_feet(self, qpos):
        """Shift the root to guard the CoM and re-solve each leg (6-DoF IK) for a flat, planted foot."""
        m, d = self.mj_model, self.mj_data
        out = qpos.copy()
        yaws, heights, coms = [], [], []
        for k in range(len(qpos)):
            d.qpos[:] = qpos[k]
            mujoco.mj_kinematics(m, d)
            yaws.append([np.arctan2(d.xmat[b][3], d.xmat[b][0]) for b in self.foot_bodies])
            heights.append([d.xpos[b][2] for b in self.foot_bodies])
            mujoco.mj_comPos(m, d)
            coms.append(d.subtree_com[self.pelvis_body].copy())
            if k == 0:
                pos0 = [d.xpos[b].copy() for b in self.foot_bodies]
        yaws, heights = np.array(yaws), np.array(heights)
        # CoM guard: shift the root horizontally (feet stay planted) so the reference CoM keeps a
        # margin to the toe and heel edges of the support polygon; the clip parks it near the toes.
        com = np.array(coms)
        heading = [np.array([np.cos(y), np.sin(y)]) for y in yaws[0]]
        toe = min(pos0[f][0] + 0.12 * heading[f][0] for f in range(2))
        heel = max(pos0[f][0] - 0.05 * heading[f][0] for f in range(2))
        lo, hi = heel + self.COM_MARGIN_HEEL, toe - self.COM_MARGIN_TOE
        shift = np.clip(com[:, 0], lo, max(lo, hi)) - com[:, 0]
        if self.COM_SHIFT_SMOOTH > 0:
            shift = gaussian_filter1d(shift, self.COM_SHIFT_SMOOTH, mode="nearest")
        self.com_shift = shift
        # Planted feet: initial foot position, reference foot height and yaw, zero roll and pitch.
        for k in range(len(qpos)):
            q = qpos[k].copy()
            q[0] += shift[k]
            for f, b in enumerate(self.foot_bodies):
                dofs = np.arange(6 + 6 * f, 12 + 6 * f)
                c, s = np.cos(yaws[k, f]), np.sin(yaws[k, f])
                r_target = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.0]])
                p_target = np.array([pos0[f][0], pos0[f][1], heights[k, f]])
                for _ in range(50):
                    d.qpos[:] = q
                    mujoco.mj_kinematics(m, d)
                    mujoco.mj_comPos(m, d)
                    r = d.xmat[b].reshape(3, 3)
                    ep = p_target - d.xpos[b]
                    er = 0.5 * sum(np.cross(r[:, i], r_target[:, i]) for i in range(3))
                    e = np.r_[ep, er]
                    if np.linalg.norm(e) < 1e-7:
                        break
                    jp, jr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
                    mujoco.mj_jacBody(m, d, jp, jr, b)
                    j = np.vstack([jp, jr])[:, dofs]
                    dq = np.linalg.solve(j.T @ j + 1e-5 * np.eye(6), j.T @ e)
                    q[dofs + 1] += np.clip(dq, -0.05, 0.05)
            out[k] = q
        return out

    def _foot_jacobians(self, d):
        m = self.mj_model
        jac = []
        for b in self.foot_bodies:
            rot = d.xmat[b].reshape(3, 3)
            point = d.xpos[b] + rot @ np.array([0.035, 0.0, -0.035])
            jp, jr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
            mujoco.mj_jac(m, d, jp, jr, point, b)
            jac.append(np.vstack([jp, jr]))
        return jac

    def _inverse_dynamics(self, qpos, qvel, qacc):
        """Joint torques realizing qacc with both feet supporting the base (min-norm foot wrenches).

        MuJoCo inverse dynamics without constraints gives the generalized force; its floating-base
        part is assigned to the two sole wrenches, whose joint-space reaction is removed from the
        joint torques.
        """
        m, d = self.mj_model, self.mj_data
        d.qpos[:], d.qvel[:], d.qacc[:] = qpos, qvel, qacc
        flags = m.opt.disableflags
        m.opt.disableflags = flags | int(mujoco.mjtDisableBit.mjDSBL_CONSTRAINT)
        mujoco.mj_inverse(m, d)
        m.opt.disableflags = flags
        qfrc = d.qfrc_inverse.copy()
        jl, jr = self._foot_jacobians(d)
        a = np.hstack([jl[:, :6].T, jr[:, :6].T])  # 6 x 12
        w_inv = np.diag(np.tile([1.0, 1.0, 1.0] + [self.MOMENT_WEIGHT] * 3, 2))  # cheap forces, costly moments
        wrench = w_inv @ a.T @ np.linalg.solve(a @ w_inv @ a.T, qfrc[:6])
        return qfrc[6:] - jl[:, 6:].T @ wrench[:6] - jr[:, 6:].T @ wrench[6:]

    def _sample(self, table, t):
        x = np.clip(t, 0.0, self.motion.duration) * self.motion.fps
        i = min(int(x), len(table) - 2)
        a = x - i
        return (1 - a) * table[i] + a * table[i + 1]

    def step(self):
        # Servo targets one frame ahead. Position actuators apply kp (target - q) - kd qd, so the
        # feedforward torque tau_ff and the reference velocity term kd qd_ref enter as a target
        # offset (tau_ff + kd qd_ref) / kp and remain subject to the actuator torque limits.
        t = self.sim_time + self.frame_dt
        target = self.reference(t)
        tau = self._sample(self.servo_tau, t) + self.kd * self._sample(self.servo_qd, t)
        target[7:] = self._sample(self.servo_q, t) + tau / self.kp
        self.control.joint_target_q.assign(target)
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    # -------------------------------------------------------------

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
