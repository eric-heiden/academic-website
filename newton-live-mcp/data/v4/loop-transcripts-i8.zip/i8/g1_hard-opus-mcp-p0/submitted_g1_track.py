# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a Kimodo reference motion with joint-space PD actuators.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF; the controller sets their gains and targets every frame.

Controller: at start-up the clip is turned into a balanced plan (feet kept flat and
planted by leg IK, center of mass shifted by a small QP so the zero-moment point stays
inside the support polygon) with inverse-dynamics feedforward torques. Every frame the
servo targets are the planned angles offset by (feedforward torque + kd * planned
velocity) / kp, so the torque-limited servos apply PD + feedforward.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import copy

import mujoco
import numpy as np
import warp as wp
import cvxpy as cp
from scipy.ndimage import gaussian_filter1d
from scipy.spatial import ConvexHull

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        # Controller settings.
        self.servo_hz = 35.0  # servo natural frequency [Hz]
        self.servo_zeta = 1.0  # servo damping ratio
        self.smooth_legs = 2.0  # reference smoothing (Gaussian sigma in clip frames) for root, legs, waist
        self.smooth_arms = 1.0  # same for the arms
        self.moment_weight = 400.0  # foot-moment weight in the contact-wrench distribution
        self.use_feedforward = 1.0
        self.foot_height = 0.0345  # ankle-roll-link height [m] of a flat foot resting on the floor
        self.ik_iterations = 15
        self.ik_height_weight = 0.3  # relative ease of moving the pelvis height vs. the leg joints
        self.ik_pelvis_rot_weight = 1.0  # same for the pelvis orientation
        self.zmp_margin = 0.05  # required ZMP distance [m] from the support polygon edge (None: off)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # per actuated joint, derived from a natural frequency on the reflected inertia.
        natural_frequency = 2.0 * np.pi * self.servo_hz
        self.kp = ARMATURE * natural_frequency**2
        self.kd = 2.0 * self.servo_zeta * ARMATURE * natural_frequency
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self._build_feedforward()
        self.viewer.set_model(self.model)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def _build_feedforward(self):
        """Balanced reference trajectory, its velocities and inverse-dynamics joint torques.

        1. Low-pass filter the reference (MuJoCo qpos layout) in time.
        2. Leg IK keeps both feet flat and planted where they start (the clips lift the
           heels and pivot the feet, which tips a rigid position-controlled robot).
        3. A small QP shifts the center of mass horizontally so that the zero-moment
           point stays inside the support polygon with a margin; leg IK realizes it.
        4. MuJoCo inverse dynamics without contacts gives the generalized forces; the
           floating-base part is distributed onto both feet (weighted least norm) and the
           remaining joint torques are the feedforward.
        """
        m = copy.deepcopy(self.solver.mj_model)
        d = mujoco.MjData(m)
        m_free = copy.deepcopy(m)
        m_free.opt.disableflags |= int(mujoco.mjtDisableBit.mjDSBL_CONSTRAINT)
        d_free = mujoco.MjData(m_free)
        dt = 1.0 / self.motion.fps

        traj = self.motion.qpos.copy()
        traj[:, 2] += self.floor_offset
        for i in range(1, len(traj)):
            if np.dot(traj[i, 3:7], traj[i - 1, 3:7]) < 0.0:
                traj[i, 3:7] *= -1.0
        sigma = np.full(traj.shape[1], self.smooth_legs)
        sigma[7 + 15 :] = self.smooth_arms
        for j in range(traj.shape[1]):
            if sigma[j] > 0.0 and len(traj) > 1:
                traj[:, j] = gaussian_filter1d(traj[:, j], sigma[j], mode="nearest")
        traj[:, 3:7] /= np.linalg.norm(traj[:, 3:7], axis=1, keepdims=True)

        feet = [i for i in range(m.nbody) if mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_BODY, i).endswith("ankle_roll_link")]
        goals = self._foot_goals(m, d, traj[0], feet)
        traj = self._plant_feet(m, d, traj, feet, goals)

        if self.zmp_margin is not None and len(traj) > 2:
            # Support polygon: convex hull of the foot contact spheres of the planted feet.
            points = []
            for body, (pos, rot) in zip(feet, goals):
                for g in np.flatnonzero(m.geom_bodyid == body):
                    points.append((pos + rot @ m.geom_pos[g])[:2])
            planes = ConvexHull(np.array(points)).equations  # a x + b y + c <= 0 inside
            vel, acc = self._derivatives(m, traj, dt)
            zmp, com = self._zmp(m_free, d_free, traj, vel, acc)
            target = com[:, :2] + self._zmp_shift(zmp, com, planes, dt)
            for _ in range(3):
                com = self._com(m, d, traj)
                traj[:, :2] += (target - com[:, :2]) / 0.85
                traj = self._plant_feet(m, d, traj, feet, goals)

        vel, acc = self._derivatives(m, traj, dt)
        w_inv = np.diag(1.0 / np.tile([1.0, 1.0, 1.0] + [self.moment_weight] * 3, len(feet)))
        tau = np.zeros((len(traj), m.nv - 6))
        jp, jr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
        for i in range(len(traj)):
            d_free.qpos[:], d_free.qvel[:], d_free.qacc[:] = traj[i], vel[i], acc[i]
            mujoco.mj_inverse(m_free, d_free)
            jac = []
            for body in feet:
                point = d_free.xpos[body] + d_free.xmat[body].reshape(3, 3) @ np.array([0.035, 0.0, -0.035])
                mujoco.mj_jac(m_free, d_free, jp, jr, point, body)
                jac.append(np.vstack([jp, jr]))
            jac = np.vstack(jac)
            base = jac[:, :6].T
            wrench = w_inv @ base.T @ np.linalg.solve(base @ w_inv @ base.T, d_free.qfrc_inverse[:6])
            tau[i] = d_free.qfrc_inverse[6:] - (jac.T @ wrench)[6:]
        # Newton layout: root pos, quat xyzw, joints.
        self.ref_q = np.concatenate([traj[:, :3], quat_wxyz_to_xyzw(traj[:, 3:7]), traj[:, 7:]], axis=1)
        self.ref_qd = vel[:, 6:]
        self.ref_tau = tau

    @staticmethod
    def _derivatives(m, traj, dt):
        n = len(traj)
        vel = np.zeros((n, m.nv))
        for i in range(n):
            a, b = max(i - 1, 0), min(i + 1, n - 1)
            if b > a:
                mujoco.mj_differentiatePos(m, vel[i], (b - a) * dt, traj[a], traj[b])
        acc = np.gradient(vel, dt, axis=0) if n > 1 else np.zeros_like(vel)
        return vel, acc

    @staticmethod
    def _com(m, d, traj):
        com = np.zeros((len(traj), 3))
        for i in range(len(traj)):
            d.qpos[:] = traj[i]
            mujoco.mj_kinematics(m, d)
            mujoco.mj_comPos(m, d)
            com[i] = d.subtree_com[1]
        return com

    @staticmethod
    def _zmp(m, d, traj, vel, acc):
        """Zero-moment point from the total ground force needed by the (contact-free) inverse dynamics."""
        zmp, com = np.zeros((len(traj), 2)), np.zeros((len(traj), 3))
        for i in range(len(traj)):
            d.qpos[:], d.qvel[:], d.qacc[:] = traj[i], vel[i], acc[i]
            mujoco.mj_inverse(m, d)
            force = d.qfrc_inverse[:3]
            com[i] = d.subtree_com[1]
            zmp[i] = com[i, :2] - com[i, 2] * force[:2] / force[2]
        return zmp, com

    def _zmp_shift(self, zmp, com, planes, dt, g=9.81):
        """Smallest horizontal CoM offset (cart-table model) keeping the ZMP inside the support."""
        n = len(zmp)
        height = float(np.mean(com[:, 2]))
        d2 = (np.eye(n, k=1) - 2.0 * np.eye(n) + np.eye(n, k=-1)) / dt**2
        d2[0, :] = 0.0
        d2[-1, :] = 0.0
        shift = cp.Variable((n, 2))
        new_zmp = zmp + shift - (height / g) * (d2 @ shift)
        constraints = [new_zmp @ planes[:, :2].T + planes[:, 2][None, :] <= -self.zmp_margin, shift[0] == 0.0]
        objective = cp.Minimize(cp.sum_squares(shift) + 1e-4 * cp.sum_squares(d2 @ shift))
        problem = cp.Problem(objective, constraints)
        problem.solve(solver=cp.CLARABEL)
        if shift.value is None:
            return np.zeros((n, 2))
        return shift.value

    def _foot_goals(self, m, d, q0, feet):
        """Flat foot poses (initial position and heading) resting on the floor."""
        d.qpos[:] = q0
        mujoco.mj_kinematics(m, d)
        goals = []
        for body in feet:
            x_axis = d.xmat[body].reshape(3, 3)[:, 0]
            yaw = np.arctan2(x_axis[1], x_axis[0])
            c, s = np.cos(yaw), np.sin(yaw)
            rot = np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])
            pos = d.xpos[body].copy()
            pos[2] = self.foot_height
            goals.append((pos, rot))
        return goals

    def _plant_feet(self, m, d, traj, feet, goals):
        """Leg IK that puts both feet at their goal poses under the reference pelvis."""
        traj = traj.copy()
        # Unknowns: pelvis height and orientation and the 12 leg joints. The knees are
        # nearly straight, so a flat foot under a raised or tilted heel is easier to reach
        # by moving the pelvis a little (its orientation is free for the upper body joints).
        jp, jr = np.zeros((3, m.nv)), np.zeros((3, m.nv))
        dof_idx = np.concatenate([[2, 3, 4, 5], np.arange(6, 18)])
        w_inv = np.ones(len(dof_idx))
        w_inv[0] = self.ik_height_weight
        w_inv[1:4] = self.ik_pelvis_rot_weight
        step = np.zeros(m.nv)
        for i in range(len(traj)):
            q = traj[i].copy()
            for _ in range(self.ik_iterations):
                d.qpos[:] = q
                mujoco.mj_kinematics(m, d)
                mujoco.mj_comPos(m, d)
                err, jac = [], []
                for body, (pos, rot) in zip(feet, goals):
                    quat = np.zeros(4)
                    mujoco.mju_mat2Quat(quat, (rot @ d.xmat[body].reshape(3, 3).T).flatten())
                    rotvec = np.zeros(3)
                    mujoco.mju_quat2Vel(rotvec, quat, 1.0)
                    err.append(np.concatenate([pos - d.xpos[body], rotvec]))
                    mujoco.mj_jacBody(m, d, jp, jr, body)
                    jac.append(np.vstack([jp, jr])[:, dof_idx])
                err, jac = np.concatenate(err), np.vstack(jac)
                gram = jac @ (w_inv[:, None] * jac.T) + 1e-4 * np.eye(len(err))
                step[:] = 0.0
                step[dof_idx] = w_inv * (jac.T @ np.linalg.solve(gram, err))
                mujoco.mj_integratePos(m, q, step, 1.0)
            traj[i] = q
        return traj

    def _interp(self, table, t):
        x = np.clip(t * self.motion.fps, 0.0, len(table) - 1)
        i = min(int(x), max(len(table) - 2, 0))
        a = x - i
        return (1 - a) * table[i] + a * table[min(i + 1, len(table) - 1)]

    def simulate(self):
        for _ in range(self.sim_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        # Position targets one frame ahead: planned (balanced) angles, shifted so that the servo
        # also applies the inverse-dynamics torque and damps toward the planned velocity.
        t = self.sim_time + self.frame_dt
        target = self._interp(self.ref_q, t)
        tau = self.use_feedforward * self._interp(self.ref_tau, t)
        qd = self._interp(self.ref_qd, t)
        target[7:] += (tau + self.kd * qd) / self.kp
        self.control.joint_target_q.assign(target)
        # -------------------------------------------------------
        if self.graph is not None:
            wp.capture_launch(self.graph)
        else:
            self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
