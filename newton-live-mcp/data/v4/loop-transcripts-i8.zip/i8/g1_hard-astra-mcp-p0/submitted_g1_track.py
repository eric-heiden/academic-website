# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following Kimodo motion with whole-body inverse dynamics.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A 250 Hz controller tracks root pose and joints while allocating
foot support forces subject to friction and actuator limits. Its only outputs
are joint servo targets; Newton integrates all motion at the original 2 ms step.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import warp as wp
from scipy import sparse

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


def mj_qpos(q):
    """Convert a Newton configuration to MuJoCo's wxyz quaternion convention."""
    return np.r_[q[:3], q[6], q[3:6], q[7:]]


class WholeBodyController:
    """Balance and posture QP for motions with both feet supporting the robot.

    Decision variables are generalized accelerations and foot point forces.
    Floating-base dynamics are equality constraints with zero base actuation;
    joint dynamics supply torque bounds. Soft foot acceleration tasks accommodate
    the small foot-height inconsistencies in a kinematic motion reference.
    The point forces are planning variables, never forces applied to the model.
    """

    def __init__(self, example):
        self.e = example
        self.m = example.solver.mj_model
        self.d = mujoco.MjData(self.m)
        self.geoms = [
            i for i in range(self.m.ngeom)
            if self.m.geom_type[i] == mujoco.mjtGeom.mjGEOM_SPHERE
            and "ankle_roll_link" in self.m.body(int(self.m.geom_bodyid[i])).name
        ]
        self.com = example.model.body_com.numpy()[0].astype(float)
        self.weights = np.r_[[200.0] * 3, [100.0] * 3, np.ones(29)]
        self.tracking_kp = np.r_[[200.0] * 6, [1600.0] * 29]
        self.tracking_kd = 2 * np.sqrt(self.tracking_kp)
        self.foot_weight = 100.0
        self.last = None

    def compute(self, t):
        e, m, d = self.e, self.m, self.d
        q = e.state_0.joint_q.numpy().astype(float)
        v = e.state_0.joint_qd.numpy().astype(float)
        d.qpos[:] = mj_qpos(q)
        rot = np.empty(9)
        mujoco.mju_quat2Mat(rot, d.qpos[3:7])
        rot = rot.reshape(3, 3)
        # Newton stores root COM velocity and world angular velocity. MuJoCo
        # uses root-origin velocity and body-frame angular velocity instead.
        d.qvel[:] = v
        d.qvel[:3] -= np.cross(v[3:6], rot @ self.com)
        d.qvel[3:6] = rot.T @ v[3:6]
        mujoco.mj_forward(m, d)
        # Differentiate the original sampler, including its endpoint hold.
        # A one-source-frame stencil smooths piecewise-linear velocity jumps.
        h = 1 / 30.0
        qr = mj_qpos(e.reference(t))
        qm = mj_qpos(e.reference(t - h))
        qp = mj_qpos(e.reference(t + h))
        err, vr, vm, vp = [np.zeros(m.nv) for _ in range(4)]
        mujoco.mj_differentiatePos(m, err, 1.0, d.qpos, qr)
        mujoco.mj_differentiatePos(m, vr, 2 * h, qm, qp)
        mujoco.mj_differentiatePos(m, vm, h, qm, qr)
        mujoco.mj_differentiatePos(m, vp, h, qr, qp)
        ar = (vp - vm) / h
        desired = ar + self.tracking_kp * err + self.tracking_kd * (vr - d.qvel)
        mass = np.zeros((m.nv, m.nv))
        mujoco.mj_fullM(m, d, mass)
        bias = d.qfrc_bias - d.qfrc_passive
        jac, jdot, pos = [], [], []
        for g in self.geoms:
            point = d.geom_xpos[g].copy()
            point[2] -= m.geom_size[g, 0]
            jp, jd = np.zeros((3, m.nv)), np.zeros((3, m.nv))
            body = int(m.geom_bodyid[g])
            mujoco.mj_jac(m, d, jp, None, point, body)
            mujoco.mj_jacDot(m, d, jd, None, point, body)
            jac.append(jp)
            jdot.append(jd @ d.qvel)
            pos.append(point)
        J = np.vstack(jac)
        jd = np.concatenate(jdot)
        pos = np.array(pos)
        # Dampen foot slip and settle the sole on the compliant ground contact.
        foot_acc = -40 * (J @ d.qvel).reshape(-1, 3)
        foot_acc[:, 2] -= 400 * (pos[:, 2] + 0.0005)
        foot_acc = foot_acc.ravel() - jd
        nf = len(jd)
        # M*a + bias - J.T*f = [0 (floating base), joint torques].
        dynamics = np.hstack((mass, -J.T))
        P = np.zeros((m.nv + nf, m.nv + nf))
        P[:m.nv, :m.nv] = np.diag(self.weights) + self.foot_weight * J.T @ J
        P[m.nv:, m.nv:] = np.eye(nf) * 1.0e-4
        lin = np.r_[-self.weights * desired - self.foot_weight * J.T @ foot_acc, np.zeros(nf)]
        # Four-sided friction cones at each actual foot collision sphere.
        cone = np.zeros((len(self.geoms) * 5, m.nv + nf))
        for i in range(len(self.geoms)):
            cone[5*i:5*i+5, m.nv+3*i:m.nv+3*i+3] = [
                [1, 0, -0.6], [-1, 0, -0.6],
                [0, 1, -0.6], [0, -1, -0.6], [0, 0, -1],
            ]
        A = np.vstack((dynamics, cone))
        lo = np.r_[-bias[:6], m.actuator_forcerange[:, 0] - bias[6:], np.full(len(cone), -np.inf)]
        hi = np.r_[-bias[:6], m.actuator_forcerange[:, 1] - bias[6:], np.zeros(len(cone))]
        prob = osqp.OSQP()
        prob.setup(
            P=sparse.csc_matrix(P), q=lin, A=sparse.csc_matrix(A), l=lo, u=hi,
            verbose=False, eps_abs=1.0e-4, eps_rel=1.0e-4, max_iter=2000, polishing=False,
        )
        if self.last is not None and t > 0.0:
            prob.warm_start(x=self.last)
        result = prob.solve(raise_error=False)
        if result.x is None or result.info.status_val not in (1, 2):
            raise RuntimeError("Whole body QP: " + result.info.status)
        self.last = result.x
        tau = dynamics[6:] @ result.x + bias[6:]
        # Invert tau = kp*(target-q) - kd*v. The existing MuJoCo servos
        # retain their original hard torque limits throughout every substep.
        target = q.copy()
        target[7:] += (tau + e.kd * d.qvel[6:]) / e.kp
        return target


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # ---------------- Controller (tunable) ----------------
        # Joint-space PD servos: stiffness kp [N m/rad] and damping kd [N m s/rad]
        # kept compliant between the inverse-dynamics updates.
        self.kp = np.full(29, 20.0)
        self.kd = np.full(29, 0.3)
        self.control_substeps = 2
        # -------------------------------------------------------

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self.controller = WholeBodyController(self)
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        # An even number of ping-pong steps lets the same CUDA graph be reused
        # without swapping its input/output buffers between launches.
        for _ in range(self.control_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # ---------------- Controller (tunable) ----------------
        # Five feedback updates, each followed by two unchanged 2 ms steps.
        for k in range(self.sim_substeps // self.control_substeps):
            target = self.controller.compute(self.sim_time + k * self.control_substeps * self.sim_dt)
            self.control.joint_target_q.assign(target)
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        # -------------------------------------------------------
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
