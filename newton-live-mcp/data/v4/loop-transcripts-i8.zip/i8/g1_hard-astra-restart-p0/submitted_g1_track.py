# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 tracking standing Kimodo motions with whole-body balance control.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A constrained inverse-dynamics controller updates their targets
at 250 Hz, coordinating pelvis tracking, joint tracking, and sole support.
Physics still runs at 500 Hz and viewer frames at 50 Hz. Contact forces are
optimization variables only: the controller commands the 29 joint servos,
and the simulator supplies all ground reactions.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import warp as wp
from scipy import sparse

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # Local servo stiffness/damping stabilizes the interval between
        # whole-body updates. The inverse-dynamics torque is encoded as a
        # position-target offset; the original actuator limits still apply.
        self.kp = np.full(29, 150.0)
        self.kd = np.full(29, 5.0)

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self._init_controller()
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self._simulate_control_interval()
            self.graph = capture.graph

    def _init_controller(self):
        m = self.solver.mj_model
        # Separate analytical data: never write the simulator state or model.
        self.id_data = mujoco.MjData(m)
        self.control_substeps = 2
        self.control_failures = 0
        self.acc_weights = np.array([100.0] * 3 + [10.0] * 3 + [1.0] * 29)
        self.tracking_gain = np.array([150.0] * 6 + [400.0] * 29)
        self.foot_geoms = [
            g
            for g in range(m.ngeom)
            if m.geom_type[g] == mujoco.mjtGeom.mjGEOM_SPHERE
            and m.body(int(m.geom_bodyid[g])).name.endswith(
                ("left_ankle_roll_link", "right_ankle_roll_link")
            )
        ]
        self.nforce = 3 * len(self.foot_geoms)
        self.nvar = m.nv + self.nforce

        # Each sole corner has a unilateral normal force and a conservative
        # friction pyramid: |fx|, |fy| <= 0.7*fz. No contact wrench is applied
        # directly; these constraints determine feasible joint torques.
        self.friction = np.zeros((5 * len(self.foot_geoms), self.nvar))
        pyramid = np.array([[1, 0, -0.7], [-1, 0, -0.7],
                            [0, 1, -0.7], [0, -1, -0.7], [0, 0, -1]])
        for k in range(len(self.foot_geoms)):
            self.friction[5 * k : 5 * k + 5, m.nv + 3 * k : m.nv + 3 * k + 3] = pyramid

        # Leave a little torque headroom for the local servo feedback.
        self.force_lower = np.r_[np.zeros(6), 0.95 * m.actuator_forcerange[:, 0]]
        self.force_upper = np.r_[np.zeros(6), 0.95 * m.actuator_forcerange[:, 1]]

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def _simulate_control_interval(self):
        # An even number of steps keeps the captured graph's state buffers
        # consistent. Five intervals still give ten 2 ms steps per frame.
        for _ in range(self.control_substeps):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def _mj_reference(self, t):
        """Convert the unchanged playback reference to MuJoCo coordinates."""
        q = self.reference(t)
        return np.r_[q[:3], q[6], q[3:6], q[7:]]

    def _compute_control(self, t):
        m, d = self.solver.mj_model, self.id_data
        # Read native qvel so the free joint's angular velocity has MuJoCo's
        # local-frame convention, rather than Newton's spatial convention.
        if self.solver.use_mujoco_cpu:
            d.qpos[:] = self.solver.mj_data.qpos
            d.qvel[:] = self.solver.mj_data.qvel
        else:
            d.qpos[:] = self.solver.mjw_data.qpos.numpy()[0]
            d.qvel[:] = self.solver.mjw_data.qvel.numpy()[0]
        qr = self._mj_reference(t)
        # Differentiate the sampler, not the CSV frame indices. This also
        # follows any playback rate used by the caller. Quaternion differences
        # are taken on the rotation manifold by mj_differentiatePos.
        eps = 0.01
        qm, qp = self._mj_reference(t - eps), self._mj_reference(t + eps)
        vr = np.zeros(m.nv)
        mujoco.mj_differentiatePos(m, vr, 2 * eps, qm, qp)
        vm, vp = np.zeros(m.nv), np.zeros(m.nv)
        mujoco.mj_differentiatePos(m, vm, eps, qm, qr)
        mujoco.mj_differentiatePos(m, vp, eps, qr, qp)
        ar = (vp - vm) / eps
        err = np.zeros(m.nv)
        mujoco.mj_differentiatePos(m, err, 1.0, d.qpos, qr)
        gain = self.tracking_gain
        ades = ar + gain * err + 2 * np.sqrt(gain) * (vr - d.qvel)
        mujoco.mj_forward(m, d)
        M = np.zeros((m.nv, m.nv))
        mujoco.mj_fullM(m, d, M)
        bias = d.qfrc_bias - d.qfrc_passive

        # Soft sole-acceleration tasks allow the small foot-pose discrepancies
        # in a kinematic reference to be absorbed without fighting the floor.
        # Tangential velocity damping prevents slip; the vertical task gently
        # seats the sole on the compliant ground contact.
        J = np.zeros((self.nforce, m.nv))
        ca = np.zeros(self.nforce)
        for k, g in enumerate(self.foot_geoms):
            pt = d.geom_xpos[g].copy()
            pt[2] -= m.geom_size[g, 0]
            jp, jd = np.zeros((3, m.nv)), np.zeros((3, m.nv))
            mujoco.mj_jac(m, d, jp, None, pt, int(m.geom_bodyid[g]))
            mujoco.mj_jacDot(m, d, jd, None, pt, int(m.geom_bodyid[g]))
            J[3 * k : 3 * k + 3] = jp
            ca[3 * k : 3 * k + 3] = -40 * (jp @ d.qvel) - jd @ d.qvel
            ca[3 * k + 2] += -500 * (pt[2] + 0.001)

        # QP variables are [generalized acceleration, corner forces]. Track
        # pelvis/joint accelerations and sole support, with small force/effort
        # penalties to avoid excessive internal forces between the two legs.
        H = np.zeros((self.nvar, self.nvar))
        H[:m.nv, :m.nv] = np.diag(self.acc_weights) + 100 * J.T @ J
        H[m.nv:, m.nv:] = 1e-4 * np.eye(self.nforce)
        linear = np.r_[-self.acc_weights * ades - 100 * J.T @ ca, np.zeros(self.nforce)]
        dynamics = np.c_[M, -J.T]
        H += 1e-4 * dynamics.T @ dynamics
        linear += 1e-4 * dynamics.T @ bias

        # M*a + bias - J.T*f = [0, joint_torque]. The first six rows
        # explicitly enforce an unactuated floating base; the remaining rows
        # enforce the original robot's joint torque limits.
        A = np.r_[dynamics, self.friction]
        lo = np.r_[self.force_lower - bias, np.full(len(self.friction), -np.inf)]
        hi = np.r_[self.force_upper - bias, np.zeros(len(self.friction))]
        prob = osqp.OSQP()
        prob.setup(
            P=sparse.csc_matrix(H), q=linear, A=sparse.csc_matrix(A), l=lo, u=hi,
            verbose=False, eps_abs=1e-5, eps_rel=1e-5, max_iter=2000, polishing=True,
        )
        sol = prob.solve()
        if sol.x is not None and sol.info.status_val in (1, 2):
            acc = sol.x[:m.nv]
            tau = (dynamics @ sol.x + bias)[6:]
        else:
            self.control_failures += 1
            acc = ades
            tau = self.kp * (qr[7:] - d.qpos[7:]) + self.kd * (vr[6:] - d.qvel[6:])

        # tau = kp*(target-q) - kd*v. The acceleration term compensates
        # for one integration step of implicit servo damping. Only the 29
        # actuated joint targets have any effect on the simulation.
        target = self.reference(t)
        target[7:] = d.qpos[7:] + (tau + self.kd * (d.qvel[6:] + self.sim_dt * acc[6:])) / self.kp
        self.control.joint_target_q.assign(target)

    def simulate(self):
        for i in range(self.sim_substeps // self.control_substeps):
            self._compute_control(self.sim_time + i * self.control_substeps * self.sim_dt)
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self._simulate_control_interval()

    def step(self):
        self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
