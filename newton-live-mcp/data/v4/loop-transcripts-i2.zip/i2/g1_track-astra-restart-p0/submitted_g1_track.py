# SPDX-FileCopyrightText: Copyright (c) 2026 The Newton Developers
# SPDX-License-Identifier: Apache-2.0

"""Unitree G1 following a standing Kimodo motion with whole-body feedback.

The floating-base G1 stands on the ground and tracks the 29 reference joint
angles of a MuJoCo-qpos CSV clip (root xyz, root quaternion wxyz, 29 joints at
30 fps). Actuators are MuJoCo position servos with torque limits from the
robot's MJCF. A constrained inverse-dynamics controller updates their targets
at 250 Hz, balancing through the feet while tracking the pelvis and joints.
Rendering remains at 50 Hz and physics uses the original 2 ms substeps.

Run: ``python g1_track.py --motion wave.csv --viewer null --num-frames 250``
"""

from __future__ import annotations

import mujoco
import numpy as np
import osqp
import scipy.sparse as sparse
import warp as wp
from scipy.spatial.transform import Rotation

import newton
import newton.examples

# Reflected actuator inertia per joint (BeyondMimic G1 configuration) [kg m^2].
LEG = [0.010177520, 0.025101925, 0.010177520, 0.025101925, 0.007219450, 0.007219450]
ARM = [0.003609725] * 5 + [0.00425] * 2
ARMATURE = np.array(LEG * 2 + [0.010177520, 0.007219450, 0.007219450] + ARM * 2)


def quat_wxyz_to_xyzw(q):
    return np.concatenate([q[..., 1:4], q[..., :1]], axis=-1)


class MotionClip:
    """Linear interpolation of a qpos CSV in time (root quaternion by normalized lerp)."""

    def __init__(self, path, fps=30.0):
        self.qpos = np.loadtxt(path, delimiter=",")
        if self.qpos.ndim != 2 or self.qpos.shape[1] != 36:
            raise ValueError("Expected rows of 36 qpos values (root pos, root quat wxyz, 29 joints)")
        self.fps = fps
        self.duration = (len(self.qpos) - 1) / fps

    def sample(self, t):
        """Reference joint_q in Newton layout (root pos, root quat xyzw, joints) at time t [s]."""
        x = np.clip(t, 0.0, self.duration) * self.fps
        i = min(int(x), len(self.qpos) - 2)
        a = x - i
        q = (1 - a) * self.qpos[i] + a * self.qpos[i + 1]
        q[3:7] /= np.linalg.norm(q[3:7])
        return np.concatenate([q[:3], quat_wxyz_to_xyzw(q[3:7]), q[7:]])


class Example:
    def __init__(self, viewer, args):
        self.viewer = viewer
        self.fps = 50
        self.frame_dt = 1.0 / self.fps
        self.sim_substeps = 10
        self.sim_dt = self.frame_dt / self.sim_substeps
        self.sim_time = 0.0
        self.motion = MotionClip(args.motion)

        builder = newton.ModelBuilder()
        newton.solvers.SolverMuJoCo.register_custom_attributes(builder)
        asset = newton.utils.download_asset("unitree_g1")
        builder.add_mjcf(str(asset / "mjcf/g1_29dof_rev_1_0.xml"), collapse_fixed_joints=True)
        # Robot self-collision is excluded; feet and body still collide with the floor.
        robot_shapes = [i for i, body in enumerate(builder.shape_body) if body >= 0]
        for i, shape in enumerate(robot_shapes):
            for other in robot_shapes[i + 1 :]:
                builder.add_shape_collision_filter_pair(shape, other)
        builder.joint_armature[6:] = ARMATURE.tolist()

        # Local servo stiffness [Nm/rad] and damping [Nm s/rad]. The balance
        # controller encodes its joint torques as offsets to these targets.
        self.kp = np.array([200.0] * 15 + [80.0] * 14)
        self.kd = np.array([8.0] * 15 + [3.0] * 14)

        builder.joint_target_ke[6:] = self.kp.tolist()
        builder.joint_target_kd[6:] = self.kd.tolist()
        builder.joint_target_mode[6:] = [int(newton.JointTargetMode.POSITION)] * 29
        builder.custom_attributes["mujoco:ctrl_source"].values = [
            int(newton.solvers.SolverMuJoCo.CtrlSource.JOINT_TARGET)
        ] * 29
        builder.custom_attributes["mujoco:actuator_has_forcerange"].values = [True] * 29
        builder.custom_attributes["mujoco:actuator_forcelimited"].values = [1] * 29
        builder.custom_attributes["mujoco:actuator_forcerange"].values = [
            (-limit, limit) for limit in builder.joint_effort_limit[6:]
        ]

        # Start at the first reference frame with the feet just touching the ground.
        q0 = self.motion.sample(0.0)
        builder.joint_q[:] = q0.tolist()
        self.model = builder.finalize()
        self.floor_offset = self._floor_offset(q0)
        self.model.joint_q.assign(self._shifted(q0))
        self.solver = newton.solvers.SolverMuJoCo(
            self.model,
            njmax=192,
            nconmax=64,
            use_mujoco_contacts=True,
            integrator="implicitfast",
            iterations=50,
        )
        self.state_0, self.state_1 = self.model.state(), self.model.state()
        self.control = self.model.control()
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, self.state_0)
        self.viewer.set_model(self.model)
        self._init_controller()
        self.graph = None
        if wp.get_device().is_cuda:
            with wp.ScopedCapture() as capture:
                self.simulate()
            self.graph = capture.graph

    def _floor_offset(self, q0):
        """Vertical shift [m] that puts the lowest foot collision point 2 mm above the floor."""
        state = self.model.state()
        self.model.joint_q.assign(q0)
        newton.eval_fk(self.model, self.model.joint_q, self.model.joint_qd, state)
        body_q = state.body_q.numpy()
        labels = [label.rsplit("/", 1)[-1] for label in self.model.body_label]
        lowest = np.inf
        for side in ("left", "right"):
            pose = body_q[labels.index(f"{side}_ankle_roll_link")]
            rotation = np.asarray(wp.quat_to_matrix(wp.quat(*pose[3:7]))).reshape(3, 3)
            for x in (-0.05, 0.12):
                for y in (-0.025, 0.025):
                    lowest = min(lowest, (pose[:3] + rotation @ np.array([x, y, -0.035]))[2])
        return 0.002 - lowest

    def _shifted(self, q):
        q = q.copy()
        q[2] += self.floor_offset
        return q

    def _init_controller(self):
        """Set up a dynamics workspace and the two stationary support feet.

        This MjData is only used for kinematics and inverse dynamics. Its
        estimated contact forces are never applied to the simulated robot.
        """
        self.cm = self.solver.mj_model
        self.cd = mujoco.MjData(self.cm)
        self.cd.qpos[:] = self.solver.mj_data.qpos
        mujoco.mj_forward(self.cm, self.cd)
        self.feet = [
            i for i in range(self.cm.nbody) if self.cm.body(i).name.endswith("ankle_roll_link")
        ]
        # Preserve the initial footprint and yaw, and settle each sole flat.
        self.foot_positions = self.cd.xpos[self.feet].copy()
        self.foot_positions[:, 2] = 0.035
        self.foot_rotations = []
        for b in self.feet:
            yaw = Rotation.from_matrix(self.cd.xmat[b].reshape(3, 3)).as_euler("xyz")[2]
            self.foot_rotations.append(Rotation.from_euler("z", yaw))
        self.corner_offsets = np.array(
            [[-0.05, 0.025, -0.035], [-0.05, -0.025, -0.035],
             [0.12, 0.03, -0.035], [0.12, -0.03, -0.035]]
        )
        self.mass_matrix = np.zeros((35, 35))
        self.last_solution = None
        self.qp_failures = 0

        # Acceleration tracking weights: pelvis translation, orientation,
        # then joint posture. Force regularization shares load between feet.
        self.tracking_weights = np.r_[[100.0] * 3, [30.0] * 3, [1.0] * 29]
        self.qp_hessian = sparse.diags(np.r_[self.tracking_weights, [1.0e-5] * 24], format="csc")
        self.friction_constraints = np.zeros((40, 59))
        for c in range(8):
            idx = 35 + c * 3
            self.friction_constraints[c * 5:c * 5 + 5, idx:idx + 3] = [
                [1, 0, -0.6], [-1, 0, -0.6], [0, 1, -0.6], [0, -1, -0.6], [0, 0, -1]
            ]

    def _mujoco_reference(self, t):
        q = self.reference(t)
        return np.r_[q[:3], q[6], q[3:6], q[7:]]

    def _controller(self, t):
        """Solve for feasible accelerations/contact forces; command only joints."""
        m, d = self.cm, self.cd
        d.qpos[:] = self.solver.mjw_data.qpos.numpy()[0]
        d.qvel[:] = self.solver.mjw_data.qvel.numpy()[0]
        mujoco.mj_forward(m, d)

        # Differentiate the actual playback sampler, so feedforward also
        # follows a changed playback rate. Quaternion differences use SO(3).
        eps = 0.01
        qr = self._mujoco_reference(t)
        qm = self._mujoco_reference(t - eps)
        qp = self._mujoco_reference(t + eps)
        vr, vm, vp, err = (np.zeros(35) for _ in range(4))
        mujoco.mj_differentiatePos(m, vr, 2 * eps, qm, qp)
        mujoco.mj_differentiatePos(m, vm, eps, qm, qr)
        mujoco.mj_differentiatePos(m, vp, eps, qr, qp)
        mujoco.mj_differentiatePos(m, err, 1.0, d.qpos, qr)
        ar = (vp - vm) / eps
        desired = ar + 1200.0 * err + 70.0 * (vr - d.qvel)
        desired[:6] = ar[:6] + 300.0 * err[:6] + 35.0 * (vr[:6] - d.qvel[:6])
        mujoco.mj_fullM(m, d, self.mass_matrix)
        M = self.mass_matrix
        h = d.qfrc_bias - d.qfrc_passive
        J = np.zeros((24, 35))
        Jfoot = np.zeros((12, 35))
        contact_acc = np.zeros(12)
        for k, b in enumerate(self.feet):
            R = d.xmat[b].reshape(3, 3)
            jf = Jfoot[k * 6:k * 6 + 6]
            mujoco.mj_jacBody(m, d, jf[:3], jf[3:], b)
            jd = np.zeros((6, 35))
            mujoco.mj_jacDot(m, d, jd[:3], jd[3:], d.xpos[b], b)
            pe = self.foot_positions[k] - d.xpos[b]
            re = (self.foot_rotations[k] * Rotation.from_matrix(R).inv()).as_rotvec()
            contact_acc[k * 6:k * 6 + 6] = 400.0 * np.r_[pe, re] - 40.0 * (jf @ d.qvel) - jd @ d.qvel
            for c, offset in enumerate(self.corner_offsets):
                p = d.xpos[b] + R @ offset
                mujoco.mj_jac(m, d, J[k * 12 + c * 3:k * 12 + c * 3 + 3], None, p, b)

        # Variables: 35 generalized accelerations and eight 3D contact forces.
        # M a + h = S^T tau + J^T f. The first six rows have zero actuation;
        # joint torques are eliminated and bounded by the original MJCF limits.
        dynamics = np.c_[M, -J.T]
        eq = np.r_[dynamics[:6], np.c_[Jfoot, np.zeros((12, 24))]]
        rhs = np.r_[-h[:6], contact_acc]
        g = np.r_[-self.tracking_weights * desired, np.zeros(24)]
        A = sparse.csc_matrix(np.r_[eq, dynamics[6:], self.friction_constraints])
        lim = m.actuator_forcerange[:, 1]
        lo = np.r_[rhs, -lim - h[6:], np.full(40, -np.inf)]
        hi = np.r_[rhs, lim - h[6:], np.zeros(40)]
        problem = osqp.OSQP()
        problem.setup(
            P=self.qp_hessian, q=g, A=A, l=lo, u=hi, verbose=False,
            eps_abs=1.0e-4, eps_rel=1.0e-4, max_iter=3000, polishing=True,
        )
        if self.last_solution is not None:
            problem.warm_start(x=self.last_solution)
        result = problem.solve()
        if result.x is None or result.info.status_val not in (1, 2) or not np.all(np.isfinite(result.x)):
            self.qp_failures += 1
            tau = self.kp * (qr[7:] - d.qpos[7:]) + self.kd * (vr[6:] - d.qvel[6:])
        else:
            self.last_solution = result.x
            tau = dynamics[6:] @ result.x + h[6:]
        tau = np.clip(tau, -lim, lim)

        # Encode the desired torque in the existing position servos:
        # tau = kp (target - q) - kd v. Predict position to the midpoint of
        # the 4 ms control interval to reduce the lag from holding a target.
        # The simulator still enforces each actuator's original force range.
        target = self.reference(t)
        target[7:] = d.qpos[7:] + d.qvel[6:] * self.sim_dt + (tau + self.kd * d.qvel[6:]) / self.kp
        self.control.joint_target_q.assign(target)

    def reference(self, t):
        """Reference joint_q (with the floor shift applied) at time t [s]."""
        return self._shifted(self.motion.sample(t))

    def simulate(self):
        # An even number of steps preserves the input/output buffer identities
        # when this block is replayed as a CUDA graph.
        for _ in range(2):
            self.state_0.clear_forces()
            self.solver.step(self.state_0, self.state_1, self.control, None, self.sim_dt)
            self.state_0, self.state_1 = self.state_1, self.state_0

    def step(self):
        # Five feedback updates, ten unchanged physics steps, one 50 Hz frame.
        for substep in range(0, self.sim_substeps, 2):
            self._controller(self.sim_time + substep * self.sim_dt)
            if self.graph is not None:
                wp.capture_launch(self.graph)
            else:
                self.simulate()
        self.sim_time += self.frame_dt

    def render(self):
        self.viewer.begin_frame(self.sim_time)
        self.viewer.log_state(self.state_0)
        self.viewer.end_frame()

    @staticmethod
    def create_parser():
        parser = newton.examples.create_parser()
        parser.add_argument("--motion", type=str, required=False, default="wave.csv", help="Kimodo G1 qpos CSV")
        return parser


if __name__ == "__main__":
    viewer, args = newton.examples.init(Example.create_parser())
    newton.examples.run(Example(viewer, args), args)
